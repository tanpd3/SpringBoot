
var imgURR = new Array("nextprev/banner1.png","nextprev/banner2.png","nextprev/banner3.png","nextprev/banner4.png"
        ,"nextprev/banner5.png","nextprev/banner6.png");
var j = 0;

function Toi()
{
    j++;
    if (j == imgURR.length)
        j = 0;
    document.getElementById('sweetHome').src = imgURR[j];

}

function Lui()
{
    j--;
    if (j == -1)
        j = imgURR.length - 1;
    document.getElementById('sweetHome').src = imgURR[j];

}



function slideshow()
{
    j++;
    if (j == imgURR.length)
        j = 0;
    document.getElementById('sweetHome').src = imgURR[j];

    t = setTimeout(slideshow, 3500);
}


function stopshow()
{
    clearTimeout(t);
}

window.onload = slideshow;


function InUNameFocus()
{
    document.all.in_log_UName.value = '';
}

function InPassFocus()
{
    document.all.in_log_Pass.value = '';
}