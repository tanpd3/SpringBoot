/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actionformbean;

import com.mysweethome.dal.entity.DirectoryCategory;
import com.mysweethome.dao.DirectoryCategoryDao;
import java.io.File;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.ServletActionContext;

/**
 *
 * @author ThanhChung
 */
public class DirectoryCategoryActionFormBean {

    HttpServletRequest request = ServletActionContext.getRequest();
    DirectoryCategoryDao directCateDao = new DirectoryCategoryDao();

    List<DirectoryCategory> listDirectCate;

    DirectoryCategory directCate;
    String statusDirectCate;

    public DirectoryCategoryDao getDirectCateDao() {
        return directCateDao;
    }

    public void setDirectCateDao(DirectoryCategoryDao directCateDao) {
        this.directCateDao = directCateDao;
    }

    public String getStatusDirectCate() {
        return statusDirectCate;
    }

    public void setStatusDirectCate(String statusDirectCate) {
        this.statusDirectCate = statusDirectCate;
    }

    public List<DirectoryCategory> getListDirectCate() {
        return listDirectCate;
    }

    public void setListDirectCate(List<DirectoryCategory> listDirectCate) {
        this.listDirectCate = listDirectCate;
    }

    public DirectoryCategory getDirectCate() {
        return directCate;
    }

    public void setDirectCate(DirectoryCategory directCate) {
        this.directCate = directCate;
    }

    public String loadAllDirectoryCategory() {
        listDirectCate = directCateDao.loadAllDirectoryCategoryEnable();
        return "success";
    }

    public String loadAllDirectoryCategoryAdmin() {
        listDirectCate = directCateDao.loadAllDirectoryCategory();
        return "success";
    }

    public String viewDetailDirectoryCategory() {
        listDirectCate = directCateDao.loadAllDirectoryCategoryEnable();
        return "success";
    }

    public String findDetailDirectoryCategory() {
        directCate = directCateDao.findDirectoryCategory(directCate);
        return "success";
    }

    public String goToAddDirectoryCategory() {
        return "success";
    }

    public String addNewDirectoryCategory() {
        String realPath = request.getServletContext().getRealPath("images");
        File f = new File(realPath + "\\directory" + "\\" + directCate.getDirectoryCategoryname().replace(" ", "").toLowerCase().trim());

        directCate.setDirectoryCategoryname(directCate.getDirectoryCategoryname().replace(" ", "").toLowerCase().trim());
        if (statusDirectCate.equals("Block")) {
            directCate.setIsdeleted(false);
        } else {
            directCate.setIsdeleted(true);
        }

        if (directCate.getDirectoryCategoryname().length() <= 1) {
            request.setAttribute("folderErr", "Please input Name of service > 1 character");
            return "fail";
        } else {
            if (!f.exists()) {
                f.mkdir();
                boolean result = directCateDao.addNewDirectoryCategory(directCate);
                if (result) {
                    return "success";
                } else {
                    request.setAttribute("folderErr", "Add new Directory Category Name has failed");
                    return "fail";
                }
            } else {
                request.setAttribute("folderErr", "Directory Category Name has existed please choose another");
                return "fail";
            }
        }
    }

    public String editDirectoryCategory() {
        DirectoryCategory findDirectoryCategory = directCateDao.findDirectoryCategory(directCate);
        if (statusDirectCate.equals("Block")) {
            findDirectoryCategory.setIsdeleted(false);
        } else {
            findDirectoryCategory.setIsdeleted(true);
        }
        boolean result = directCateDao.addNewDirectoryCategory(findDirectoryCategory);
        if (result) {
            return "success";
        } else {
            return "fail";
        }
    }

}
