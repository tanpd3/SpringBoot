/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actionformbean;

import com.mysweethome.dal.entity.BankPolicy;
import com.mysweethome.dao.BankPolicyDao;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.struts2.ServletActionContext;

/**
 *
 * @author ThanhChung
 */
public class BankPolicyActionFormBean {

    HttpSession session = ServletActionContext.getRequest().getSession();
    HttpServletRequest request = ServletActionContext.getRequest();

    BankPolicyDao bankDao = new BankPolicyDao();

    List<BankPolicy> listBank;

    BankPolicy bankPolicy;

    public List<BankPolicy> getListBank() {
        return listBank;
    }

    public void setListBank(List<BankPolicy> listBank) {
        this.listBank = listBank;
    }

    public BankPolicy getBankPolicy() {
        return bankPolicy;
    }

    public void setBankPolicy(BankPolicy bankPolicy) {
        this.bankPolicy = bankPolicy;
    }

    public String goToBankPolicy() {
        return "success";
    }

    public String loadAllBankPolicy() {
        listBank = bankDao.loadAllBankPolicy();
        return "success";
    }

    public String viewDetailBankPolicy() {
        bankPolicy = bankDao.findBankPolicy(bankPolicy);
        return "success";
    }

    public String goToManagerUser() {
        return "success";
    }

    public String editBankPolicy() {
        boolean result = bankDao.updateBankPolicy(bankPolicy);
        if (result) {
            return "success";
        } else {
            return "fail";
        }
    }

    public String deleteBankPolicy() {
        boolean result = bankDao.deleteBankPolicy(bankPolicy);
        if (result) {
            return "success";
        } else {
            return "fail";
        }
    }

    public String goToAddBank() {
        return "success";
    }

    public String addNewBankPolicy() {
        String msg = "";
        if (bankPolicy.getBankName() == null || bankPolicy.getBankName().equals("")) {
            msg += "Please input Bank Name<br/>";
        } else if (bankPolicy.getBankName().length() <= 2) {
            msg += "Please input Bank Name more 2 character<br/>";
        }

        if (bankPolicy.getPolicyName()== null || bankPolicy.getPolicyName().equals("")) {
            msg += "Please input Policy Name<br/>";
        } else if (bankPolicy.getPolicyName().length() <= 2) {
            msg += "Please input Policy Name more 2 character<br/>";
        }

        if (!msg.equals("")) {
            request.setAttribute("bankErr", msg);
            return "fail";
        } else {
            boolean result = bankDao.addNewBankPolicy(bankPolicy);
            if (result) {
                return "success";
            } else {
                return "fail";
            }
        }
    }
}
