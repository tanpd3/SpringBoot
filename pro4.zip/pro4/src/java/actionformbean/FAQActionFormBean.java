/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actionformbean;

import com.mysweethome.dal.entity.Faq;
import com.mysweethome.dao.FAQDao;
import java.util.List;

/**
 *
 * @author DucPhuong
 */
public class FAQActionFormBean {

    FAQDao faqDao = new FAQDao();

    List<Faq> listFaq;

    Faq faq;

    public Faq getFaq() {
        return faq;
    }

    public void setFaq(Faq faq) {
        this.faq = faq;
    }

    public List<Faq> getListFaq() {
        return listFaq;
    }

    public void setListFaq(List<Faq> listFaq) {
        this.listFaq = listFaq;
    }

    public String goToFAQ() {
        return "success";
    }

    public String sendFAQ() {

        return "success";
    }

}
