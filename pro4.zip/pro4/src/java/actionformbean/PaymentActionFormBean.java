/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actionformbean;

import com.mysweethome.dal.entity.Payment;
import com.mysweethome.dao.PaymentDao;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.ServletActionContext;

/**
 *
 * @author DucPhuong
 */
public class PaymentActionFormBean {

    HttpServletRequest request = ServletActionContext.getRequest();
    PaymentDao payDao = new PaymentDao();

    List<Payment> listPayment;

    Payment pay;
    String statusPayment;

    public String getStatusPayment() {
        return statusPayment;
    }

    public void setStatusPayment(String statusPayment) {
        this.statusPayment = statusPayment;
    }

    public PaymentDao getPayDao() {
        return payDao;
    }

    public void setPayDao(PaymentDao payDao) {
        this.payDao = payDao;
    }

    public List<Payment> getListPayment() {
        return listPayment;
    }

    public void setListPayment(List<Payment> listPayment) {
        this.listPayment = listPayment;
    }

    public Payment getPay() {
        return pay;
    }

    public void setPay(Payment pay) {
        this.pay = pay;
    }

    public String loadAllPaymentMethod() {
        listPayment = payDao.loadAllPaymentMethod();
        return "success";
    }

    public String viewDetailPayment() {
        pay = payDao.findPaymentMethod(pay);
        return "success";
    }

    public String editPaymentMethod() {
        Payment findPaymentMethod = payDao.findPaymentMethod(pay);
        if (statusPayment.equals("Block")) {
            findPaymentMethod.setIsDeleted(false);
        } else {
            findPaymentMethod.setIsDeleted(true);
        }
        boolean result = payDao.updatePaymentMethod(findPaymentMethod);
        if (result) {
            return "success";
        } else {
            return "fail";
        }

    }

    public String deletePaymentMethod() {
        if (statusPayment.equals("Block")) {
            pay.setIsDeleted(false);
        } else {
            pay.setIsDeleted(true);
        }
        boolean result = payDao.deletePaymentMethod(pay);
        if (result) {
            return "success";
        } else {
            return "fail";
        }
    }

    public String goToAddPaymentMethod() {
        return "success";
    }

    public String addNewPaymentMethod() {
        String msg = "";
        if (pay.getPaymentMethod() == null || pay.getPaymentMethod().equals("")) {
            msg += "Please input Payment Method Name";
        } else if (pay.getPaymentMethod().length() <= 2) {
            msg += "Please input more 2 character";
        }

        if (!msg.equals("")) {
            request.setAttribute("paymentMethodErr", msg);
            return "fail";
        } else {
            boolean check = payDao.checkExistPaymentMethodName(pay);
            if (check) {
                request.setAttribute("paymentMethodErr", "Payment method name has existed please choose another");
                return "fail";
            } else {
                pay.setIsDeleted(true);
                boolean result = payDao.addNewPaymentMethod(pay);
                if (result) {
                    return "success";
                } else {
                    return "fail";
                }
            }
        }

    }
}
