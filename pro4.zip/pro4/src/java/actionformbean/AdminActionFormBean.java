/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actionformbean;

import com.mysweethome.common.util.EncryptUtil;
import com.mysweethome.dal.entity.Administrator;
import com.mysweethome.dao.AdminDao;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.struts2.ServletActionContext;

/**
 *
 * @author ThanhChung
 */
public class AdminActionFormBean {

    HttpSession session = ServletActionContext.getRequest().getSession();
    HttpServletRequest request = ServletActionContext.getRequest();

    AdminDao adDao = new AdminDao();

    Administrator admin;

    String oldPassword;
    String retypePassword;

    public HttpSession getSession() {
        return session;
    }

    public void setSession(HttpSession session) {
        this.session = session;
    }

    public HttpServletRequest getRequest() {
        return request;
    }

    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }

    public AdminDao getAdDao() {
        return adDao;
    }

    public void setAdDao(AdminDao adDao) {
        this.adDao = adDao;
    }

    public Administrator getAdmin() {
        return admin;
    }

    public void setAdmin(Administrator admin) {
        this.admin = admin;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    public String getRetypePassword() {
        return retypePassword;
    }

    public void setRetypePassword(String retypePassword) {
        this.retypePassword = retypePassword;
    }

    public String goHomePage() {
        return "success";
    }

    public String goLoginAdmin() {
        return "success";
    }

    public String loginAdminAccess() {
        try {
            admin.setAdminPassword(EncryptUtil.md5(admin.getAdminPassword()));
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(CustomerActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(CustomerActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        Administrator result = adDao.loginAdmin(admin);

        if (result != null) {
            session.setAttribute("adminAccount", result.getAdminAccount());
            return "success";
        } else {
            request.setAttribute("LoginErr", "Wrong UserName or passsword please try again");
            return "fail";
        }
    }

    public String logOut() {
        HttpSession session = ServletActionContext.getRequest().getSession();
        if (session != null) {
            session.removeAttribute("adminAccount");
        }
        return "success";
    }

    public String goToChangePasswordAdmin() {
        return "success";
    }

    public String changePasswordAdmin() {
        if (!retypePassword.equals(admin.getAdminPassword())) {
            request.setAttribute("ChangePassStatus", "new Password and retype password not match");
            return "fail";
        } else {
            try {
                admin.setAdminPassword(EncryptUtil.md5(admin.getAdminPassword()));
                setOldPassword(EncryptUtil.md5(oldPassword));
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(CustomerActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
            } catch (UnsupportedEncodingException ex) {
                Logger.getLogger(CustomerActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
            }

            boolean result = adDao.changePasswordAdmin(admin, getOldPassword());
            if (result) {
                request.setAttribute("ChangePassStatus", "Change password has successfull");
                return "success";
            } else {
                request.setAttribute("ChangePassStatus", "Change password has failed");
                return "fail";
            }
        }
    }

}
