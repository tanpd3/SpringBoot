/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actionformbean;

import com.mysweethome.common.util.EncryptUtil;
import com.mysweethome.dal.entity.Customer;
import com.mysweethome.dao.CustomerDao;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.struts2.ServletActionContext;

/**
 *
 * @author ThanhChung
 */
public class CustomerActionFormBean {

    HttpSession session = ServletActionContext.getRequest().getSession();
    HttpServletRequest request = ServletActionContext.getRequest();

    CustomerDao cusDao = new CustomerDao();

    List<Customer> listCustomer;

    Customer cust;

    String oldPassword;
    String retypePassword;
    String gender;
    String typeUser;
    String customerAccount;

    public String getCustomerAccount() {
        return customerAccount;
    }

    public void setCustomerAccount(String customerAccount) {
        this.customerAccount = customerAccount;
    }

    public String getTypeUser() {
        return typeUser;
    }

    public void setTypeUser(String typeUser) {
        this.typeUser = typeUser;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Customer getCust() {
        return cust;
    }

    public void setCust(Customer cust) {
        this.cust = cust;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    public String getRetypePassword() {
        return retypePassword;
    }

    public void setRetypePassword(String retypePassword) {
        this.retypePassword = retypePassword;
    }

    public List<Customer> getListCustomer() {
        return listCustomer;
    }

    public void setListCustomer(List<Customer> listCustomer) {
        this.listCustomer = listCustomer;
    }

    public String goHomePage() {
        return "success";
    }

    public String goLoginCustomer() {
        return "success";
    }

    public String goAboutUs() {
        return "success";
    }

    public String loginCustomer() {
        try {
            cust.setUserPassword(EncryptUtil.md5(cust.getUserPassword()));
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(CustomerActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(CustomerActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
        }

        Customer result = cusDao.loginCustomer(cust);
        if (result != null) {
            if (result.getIsDeleted() == false) {
                request.setAttribute("LoginErrr", "Your account have been block,please contact with administrator of web page");
                return "fail";
            } else {
                session.setAttribute("userAccount", result.getUserAccount());
                session.setAttribute("userNo", result.getUserNo());
                if (result.getTypeUser() == false) {
                    session.setAttribute("typeUser", result.getTypeUser());
                }
            }
            return "success";
        } else {
            request.setAttribute("LoginErrr", "Wrong UserName or passsword please try again");
            return "fail";
        }

    }

    public String logOut() {
        HttpSession session = ServletActionContext.getRequest().getSession();

        if (session != null) {
            session.removeAttribute("userAccount");
            session.removeAttribute("userNo");
            session.removeAttribute("typeUser");
        }
        return "success";
    }

    public String loadAllCustomer() {
        listCustomer = cusDao.loadAllCustomer();
        return "success";
    }

    public String changeToRegister() {
        return "success";
    }

    public String goChangeInformation() {
        cust = cusDao.findCustomer(cust);
        return "success";
    }

    public String goToChangePass() {
        return "success";
    }

    public String changePassword() {
        if (!retypePassword.equals(cust.getUserPassword())) {
            request.setAttribute("ChangePassStatus", "new Password and retype password not match");
            return "fail";
        } else {
            try {
                cust.setUserPassword(EncryptUtil.md5(cust.getUserPassword()));
                setOldPassword(EncryptUtil.md5(oldPassword));
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(CustomerActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
            } catch (UnsupportedEncodingException ex) {
                Logger.getLogger(CustomerActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
            }

            boolean result = cusDao.changePassword(cust, getOldPassword());
            if (result) {
                request.setAttribute("ChangePassStatus", "Change pass has successfull");
                return "success";
            } else {
                request.setAttribute("ChangePassStatus", "Change pass has failed");
                return "fail";
            }
        }
    }

    public String deleteCustomerAdmin() {
        Customer findCustomer = cusDao.findCustomer(cust);
        if (typeUser.equals("Block")) {
            findCustomer.setIsDeleted(false);
        } else {
            findCustomer.setIsDeleted(true);
        }

        boolean result = cusDao.deleteCustomer(findCustomer);

        if (result) {
            return "success";
        } else {
            return "fail";
        }
    }

    public String register() {
        String msg = "";
        if (cust.getUserAccount() == null || cust.getUserAccount().equals("")) {
            msg += "Please input User Account<br/>";
        } else if (cust.getUserAccount().length() < 3) {
            msg += "Please input User Account >=3 character<br/>";
        }

        if (cust.getUserPassword() == null || cust.getUserPassword().equals("")) {
            msg += "Please input User Password<br/>";
        } else if (cust.getUserPassword().length() < 3) {
            msg += "Please input User Password >=3 character<br/>";
        }

        if (cust.getEmail()== null || cust.getEmail().equals("")) {
            msg += "Please input Your Email<br/>";
        } 

        if (!msg.equals("")) {
            request.setAttribute("registerErr", msg);
            return "fail";
        } else {
            if (typeUser == null) {
                cust.setTypeUser(true);
            } else if (typeUser.equals("Buyer")) {
                cust.setTypeUser(true);
            } else if (typeUser.equals("Seller")) {
                cust.setTypeUser(false);
            }

            if (gender == null) {
                cust.setGender(true);
            } else if (gender.equals("Male")) {
                cust.setGender(true);
            } else if (gender.equals("Female")) {
                cust.setGender(false);
            }

            cust.setIsDeleted(true);

            try {
                cust.setUserPassword(EncryptUtil.md5(cust.getUserPassword()));
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(CustomerActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
            } catch (UnsupportedEncodingException ex) {
                Logger.getLogger(CustomerActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
            }

            boolean kq = cusDao.checkExistUserAccount(cust);
            if (kq) {
                request.setAttribute("registerErr", "Login account has existed please choose another: " + cust.getUserName());
                return "fail";
            } else {
                boolean result = cusDao.registerCustomer(cust);

                if (result) {
                    request.setAttribute("addStatus", "Register Customer has successfull: " + cust.getUserName());
                    return "success";
                } else {
                    request.setAttribute("registerErr", "Register member has failed: " + cust.getUserName());
                    return "fail";
                }
            }
        }
    }

    public String updateInformationCustomer() {
        Customer cus = cusDao.findCustomer(cust);

        if (gender == null) {
            cus.setGender(true);
        } else if (gender.equals("Male")) {
            cus.setGender(true);
        } else if (gender.equals("Female")) {
            cus.setGender(false);
        }

        cus.setAddress(cust.getAddress());
        cus.setEmail(cust.getEmail());
        cus.setPhone(cust.getPhone());
        cus.setIsDeleted(true);

        boolean result = cusDao.changeInformationCustomer(cus);

        if (result) {
            request.setAttribute("addStatus", "Change Information of Customer has successfull: " + cust.getUserName());
            return "success";
        } else {
            request.setAttribute("addErr", "Change Information of member has failed: " + cust.getUserName());
            return "fail";
        }
    }

    public String searchUserByUserAccount() {
        Customer customer = new Customer();
        customer.setUserAccount(customerAccount);

        listCustomer = cusDao.findUserByName(customer);
        return "success";
    }
}
