/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actionformbean;

import com.mysweethome.dal.entity.DirectoryCategory;
import com.mysweethome.dal.entity.DirectoryCompany;
import com.mysweethome.dao.DirectoryCategoryDao;
import com.mysweethome.dao.DirectoryCompanyDao;
import com.opensymphony.xwork2.ActionSupport;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

/**
 *
 * @author ThanhChung
 */
public class DirectoryCompanyActionFormBean extends ActionSupport {

    HttpServletRequest request = ServletActionContext.getRequest();
    HttpSession session = ServletActionContext.getRequest().getSession();

    DirectoryCompanyDao directCompnanyDao = new DirectoryCompanyDao();
    DirectoryCategoryDao directCateDao = new DirectoryCategoryDao();

    List<DirectoryCompany> listDirectComp;
    List<DirectoryCategory> listDirectCate;

    DirectoryCompany directCompany;
    DirectoryCategory directCategory;

    File urlAnh;
    String statusCompany;

    int page = 1;
    int totalPage;
    int totalRow;
    public static final int PAGE_SIZE = 4;
    int maxPage;

    public HttpServletRequest getRequest() {
        return request;
    }

    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpSession getSession() {
        return session;
    }

    public void setSession(HttpSession session) {
        this.session = session;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalRow() {
        return totalRow;
    }

    public void setTotalRow(int totalRow) {
        this.totalRow = totalRow;
    }

    public int getMaxPage() {
        return maxPage;
    }

    public void setMaxPage(int maxPage) {
        this.maxPage = maxPage;
    }

    public String getStatusCompany() {
        return statusCompany;
    }

    public void setStatusCompany(String statusCompany) {
        this.statusCompany = statusCompany;
    }

    public DirectoryCategoryDao getDirectCateDao() {
        return directCateDao;
    }

    public void setDirectCateDao(DirectoryCategoryDao directCateDao) {
        this.directCateDao = directCateDao;
    }

    public File getUrlAnh() {
        return urlAnh;
    }

    public void setUrlAnh(File urlAnh) {
        this.urlAnh = urlAnh;
    }

    public DirectoryCompanyDao getDirectCompnanyDao() {
        return directCompnanyDao;
    }

    public void setDirectCompnanyDao(DirectoryCompanyDao directCompnanyDao) {
        this.directCompnanyDao = directCompnanyDao;
    }

    public List<DirectoryCategory> getListDirectCate() {
        return listDirectCate;
    }

    public void setListDirectCate(List<DirectoryCategory> listDirectCate) {
        this.listDirectCate = listDirectCate;
    }

    public List<DirectoryCompany> getListDirectComp() {
        return listDirectComp;
    }

    public void setListDirectComp(List<DirectoryCompany> listDirectComp) {
        this.listDirectComp = listDirectComp;
    }

    public DirectoryCategory getDirectCategory() {
        return directCategory;
    }

    public void setDirectCategory(DirectoryCategory directCategory) {
        this.directCategory = directCategory;
    }

    public DirectoryCompany getDirectCompany() {
        return directCompany;
    }

    public void setDirectCompany(DirectoryCompany directCompany) {
        this.directCompany = directCompany;
    }

    public String loadAllDirectoryCompnayByDirectCateID() {
        listDirectComp = directCompnanyDao.loadAllDirectoryCompanyByDirectoryCategoryId(directCompany);
        if (listDirectComp.size() > 0) {
            return "success";
        } else {
            request.setAttribute("listDirectComErr", "No Data");
            return "fail";
        }
    }

    public String viewDetailDirectoryCompany() {
        directCompany = directCompnanyDao.findDirectoryCompany(directCompany);
        listDirectCate = directCateDao.loadAllDirectoryCategory();
        session.setAttribute("companyId", directCompany.getDirectoryComparyId());

        return "success";
    }

    public String loadAllDirecroyCompany() {
        this.totalRow = directCompnanyDao.countCompanyAdmin();
        this.totalPage = (int) Math.ceil((double) totalRow / 4);

        int firstResult = (page - 1) * PAGE_SIZE;
        listDirectComp = directCompnanyDao.loadAllDirectoryCompany(PAGE_SIZE, firstResult);
        maxPage = (int) Math.ceil((double) totalRow / 4);
        request = ServletActionContext.getRequest();
        request.setAttribute("LastPage", maxPage);

        return "success";
    }

    public String goAddDirectoryCompany() {
        listDirectCate = directCateDao.loadAllDirectoryCategory();
        return "success";
    }

    public String addNewDirectoryCompany() {
        String msg = "";
        if (urlAnh == null) {
            msg += "Please choose image <br/>";
        }

        if (directCompany.getDirectoryName() == null || directCompany.getDirectoryName().equals("")) {
            msg += "Please input Directory Company Name<br/>";
        } else if (directCompany.getDirectoryName().length() <= 2) {
            msg += "Please input more 2 character<br/>";
        }

        if (!msg.equals("")) {
            listDirectCate = directCateDao.loadAllDirectoryCategory();
            request.setAttribute("addDirectoryCompanyErr", msg);
            return "fail";
        } else {
            DirectoryCategory dcate = new DirectoryCategory();
            dcate.setDirectoryCategoryId(directCategory.getDirectoryCategoryId());

            List<DirectoryCategory> listcate = directCateDao.loadAllDirectoryCategory();
            String nameCateFolder = "";
            for (DirectoryCategory listDirCate : listcate) {
                if (listDirCate.getDirectoryCategoryId() == directCategory.getDirectoryCategoryId()) {
                    nameCateFolder = listDirCate.getDirectoryCategoryname().replace(" ", "").toLowerCase().trim();
                }
            }
            directCompany.setImage("images" + "/" + "directory" + "/" + nameCateFolder
                    + "/" + urlAnh.getName().replace("tmp", "jpg"));

            File fileToCreate = new File(request.getServletContext().getRealPath(
                    "images") + File.separator + "directory" + File.separator + nameCateFolder
                    + File.separator + urlAnh.getName().replace("tmp", "jpg"));
            try {
                FileUtils.copyFile(urlAnh, fileToCreate);
            } catch (IOException ex) {
                Logger.getLogger(DirectoryCategoryActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
            }

            directCompany.setDirectoryCategory(dcate);
            if (statusCompany.equals("Enable")) {
                directCompany.setIsDeleted(false);
            } else {
                directCompany.setIsDeleted(true);
            }

            boolean result = directCompnanyDao.addNewDirectoryCompany(directCompany);
            if (result) {
                return "success";
            } else {
                listDirectCate = directCateDao.loadAllDirectoryCategory();
                request.setAttribute("addDirectoryCompanyErr", "Add New directory company has failed");
                return "fail";
            }
        }
    }

    public String editDirectoryCompany() {
        DirectoryCategory dcate = new DirectoryCategory();
        dcate.setDirectoryCategoryId(directCategory.getDirectoryCategoryId());

        if (urlAnh == null) {
            directCompany.setImage(directCompany.getImage());
        } else {
            List<DirectoryCategory> listcate = directCateDao.loadAllDirectoryCategory();
            String nameCateFolder = null;
            for (DirectoryCategory listDirCate : listcate) {
                if (listDirCate.getDirectoryCategoryId() == directCategory.getDirectoryCategoryId()) {
                    nameCateFolder = listDirCate.getDirectoryCategoryname().replace(" ", "").toLowerCase().trim();
                }
            }
            directCompany.setImage("images" + "/" + "directory" + "/" + nameCateFolder
                    + "/" + urlAnh.getName().replace("tmp", "jpg"));

            File fileToCreate = new File(request.getServletContext().getRealPath(
                    "images") + File.separator + "directory" + File.separator + nameCateFolder
                    + File.separator + urlAnh.getName().replace("tmp", "jpg"));
            try {
                FileUtils.copyFile(urlAnh, fileToCreate);
            } catch (IOException ex) {
                Logger.getLogger(DirectoryCategoryActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        directCompany.setDirectoryCategory(dcate);

        if (statusCompany.equals("Block")) {
            directCompany.setIsDeleted(false);
        } else {
            directCompany.setIsDeleted(true);
        }

        boolean result = directCompnanyDao.updateDirectoryCompany(directCompany);
        if (result) {
            return "success";
        } else {
            listDirectCate = directCateDao.loadAllDirectoryCategory();
            request.setAttribute("editDirectoryCompanyErr", "Update directory company has failed");
            return "fail";
        }
    }
}
