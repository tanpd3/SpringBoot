/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actionformbean;

import com.mysweethome.dal.entity.TypeOfService;
import com.mysweethome.dao.TypeOfServiceDao;
import java.io.File;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.ServletActionContext;

/**
 *
 * @author DucPhuong
 */
public class TypeOfServiceActionFormBean {

    HttpServletRequest request = ServletActionContext.getRequest();
    TypeOfServiceDao typeServiceDao = new TypeOfServiceDao();

    List<TypeOfService> listTypeService;

    TypeOfService typeOfService;
    String statusTypeOfService;

    public String getStatusTypeOfService() {
        return statusTypeOfService;
    }

    public void setStatusTypeOfService(String statusTypeOfService) {
        this.statusTypeOfService = statusTypeOfService;
    }

    public TypeOfServiceDao getTypeServiceDao() {
        return typeServiceDao;
    }

    public void setTypeServiceDao(TypeOfServiceDao typeServiceDao) {
        this.typeServiceDao = typeServiceDao;
    }

    public List<TypeOfService> getListTypeService() {
        return listTypeService;
    }

    public void setListTypeService(List<TypeOfService> listTypeService) {
        this.listTypeService = listTypeService;
    }

    public TypeOfService getTypeOfService() {
        return typeOfService;
    }

    public void setTypeOfService(TypeOfService typeOfService) {
        this.typeOfService = typeOfService;
    }

    public String loadAllTypeOfService() {
        listTypeService = typeServiceDao.loadAllTypeOfServiceEnable();
        return "success";
    }

    public String loadAllTypeOfServiceAdmin() {
        listTypeService = typeServiceDao.loadAllTypeOfService();
        return "success";
    }

    public String viewDetailTypeService() {
        typeOfService = typeServiceDao.findTypeOfService(typeOfService);
        return "success";
    }

    public String updateTypeService() {
        TypeOfService findTypeOfService = typeServiceDao.findTypeOfService(typeOfService);
        if (statusTypeOfService.equals("Block")) {
            findTypeOfService.setIsDeleted(false);
        } else {
            findTypeOfService.setIsDeleted(true);
        }
        boolean result = typeServiceDao.updateTypeOfService(findTypeOfService);
        if (result) {
            return "success";
        } else {
            return "fail";
        }
    }

    public String goToAddTypeService() {
        return "success";
    }

    public String addNewTypeService() {
        String realPath = request.getServletContext().getRealPath("images");
        File f = new File(realPath + "\\" + typeOfService.getNameOfService().replace(" ", "").toLowerCase().trim());

        typeOfService.setNameOfService(typeOfService.getNameOfService().replace(" ", "").toLowerCase().trim());
        if (statusTypeOfService.equals("Enable")) {
            typeOfService.setIsDeleted(false);
        } else {
            typeOfService.setIsDeleted(true);
        }

        if (typeOfService.getNameOfService().length() <= 1) {
            request.setAttribute("folderErr", "Please input Name of service > 1 character");
            return "fail";
        } else {
            if (!f.exists()) {
                f.mkdir();
                boolean result = typeServiceDao.addNewTypeOfService(typeOfService);
                if (result) {
                    return "success";
                } else {
                    request.setAttribute("folderErr", "Add new Service type has failed");
                    return "fail";
                }
            } else {
                request.setAttribute("folderErr", "Name of service has existed please choose another");
                return "fail";
            }
        }
    }
    
}
