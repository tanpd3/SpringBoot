/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actionformbean;

import com.mysweethome.dal.entity.Customer;
import com.mysweethome.dal.entity.DirectoryCategory;
import com.mysweethome.dal.entity.Faq;
import com.mysweethome.dal.entity.Payment;
import com.mysweethome.dal.entity.Property;
import com.mysweethome.dal.entity.TypeOfProperty;
import com.mysweethome.dal.entity.TypeOfService;
import com.mysweethome.dao.CustomerDao;
import com.mysweethome.dao.DirectoryCategoryDao;
import com.mysweethome.dao.FAQDao;
import com.mysweethome.dao.PaymentDao;
import com.mysweethome.dao.PropertyDao;
import com.mysweethome.dao.TypeOfPropertyDao;
import com.mysweethome.dao.TypeOfServiceDao;
import com.opensymphony.xwork2.ActionSupport;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

/**
 *
 * @author DucPhuong
 */
public class PropertyActionFormBean extends ActionSupport {

    HttpSession session = ServletActionContext.getRequest().getSession();
    HttpServletRequest request = ServletActionContext.getRequest();

    PropertyDao proDao = new PropertyDao();
    CustomerDao cusDao = new CustomerDao();
    DirectoryCategoryDao directCatedao = new DirectoryCategoryDao();
    TypeOfPropertyDao typeProDao = new TypeOfPropertyDao();
    PaymentDao payDao = new PaymentDao();
    TypeOfServiceDao typeSerivceDao = new TypeOfServiceDao();
    FAQDao faqDao = new FAQDao();

    List<Property> listProperty;
    List<Property> listProAdmin;
    List<DirectoryCategory> listDirectCate;
    List<TypeOfProperty> listTypePro;
    List<Payment> listPay;
    List<TypeOfService> listService;
    List<Faq> listFaq;

    Property pro;
    TypeOfProperty typeOfPro;
    TypeOfService typeService;
    Payment pay;
    Customer cust;
    Faq faqQuestion;

    int page = 1;
    int totalPage;
    int totalRow;
    public static final int PAGE_SIZE = 5;
    int maxPage;

    String statusProperty;
    String poster;

    String extraFacilities;
    String modesTransport;
    String fur;
    int typeServiceId;
    String negotiable;

    File urlAnh;

    double minPrice;
    double maxPrice;

    public FAQDao getFaqDao() {
        return faqDao;
    }

    public void setFaqDao(FAQDao faqDao) {
        this.faqDao = faqDao;
    }

    public List<Faq> getListFaq() {
        return listFaq;
    }

    public void setListFaq(List<Faq> listFaq) {
        this.listFaq = listFaq;
    }

    public Faq getFaqQuestion() {
        return faqQuestion;
    }

    public void setFaqQuestion(Faq faqQuestion) {
        this.faqQuestion = faqQuestion;
    }

    public Customer getCust() {
        return cust;
    }

    public void setCust(Customer cust) {
        this.cust = cust;
    }

    public double getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(double minPrice) {
        this.minPrice = minPrice;
    }

    public double getMaxPrice() {
        return maxPrice;
    }

    public void setMaxPrice(double maxPrice) {
        this.maxPrice = maxPrice;
    }

    public String getNegotiable() {
        return negotiable;
    }

    public void setNegotiable(String negotiable) {
        this.negotiable = negotiable;
    }

    public List<TypeOfService> getListService() {
        return listService;
    }

    public void setListService(List<TypeOfService> listService) {
        this.listService = listService;
    }

    public File getUrlAnh() {
        return urlAnh;
    }

    public void setUrlAnh(File urlAnh) {
        this.urlAnh = urlAnh;
    }

    public TypeOfServiceDao getTypeSerivceDao() {
        return typeSerivceDao;
    }

    public void setTypeSerivceDao(TypeOfServiceDao typeSerivceDao) {
        this.typeSerivceDao = typeSerivceDao;
    }

    public String getExtraFacilities() {
        return extraFacilities;
    }

    public void setExtraFacilities(String extraFacilities) {
        this.extraFacilities = extraFacilities;
    }

    public String getModesTransport() {
        return modesTransport;
    }

    public void setModesTransport(String modesTransport) {
        this.modesTransport = modesTransport;
    }

    public String getFur() {
        return fur;
    }

    public void setFur(String fur) {
        this.fur = fur;
    }

    public int getTypeServiceId() {
        return typeServiceId;
    }

    public void setTypeServiceId(int typeServiceId) {
        this.typeServiceId = typeServiceId;
    }

    public TypeOfService getTypeService() {
        return typeService;
    }

    public void setTypeService(TypeOfService typeService) {
        this.typeService = typeService;
    }

    public Payment getPay() {
        return pay;
    }

    public void setPay(Payment pay) {
        this.pay = pay;
    }

    public PaymentDao getPayDao() {
        return payDao;
    }

    public void setPayDao(PaymentDao payDao) {
        this.payDao = payDao;
    }

    public List<Payment> getListPay() {
        return listPay;
    }

    public void setListPay(List<Payment> listPay) {
        this.listPay = listPay;
    }

    public TypeOfPropertyDao getTypeProDao() {
        return typeProDao;
    }

    public void setTypeProDao(TypeOfPropertyDao typeProDao) {
        this.typeProDao = typeProDao;
    }

    public List<TypeOfProperty> getListTypePro() {
        return listTypePro;
    }

    public void setListTypePro(List<TypeOfProperty> listTypePro) {
        this.listTypePro = listTypePro;
    }

    public TypeOfProperty getTypeOfPro() {
        return typeOfPro;
    }

    public void setTypeOfPro(TypeOfProperty typeOfPro) {
        this.typeOfPro = typeOfPro;
    }

    public HttpSession getSession() {
        return session;
    }

    public void setSession(HttpSession session) {
        this.session = session;
    }

    public HttpServletRequest getRequest() {
        return request;
    }

    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }

    public CustomerDao getCusDao() {
        return cusDao;
    }

    public void setCusDao(CustomerDao cusDao) {
        this.cusDao = cusDao;
    }

    public DirectoryCategoryDao getDirectCatedao() {
        return directCatedao;
    }

    public void setDirectCatedao(DirectoryCategoryDao directCatedao) {
        this.directCatedao = directCatedao;
    }

    public List<DirectoryCategory> getListDirectCate() {
        return listDirectCate;
    }

    public void setListDirectCate(List<DirectoryCategory> listDirectCate) {
        this.listDirectCate = listDirectCate;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public String getStatusProperty() {
        return statusProperty;
    }

    public void setStatusProperty(String statusProperty) {
        this.statusProperty = statusProperty;
    }

    public List<Property> getListProAdmin() {
        return listProAdmin;
    }

    public void setListProAdmin(List<Property> listProAdmin) {
        this.listProAdmin = listProAdmin;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalRow() {
        return totalRow;
    }

    public void setTotalRow(int totalRow) {
        this.totalRow = totalRow;
    }

    public int getMaxPage() {
        return maxPage;
    }

    public void setMaxPage(int maxPage) {
        this.maxPage = maxPage;
    }

    public PropertyDao getProDao() {
        return proDao;
    }

    public void setProDao(PropertyDao proDao) {
        this.proDao = proDao;
    }

    public List<Property> getListProperty() {
        return listProperty;
    }

    public void setListProperty(List<Property> listProperty) {
        this.listProperty = listProperty;
    }

    public Property getPro() {
        return pro;
    }

    public void setPro(Property pro) {
        this.pro = pro;
    }

    public String loadAllPropertyForAdmin() {
        this.totalRow = proDao.countAdvertisementAdmin();
        this.totalPage = (int) Math.ceil((double) totalRow / 5);

        int firstResult = (page - 1) * PAGE_SIZE;
        listProAdmin = proDao.loadAllProperty(PAGE_SIZE, firstResult);

        maxPage = (int) Math.ceil((double) totalRow / 5);
        request = ServletActionContext.getRequest();
        request.setAttribute("LastPage", maxPage);

        return "success";
    }

    public String loadAllProperty() {
        //pagging with Hibernate for user
        this.totalRow = proDao.countAdvertisement();
        this.totalPage = (int) Math.ceil((double) totalRow / 5);

        int firstResult = (page - 1) * PAGE_SIZE;
        listProperty = proDao.loadAllPropertyEnable(PAGE_SIZE, firstResult);

        maxPage = (int) Math.ceil((double) totalRow / 5);
        request = ServletActionContext.getRequest();
        request.setAttribute("LastPage", maxPage);

        return "success";
    }

    public String viewDetailProperty() {
        Faq faqQ = new Faq();
        faqQ.setPropertyId(pro.getPropertyId());
        Property pppp = new Property();
        pppp.setPropertyId(pro.getPropertyId());
        pro = proDao.findProperty(pppp);

        listFaq = faqDao.selectFAQ(faqQ);
        return "success";
    }

    public String postFaq() {
        String msg = "";
        if (faqQuestion.getQuestionContent() == null || faqQuestion.getQuestionContent().equals("")) {
            msg += "Please input Content Question<br/>";
        } else if (faqQuestion.getQuestionContent().length() > 250) {
            msg += "Please input <250 character";
        }

        if (!msg.equals("")) {
            Faq faqQ = new Faq();
            faqQ.setPropertyId(pro.getPropertyId());
            Property pppp = new Property();
            pppp.setPropertyId(pro.getPropertyId());
            pro = proDao.findProperty(pppp);
            listFaq = faqDao.selectFAQ(faqQ);
            request.setAttribute("sendFaqErr", msg);
            return "fail";
        } else {
            if (session.getAttribute("userAccount") != null) {
                String sender = (String) session.getAttribute("userAccount");
                faqQuestion.setSender(sender);
            } else {
                faqQuestion.setSender("Guest");
            }
            faqQuestion.setSubmitDate(new Date());
            faqQuestion.setPropertyId(pro.getPropertyId());

            boolean result = faqDao.addNewFAQ(faqQuestion);
            if (result) {
                Faq faqQ = new Faq();
                faqQ.setPropertyId(pro.getPropertyId());
                Property pppp = new Property();
                pppp.setPropertyId(pro.getPropertyId());
                pro = proDao.findProperty(pppp);
                listFaq = faqDao.selectFAQ(faqQ);

                return "success";
            } else {
                return "fail";
            }
        }
    }

    public String listPropertyByTypeOfProperty() {
        this.totalRow = proDao.countAdvertisement();
        this.totalPage = (int) Math.ceil((double) totalRow / 5);

        int firstResult = (page - 1) * PAGE_SIZE;
        listProperty = proDao.loadAllPropertyByTypeOfPropertyId(pro, PAGE_SIZE, firstResult);
        maxPage = (int) Math.ceil((double) totalRow / 5);
        request = ServletActionContext.getRequest();
        request.setAttribute("LastPage", maxPage);

        if (listProperty.isEmpty()) {
            request.setAttribute("searchErr", "No Data");
            return "fail";
        } else {
            return "success";
        }
    }

    public String listPropertyByTypeOfService() {
        this.totalRow = proDao.countAdvertisement();
        this.totalPage = (int) Math.ceil((double) totalRow / 5);

        int firstResult = (page - 1) * PAGE_SIZE;
        listProperty = proDao.loadAllPropertyByTypeOfServiceId(pro, PAGE_SIZE, firstResult);
        maxPage = (int) Math.ceil((double) totalRow / 5);
        request = ServletActionContext.getRequest();
        request.setAttribute("LastPage", maxPage);

        return "success";
    }

    public String editStatusProperty() {
        Property findProperty = proDao.findProperty(pro);
        if (statusProperty.equals("Block")) {
            findProperty.setIsDeleted(false);
        } else {
            findProperty.setIsDeleted(true);
        }
        boolean result = proDao.deleteProperty(findProperty);
        if (result) {
            return "success";
        } else {
            request.setAttribute("EditProErr", "Edit status Property has failed");
            return "fail";
        }
    }

    public String searchPropertyByPoster() {
        Customer custo = new Customer();
        List<Customer> loadAllCustomer = cusDao.loadAllCustomer();
        for (Customer cus : loadAllCustomer) {
            if (cus.getUserAccount().toLowerCase().equals(poster.toLowerCase())) {
                custo.setUserNo(cus.getUserNo());
            }
        }
        Property p = new Property();
        p.setCustomer(custo);
        listProAdmin = proDao.searchPropertyByPoster(p);
        if (listProAdmin.size() > 0) {
            return "success";
        } else {
            request.setAttribute("searhErr", "Cant find information");
            return "fail";
        }
    }

    public String viewUserProperty() {
        Customer custo = new Customer();
        Property p = new Property();
        custo.setUserNo(cust.getUserNo());
        p.setCustomer(custo);

        this.totalRow = proDao.countSLSPForUser(custo);
        this.totalPage = (int) Math.ceil((double) totalRow / 5);

        int firstResult = (page - 1) * PAGE_SIZE;
        listProperty = proDao.searchPropertyByPosterPagging(p, PAGE_SIZE, firstResult);
        maxPage = (int) Math.ceil((double) totalRow / 5);
        request = ServletActionContext.getRequest();
        request.setAttribute("LastPage", maxPage);

        if (listProperty.size() > 0) {
            return "success";
        } else {
            request.setAttribute("searhErr", "No data for you");
            return "fail";
        }
    }

    public String goEditPropertyForUser() {
        Faq faqQ = new Faq();
        faqQ.setPropertyId(pro.getPropertyId());
        Property pppp = new Property();
        pppp.setPropertyId(pro.getPropertyId());
        pro = proDao.findProperty(pppp);
        listFaq = faqDao.selectFAQ(faqQ);
        

        return "success";
    }

    public String editPropertyUser() {
        Property findProperty = proDao.findProperty(pro);
        if (statusProperty.equals("Delete")) {
            findProperty.setIsDeleted(false);
        } else {
            findProperty.setIsDeleted(true);
        }
        boolean reuslt = proDao.updateProperty(findProperty);
        
        if (reuslt) {
            Customer custo = new Customer();
            Property p = new Property();
            custo.setUserNo(pro.getCustomer().getUserNo());
            p.setCustomer(custo);

            this.totalRow = proDao.countSLSPForUser(custo);
            this.totalPage = (int) Math.ceil((double) totalRow / 5);

            int firstResult = (page - 1) * PAGE_SIZE;
            listProperty = proDao.searchPropertyByPosterPagging(p, PAGE_SIZE, firstResult);
            maxPage = (int) Math.ceil((double) totalRow / 5);
            request = ServletActionContext.getRequest();
            request.setAttribute("LastPage", maxPage);

            return "success";
        } else {
            request.setAttribute("editPropertyUserErr", "Delete Property has failed");
            return "fail";
        }
    }

    public String goToChooseTypeService() {
        return "success";
    }

    public String goToCreateAdvertisement() {
        Object obj = session.getAttribute("typeUser");
        if (obj == null) {
            listTypePro = typeProDao.loadAllTypeOfProperyEnable();
            listPay = payDao.loadAllPaymentMethodEnable();
            request.setAttribute("LoginErr", "Please login with type Seller");
            return "fail";
        } else {
            listTypePro = typeProDao.loadAllTypeOfProperyEnable();
            listPay = payDao.loadAllPaymentMethodEnable();
            return "success";
        }
    }

    public String goToCreateRentHouse() {
        Object obj = session.getAttribute("typeUser");
        if (obj == null) {
            listTypePro = typeProDao.loadAllTypeOfProperyEnable();
            listPay = payDao.loadAllPaymentMethodEnable();
            request.setAttribute("LoginErr", "Please login with type Seller");
            return "fail";
        } else {
            listTypePro = typeProDao.loadAllTypeOfProperyEnable();
            listPay = payDao.loadAllPaymentMethodEnable();
            return "success";
        }
    }

    public String goAccommodationAsAPayingGuest() {
        Object obj = session.getAttribute("typeUser");
        if (obj == null) {
            request.setAttribute("LoginErr", "Please login with type Seller");
            return "fail";
        } else {
            return "success";
        }
    }

    public String addNewHouseForSales() {
        String msg = "";
        if (urlAnh == null) {
            msg += "Please choose image <br/>";
        }
        if (pro.getContactName() == null || pro.getContactName().equals("")) {
            msg += "Please input Contact Name<br/>";
        }
        if (pro.getContactPhone() == null || pro.getContactPhone().equals("")) {
            msg += "Please input Contact Phone<br/>";
        }
        if (pro.getContactAddress() == null || pro.getContactAddress().equals("")) {
            msg += "Please input Contact Phone<br/>";
        }

        if (pro.getNumberOfBathroom() == null) {
            msg += "Please input Number Of Bathroom <br/>";
        } else {
            if (pro.getNumberOfBathroom() < 0) {
                msg += "Please input Number Of Bathroom > 0 <br/>";
            }
        }

        if (pro.getNumberOfBedroom() == null) {
            msg += "Please input Number Of Bedroom <br/>";
        } else {
            if (pro.getNumberOfBedroom() < 0) {
                msg += "Please input Number Of Bedroom > 0 <br/>";
            }
        }

        if (extraFacilities == null || extraFacilities.equals("")) {
            msg += "Please choose Facility <br/>";
        }

        if (fur == null || fur.equals("")) {
            msg += "Please choose Furniture status <br/>";
        }

        if (pro.getCity() == null || pro.getCity().equals("")) {
            msg += "Please input City Name<br/>";
        }

        if (pro.getStreet() == null || pro.getStreet().equals("")) {
            msg += "Please input Street <br/>";
        }

        if (pro.getPrice() < 0) {
            msg += "Please input  Sell price >0<br/>";
        }

        if (negotiable == null || negotiable.equals("")) {
            msg += "Please choose negotiable <br/>";
        }

        if (!msg.equals("")) {
            listTypePro = typeProDao.loadAllTypeOfProperyEnable();
            listPay = payDao.loadAllPaymentMethodEnable();
            request.setAttribute("addProErr", msg);
            return "fail";
        } else {
            TypeOfService tOService = new TypeOfService();
            tOService.setTypeOfServiceId(typeServiceId);
            pro.setTypeOfService(tOService);

            String nameServiceFolder = "";
            List<TypeOfService> loadAllTypeOfService = typeSerivceDao.loadAllTypeOfService();
            for (TypeOfService loadAllTypeOfService1 : loadAllTypeOfService) {
                if (loadAllTypeOfService1.getTypeOfServiceId() == typeServiceId) {
                    nameServiceFolder = loadAllTypeOfService1.getNameOfService()
                            .replace(" ", "").toLowerCase().trim();
                }
            }
            //image save into database
            pro.setImage("images" + "/" + nameServiceFolder + "/" + urlAnh.getName().replace("tmp", "jpg"));

            //save image into folder
            File fileToCreate = new File(request.getServletContext().getRealPath("images")
                    + File.separator + nameServiceFolder
                    + File.separator + urlAnh.getName().replace("tmp", "jpg"));
            try {
                FileUtils.copyFile(urlAnh, fileToCreate);
            } catch (IOException ex) {
                Logger.getLogger(DirectoryCategoryActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
            }

            String userAcc = "";
            if (session != null) {
                userAcc = (String) session.getAttribute("userAccount");
            }
            Customer custom = new Customer();
            List<Customer> loadAllCustomer = cusDao.loadAllCustomer();
            for (Customer allCust : loadAllCustomer) {
                if (allCust.getUserAccount().equals(userAcc)) {
                    custom.setUserNo(allCust.getUserNo());
                }
            }
            pro.setCustomer(custom);

            TypeOfProperty typePro = new TypeOfProperty();
            typePro.setTypeOfPropertyId(typeOfPro.getTypeOfPropertyId());
            pro.setTypeOfProperty(typePro);

            if (extraFacilities.equals("Yes")) {
                pro.setExtraFacilitiesAvailable(true);
            } else {
                pro.setExtraFacilitiesAvailable(false);
            }

            if (negotiable.equals("Yes")) {
                pro.setNegotiable(true);
            } else {
                pro.setNegotiable(false);
            }

            if (modesTransport.equals("Bus")) {
                pro.setModesOfTransport("Bus");
            } else if (modesTransport.equals("Taxi")) {
                pro.setModesOfTransport("Taxi");
            } else if (modesTransport.equals("Trunk")) {
                pro.setModesOfTransport("Trunk");
            } else if (modesTransport.equals("Train")) {
                pro.setModesOfTransport("Train");
            }

            if (fur.equals("Yes")) {
                pro.setFurniture(true);
            } else {
                pro.setFurniture(false);
            }

            Payment pa = new Payment();
            pa.setPaymentId(pay.getPaymentId());
            pro.setPayment(pa);

            pro.setIsDeleted(true);

            pro.setSubmitDate(new Date());
            //Expired Date month+1
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MONTH, +1);
            Date d = cal.getTime();
            pro.setExpiredDate(d);

            pro.setStatusAdvertise(true);
            pro.setDepositPrice(0);

            boolean result = proDao.insertHouseForSale(pro);

            if (result) {
                return "success";
            } else {
                listTypePro = typeProDao.loadAllTypeOfProperyEnable();
                listPay = payDao.loadAllPaymentMethodEnable();
                request.setAttribute("addProErr", "Add New advertisement has failed please try again");
                return "fail";
            }
        }
    }

    public String insertHouseForRent() {
        String msg = "";
        if (urlAnh == null) {
            msg += "Please choose image <br/>";
        }
        if (pro.getContactName() == null || pro.getContactName().equals("")) {
            msg += "Please input Contact Name<br/>";
        }
        if (pro.getContactPhone() == null || pro.getContactPhone().equals("")) {
            msg += "Please input Contact Phone<br/>";
        }
        if (pro.getContactAddress() == null || pro.getContactAddress().equals("")) {
            msg += "Please input Contact Phone<br/>";
        }

        if (pro.getNumberOfBathroom() == null) {
            msg += "Please input Number Of Bathroom <br/>";
        } else {
            if (pro.getNumberOfBathroom() < 0) {
                msg += "Please input Number Of Bathroom > 0 <br/>";
            }
        }

        if (pro.getNumberOfBedroom() == null) {
            msg += "Please input Number Of Bedroom <br/>";
        } else {
            if (pro.getNumberOfBedroom() < 0) {
                msg += "Please input Number Of Bedroom > 0 <br/>";
            }
        }

        if (pro.getCity() == null || pro.getCity().equals("")) {
            msg += "Please input City Name<br/>";
        }

        if (pro.getStreet() == null || pro.getStreet().equals("")) {
            msg += "Please input Street <br/>";
        }

        if (extraFacilities == null || extraFacilities.equals("")) {
            msg += "Please choose Facility <br/>";
        }

        if (negotiable == null || negotiable.equals("")) {
            msg += "Please choose negotiable <br/>";
        }

        if (fur == null || fur.equals("")) {
            msg += "Please choose Furniture status <br/>";
        }

        if (pro.getDepositPrice() < 0) {
            msg += "Please input Deposit >0<br/>";
        }

        if (pro.getPrice() < 0) {
            msg += "Please input  Rent price >0<br/>";
        }

        if (!msg.equals("")) {
            listTypePro = typeProDao.loadAllTypeOfProperyEnable();
            listPay = payDao.loadAllPaymentMethodEnable();
            request.setAttribute("addProErr", msg);
            return "fail";
        } else {
            TypeOfService tOService = new TypeOfService();
            tOService.setTypeOfServiceId(typeServiceId);
            pro.setTypeOfService(tOService);

            String nameServiceFolder = "";
            List<TypeOfService> loadAllTypeOfService = typeSerivceDao.loadAllTypeOfService();
            for (TypeOfService loadAllTypeOfService1 : loadAllTypeOfService) {
                if (loadAllTypeOfService1.getTypeOfServiceId() == typeServiceId) {
                    nameServiceFolder = loadAllTypeOfService1.getNameOfService()
                            .replace(" ", "").toLowerCase().trim();
                }
            }
            //image save into database
            pro.setImage("images" + "/" + nameServiceFolder + "/" + urlAnh.getName().replace("tmp", "jpg"));

            //save image into folder
            File fileToCreate = new File(request.getServletContext().getRealPath("images")
                    + File.separator + nameServiceFolder
                    + File.separator + urlAnh.getName().replace("tmp", "jpg"));
            try {
                FileUtils.copyFile(urlAnh, fileToCreate);
            } catch (IOException ex) {
                Logger.getLogger(DirectoryCategoryActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
            }

            String userAcc = "";
            if (session != null) {
                userAcc = (String) session.getAttribute("userAccount");
            }
            Customer custom = new Customer();
            List<Customer> loadAllCustomer = cusDao.loadAllCustomer();
            for (Customer allCust : loadAllCustomer) {
                if (allCust.getUserAccount().equals(userAcc)) {
                    custom.setUserNo(allCust.getUserNo());
                }
            }
            pro.setCustomer(custom);

            TypeOfProperty typePro = new TypeOfProperty();
            typePro.setTypeOfPropertyId(typeOfPro.getTypeOfPropertyId());
            pro.setTypeOfProperty(typePro);

            if (extraFacilities.equals("Yes")) {
                pro.setExtraFacilitiesAvailable(true);
            } else {
                pro.setExtraFacilitiesAvailable(false);
            }

            if (modesTransport.equals("Bus")) {
                pro.setModesOfTransport("Bus");
            } else if (modesTransport.equals("Taxi")) {
                pro.setModesOfTransport("Taxi");
            } else if (modesTransport.equals("Trunk")) {
                pro.setModesOfTransport("Trunk");
            } else if (modesTransport.equals("Train")) {
                pro.setModesOfTransport("Train");
            }

            if (fur.equals("Yes")) {
                pro.setFurniture(true);
            } else {
                pro.setFurniture(false);
            }

            Payment pa = new Payment();
            pa.setPaymentId(pay.getPaymentId());
            pro.setPayment(pa);

            pro.setIsDeleted(true);
            if (negotiable.equals("Yes")) {
                pro.setNegotiable(true);
            } else {
                pro.setNegotiable(false);
            }
            pro.setSubmitDate(new Date());
            //Expired Date month+1
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MONTH, +1);
            Date d = cal.getTime();
            pro.setExpiredDate(d);
            pro.setStatusAdvertise(true);

            boolean result = proDao.insertHouseForSale(pro);

            if (result) {
                return "success";
            } else {
                listTypePro = typeProDao.loadAllTypeOfProperyEnable();
                listPay = payDao.loadAllPaymentMethodEnable();
                request.setAttribute("addProErr", "Add New advertisement has failed please try again");
                return "fail";
            }
        }
    }

    public String insertAccommodationOnRental() {
        String msg = "";
        if (urlAnh == null) {
            msg += "Please choose image <br/>";
        }

        if (pro.getNumberOfBathroom() == null) {
            msg += "Please input Number Of Bathroom <br/>";
        } else {
            if (pro.getNumberOfBathroom() < 0) {
                msg += "Please input Number Of Bathroom > 0 <br/>";
            }
        }

        if (pro.getNumberOfBedroom() == null) {
            msg += "Please input Number Of Bedroom <br/>";
        } else {
            if (pro.getNumberOfBedroom() < 0) {
                msg += "Please input Number Of Bedroom > 0 <br/>";
            }
        }

        if (pro.getDepositPrice() < 0) {
            msg += "Please input Deposit >0<br/>";
        }

        if (pro.getPrice() < 0) {
            msg += "Please input Rent price >0<br/>";
        }

        if (pro.getCity() == null || pro.getCity().equals("")) {
            msg += "Please input City Name<br/>";
        }

        if (pro.getStreet() == null || pro.getStreet().equals("")) {
            msg += "Please input Street <br/>";
        }

        if (!msg.equals("")) {
            listTypePro = typeProDao.loadAllTypeOfProperyEnable();
            listPay = payDao.loadAllPaymentMethodEnable();
            request.setAttribute("addProErr", msg);
            return "fail";
        } else {
            TypeOfService tOService = new TypeOfService();
            tOService.setTypeOfServiceId(typeServiceId);
            pro.setTypeOfService(tOService);

            String nameServiceFolder = "";
            List<TypeOfService> loadAllTypeOfService = typeSerivceDao.loadAllTypeOfService();
            for (TypeOfService loadAllTypeOfService1 : loadAllTypeOfService) {
                if (loadAllTypeOfService1.getTypeOfServiceId() == typeServiceId) {
                    nameServiceFolder = loadAllTypeOfService1.getNameOfService()
                            .replace(" ", "").toLowerCase().trim();
                }
            }
            //image save into database
            pro.setImage("images" + "/" + nameServiceFolder + "/" + urlAnh.getName().replace("tmp", "jpg"));

            //save image into folder
            File fileToCreate = new File(request.getServletContext().getRealPath("images")
                    + File.separator + nameServiceFolder
                    + File.separator + urlAnh.getName().replace("tmp", "jpg"));
            try {
                FileUtils.copyFile(urlAnh, fileToCreate);
            } catch (IOException ex) {
                Logger.getLogger(DirectoryCategoryActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
            }

            String userAcc = "";
            if (session != null) {
                userAcc = (String) session.getAttribute("userAccount");
            }
            Customer custom = new Customer();
            List<Customer> loadAllCustomer = cusDao.loadAllCustomer();
            for (Customer allCust : loadAllCustomer) {
                if (allCust.getUserAccount().equals(userAcc)) {
                    custom.setUserNo(allCust.getUserNo());
                }
            }
            pro.setCustomer(custom);

            TypeOfProperty typePro = new TypeOfProperty();
            typePro.setTypeOfPropertyId(7);
            pro.setTypeOfProperty(typePro);
            Payment pa = new Payment();
            pa.setPaymentId(pay.getPaymentId());
            pro.setPayment(pa);
            pro.setIsDeleted(true);

            //Submit Date= getDate()
            pro.setSubmitDate(new Date());
            //Expired Date month+1
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MONTH, +1);
            Date d = cal.getTime();
            pro.setExpiredDate(d);

            pro.setStatusAdvertise(true);
            boolean result = proDao.insertHouseForSale(pro);

            if (result) {
                return "success";
            } else {
                listTypePro = typeProDao.loadAllTypeOfProperyEnable();
                listPay = payDao.loadAllPaymentMethodEnable();
                request.setAttribute("addProErr", "Add New advertisement has failed please try again");
                return "fail";
            }
        }
    }

    public String insertAccommodationAsAPayingGuest() {
        String msg = "";
        if (urlAnh == null) {
            msg += "Please choose image <br/>";
        }
        if (pro.getDepositPrice() < 0) {
            msg += "Please input Deposit >0<br/>";
        }
        if (pro.getPrice() < 0) {
            msg += "Please input Rent price >0<br/>";
        }
        if (pro.getCity() == null || pro.getCity().equals("")) {
            msg += "Please input City Name<br/>";
        }
        if (pro.getStreet() == null || pro.getStreet().equals("")) {
            msg += "Please input Street <br/>";
        }

        if (!msg.equals("")) {
            request.setAttribute("addProErr", msg);
            return "fail";
        } else {
            TypeOfService tOService = new TypeOfService();
            tOService.setTypeOfServiceId(typeServiceId);
            pro.setTypeOfService(tOService);

            String nameServiceFolder = "";
            List<TypeOfService> loadAllTypeOfService = typeSerivceDao.loadAllTypeOfService();
            for (TypeOfService loadAllTypeOfService1 : loadAllTypeOfService) {
                if (loadAllTypeOfService1.getTypeOfServiceId() == typeServiceId) {
                    nameServiceFolder = loadAllTypeOfService1.getNameOfService()
                            .replace(" ", "").toLowerCase().trim();
                }
            }
            //image save into database
            pro.setImage("images" + "/" + nameServiceFolder + "/" + urlAnh.getName().replace("tmp", "jpg"));

            //save image into folder
            File fileToCreate = new File(request.getServletContext().getRealPath("images")
                    + File.separator + nameServiceFolder
                    + File.separator + urlAnh.getName().replace("tmp", "jpg"));
            try {
                FileUtils.copyFile(urlAnh, fileToCreate);
            } catch (IOException ex) {
                Logger.getLogger(DirectoryCategoryActionFormBean.class.getName()).log(Level.SEVERE, null, ex);
            }

            String userAcc = "";
            if (session != null) {
                userAcc = (String) session.getAttribute("userAccount");
            }
            Customer custom = new Customer();
            List<Customer> loadAllCustomer = cusDao.loadAllCustomer();
            for (Customer allCust : loadAllCustomer) {
                if (allCust.getUserAccount().equals(userAcc)) {
                    custom.setUserNo(allCust.getUserNo());
                }
            }
            pro.setCustomer(custom);

            TypeOfProperty typePro = new TypeOfProperty();
            typePro.setTypeOfPropertyId(7);
            pro.setTypeOfProperty(typePro);

            Payment pa = new Payment();
            pa.setPaymentId(5);
            pro.setPayment(pa);

            pro.setIsDeleted(true);

            pro.setSubmitDate(new Date());
            //Expired Date month+1
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MONTH, +1);
            Date d = cal.getTime();
            pro.setExpiredDate(d);

            pro.setStatusAdvertise(true);

            boolean result = proDao.insertHouseForSale(pro);

            if (result) {
                return "success";
            } else {
                listTypePro = typeProDao.loadAllTypeOfProperyEnable();
                listPay = payDao.loadAllPaymentMethodEnable();
                request.setAttribute("addProErr", "Add New advertisement has failed please try again");
                return "fail";
            }
        }
    }

    public String goFindHouseSales() {
        listTypePro = typeProDao.loadAllTypeOfProperyEnable();
        return "success";
    }

    public String goFindHouseForRent() {
        return "success";
    }

    public String goFindAccommodationOnRental() {
        return "success";
    }

    public String goFindAccommodationAsAPayingGuest() {
        return "success";
    }

    public String findHouseForSales() {
        String msg = "";

        if (pro.getSquareFootage() < 0) {
            msg += "Please input Square Footage >0<br/>";
        }

        if (minPrice < 0) {
            msg += "Please input Minimum Money >0<br/>";
        }
        if (maxPrice < 0) {
            msg += "Please input Maximum Money  >0<br/>";
        }

        if (pro.getCity() == null || pro.getCity().equals("")) {
            msg += "Please input City Name<br/>";
        }
        if (pro.getStreet() == null || pro.getStreet().equals("")) {
            msg += "Please input Street <br/>";
        }
        if (pro.getNumberOfBathroom() == null) {
            msg += "Please input Number Of Bathroom <br/>";
        } else {
            if (pro.getNumberOfBathroom() < 0) {
                msg += "Please input Number Of Bathroom > 0 <br/>";
            }
        }

        if (pro.getNumberOfBedroom() == null) {
            msg += "Please input Number Of Bedroom <br/>";
        } else {
            if (pro.getNumberOfBedroom() < 0) {
                msg += "Please input Number Of Bedroom > 0 <br/>";
            }
        }

        if (!msg.equals("")) {
            listTypePro = typeProDao.loadAllTypeOfProperyEnable();
            request.setAttribute("findProErr", msg);
            return "fail";
        } else {
            TypeOfProperty typePro = new TypeOfProperty();
            typePro.setTypeOfPropertyId(typeOfPro.getTypeOfPropertyId());
            pro.setTypeOfProperty(typePro);

            listProperty = proDao.findHouseForSale(pro, minPrice, maxPrice);

            if (listProperty.size() > 0) {
                return "success";
            } else {
                listTypePro = typeProDao.loadAllTypeOfProperyEnable();
                request.setAttribute("searchErr", "Can not find information please try again");
                return "success";
            }
        }
    }

    public String findHouseForRent() {
        String msg = "";

        if (maxPrice < 0) {
            msg += "Please input Maximum Money  >0<br/>";
        }

        if (pro.getDepositPrice() < 0) {
            msg += "Please input Deposit >0<br/>";
        }

        if (pro.getCity() == null || pro.getCity().equals("")) {
            msg += "Please input City Name<br/>";
        }
        if (pro.getStreet() == null || pro.getStreet().equals("")) {
            msg += "Please input Street <br/>";
        }
        if (pro.getNumberOfBathroom() == null) {
            msg += "Please input Number Of Bathroom <br/>";
        } else {
            if (pro.getNumberOfBathroom() < 0) {
                msg += "Please input Number Of Bathroom > 0 <br/>";
            }
        }

        if (pro.getNumberOfBedroom() == null) {
            msg += "Please input Number Of Bedroom <br/>";
        } else {
            if (pro.getNumberOfBedroom() < 0) {
                msg += "Please input Number Of Bedroom > 0 <br/>";
            }
        }

        if (!msg.equals("")) {
            listTypePro = typeProDao.loadAllTypeOfProperyEnable();
            request.setAttribute("findProErr", msg);
            return "fail";
        } else {
            listProperty = proDao.findHouseForRent(pro);

            if (listProperty.size() > 0) {
                return "success";
            } else {
                listTypePro = typeProDao.loadAllTypeOfProperyEnable();
                request.setAttribute("searchErr", "Can not find information please try again");
                return "success";
            }
        }
    }

    public String findAccommodationOnRental() {
        String msg = "";

        if (pro.getDepositPrice() < 0) {
            msg += "Please input Deposit >0<br/>";
        }

        if (!msg.equals("")) {
            request.setAttribute("findProErr", msg);
            return "fail";
        } else {
            listProperty = proDao.findAccommodationOnRental(pro);

            if (listProperty.size() > 0) {
                return "success";
            } else {
                request.setAttribute("searchErr", "Can not find information please try again");
                return "success";
            }
        }
    }

    public String findAccommodationAsAPayingGuest() {
        String msg = "";

        if (pro.getDepositPrice() < 0) {
            msg += "Please input Deposit >0<br/>";
        }

        if (!msg.equals("")) {
            request.setAttribute("findProErr", msg);
            return "fail";
        } else {
            listProperty = proDao.findAccommodationAsAPayingGuest(pro);

            if (listProperty.size() > 0) {
                return "success";
            } else {
                request.setAttribute("searchErr", "Can not find information please try again");
                return "success";
            }
        }
    }
}
