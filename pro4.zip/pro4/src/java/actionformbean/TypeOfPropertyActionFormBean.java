/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actionformbean;

import com.mysweethome.dal.entity.Property;
import com.mysweethome.dal.entity.TypeOfProperty;
import com.mysweethome.dao.TypeOfPropertyDao;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.struts2.ServletActionContext;

/**
 *
 * @author DucPhuong
 */
public class TypeOfPropertyActionFormBean {

    HttpServletRequest request = ServletActionContext.getRequest();
    TypeOfPropertyDao typeOfProDao = new TypeOfPropertyDao();

    List<TypeOfProperty> listTypeOfPro;

    TypeOfProperty typeOfPro;
    Property pro;
    String statusTypeOfproperty;

    public String getStatusTypeOfproperty() {
        return statusTypeOfproperty;
    }

    public void setStatusTypeOfproperty(String statusTypeOfproperty) {
        this.statusTypeOfproperty = statusTypeOfproperty;
    }

    public Property getPro() {
        return pro;
    }

    public void setPro(Property pro) {
        this.pro = pro;
    }

    public TypeOfPropertyDao getTypeOfProDao() {
        return typeOfProDao;
    }

    public void setTypeOfProDao(TypeOfPropertyDao typeOfProDao) {
        this.typeOfProDao = typeOfProDao;
    }

    public List<TypeOfProperty> getListTypeOfPro() {
        return listTypeOfPro;
    }

    public void setListTypeOfPro(List<TypeOfProperty> listTypeOfPro) {
        this.listTypeOfPro = listTypeOfPro;
    }

    public TypeOfProperty getTypeOfPro() {
        return typeOfPro;
    }

    public void setTypeOfPro(TypeOfProperty typeOfPro) {
        this.typeOfPro = typeOfPro;
    }

    public String loadAllTypeOfProperty() {
        listTypeOfPro = typeOfProDao.loadAllTypeOfProperyEnable();
        return "success";
    }

    public String viewDetailTypeOfProperty() {
        typeOfPro = typeOfProDao.findTypeOfPropery(typeOfPro);
        return "success";
    }

    public String loadAllTypeOfPropertyAdmin() {
        listTypeOfPro = typeOfProDao.loadAllTypeOfPropery();
        return "success";
    }

    public String updateTypePro() {
        TypeOfProperty findTypeOfPropery = typeOfProDao.findTypeOfPropery(typeOfPro);
        if (statusTypeOfproperty.equals("Block")) {
            findTypeOfPropery.setIsDeleted(false);
        } else {
            findTypeOfPropery.setIsDeleted(true);
        }
        boolean result = typeOfProDao.updateTypeOfPropery(findTypeOfPropery);
        if (result) {
            return "success";
        } else {
            return "fail";
        }
    }

    public String goAddTypePro() {
        return "success";
    }

    public String addNewTypeOfPro() {
        String msg = "";
        if (typeOfPro.getTypeOfPropertyName()== null || typeOfPro.getTypeOfPropertyName().equals("")) {
            msg += "Please input Type Of Property Name";
        } else if (typeOfPro.getTypeOfPropertyName().length() <= 2) {
            msg += "Please input more 2 character";
        }

        boolean check = typeOfProDao.checkExistTypeOfProperty(typeOfPro);

        if (!msg.equals("")) {
            request.setAttribute("typePropertyErr", msg);
            return "fail";
        } else {
            if (check) {
                request.setAttribute("typePropertyErr", "Type Property name has existed please choose another");
                return "fail";
            } else {
                if (statusTypeOfproperty.equals("Block")) {
                    typeOfPro.setIsDeleted(false);
                } else {
                    typeOfPro.setIsDeleted(true);
                }
                boolean result = typeOfProDao.addNewTypeOfPropery(typeOfPro);
                if (result) {
                    return "success";
                } else {
                    return "fail";
                }
            }
        }

    }
}
