/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.common.util;

/**
 *
 * @author VietNH10
 */
public class StaticParameter {

    public static String adminAccount;
    public static int userNo;
    //public static int propertyId=0;
   // public static String sender="Guest";

}
