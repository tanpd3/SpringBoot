/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.common.basedaoimpl;

import java.util.List;

/**
 *
 * @author VietNH10
 */
public interface DirectoryCategoryInteface<T> {

    List<T> loadAllDirectoryCategory();//Loadd all Directory category

    List<T> loadAllDirectoryCategoryDisable();//Loadd all Directory category have been deleted

    List<T> loadAllDirectoryCategoryEnable();//Loadd all Directory category have not been deleted

    boolean addNewDirectoryCategory(T obj);//insert new directory Category 

    boolean updateDirectoryCategory(T obj);//update Directory Category by primary key

    boolean deleteDirectoryCategory(T obj);//Delete Directory Category by primary key

    T findDirectoryCategory(T obj);//Find Directory Category by primary key

    boolean checkExistDirectoryCategoryName(T obj); //Check Exist Directory Category Name
}
