/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.common.basedaoimpl;

import java.util.List;

/**
 *
 * @author VietNH10
 */
public interface DirectoryCompanyInterface<T> {

    List<T> loadAllDirectoryCompany(int maxResults, int firstResult);//Load all Directory Company

    List<T> loadAllDirectoryCompanyDisable();//Load all Directory Company have been deleted

    List<T> loadAllDirectoryCompanyEnable();//Load all Directory Company have not been deleted

    List<T> loadAllDirectoryCompanyByDirectoryCategoryId(T obj);//Load All Directory Company by Directory CategoryId

    boolean addNewDirectoryCompany(T obj); //Insert new Directory Company

    boolean updateDirectoryCompany(T obj);//Update Directory Company by primary key

    boolean deleteDirectoryCompany(T obj);//Delete Directory Company by primary key

    T findDirectoryCompany(T obj);//Find Directory by by primary key

    int countCompanyAdmin();//count number of property for pagging
}
