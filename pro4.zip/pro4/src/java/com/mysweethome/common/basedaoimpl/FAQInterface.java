/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.common.basedaoimpl;

import java.util.List;

/**
 *
 * @author VietNH10
 */
public interface FAQInterface<T> {

    List<T> loadAllFAQ();//Load All FAQ

    boolean addNewFAQ(T obj);//insert New FAQ

    boolean updateFAQ(T obj);//Update FAQ by primary key

    boolean deleteFAQ(T obj);//Delete FAQ by by primary key

    List<T> selectFAQ(T obj);//Find FAQ by primary key
}
