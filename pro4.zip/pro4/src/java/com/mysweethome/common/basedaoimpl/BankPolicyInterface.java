/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.common.basedaoimpl;

import java.util.List;

/**
 *
 * @author VietNH10
 */
public interface BankPolicyInterface<T> {

    List<T> loadAllBankPolicy();//Load all bank policy

    boolean addNewBankPolicy(T obj);//Insert new bank policy

    boolean updateBankPolicy(T obj);//uppdate bank policy by primary key

    boolean deleteBankPolicy(T obj);//delete bank policy by primary key

    T findBankPolicy(T obj);//Find information by primary key

}
