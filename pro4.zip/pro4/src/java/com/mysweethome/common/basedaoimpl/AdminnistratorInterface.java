/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.common.basedaoimpl;

import java.util.List;

/**
 *
 * @author VietNH10
 */
public interface AdminnistratorInterface<T> {

    T loginAdmin(T a);//Login Admin

    boolean changePasswordAdmin(T a,String oldPassword);//Change password for admin
}
