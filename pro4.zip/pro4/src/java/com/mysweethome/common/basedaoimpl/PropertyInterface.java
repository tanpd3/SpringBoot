/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.common.basedaoimpl;

import java.util.List;

/**
 *
 * @author VietNH10
 * @param <T>
 */
public interface PropertyInterface<T> {

    List<T> loadAllProperty(int maxResults, int firstResult);//Load All Property

    List<T> loadAllPropertyDisable(int maxResults, int firstResult);//Load All Property have been deleted

    List<T> loadAllPropertyEnable(int maxResults, int firstResult);//Load All Property have not been deleted

    List<T> findHouseForSale(T obj, double minimumPrice, double maximumPrice);
    //Find follow :
//1.	Price(minimum/maximum)
//2.	Square footage
//3.	city
//4.	location/ specific area in the city
//5.	No. of bedrooms
//6.	No. of bathrooms
//7.	Type(i.e. Residential Land, Commercial, Condominium, Townhouse,  Multi-unit dwelling)

    List<T> findHouseForRent(T obj);
    //Find follow :
//1.	Amount to be paid as a deposit
//2.	Rent
//3.	City
//4.	Location/ specific area in the city
//5.	No. of bedrooms
//6.	No. of bathrooms

    List<T> findAccommodationOnRental(T obj);
    //Find follow :
//1.	Deposit
//2.	Rent

    List<T> findAccommodationAsAPayingGuest(T obj);
    //Find follow :
//1.	Deposit
//2.	Rent

    List<T> loadAllPropertyByTypeOfServiceId(T obj, int maxResults, int firstResult); //Load All Propery by Type Of Service Id

    List<T> loadAllPropertyByTypeOfPropertyId(T obj, int maxResults, int firstResult);//Load All Propery by Type Of Property Id

    List<T> loadAllPropertyByPaymentMethod(T obj);//Load All Propery by Payment Method

    boolean insertHouseForSale(T obj);
    //insert follow
//1.	City where the house is located.
//2.	Location/ particular area in the city.  
//3.	price( fixed/ negotiable)
//4.	No of bedrooms.
//5.	No. of bathrooms.
//6.	Type (i.e. Residential Land, Commercial, Condominium, Townhouse,  Multi-unit dwelling)
//7.	Extra facilities available.
//8.	Convenient Modes of transport.
//9.	With or without furniture/interiors.
//10.	 Image.
//11.	 Mode of payment. 
//12.	 Contact details

    boolean insertHouseForRent(T obj);
    //insert follow
//1.	City where the house is located.
//2.	Location/ particular area in the city.  
//3.	Rent( fixed/ negotiable)
//4.	No of bedrooms.
//5.	No. of bathrooms.
//6.	Type (i.e. Residential Land, Commercial, Condominium,      Townhouse,  Multi-unit dwelling)
//7.	Extra facilities available.
//8.	Convenient Modes of transport.
//9.	With or without furniture/interiors.
//10.	 Image.
//11.	 Mode of payment. 
//12.	 Contact details   

    boolean insertAccommodationOnRental(T obj);
    //insert follow   
//1.	City
//2.	Location 
//3.	Deposit
//4.	Rent 
//5.	No. of bedrooms
//6.	No. of bathrooms
//7.	Image
//8.	Modes of payment

    boolean insertAccommodationAsAPayingGuest(T obj);
    //insert follow
//1.	City
//2.	Location
//3.	Deposit
//4.	Rent

    boolean updateProperty(T obj);//Update Propery by Primary Key

    boolean deleteProperty(T obj);//Update(set isDeleted) by Primary Key

    T findProperty(T obj); //find Property by Primary Key

    int countAdvertisement();//Count Number of Advertisment for pagging user

    int countAdvertisementAdmin();//Count Number of Advertisment for pagging admin
    
    List<T> searchPropertyByPoster(T obj);//Search Property by Poster
    
    List<T> searchPropertyByPosterPagging(T obj, int maxResults, int firstResult);//Search Property by Poster pagging
    
}
