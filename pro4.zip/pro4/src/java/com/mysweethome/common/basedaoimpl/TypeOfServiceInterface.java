/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.common.basedaoimpl;

import java.util.List;

/**
 *
 * @author VietNH10
 */
public interface TypeOfServiceInterface<T> {

    List<T> loadAllTypeOfService();//load All type of Service

    List<T> loadAllTypeOfServiceDisable();//load All type of Service have been deleted

    List<T> loadAllTypeOfServiceEnable();//load All type of Service have not been deleted

    boolean addNewTypeOfService(T obj);//Insert new type of Service

    boolean updateTypeOfService(T obj);//update type of Service by Primary Key

    boolean deleteTypeOfService(T obj);//delete type Of Service by Primary Key

    T findTypeOfService(T obj);//find type of Service by Primary Key

    boolean checkExistTypeOfService(T obj);//Check Exist type of Service Name
}
