/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.common.basedaoimpl;

import java.util.List;

/**
 *
 * @author VietNH10
 */
public interface PaymentInterface<T> {

    List<T> loadAllPaymentMethod();//Load All payment Method

    List<T> loadAllPaymentMethodDisable();//Load All payment Method have been deleted

    List<T> loadAllPaymentMethodEnable();//Load All payment Method have not been deleted

    boolean addNewPaymentMethod(T obj);//Insert new payment Method

    boolean updatePaymentMethod(T obj);//Update payment Method

    boolean deletePaymentMethod(T obj);//Delete payment Method

    T findPaymentMethod(T obj);//Find payment method by Primary key

    boolean checkExistPaymentMethodName(T obj);//Check Exist Payment Method Name
}
