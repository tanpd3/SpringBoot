 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.common.basedaoimpl;

import java.util.List;

/**
 *
 * @author VietNH10
 */
public interface CustomerInterface<T> {

    List<T> loadAllCustomer();//Load all Customer

    boolean registerCustomer(T obj); //Insert Customer

    boolean changeInformationCustomer(T obj);//Update Customer by primary key

    boolean deleteCustomer(T obj);//Update isDeleted by primary key (blockUser)

    T findCustomer(T obj);//select find Customer by primary key

    boolean changePassword(T obj, String oldPassword);//changePassword User

    T loginCustomer(T obj);//Login Customer

    boolean checkExistUserAccount(T obj);//Check Exist UserName (where userAccount into database)

    T checkBlockUserAccount(T obj);//Check Block UserName (where userAccount into database)
    
    List<T> findUserByName(T obj);//find user like userAccount
}
