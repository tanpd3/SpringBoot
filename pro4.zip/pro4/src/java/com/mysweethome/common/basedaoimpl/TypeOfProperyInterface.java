/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.common.basedaoimpl;

import java.util.List;

/**
 *
 * @author VietNH10
 */
public interface TypeOfProperyInterface<T> {

    List<T> loadAllTypeOfPropery();//Load All type Of Property

    List<T> loadAllTypeOfProperyDisable();//Load All type Of Property have been deleted

    List<T> loadAllTypeOfProperyEnable();//Load All type Of Property have not been deleted

    boolean addNewTypeOfPropery(T obj);//Insert new type Of Property

    boolean updateTypeOfPropery(T obj);//Update type of property by Primary Key

    boolean deleteTypeOfPropery(T obj);//Delete type of property by Primary Key

    T findTypeOfPropery(T obj);//find type of Property by Primary Key

    boolean checkExistTypeOfProperty(T obj);//Check Exist type of Property Name
}
