/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.dao;

import com.mysweethome.common.basedaoimpl.AdminnistratorInterface;
import com.mysweethome.dal.entity.Administrator;
import com.mysweethome.common.hibernateutil.NewHibernateUtil;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;


/**
 *
 * @author CanhToan
 */
public class AdminDao extends NewHibernateUtil implements AdminnistratorInterface<Administrator> {

    @Override
    public Administrator loginAdmin(Administrator a) {
        Session session = this.getSession();

        Query q = session.createQuery("From Administrator where adminAccount=:loginName and adminPassword=:pass");
        q.setParameter("loginName", a.getAdminAccount());
        q.setParameter("pass", a.getAdminPassword());

        Administrator ad = (Administrator) q.uniqueResult();
        return ad;
    }

    @Override
    public boolean changePasswordAdmin(Administrator a, String oldPassword) {
        boolean result;
        Session session = this.getSession();
        Transaction tran = null;

        try {
            tran = session.beginTransaction();
            SQLQuery q = session.createSQLQuery("update Administrator set adminPassword=? where adminAccount=? and adminPassword=?");
            q.setParameter(0, a.getAdminPassword());
            q.setParameter(1, a.getAdminAccount());
            q.setParameter(2, oldPassword);

            if (q.executeUpdate() > 0) {
                result = true;
            } else {
                result = false;
            }

            tran.commit();

        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }

        return result;
    }
}
