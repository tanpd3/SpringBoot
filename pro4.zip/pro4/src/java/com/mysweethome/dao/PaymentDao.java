/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.dao;

import com.mysweethome.common.basedaoimpl.PaymentInterface;
import com.mysweethome.dal.entity.Payment;
import com.mysweethome.common.hibernateutil.NewHibernateUtil;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author TuanAnh
 */
public class PaymentDao extends NewHibernateUtil implements PaymentInterface<Payment> {
    
    @Override
    public List<Payment> loadAllPaymentMethod() {
        Session session = this.getSession();
        Query q = session.createQuery("From Payment");
        return q.list();
    }
    
    @Override
    public List<Payment> loadAllPaymentMethodDisable() {
        Session session = this.getSession();
        Query q = session.createQuery("From Payment where isDeleted=0");
        return q.list();
    }
    
    @Override
    public List<Payment> loadAllPaymentMethodEnable() {
        Session session = this.getSession();
        Query q = session.createQuery("From Payment where isDeleted=1");
        return q.list();
    }
    
    @Override
    public boolean addNewPaymentMethod(Payment obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;
        
        try {
            tran = session.beginTransaction();
            session.save(obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }
    
    @Override
    public boolean updatePaymentMethod(Payment obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;
        
        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getPaymentId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }
    
    @Override
    public boolean deletePaymentMethod(Payment obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;
        
        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getPaymentId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }
    
    @Override
    public Payment findPaymentMethod(Payment obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From Payment where paymentId=:paymentId");
        q.setParameter("paymentId", obj.getPaymentId());
        Payment result = (Payment) q.uniqueResult();
        
        return result;
    }
    
    @Override
    public boolean checkExistPaymentMethodName(Payment obj) {
        Session session = this.getSession();
        boolean result;
        
        Query q = session.createQuery("From Payment where paymentMethod=:paymentMethodName");
        q.setParameter("paymentMethodName", obj.getPaymentMethod());
        Payment payment = (Payment) q.uniqueResult();
        
        if (payment != null) {
            result = true;
        } else {
            result = false;
        }
        return result;
    }
    
}
