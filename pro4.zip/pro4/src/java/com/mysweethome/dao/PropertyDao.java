/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.dao;

import com.mysweethome.common.basedaoimpl.PropertyInterface;
import com.mysweethome.dal.entity.Property;
import com.mysweethome.common.hibernateutil.NewHibernateUtil;
import com.mysweethome.dal.entity.Customer;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author TuanAnh
 */
public class PropertyDao extends NewHibernateUtil implements PropertyInterface<Property> {

    @Override
    public List<Property> loadAllProperty(int maxResults, int firstResult) {
        Session session = this.getSession();
        Query q = session.createQuery("From Property");
        q.setFirstResult(firstResult);
        q.setMaxResults(maxResults);
        return q.list();
    }

    @Override
    public List<Property> loadAllPropertyDisable(int maxResults, int firstResult) {
        Session session = this.getSession();
        Query q = session.createQuery("From Property where isDeleted=0");
        q.setFirstResult(firstResult);
        q.setMaxResults(maxResults);
        return q.list();
    }

    @Override
    public List<Property> loadAllPropertyEnable(int maxResults, int firstResult) {
        Session session = this.getSession();
        Query q = session.createQuery("From Property where isDeleted=1");
        q.setFirstResult(firstResult);
        q.setMaxResults(maxResults);
        return q.list();
    }

    @Override
    public List<Property> findHouseForSale(Property obj, double minimumPrice, double maximumPrice) {
        Session session = this.getSession();
        Query q = session.createQuery("From Property where  price<=:maximumPrice and "
                + "price>=:minimumPrice and city like '%' +:city+ '%' and squareFootage<=:squareFootage"
                + " and street like '%' +:street + '%' and numberOfBathroom<=:numberOfBathroom"
                + " and numberOfBedroom<=:numberOfBedroom and typeOfPropertyId=:typeOfPropertyId "
                + "and isDeleted=1 and typeOfServiceId=1");

        q.setParameter("minimumPrice", minimumPrice);
        q.setParameter("maximumPrice", maximumPrice);
        q.setParameter("city", obj.getCity());
        q.setParameter("street", obj.getStreet());
        q.setParameter("squareFootage", obj.getSquareFootage());
        q.setParameter("numberOfBathroom", obj.getNumberOfBathroom());
        q.setParameter("numberOfBedroom", obj.getNumberOfBedroom());
        q.setParameter("typeOfPropertyId", obj.getTypeOfProperty().getTypeOfPropertyId());

        return q.list();
    }

    @Override
    public List<Property> findHouseForRent(Property obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From Property where depositPrice<=:deposit "
                + "and price<=:rent and city like '%' +:city+ '%' and street like "
                + "'%' +:street + '%' and numberOfBathroom<=:numberOfBathroom "
                + "and numberOfBedroom<=:numberOfBedroom and isDeleted=1 and typeOfServiceId=2");
        q.setParameter("deposit", obj.getDepositPrice());
        q.setParameter("rent", obj.getPrice());
        q.setParameter("city", obj.getCity());
        q.setParameter("street", obj.getStreet());
        q.setParameter("numberOfBathroom", obj.getNumberOfBathroom());
        q.setParameter("numberOfBedroom", obj.getNumberOfBedroom());

        return q.list();
    }

    @Override
    public List<Property> findAccommodationOnRental(Property obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From Property where depositPrice<=:deposit "
                + "and price<=:rent and isDeleted=1 and typeOfServiceId=3");
        q.setParameter("deposit", obj.getDepositPrice());
        q.setParameter("rent", obj.getPrice());
        return q.list();
    }

    @Override
    public List<Property> findAccommodationAsAPayingGuest(Property obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From Property where depositPrice<=:deposit and price<=:rent "
                + "and isDeleted=1 and typeOfServiceId=4");
        q.setParameter("deposit", obj.getDepositPrice());
        q.setParameter("rent", obj.getPrice());
        return q.list();
    }

    @Override
    public List<Property> loadAllPropertyByTypeOfServiceId(Property obj, int maxResults, int firstResult) {
        Session session = this.getSession();
        Query q = session.createQuery("From Property where typeOfService.typeOfServiceId=:typeOfServiceId and isDeleted=1");
        q.setParameter("typeOfServiceId", obj.getTypeOfService().getTypeOfServiceId());
        return q.list();
    }

    @Override
    public List<Property> loadAllPropertyByTypeOfPropertyId(Property obj, int maxResults, int firstResult) {
        Session session = this.getSession();
        Query q = session.createQuery("From Property where typeOfProperty.typeOfPropertyId=:typeOfPropertyId and isDeleted=1");
        q.setParameter("typeOfPropertyId", obj.getTypeOfProperty().getTypeOfPropertyId());
        return q.list();
    }

    @Override
    public List<Property> loadAllPropertyByPaymentMethod(Property obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From Property where payment.paymentId=:paymentMethod and isDeleted=1");
        q.setParameter("paymentMethod", obj.getPayment().getPaymentId());
        return q.list();
    }

    @Override
    public boolean insertHouseForSale(Property obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.save(obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean insertHouseForRent(Property obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.save(obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean insertAccommodationOnRental(Property obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.save(obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean insertAccommodationAsAPayingGuest(Property obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.save(obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean updateProperty(Property obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getPropertyId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean deleteProperty(Property obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getPropertyId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public Property findProperty(Property obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From Property where propertyId=:propertyId");
        q.setParameter("propertyId", obj.getPropertyId());
        Property result = (Property) q.uniqueResult();
        return result;
    }

    @Override
    public int countAdvertisement() {
        Session session = this.getSession();
        SQLQuery q = session.createSQLQuery("select count(*) as numberProperty from Property where isDeleted=1");
        return q.uniqueResult().hashCode();
    }

    @Override
    public int countAdvertisementAdmin() {
        Session session = this.getSession();
        SQLQuery q = session.createSQLQuery("select count(*) as numberProperty from Property");
        return q.uniqueResult().hashCode();
    }

    @Override
    public List<Property> searchPropertyByPoster(Property obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From Property where customer.userNo=:userAccount and isDeleted=1");
        q.setParameter("userAccount", obj.getCustomer().getUserNo());
        return q.list();
    }

    @Override
    public List<Property> searchPropertyByPosterPagging(Property obj, int maxResults, int firstResult) {
        Session session = this.getSession();
        Query q = session.createQuery("From Property where customer.userNo=:userAccount and isDeleted=1");
        q.setParameter("userAccount", obj.getCustomer().getUserNo());
        q.setMaxResults(maxResults);
        q.setFirstResult(firstResult);
        return q.list();
    }

    public int countSLSPForUser(Customer obj) {
        Session session = this.getSession();
        SQLQuery q = session.createSQLQuery("select count(*) as numberProperty from Property where Property.userNo=?");
        q.setParameter(0, obj.getUserNo());
        return q.uniqueResult().hashCode();
    }

}
