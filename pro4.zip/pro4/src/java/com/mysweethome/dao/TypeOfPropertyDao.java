/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.dao;

import com.mysweethome.common.basedaoimpl.TypeOfProperyInterface;
import com.mysweethome.dal.entity.TypeOfProperty;
import com.mysweethome.common.hibernateutil.NewHibernateUtil;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author TuanAnh
 */
public class TypeOfPropertyDao extends NewHibernateUtil implements TypeOfProperyInterface<TypeOfProperty> {

    @Override
    public List<TypeOfProperty> loadAllTypeOfPropery() {
        Session session = this.getSession();
        Query q = session.createQuery("From TypeOfProperty");
        return q.list();
    }

    @Override
    public List<TypeOfProperty> loadAllTypeOfProperyDisable() {
        Session session = this.getSession();
        Query q = session.createQuery("From TypeOfProperty where isDeleted=0");
        return q.list();
    }

    @Override
    public List<TypeOfProperty> loadAllTypeOfProperyEnable() {
        Session session = this.getSession();
        Query q = session.createQuery("From TypeOfProperty where isDeleted=1");
        return q.list();
    }

    @Override
    public boolean addNewTypeOfPropery(TypeOfProperty obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.save(obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean updateTypeOfPropery(TypeOfProperty obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getTypeOfPropertyId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean deleteTypeOfPropery(TypeOfProperty obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getTypeOfPropertyId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public TypeOfProperty findTypeOfPropery(TypeOfProperty obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From TypeOfProperty where typeOfPropertyId=:typeOfPropertyId");
        q.setParameter("typeOfPropertyId", obj.getTypeOfPropertyId());
        TypeOfProperty result = (TypeOfProperty) q.uniqueResult();

        return result;
    }

    @Override
    public boolean checkExistTypeOfProperty(TypeOfProperty obj) {
        Session session = this.getSession();
        boolean result;

        Query q = session.createQuery("From TypeOfProperty where typeOfPropertyName=:typeOfPropertyName");
        q.setParameter("typeOfPropertyName", obj.getTypeOfPropertyName());
        TypeOfProperty typeOfPro = (TypeOfProperty) q.uniqueResult();

        if (typeOfPro != null) {
            result = true;
        } else {
            result = false;
        }
        return result;
    }

}
