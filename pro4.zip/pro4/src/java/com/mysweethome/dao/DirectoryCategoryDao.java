/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.dao;

import com.mysweethome.common.basedaoimpl.DirectoryCategoryInteface;
import com.mysweethome.common.hibernateutil.NewHibernateUtil;
import com.mysweethome.dal.entity.DirectoryCategory;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author CanhToan
 */
public class DirectoryCategoryDao extends NewHibernateUtil implements DirectoryCategoryInteface<DirectoryCategory> {

    @Override
    public List<DirectoryCategory> loadAllDirectoryCategory() {
        Session session = this.getSession();
        Query q = session.createQuery("From DirectoryCategory");
        return q.list();
    }

    @Override
    public List<DirectoryCategory> loadAllDirectoryCategoryDisable() {
        Session session = this.getSession();
        Query q = session.createQuery("From DirectoryCategory where isDeleted=0");
        return q.list();
    }

    @Override
    public List<DirectoryCategory> loadAllDirectoryCategoryEnable() {
        Session session = this.getSession();
        Query q = session.createQuery("From DirectoryCategory where isDeleted=1");
        return q.list();
    }

    @Override
    public boolean addNewDirectoryCategory(DirectoryCategory obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.save(obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean updateDirectoryCategory(DirectoryCategory obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getDirectoryCategoryId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean deleteDirectoryCategory(DirectoryCategory obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getDirectoryCategoryId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public DirectoryCategory findDirectoryCategory(DirectoryCategory obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From DirectoryCategory where DirectoryCategoryId=:DirectCateId");
        q.setParameter("DirectCateId", obj.getDirectoryCategoryId());
        DirectoryCategory result = (DirectoryCategory) q.uniqueResult();
        return result;
    }

    @Override
    public boolean checkExistDirectoryCategoryName(DirectoryCategory obj) {
        Session session = this.getSession();
        boolean result;

        Query q = session.createQuery("From DirectoryCategory where directoryCategoryname=:directoryCategoryName");
        q.setParameter("directoryCategoryName", obj.getDirectoryCategoryname());
        DirectoryCategory directCate = (DirectoryCategory) q.uniqueResult();

        if (directCate != null) {
            result = true;
        } else {
            result = false;
        }

        return result;
    }

}
