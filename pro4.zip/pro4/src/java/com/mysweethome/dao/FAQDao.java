/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.dao;

import com.mysweethome.common.basedaoimpl.FAQInterface;
import com.mysweethome.dal.entity.Faq;
import com.mysweethome.common.hibernateutil.NewHibernateUtil;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author TuanAnh
 */
public class FAQDao extends NewHibernateUtil implements FAQInterface<Faq> {

    @Override
    public List<Faq> loadAllFAQ() {
        Session session = this.getSession();
        Query q = session.createQuery("From Faq");
        return q.list();
    }

    @Override
    public boolean addNewFAQ(Faq obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.save(obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean updateFAQ(Faq obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getQuestionId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean deleteFAQ(Faq obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.delete(String.valueOf(obj.getQuestionId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public List<Faq> selectFAQ(Faq obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From Faq where propertyId=:propertyId");
        q.setParameter("propertyId", obj.getPropertyId());
        List listFaq = q.list();
        
        return listFaq;
    }
  
    
}
