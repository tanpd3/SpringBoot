/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.dao;

import com.mysweethome.common.basedaoimpl.CustomerInterface;
import com.mysweethome.dal.entity.Customer;
import com.mysweethome.common.hibernateutil.NewHibernateUtil;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.SQLQuery;

/**
 *
 * @author CanhToan
 */
public class CustomerDao extends NewHibernateUtil implements CustomerInterface<Customer> {

    @Override
    public List<Customer> loadAllCustomer() {
        Session session = this.getSession();
        Query q = session.createQuery("From Customer");
        return q.list();
    }

    @Override
    public boolean registerCustomer(Customer obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.save(obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean changeInformationCustomer(Customer obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getUserNo()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean deleteCustomer(Customer obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getUserNo()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public Customer findCustomer(Customer obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From Customer where userNo=:userNumber");
        q.setParameter("userNumber", obj.getUserNo());
        Customer result = (Customer) q.uniqueResult();
        return result;
    }

    @Override
    public boolean changePassword(Customer obj, String oldPassword) {
        boolean result;
        Session session = this.getSession();
        Transaction tran = null;

        try {
            tran = session.beginTransaction();
            SQLQuery q = session.createSQLQuery("update Customer set userPassword=? where userNo=? and userPassword=?");
            q.setParameter(0, obj.getUserPassword());
            q.setParameter(1, obj.getUserNo());
            q.setParameter(2, oldPassword);

            if (q.executeUpdate() > 0) {
                result = true;
            } else {
                result = false;
            }
            tran.commit();
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }

        return result;
    }

    @Override
    public Customer loginCustomer(Customer obj) {
        Session session = this.getSession();

        Query q = session.createQuery("From Customer where userAccount=:loginName and userPassword=:pass");
        q.setParameter("loginName", obj.getUserAccount());
        q.setParameter("pass", obj.getUserPassword());

        Customer result = (Customer) q.uniqueResult();
        return result;
    }

    @Override
    public boolean checkExistUserAccount(Customer obj) {
        Session session = this.getSession();
        boolean result;

        Query q = session.createQuery("From Customer where userAccount=:loginName");
        q.setParameter("loginName", obj.getUserAccount());
        Customer cus = (Customer) q.uniqueResult();
        if (cus != null) {
            result = true;
        } else {
            result = false;
        }
        return result;
    }

    @Override
    public Customer checkBlockUserAccount(Customer obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From Customer where userAccount=:loginName and isDeleted=0");
        q.setParameter("loginName", obj.getUserAccount());
        Customer cus = (Customer) q.uniqueResult();
        if (cus != null) {
            return cus;
        }else{
            return new Customer();
        }

    }

    @Override
    public List<Customer> findUserByName(Customer obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From Customer where userAccount like '%' +:userName + '%'");
        q.setParameter("userName", obj.getUserAccount());
        return q.list();
    }
}
