/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.dao;

import com.mysweethome.common.basedaoimpl.DirectoryCompanyInterface;
import com.mysweethome.dal.entity.DirectoryCompany;
import com.mysweethome.common.hibernateutil.NewHibernateUtil;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author TuanAnh
 */
public class DirectoryCompanyDao extends NewHibernateUtil implements DirectoryCompanyInterface<DirectoryCompany> {

    @Override
    public List<DirectoryCompany> loadAllDirectoryCompany(int maxResults, int firstResult) {
        Session session = this.getSession();
        Query q = session.createQuery("From DirectoryCompany");
        q.setFirstResult(firstResult);
        q.setMaxResults(maxResults);
        return q.list();
    }

    @Override
    public List<DirectoryCompany> loadAllDirectoryCompanyDisable() {
        Session session = this.getSession();
        Query q = session.createQuery("From DirectoryCompany isDeleted=0");
        return q.list();
    }

    @Override
    public List<DirectoryCompany> loadAllDirectoryCompanyEnable() {
        Session session = this.getSession();
        Query q = session.createQuery("From DirectoryCompany isDeleted=1");
        return q.list();
    }

    @Override
    public List<DirectoryCompany> loadAllDirectoryCompanyByDirectoryCategoryId(DirectoryCompany obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From DirectoryCompany where directoryCategory.directoryCategoryId=:directCateId and isDeleted=1");
        q.setParameter("directCateId", obj.getDirectoryCategory().getDirectoryCategoryId());
        return q.list();
    }

    @Override
    public boolean addNewDirectoryCompany(DirectoryCompany obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.save(obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean updateDirectoryCompany(DirectoryCompany obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getDirectoryComparyId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean deleteDirectoryCompany(DirectoryCompany obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getDirectoryComparyId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public DirectoryCompany findDirectoryCompany(DirectoryCompany obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From DirectoryCompany where directoryComparyId=:DirectCompanyId");
        q.setParameter("DirectCompanyId", obj.getDirectoryComparyId());
        DirectoryCompany result = (DirectoryCompany) q.uniqueResult();
        return result;
    }

    @Override
    public int countCompanyAdmin() {
        Session session = this.getSession();
        SQLQuery q = session.createSQLQuery("select count(*) as numberCompany from DirectoryCompany");
        return q.uniqueResult().hashCode();
    }

}
