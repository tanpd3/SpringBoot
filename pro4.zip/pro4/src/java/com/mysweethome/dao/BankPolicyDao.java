/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.dao;

import com.mysweethome.common.basedaoimpl.BankPolicyInterface;
import com.mysweethome.dal.entity.BankPolicy;
import com.mysweethome.common.hibernateutil.NewHibernateUtil;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author CanhToan
 */
public class BankPolicyDao extends NewHibernateUtil implements BankPolicyInterface<BankPolicy> {

    @Override
    public List<BankPolicy> loadAllBankPolicy() {
        Session session = this.getSession();
        Query q = session.createQuery("From BankPolicy");
        return q.list();
    }

    @Override
    public boolean addNewBankPolicy(BankPolicy obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.save(obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean updateBankPolicy(BankPolicy obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getBankName()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean deleteBankPolicy(BankPolicy obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.delete(String.valueOf(obj.getBankName()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public BankPolicy findBankPolicy(BankPolicy obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From BankPolicy where bankName=:bankName");
        q.setParameter("bankName", obj.getBankName());
        BankPolicy result = (BankPolicy) q.uniqueResult();
        return result;
    }
    

}
