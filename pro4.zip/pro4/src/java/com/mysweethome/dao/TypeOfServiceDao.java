/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mysweethome.dao;

import com.mysweethome.common.basedaoimpl.TypeOfServiceInterface;
import com.mysweethome.dal.entity.TypeOfService;
import com.mysweethome.common.hibernateutil.NewHibernateUtil;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author TuanAnh
 */
public class TypeOfServiceDao extends NewHibernateUtil implements TypeOfServiceInterface<TypeOfService> {

    @Override
    public List<TypeOfService> loadAllTypeOfService() {
        Session session = this.getSession();
        Query q = session.createQuery("From TypeOfService");
        return q.list();
    }

    @Override
    public List<TypeOfService> loadAllTypeOfServiceDisable() {
        Session session = this.getSession();
        Query q = session.createQuery("From TypeOfService where isDeleted=0");
        return q.list();
    }

    @Override
    public List<TypeOfService> loadAllTypeOfServiceEnable() {
        Session session = this.getSession();
        Query q = session.createQuery("From TypeOfService where isDeleted=1");
        return q.list();
    }

    @Override
    public boolean addNewTypeOfService(TypeOfService obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.save(obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean updateTypeOfService(TypeOfService obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getTypeOfServiceId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public boolean deleteTypeOfService(TypeOfService obj) {
        Session session = this.getSession();
        Transaction tran = null;
        boolean result;

        try {
            tran = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(obj.getTypeOfServiceId()), obj);
            tran.commit();
            result = true;
        } catch (Exception e) {
            tran.rollback();
            result = false;
        } finally {
            session.close();
        }
        return result;
    }

    @Override
    public TypeOfService findTypeOfService(TypeOfService obj) {
        Session session = this.getSession();
        Query q = session.createQuery("From TypeOfService where typeOfServiceId=:typeOfServiceId");
        q.setParameter("typeOfServiceId", obj.getTypeOfServiceId());
        TypeOfService result = (TypeOfService) q.uniqueResult();
        return result;
    }

    @Override
    public boolean checkExistTypeOfService(TypeOfService obj) {
        Session session = this.getSession();
        boolean result;

        Query q = session.createQuery("From TypeOfService where nameOfService=:nameOfService");
        q.setParameter("nameOfService", obj.getNameOfService());
        TypeOfService typeofService = (TypeOfService) q.uniqueResult();

        if (typeofService != null) {
            result = true;
        } else {
            result = false;
        }
        return result;
    }

}
