//generate column license
function drawTableLicense() {
	this.getMonthActive();
	var strTheadYear;
	var strTheadMonth = "";
	var arrayMonth = ["4","5","6","7","8","9","10","11","12","1","2","3"];
	if (month == 3) {
		arrayMonth = ["10","11","12","1","2","3","4","5","6","7","8","9"];
		strTheadYear = "<tr>"
			 		 + "<td style=\"min-width: 295px;text-align: center;\" class=\"text-left apply-color\">"+(year-1)+"年度</td>"
			 		 + "<td>|</td>"
			 		 + "<td style=\"min-width: 260px;text-align: center;\" class=\"text-left apply-color\">" +(year)+"年度</td>"
			 		 + "</tr>"
	} else if (month == 1 || month == 2) {
		strTheadYear = "<tr style=\"text-align:center\">"
					 + "<td style=\"min-width: 590px;text-align: center;max-width: 590px\" class=\"text-left apply-color\">"+(year-1)+"年度</td>"
					 + "</tr>"
	} else {
		strTheadYear = "<tr style=\"text-align:center\">"
					 + "<td style=\"min-width: 590px;text-align: center;max-width: 590px\" class=\"text-left apply-color\">"+year+"年度</td>"
					 + "</tr>"
	}
	for (var i=0; i < arrayMonth.length-1; i++) {
		strTheadMonth += "<td style=\"min-width: 43px;\" class=\"text-center apply-color\">"+arrayMonth[i]+"月"+"</td>" 
						  + "<td>|</td>"
	}
		strTheadMonth += "<td style=\"min-width: 43px;\" class=\"text-center apply-color\">"+arrayMonth[i]+"月"+"</td>"
	$("#table_th_year").prepend(strTheadYear);
	$("#tr_head_month").prepend(strTheadMonth);
}

//get month active to array
function getMonthActive() {
	arrayMonthActive = null;
	switch(month) {
	case 4:
		arrayMonthActive = ["4","5","6","7","8","9"];
		break;
	case 5:
		arrayMonthActive = ["5","6","7","8","9"];
		break;
	case 6:
		arrayMonthActive = ["6","7","8","9"];
		break;
	case 7:
		arrayMonthActive = ["7","8","9"];
		break;
	case 8:
		arrayMonthActive = ["8","9"];
		break;
	case 9:
		arrayMonthActive = ["9","10","11","12","1","2","3"];
		break;
	case 10:
		arrayMonthActive = ["10","11","12","1","2","3"];
		break;
	case 11:
		arrayMonthActive = ["11","12","1","2","3"];
		break;
	case 12:
		arrayMonthActive = ["12","1","2","3"];
		break;
	case 1:
		arrayMonthActive = ["1","2","3"];
		break;
	case 2:
		arrayMonthActive = ["2","3"];
		break;
	case 3:
		arrayMonthActive = ["3","4","5","6","7","8","9"];
		break;
	}
	return arrayMonthActive;
}

//process when selected on checkbox catalog
function onClickCheckbox(catalogId) {
	var monthLicense;
	var colorRgb;
	var colorRgb9;
	var colorRgb10;
	var colorRgb11;
	var colorRgb12;
	var colorRgb1;
	var colorRgb2;
	var colorRgb3;
	var colorHex;
	var colorHex9;
	var colorHex10;
	var colorHex11;
	var colorHex12;
	var colorHex1;
	var colorHex2;
	var colorHex3;
	var idObject;
	var idObjectNextYearMonth3;
	var idObjectNextYearMonth4;
	var idObjectNextYearMonth5;
	var idObjectNextYearMonth6;
	var idObjectNextYearMonth7;
	var idObjectNextYearMonth8;
	var idObjectNextYearMonth9;
	var listMonth = [1,2,3];
	var listMonth2 = [4,5,6,7,8];

	if(listMonth.indexOf(month) > -1 ){//contain month 1,2,3
			for (var k=0; k < arrayMonthActive.length; k++) {
				monthLicense = arrayMonthActive[k];
				idObject = "catalog_"+catalogId+"_month_"+monthLicense+"_year_"+year;
				colorRgb = document.getElementById(idObject).style.backgroundColor;
				colorHex = rgb2hex(colorRgb);
				if(colorHex.toLowerCase() == "#d9d9d9"){
					document.getElementById(idObject).disabled = false;
					document.getElementById(idObject).style.backgroundColor = "#FFFFFF";
				} else {
					document.getElementById(idObject).disabled = true;
					document.getElementById(idObject).style.backgroundColor = "#D9D9D9";
				}
			}
	} else {//not contain month 1,2,3
		if(listMonth2.indexOf(month) > -1 ){//contain month 4,5,6,7,8
			for (var k=0; k < arrayMonthActive.length; k++) {
				monthLicense = arrayMonthActive[k];
				idObject = "catalog_"+catalogId+"_month_"+monthLicense+"_year_"+year;
				colorRgb = document.getElementById(idObject).style.backgroundColor;
				colorHex = rgb2hex(colorRgb);
				if(colorHex.toLowerCase() == "#d9d9d9"){
					document.getElementById(idObject).disabled = false;
					document.getElementById(idObject).style.backgroundColor = "#FFFFFF";
				} else {
					document.getElementById(idObject).disabled = true;
					document.getElementById(idObject).style.backgroundColor = "#D9D9D9";
				}
			}
		} else {//contain month 9,10,11,12
			for (var k=0; k < arrayMonthActive.length; k++) {
			monthLicense = arrayMonthActive[k];
			switch (monthLicense) {
			case "9":
				idObjectNextYearMonth9 = "catalog_"+catalogId+"_month_9_year_"+year;
				colorRgb9 = document.getElementById(idObjectNextYearMonth9).style.backgroundColor;
				colorHex9 = rgb2hex(colorRgb9);
				break;
			case "10":
				idObjectNextYearMonth10 = "catalog_"+catalogId+"_month_10_year_"+year;
				colorRgb10 = document.getElementById(idObjectNextYearMonth10).style.backgroundColor;
				colorHex10 = rgb2hex(colorRgb10);
				break;
			case "11":
				idObjectNextYearMonth11 = "catalog_"+catalogId+"_month_11_year_"+year;
				colorRgb11 = document.getElementById(idObjectNextYearMonth11).style.backgroundColor;
				colorHex11 = rgb2hex(colorRgb11);
				break;
			case "12":
				idObjectNextYearMonth12 = "catalog_"+catalogId+"_month_12_year_"+year;
				colorRgb12 = document.getElementById(idObjectNextYearMonth12).style.backgroundColor;
				colorHex12 = rgb2hex(colorRgb12);
				break;
			case "1":
				idObjectNextYearMonth1 = "catalog_"+catalogId+"_month_1_year_"+nextYear;
				colorRgb1 = document.getElementById(idObjectNextYearMonth1).style.backgroundColor;
				colorHex1 = rgb2hex(colorRgb1);
				break;
			case "2":
				idObjectNextYearMonth2 = "catalog_"+catalogId+"_month_2_year_"+nextYear;
				colorRgb2 = document.getElementById(idObjectNextYearMonth2).style.backgroundColor;
				colorHex2 = rgb2hex(colorRgb2);
				break;
			case "3":
				idObjectNextYearMonth3 = "catalog_"+catalogId+"_month_3_year_"+nextYear;
				colorRgb3 = document.getElementById(idObjectNextYearMonth3).style.backgroundColor;
				colorHex3 = rgb2hex(colorRgb3);
				break;
			}
			if(monthLicense == 9 && colorHex9 != null && colorHex9.toLowerCase() == "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth9).disabled = false;
				document.getElementById(idObjectNextYearMonth9).style.backgroundColor = "#FFFFFF";
			} else if(monthLicense == 9 && colorHex9 != null && colorHex9.toLowerCase() != "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth9).disabled = true;
				document.getElementById(idObjectNextYearMonth9).style.backgroundColor = "#D9D9D9";
			}
			if(monthLicense == 10 && colorHex10 != null && colorHex10.toLowerCase() == "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth10).disabled = false;
				document.getElementById(idObjectNextYearMonth10).style.backgroundColor = "#FFFFFF";
			} else if(monthLicense == 10 && colorHex10 != null && colorHex10.toLowerCase() != "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth10).disabled = true;
				document.getElementById(idObjectNextYearMonth10).style.backgroundColor = "#D9D9D9";
			}
			if(monthLicense == 11 && colorHex11 != null && colorHex11.toLowerCase() == "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth11).disabled = false;
				document.getElementById(idObjectNextYearMonth11).style.backgroundColor = "#FFFFFF";
			} else if(monthLicense == 11 && colorHex11 != null && colorHex11.toLowerCase() != "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth11).disabled = true;
				document.getElementById(idObjectNextYearMonth11).style.backgroundColor = "#D9D9D9";
			}
			if(monthLicense == 12 && colorHex12 != null && colorHex12.toLowerCase() == "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth12).disabled = false;
				document.getElementById(idObjectNextYearMonth12).style.backgroundColor = "#FFFFFF";
			} else if(monthLicense == 12 && colorHex12 != null && colorHex12.toLowerCase() != "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth12).disabled = true;
				document.getElementById(idObjectNextYearMonth12).style.backgroundColor = "#D9D9D9";
			}
			if(monthLicense == 1 && colorHex1 != null && colorHex1.toLowerCase() == "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth1).disabled = false;
				document.getElementById(idObjectNextYearMonth1).style.backgroundColor = "#FFFFFF";
			} else if(monthLicense == 1 && colorHex1 != null && colorHex1.toLowerCase() != "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth1).disabled = true;
				document.getElementById(idObjectNextYearMonth1).style.backgroundColor = "#D9D9D9";
			}
			if(monthLicense == 2 && colorHex2 != null && colorHex2.toLowerCase() == "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth2).disabled = false;
				document.getElementById(idObjectNextYearMonth2).style.backgroundColor = "#FFFFFF";
			} else if(monthLicense == 2 && colorHex2 != null && colorHex2.toLowerCase() != "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth2).disabled = true;
				document.getElementById(idObjectNextYearMonth2).style.backgroundColor = "#D9D9D9";
			}
			if(monthLicense == 3 && colorHex3 != null && colorHex3.toLowerCase() == "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth3).disabled = false;
				document.getElementById(idObjectNextYearMonth3).style.backgroundColor = "#FFFFFF";
			} else if(monthLicense == 3 && colorHex3 != null && colorHex3.toLowerCase() != "#d9d9d9"){
				document.getElementById(idObjectNextYearMonth3).disabled = true;
				document.getElementById(idObjectNextYearMonth3).style.backgroundColor = "#D9D9D9";
			}
		}
	}
}
	//get list CatalogID
	var check = document.getElementsByName('chk_'+catalogId)[0].checked;
	if (check) {
		var objValNumber = {catalogId: catalogId};
		var value4;
		var id4 = document.getElementById("catalog_" + catalogId + "_month_" + 4 + "_year_" + year);
		var id4Pre = document.getElementById("catalog_" + catalogId + "_month_" + 4 + "_year_" + preYear);
		
		var value5;
		var id5 = document.getElementById("catalog_" + catalogId + "_month_" + 5 + "_year_" + year);
		var id5Pre = document.getElementById("catalog_" + catalogId + "_month_" + 5 + "_year_" + preYear);
		
		var value6;
		var id6 = document.getElementById("catalog_" + catalogId + "_month_" + 6 + "_year_" + year);
		var id6Pre = document.getElementById("catalog_" + catalogId + "_month_" + 6 + "_year_" + preYear);
		
		var value7;
		var id7 = document.getElementById("catalog_" + catalogId + "_month_" + 7 + "_year_" + year);
		var id7Pre = document.getElementById("catalog_" + catalogId + "_month_" + 7 + "_year_" + preYear);
		
		var value8;
		var id8 = document.getElementById("catalog_" + catalogId + "_month_" + 8 + "_year_" + year);
		var id8Pre = document.getElementById("catalog_" + catalogId + "_month_" + 8 + "_year_" + preYear);
		
		var value9;
		var id9 = document.getElementById("catalog_" + catalogId + "_month_" + 9 + "_year_" + year);
		var id9Pre = document.getElementById("catalog_" + catalogId + "_month_" + 9 + "_year_" + preYear);
		
		var value10;
		var id10 = document.getElementById("catalog_" + catalogId + "_month_" + 10 + "_year_" + year);
		var id10Pre = document.getElementById("catalog_" + catalogId + "_month_" + 10 + "_year_" + preYear);
		
		var value11;
		var id11 = document.getElementById("catalog_" + catalogId + "_month_" + 11 + "_year_" + year);
		var id11Pre = document.getElementById("catalog_" + catalogId + "_month_" + 11 + "_year_" + preYear);
		
		var value12;
		var id12 = document.getElementById("catalog_" + catalogId + "_month_" + 12 + "_year_" + year);
		var id12Pre = document.getElementById("catalog_" + catalogId + "_month_" + 12 + "_year_" + preYear);
		
		var value1;
		var id1 = document.getElementById("catalog_" + catalogId + "_month_" + 1 + "_year_" + year);
		var id13 = document.getElementById("catalog_" + catalogId + "_month_" + 1 + "_year_" + nextYear);
		
		var value2;
		var id2 = document.getElementById("catalog_" + catalogId + "_month_" + 2 + "_year_" + year);
		var id23 = document.getElementById("catalog_" + catalogId + "_month_" + 2 + "_year_" + nextYear);
		
		var value3;
		var id3 = document.getElementById("catalog_" + catalogId + "_month_" + 3 + "_year_" + year);
		var id33 = document.getElementById("catalog_" + catalogId + "_month_" + 3 + "_year_" + nextYear);
		
		if(listMonth.indexOf(month) > -1 ){//contain month 1,2,3
			if(month == 3){
				if (id1 != null && id1 != "null") {
					if(id1.defaultValue != "0"){
						id1.value = id1.defaultValue;
						value1 = id1.value;
					} else {
						value1 = "";
					}
				}
				if (id2 != null && id2 != "null") {
					if(id2.defaultValue != "0"){
						id2.value = id2.defaultValue;
						value2 = id2.value;
					} else {
						value2 = "";
					}
				}
				if (id3 != null && id3 != "null") {
					if(id3.defaultValue != "0"){
						id3.value = id3.defaultValue;
						value3 = id3.value;
					} else {
						value3 = "";
					}
				}
				if (id4 != null && id4 != "null") {
					if(id4.defaultValue != "0"){
						id4.value = id4.defaultValue;
						value4 = id4.value;
					} else {
						value4 = "";
					}
				}
				if (id5 != null && id5 != "null") {
					if(id5.defaultValue != "0"){
						id5.value = id5.defaultValue;
						value5 = id5.value;
					} else {
						value5 = "";
					}
				}
				if (id6 != null && id6 != "null") {
					if(id6.defaultValue != "0"){
						id6.value = id6.defaultValue;
						value6 = id6.value;
					} else {
						value6 = "";
					}
				}
				if (id7 != null && id7 != "null") {
					if(id7.defaultValue != "0"){
						id7.value = id7.defaultValue;
						value7 = id7.value;
					} else {
						value7 = "";
					}
				}
				if (id8 != null && id8 != "null") {
					if(id8.defaultValue != "0"){
						id8.value = id8.defaultValue;
						value8 = id8.value;
					} else {
						value8 = "";
					}
				}
				if (id9 != null && id9 != "null") {
					if(id9.defaultValue != "0"){
						id9.value = id9.defaultValue;
						value9 = id9.value;
					} else {
						value9 = "";
					}
				}
				
				if (id10Pre != null && id10Pre != "null") {//Month plus preYear
					if (id10Pre.defaultValue != "0") {
						id10Pre.value = id10Pre.defaultValue;
						value10 = id10Pre.value;
					} else {
						value10 = "";
					}
				}
				if (id11Pre != null && id11Pre != "null") {
					if (id11Pre.defaultValue != "0") {
						id11Pre.value = id11Pre.defaultValue;
						value11 = id11Pre.value;
					} else {
						value11 = "";
					}
				}
				if (id12Pre != null && id12Pre != "null") {
					if (id12Pre.defaultValue != "0") {
						id12Pre.value = id12Pre.defaultValue;
						value12 = id12Pre.value;
					} else {
						value12 = "";
					}
				}
			} else if(month == 1 || month == 2){
				if (id1 != null && id1 != "null") {
					if(id1.defaultValue != "0"){
						id1.value = id1.defaultValue;
						value1 = id1.value;
					} else {
						value1 = "";
					}
				}
				if (id2 != null && id2 != "null") {
					if(id2.defaultValue != "0"){
						id2.value = id2.defaultValue;
						value2 = id2.value;
					} else {
						value2 = "";
					}
				}
				if (id3 != null && id3 != "null") {
					if(id3.defaultValue != "0"){
						id3.value = id3.defaultValue;
						value3 = id3.value;
					} else {
						value3 = "";
					}
				}
				
				if (id4Pre != null && id4Pre != "null") {//Month plus preYear
					if(id4Pre.defaultValue != "0"){
						id4Pre.value = id4Pre.defaultValue;
						value4 = id4Pre.value;
					} else {
						value4 = "";
					}
				}
				if (id5Pre != null && id5Pre != "null") {
					if(id5Pre.defaultValue != "0"){
						id5Pre.value = id5Pre.defaultValue;
						value5 = id5Pre.value;
					} else {
						value5 = "";
					}
				}
				if (id6Pre != null && id6Pre != "null") {
					if(id6Pre.defaultValue != "0"){
						id6Pre.value = id6Pre.defaultValue;
						value6 = id6Pre.value;
					} else {
						value6 = "";
					}
				}
				if (id7Pre != null && id7Pre != "null") {
					if(id7Pre.defaultValue != "0"){
						id7Pre.value = id7Pre.defaultValue;
						value7 = id7Pre.value;
					} else {
						value7 = "";
					}
				}
				if (id8Pre != null && id8Pre != "null") {
					if(id8Pre.defaultValue != "0"){
						id8Pre.value = id8Pre.defaultValue;
						value8 = id8Pre.value;
					} else {
						value8 = "";
					}
				}
				if (id9Pre != null && id9Pre != "null") {
					if(id9Pre.defaultValue != "0"){
						id9Pre.value = id9Pre.defaultValue;
						value9 = id9Pre.value;
					} else {
						value9 = "";
					}
				}
				if (id10Pre != null && id10Pre != "null") {
					if (id10Pre.defaultValue != "0") {
						id10Pre.value = id10Pre.defaultValue;
						value10 = id10Pre.value;
					} else {
						value10 = "";
					}
				}
				if (id11Pre != null && id11Pre != "null") {
					if (id11Pre.defaultValue != "0") {
						id11Pre.value = id11Pre.defaultValue;
						value11 = id11Pre.value;
					} else {
						value11 = "";
					}
				}
				if (id12Pre != null && id12Pre != "null") {
					if (id12Pre.defaultValue != "0") {
						id12Pre.value = id12Pre.defaultValue;
						value12 = id12Pre.value;
					} else {
						value12 = "";
					}
				}
			}
		} else {//not contain month 1,2,3
			if(listMonth2.indexOf(month) > -1 ){//contain month 4,5,6,7,8
				if (id4 != null && id4 != "null") {
					if(id4.defaultValue != "0"){
						id4.value = id4.defaultValue;
						value4 = id4.value;
					} else {
						value4 = "";
					}
				}
				if (id5 != null && id5 != "null") {
					if(id5.defaultValue != "0"){
						id5.value = id5.defaultValue;
						value5 = id5.value;
					} else {
						value5 = "";
					}
				}
				if (id6 != null && id6 != "null") {
					if(id6.defaultValue != "0"){
						id6.value = id6.defaultValue;
						value6 = id6.value;
					} else {
						value6 = "";
					}
				}
				if (id7 != null && id7 != "null") {
					if(id7.defaultValue != "0"){
						id7.value = id7.defaultValue;
						value7 = id7.value;
					} else {
						value7 = "";
					}
				}
				if (id8 != null && id8 != "null") {
					if(id8.defaultValue != "0"){
						id8.value = id8.defaultValue;
						value8 = id8.value;
					} else {
						value8 = "";
					}
				}
				if (id9 != null && id9 != "null") {
					if(id9.defaultValue != "0"){
						id9.value = id9.defaultValue;
						value9 = id9.value;
					} else {
						value9 = "";
					}
				}
				
				if (id13 != null && id13 != "null") {//Month plus
					if (id13.defaultValue != "0") {
						id13.value = id13.defaultValue;
						value1 = id13.value;
					} else {
						value1 = "";
					}
				}
				if (id23 != null && id23 != "null") {
					if (id23.defaultValue != "0") {
						id23.value = id23.defaultValue;
						value2 = id23.value;
					} else {
						value2 = "";
					}
				}
				if (id33 != null && id33 != "null") {
					if (id33.defaultValue != "0") {
						id33.value = id33.defaultValue;
						value3 = id33.value;
					} else {
						value3 = "";
					}
				}
				if (id10 != null && id10 != "null") {
					if (id10.defaultValue != "0") {
						id10.value = id10.defaultValue;
						value10 = id10.value;
					} else {
						value10 = "";
					}
				}
				if (id11 != null && id11 != "null") {
					if (id11.defaultValue != "0") {
						id11.value = id11.defaultValue;
						value11 = id11.value;
					} else {
						value11 = "";
					}
				}
				if (id12 != null && id12 != "null") {
					if (id12.defaultValue != "0") {
						id12.value = id12.defaultValue;
						value12 = id12.value;
					} else {
						value12 = "";
					}
				}
			} else {//contain month 9,10,11,12
				if (id9 != null && id9 != "null") {
					if (id9.defaultValue != "0") {
						id9.value = id9.defaultValue;
						value9 = id9.value;
					} else {
						value9 = "";
					}
				}
				if (id10 != null && id10 != "null") {
					if (id10.defaultValue != "0") {
						id10.value = id10.defaultValue;
						value10 = id10.value;
					} else {
						value10 = "";
					}
				}
				if (id11 != null && id11 != "null") {
					if (id11.defaultValue != "0") {
						id11.value = id11.defaultValue;
						value11 = id11.value;
					} else {
						value11 = "";
					}
				}
				if (id12 != null && id12 != "null") {
					if (id12.defaultValue != "0") {
						id12.value = id12.defaultValue;
						value12 = id12.value;
					} else {
						value12 = "";
					}
				}
				if (id13 != null && id13 != "null") {
					if (id13.defaultValue != "0") {
						id13.value = id13.defaultValue;
						value1 = id13.value;
					} else {
						value1 = "";
					}
				}
				if (id23 != null && id23 != "null") {
					if (id23.defaultValue != "0") {
						id23.value = id23.defaultValue;
						value2 = id23.value;
					} else {
						value2 = "";
					}
				}
				if (id33 != null && id33 != "null") {
					if (id33.defaultValue != "0") {
						id33.value = id33.defaultValue;
						value3 = id33.value;
					} else {
						value3 = "";
					}
				}
				
				if (id4 != null && id4 != "null") {//Moth plus
					if (id4.defaultValue != "0") {
						id4.value = id4.defaultValue;
						value4 = id4.value;
					} else {
						value4 = "";
					}
				}
				if (id5 != null && id5 != "null") {
					if (id5.defaultValue != "0") {
						id5.value = id5.defaultValue;
						value5 = id5.value;
					} else {
						value5 = "";
					}
				}
				if (id6 != null && id6 != "null") {
					if (id6.defaultValue != "0") {
						id6.value = id6.defaultValue;
						value6 = id6.value;
					} else {
						value6 = "";
					}
				}
				if (id7 != null && id7 != "null") {
					if (id7.defaultValue != "0") {
						id7.value = id7.defaultValue;
						value7 = id7.value;
					} else {
						value7 = "";
					}
				}
				if (id8 != null && id8 != "null") {
					if (id8.defaultValue != "0") {
						id8.value = id8.defaultValue;
						value8 = id8.value;
					} else {
						value8 = "";
					}
				}
			}
		}
		var object = {
			catalogId: catalogId,
			catalog_month_4: value4,
			catalog_month_5: value5,
			catalog_month_6: value6,
			catalog_month_7: value7,
			catalog_month_8: value8,
			catalog_month_9: value9,
			catalog_month_10: value10,
			catalog_month_11: value11,
			catalog_month_12: value12,
			catalog_month_1: value1,
			catalog_month_2: value2,
			catalog_month_3: value3
		};
		arrayCatalogIdChecked.push(object);
		validateNumberLicense.push(objValNumber);
	} else {//remove element on array when not check
		if (arrayCatalogIdChecked != null && arrayCatalogIdChecked.length > 0) {
			var index = -1;
			for (var i=0;i<arrayCatalogIdChecked.length; i++) {
				var obj = arrayCatalogIdChecked[i];
				if (obj.catalogId == catalogId) {
					index = i;
					break;
				}
			}
			if (index > -1) {
				arrayCatalogIdChecked.splice(index, 1);
			}
		}
		if (validateNumberLicense != null && validateNumberLicense.length > 0) {
			var index = -1;
			for (var i=0; i< validateNumberLicense.length; i++) {
				var objNum = validateNumberLicense[i];
				if (objNum.catalogId == catalogId) {
					index = i;
					break;
				}
			}
			if (index > -1) {
				validateNumberLicense.splice(index, 1);
			}
		}
		// loop 12 month in year.
		for (var k=1; k<=12; k++) {
			var id = document.getElementById("catalog_" + catalogId + "_month_" + k + "_year_" + year);
			if(listMonth.indexOf(month) > -1 ){//contain month 1,2,3
				if(id.defaultValue != "0"){
					id.value = id.defaultValue;
				} else {
					id.value = "0";
				}
			} else {
				if(listMonth2.indexOf(month) > -1 ){//contain month 4,5,6,7,8
					if(id.defaultValue != "0"){
						id.value = id.defaultValue;
					} else {
						id.value = "0";
					}
				} else {//contain month 9,10,11,12
					if (id != null && id != "null") {
						if(id.defaultValue != "0"){
							id.value = id.defaultValue;
						} else {
							id.value = "0";
						}
					}
					var idNext = document.getElementById("catalog_" + catalogId + "_month_" + k + "_year_" + nextYear);
					if (idNext != null && idNext != "null") {
						if(idNext.defaultValue != "0"){
							idNext.value =idNext.defaultValue;
						} else {
							idNext.value = "0";
						}
					}
				}
			}
		}
	}
}

//convert color rgb to hex
function rgb2hex(rgb) {
	rgb = rgb.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+))?\)$/);
	function hex(x) {
		return ("0" + parseInt(x).toString(16)).slice(-2);
	}
	return "#" + hex(rgb[1]) + hex(rgb[2]) + hex(rgb[3]);
}

//process value change on textbox license
function getValueChange(id) {
	var value = document.getElementById(id).value;
	var strSplit = [];
	strSplit = id.split("_");
	var catalogId = strSplit[1];
	var month = strSplit[3];
	var year = strSplit[5];
	
	for (var i=0;i<arrayCatalogIdChecked.length; i++) {
		var obj = arrayCatalogIdChecked[i];
		if (obj.catalogId == catalogId) {
			setValueObjectToArray(month, obj, value);
			break;
		}
	}
	for (var i = 0;i < validateNumberLicense.length; i++) {
		var objNum = validateNumberLicense[i];
		if (objNum.catalogId == catalogId) {
			var paseMonth = parseInt(month);
			var currentMonth = "catalog_month_" + paseMonth;
			if (objNum.hasOwnProperty(currentMonth)) {
				objNum[currentMonth] = value;
				break;
			} else {
				setValueValidateArray(paseMonth, objNum, value);
				break;
			}
		}
	}
}

//update value to object on arrayCatalogIdChecked
function setValueObjectToArray(month, obj, value) {
	var paseMonth = parseInt(month);
	switch(paseMonth) {
	case 4:
		obj.catalog_month_4 = value;
		break;
	case 5:
		obj.catalog_month_5 = value;
		break;
	case 6:
		obj.catalog_month_6 = value;
		break;
	case 7:
		obj.catalog_month_7 = value;
		break;
	case 8:
		obj.catalog_month_8 = value;
		break;
	case 9:
		obj.catalog_month_9 = value;
		break;
	case 10:
		obj.catalog_month_10 = value;
		break;
	case 11:
		obj.catalog_month_11 = value;
		break;
	case 12:
		obj.catalog_month_12 = value;
		break;
	case 1:
		obj.catalog_month_1 = value;
		break;
	case 2:
		obj.catalog_month_2 = value;
		break;
	case 3:
		obj.catalog_month_3 = value;
		break;
	}
}

// process validateNumberic
function validateNumberic(validateNumberLicense) {
	var reg = /^\d+$/;
	var errMsgNumberic = "";
	for (var i = 0; i < validateNumberLicense.length; i++) {
		var objNum = validateNumberLicense[i];
		var transData = $.map(objNum , function (value, key) {
			return [[key, value]];
		});
		for (var j = 0; j < transData.length; j++) {
			var objData = transData[j];
			var elementOne = objData[0];
			var elementTwo = objData[1];
			if (elementOne == "catalogId") {
				continue;
			} else {
				if (reg.test(elementTwo)) {
					continue;
				} else {
					errMsgNumberic += "入力データが数値ではありません。"+ "<br>";
				}
			}
		}
	}
	return errMsgNumberic;
}

//setValueValidateArray
function setValueValidateArray(paseMonth, objNum, value) {
	switch(paseMonth) {
	case 4:
		objNum["catalog_month_4"] = value;
		break;
	case 5:
		objNum["catalog_month_5"] = value;
		break;
	case 6:
		objNum["catalog_month_6"] = value;
		break;
	case 7:
		objNum["catalog_month_7"] = value;
		break;
	case 8:
		objNum["catalog_month_8"] = value;
		break;
	case 9:
		objNum["catalog_month_9"] = value;
		break;
	case 10:
		objNum["catalog_month_10"] = value;
		break;
	case 11:
		objNum["catalog_month_11"] = value;
		break;
	case 12:
		objNum["catalog_month_12"] = value;
		break;
	case 1:
		objNum["catalog_month_1"] = value;
		break;
	case 2:
		objNum["catalog_month_2"] = value;
		break;
	case 3:
		objNum["catalog_month_3"] = value;
		break;
	}
}

//Function load IpAddress first
function buildTableIpFirst (lengthIpAdd) {
	if (lengthIpAdd != null && lengthIpAdd != "0") {
		var length = parseInt(lengthIpAdd, 10);
		if (length < 10) {
			for (var i = length; i < 10; i++) {
				addRowDataIPInsert(i);
			}
		} else {
			addRowDataIPInsert(length);
		}
	} else {
		for (var j = 0; j < 10; j++) {
		var contentDataIpAdd = "";
		contentDataIpAdd += '<tr>'
	        +'<td style=\"min-width: 60px; text-align: right;\">'
	        + (j + 1)
	        +'</td>'
	        +'<td style=\"min-width: 100px; text-align: left;\"></td>'
	        +'<td style=\"min-width: 260px;\" class=\"text-center\">'
	        +'<input type="text" value="" style="width:95%;" placeholder="IPアドレスを入力してください" ></input>'
	        +'</td>'
	        +'<td style=\"min-width: 63px;\" class=\"text-center\"><input type="checkbox" value="1" /></td>'
	        +'</tr>';

		$("#IpDataInsertOrDelete").append(contentDataIpAdd);
		}
	}
}

//Add row table IPAddress
function addRowTable() {
var table = $("#dataIpAddressTable tbody tr");
var lengthRowTable = table.length;
$('#dataIpAddressTable tbody').append(
		'<tr>'// need to change closing tag to an opening `<tr>` tag.
		+'<td style=\"min-width: 60px; text-align: right;\">'
		+ (lengthRowTable + 1)
		+'</td>'
		+'<td style=\"min-width: 100px; text-align: left;\"></td>'
		+'<td style=\"min-width: 260px;\" class=\"text-center\">'
		+'<input type="text" value="" style="width:95%;" placeholder="IPアドレスを入力してください" ></input>'
		+'</td>'
		+'<td style=\"min-width: 63px;\" class=\"text-center\"><input type="checkbox" value="1" /></td>'
		+'</tr>');
}

//validate format IP Address
function validateIpAdd(ipArr) {
	var regexIpSingle = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9]?)$/;
	var regexIpArr = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9]?)\-(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9]?)$/;
	var regexIpAll = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9]?)\.){3}(\*)$/;
	var flagRegEx = false;
	 var errMsgIpAdd = "";
	var length = ipArr.length;
	for (var i = 0; i < ipArr.length; i++) {
		var ipAdd = ipArr[i];
		if (regexIpSingle.test(ipAdd)) {
			continue;
		} else if (regexIpAll.test(ipAdd)) {
			continue;
		} else if (regexIpArr.test(ipAdd)) {
			var splitIPAddress = ipAdd.split(".");
			var ipEnd = splitIPAddress[3].split("-");
			var ipInputOne = parseInt(ipEnd[0]);
			var ipInputTwo = parseInt(ipEnd[1]);
			if (ipInputOne < ipInputTwo) {
				continue;
			} else {
				errMsgIpAdd += "IPアドレス" +ipArr[i]+" は "+ipInputOne+"の値が"+ipInputTwo+"の値より小さくなければなりません("+ipEnd+")"+"</br>";
				if (i == (ipArr.length - 1)) {
					flagRegEx = true;
				} else {
					continue;
				}
			} 
		} else {
			errMsgIpAdd += "IPアドレス"+ ipArr[i] +"のフォーマットが不正です。" +"</br>";
			if (i == (ipArr.length - 1)) {
				flagRegEx = true;
			} else {
				continue;
			}
		}
	}
	if (errMsgIpAdd == "" && ipArr.length > 1) {
		var errMsgDouble = validateDoubleIpAdd(ipArr);
		errMsgIpAdd += errMsgDouble;
	}
	return errMsgIpAdd;
}

//validate double IP Address
function validateDoubleIpAdd(ipArr) {
	var ipAddOneList = [];
	var ipAddTwoList = [];
	var ipAddElement = "";
	var ipSplit = [];
	var ipAddElementOneFront = "";
	var ipAddElementTwoFront = "";
	var ipAddElementOneAfter = "";
	var ipAddElementTwoAfter = "";
	var errMsgDouble = "";
	var flagIp = false;
	var flagCompare1 = false;
	var flagCompare2 = false;
	var length = ipArr.length;
	for (var i = 0; i < length; i++) {
		ipAddElement = ipArr[i];
		ipSplit = [];
		ipSplit = ipAddElement.split(".");
		ipAddElementOneFront = "";
		for (var j = 0; j < 3; j++) {
			ipAddElementOneFront += ipSplit[j];
			ipAddElementOneFront += "."
		}
		ipAddOneList.push(ipAddElementOneFront);
		ipAddTwoList.push(ipSplit[3]);
	}
	ipAddElementOneFront = "";
	ipAddElementTwoFront = "";
	for (var i = 0; i < length; i++) {
		ipAddElementOneFront = ipAddOneList[i]
		ipAddElementTwoFront = ipAddTwoList[i]
		if (ipAddElementTwoFront.indexOf("*") != -1) {
			//
		} else if (ipAddElementTwoFront.indexOf("-") != -1) {
			ipSplit = [];
			ipSplit = ipAddElementTwoFront.split("-");
			var resultElementTwoFront1 = parseInt(ipSplit[0], 10);
			var resultElementTwoFront2 = parseInt(ipSplit[1], 10);
		} else {
			var resultElementTwoFront = parseInt(ipAddElementTwoFront, 10) ;
		}
		ipAddElementOneAfter = "";
		ipAddElementTwoAfter = "";
		for (var j = (length - 1); j > i; j--) {
			ipAddElementOneAfter = ipAddOneList[j];
			ipAddElementTwoAfter = ipAddTwoList[j];
			if (ipAddElementTwoAfter.indexOf("*") != -1) {
				//
			} else if (ipAddElementTwoAfter.indexOf("-") != -1) {
				ipSplit = [];
				ipSplit = ipAddElementTwoAfter.split("-");
				var resultTestElementTwoAfter1 = parseInt(ipSplit[0], 10);
				var resultTestElementTwoAfter2 = parseInt(ipSplit[1], 10);
			} else {
				var resultElementTwoAfter = parseInt(ipAddElementTwoAfter, 10);
			}
			flagCompare1 = false;
			flagCompare2 = false;
			if (resultElementTwoFront1 <= resultElementTwoAfter && resultElementTwoAfter <= resultElementTwoFront2) {
				flagCompare1 = true;
			}
			if (resultTestElementTwoAfter1 <= resultElementTwoFront && resultElementTwoFront <= resultTestElementTwoAfter2) {
				flagCompare2 = true;
			}
			
			if (ipAddElementOneFront == ipAddElementOneAfter) {//IPアドレス「xxx」は「YYY」と重複しています。
				if (ipAddElementTwoFront == "*" || ipAddElementTwoAfter == "*") {
					errMsgDouble += "IPアドレス"+ ((ipAddOneList[i])+(ipAddTwoList[i]))+ "は"+((ipAddOneList[j])+(ipAddTwoList[j]))+"と重複しています。"+"</br>";
				} else if (flagCompare1 || flagCompare2) {
					errMsgDouble += "IPアドレス"+ ((ipAddOneList[i])+(ipAddTwoList[i]))+ "は"+((ipAddOneList[j])+(ipAddTwoList[j]))+"と重複しています。"+"</br>";
						flagIp = true;
				} else if(resultElementTwoFront == resultElementTwoAfter){
					errMsgDouble += "IPアドレス"+ ((ipAddOneList[i])+(ipAddTwoList[i]))+ "は"+((ipAddOneList[j])+(ipAddTwoList[j]))+"と重複しています。"+"</br>";
				}
			}
		}
	}
	return errMsgDouble;
}

//get data each row in table
function getIpAddInfo (){
	inputIPAddArr = [];
	ipArr = [];
	var table = $("#dataIpAddressTable tbody");

	table.find('tr').each(function (i) {
		var status = $(this).find('td').eq(1).text().trim();
		var ipAdd = $(this).find('td input:first').val();
		var checkDel = $(this).find('td input[type=checkbox]:checked').val();
		if (ipAdd != "" && checkDel == 1) {
			var param = {
					status: status,
					ipAdd: ipAdd,
					checkDel: checkDel,
			    };
			ipArr.push(ipAdd);
			inputIPAddArr.push(param);
		} else if (status != "申請済" && status != "申請中" && ipAdd != "") {
			var param = {
					status: status,
					ipAdd: ipAdd,
					checkDel: "0",
			    };
			ipArr.push(ipAdd);
			inputIPAddArr.push(param);
		}
	});
}

//Add Row default when row #10
function addRowDataIPInsert(i) {
		var contentDataIpAdd = "";
		contentDataIpAdd += '<tr>'
			+'<td style=\"min-width: 60px; text-align: right;\">'
			+ (i + 1)
			+'</td>'
			+'<td style=\"min-width: 100px; text-align: left;\"></td>'
			+'<td style=\"min-width: 260px;\" class=\"text-center\">'
			+'<input type="text" value="" style="width:95%;" placeholder="IPアドレスを入力してください" ></input>'
			+'</td>'
			+'<td style=\"min-width: 63px;\" class=\"text-center\"><input type="checkbox" value="1" /></td>'
			+'</tr>';
		$("#IpDataInsertOrDelete").append(contentDataIpAdd);
}
