	/**
	 * managerLicense
	 * @since 2017/10/02
	 */
	function managerLicense() {
		var projectName = sessionStorage.getItem('projectName');
		document.getElementById("projectCombo").value= projectName;
		var yearSelect = sessionStorage.getItem('yearSelect');
		document.getElementById("yearCombo").value= yearSelect;
		var monthSelect = sessionStorage.getItem('monthSelect');
		document.getElementById("monthCombo").value= monthSelect;

		document.getElementById("managerLicenseForm").submit();
	}

	/**
	 * exportCSV
	 * @since 2017/10/02
	 */
	function exportCSV() {
		//Get ID Project follow Project Name
		var projectId = $('#projectNameSelect').val();
		//Get year select
		var year = $('#yearSelect').val();
		//Get month select
		var month = $('#monthSelect').val();
		
		document.getElementById("projectComboxCsv").value= projectId;
		document.getElementById("yearComboxCsv").value= year;
		document.getElementById("monthComboxCsv").value= month;
		window.location = "exportDetailLicenseStatus?"
				+ $('#exportCsvForm')
						.serialize();
	};

	//Handle event change Project
	$('#projectNameSelect').change(function(e){
		// Load data when change Project
		filterDetailLicenseUsage();
	});
	
	$('#yearSelect').change(function(e){
		// Load data when change year
		filterDetailLicenseUsage();
	});
	
	$('#monthSelect').change(function(e){
		// Load data when change month
		filterDetailLicenseUsage();
	});
	
	// Handle event click radio button
	$("input[name$='filterRadio']").click(function(e) {
		filterByType();
	});

	/**
	 * filterDetailLicenseUsage
	 * @since 2017/10/02
	 */
	function filterDetailLicenseUsage() {
		//Get ID Project follow Project Name
		var projectId = $('#projectNameSelect').val();
		document.getElementById("projectCombox").value= projectId;
		//Get year select
		var year = $('#yearSelect').val();
		document.getElementById("yearCombox").value= year;
		//Get month select
		var month = $('#monthSelect').val();
		document.getElementById("monthCombox").value= month;

		document.getElementById("viewDetailLicenseForm").submit();
	}

	/**
	 * filterByType
	 * @since 2017/10/02
	 */
	function filterByType() {
		//Get ID Project follow Project Name
		var projectId = $('#projectNameSelect').val();
		document.getElementById("projectCombox").value= projectId;
		//Get year select
		var year = $('#yearSelect').val();
		document.getElementById("yearCombox").value= year;
		//Get month select
		var month = $('#monthSelect').val();
		document.getElementById("monthCombox").value= month;
		//Get radio button select
		var filterTool = $('#filterByTool').prop('checked');
		document.getElementById("filterTool").value= filterTool;
		var filterProduct = $('#filterByProduct').prop('checked');
		document.getElementById("filterProduct").value= filterProduct;
		var filterProject = $('#filterByProject').prop('checked');
		document.getElementById("filterProject").value= filterProject;

		document.getElementById("viewDetailLicenseForm").submit();
	}

