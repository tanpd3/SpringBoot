﻿// ファイル変換/DB出力の動作確認用

///**
// * File convert
// * @author	T.Obara@@tsr
// * @since	2017.07.20
// */
var fileConvert = new function() {

	var _self = this;
//	this.exportCSV = function() {
//		document.body.style.cursor = "wait" ;
//
//		window.alert("Start the file conversion.");
//		$.ajax({
//			async: true,
//			url : 'timerExportCSV',
//			data : null,
//			dataType : 'json',
//			type : 'POST',
//			success : function(res) {
//				document.body.style.cursor = "default" ;
//				btn1.disabled= false ;
//				txt.value = "" ;
//			},
//			error : function(xhr, textStatus, errorThrown) {
//				console.log('An error occurred! ' + errorThrown);
//				document.body.style.cursor = "default" ;
//				btn1.disabled= false ;
//				txt.value = "" ;
//			}
//		});
//	};
	
	/**
	 * Convert
	 * @author	T.Obara@@tsr
	 * @since	2017.07.20
	 */
	this.convert = function() {
		document.body.style.cursor = "wait" ;
		var btn1 = document.getElementById('btn_file_convert');
		var btn2 = document.getElementById('btn_output_db');
		btn1.disabled= true ;
	    btn2.disabled= true ;

		var txt = document.getElementById('txt_file_convert');
		txt.value = "     Running....." ;


		window.alert("Start the file conversion.");
		$.ajax({
			async: true,
			url : 'convertFile',
			data : null,
			dataType : 'json',
			type : 'POST',
			success : function(res) {
				window.alert("★Success!");
				document.body.style.cursor = "default" ;
				btn1.disabled= false ;
	     		btn2.disabled= false ;
				txt.value = "" ;
			},
			error : function(xhr, textStatus, errorThrown) {
				window.alert("★Error...");
				console.log('An error occurred! ' + errorThrown);
				document.body.style.cursor = "default" ;
				btn1.disabled= false ;
	     		btn2.disabled= false ;
				txt.value = "" ;
			}
		});
	};

//	/**
//	 * Output DB
//	 * @author	T.Obara@@tsr
//	 * @since	2017.08.09
//	 */
	this.outputDB = function() {
		document.body.style.cursor = "wait" ;
		var btn1 = document.getElementById('btn_file_convert');
		var btn2 = document.getElementById('btn_output_db');
		btn1.disabled= true ;
	    btn2.disabled= true ;
		var txt = document.getElementById('txt_file_convert');
		txt.value = "     Running....." ;

//		window.alert("DB出力ボタンが押されました。");
		window.alert("Start import DB.");
		$.ajax({
			async: true,
			url : 'outputDB',
			data : null,
			dataType : 'json',
			type : 'POST',
			success : function(res) {
				window.alert("★Success!");
				document.body.style.cursor = "default" ;
				btn1.disabled= false ;
	     		btn2.disabled= false ;
				txt.value = "" ;
			},
			error : function(xhr, textStatus, errorThrown) {
				window.alert("★Error...");
				console.log('An error occurred! ' + errorThrown);
				document.body.style.cursor = "default" ;
				btn1.disabled= false ;
	     		btn2.disabled= false ;
				txt.value = "" ;
			}
		});
	};
};