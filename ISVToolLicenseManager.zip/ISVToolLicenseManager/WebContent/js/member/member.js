$("select.status-select").click(function(evnet){
	$(event).closet("div.");
});

$("#AccountTypeMail").click(function(event){
	setAddModalState();
});

$("#AccountTypeDepartment").click(function(event){
	setAddModalState();
});

// setAddModalState
function setAddModalState(){
	var maile = $("#AccountTypeMail").is(':checked');
	if(maile == true){
		$("#newEmail").removeAttr("disabled");
		$("#selectedCompany").attr("disabled", "disabled");
		$("#selectedDepartment").attr("disabled", "disabled");
	} else {
		$("#newEmail").attr("disabled", "disabled");
		$("#selectedCompany").removeAttr("disabled");
		$("#selectedDepartment").removeAttr("disabled");
	}
}

