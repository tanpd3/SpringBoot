package jp.meportal.isv.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.meportal.isv.business.MemberBusiness;
import jp.meportal.isv.business.ProjectBusiness;
import jp.meportal.isv.business.SupporterBusiness;
import jp.meportal.isv.business.impl.MemberBusinessImpl;
import jp.meportal.isv.business.impl.ProjectBusinessImpl;
import jp.meportal.isv.business.impl.SupporterBusinessImpl;
import jp.meportal.isv.common.PortalCoreAccessManager;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.constant.ErrorCodes;
import jp.meportal.isv.entity.Member;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ProjectBelongInfo;
import jp.meportal.isv.entity.Support;
import jp.meportal.isv.entity.UserInfo;
import jp.meportal.isv.formbean.RegistrationProjectFormBean;
import jp.meportal.isv.model.MemberJsonDto;
import jp.meportal.isv.util.DateUtils;
import jp.meportal.isv.util.EmailUtil;
import jp.meportal.isv.util.PropertiesUtil;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

/**
 * Class Name: ProjectAction<br>
 * Created date: 2017/05/05<br>
 * 
 * @author FPT
 */
public class ProjectAction extends BaseAction {
    private static final long serialVersionUID = 1L;
    final static Logger logger = Logger.getLogger(ProjectAction.class);

    public ProjectBusiness projectBusiness;
    public SupporterBusiness supporterBusiness;
    public MemberBusiness memberBusiness;
    private RegistrationProjectFormBean regProFormBean;
    private Project project;
    private List<Project> listPro;
    private List<ProjectBelongInfo> listProjectBelongInfo;
    private List<Member> listMember;
    private List<MemberJsonDto> memberByIdList;
    private String mbProjectName;
    private String warningMsg = StringUtils.EMPTY;
    private String userBelongCompanyName;
    private String userBelongDepartmentName;
    private boolean loadFirstFlag = Constants.LOAD_FIRST_FLAG;
    private int resultRegisterProject;
    private int projectId;
    private int displayFlag;
    
    /**
     * ProjectAction
     */
    public ProjectAction() {
        projectBusiness = new ProjectBusinessImpl();
        supporterBusiness = new SupporterBusinessImpl();
        memberBusiness = new MemberBusinessImpl();
        this.initAction();
    }

    /**
     * initRegisterProject
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    public String initRegisterProject() {
        if (!isValidateUser()) {
            return LOGIN;
        }
        UserInfo userInfo = getUserInfo(null, ServletActionContext.getRequest());
        regProFormBean = new RegistrationProjectFormBean();
        regProFormBean.setManagerName(userInfo.getUserName());
        regProFormBean.setEmailAddress(this.getEmailAddress());
        String loadOriginCode = userInfo.getUserBelongDepartmentCd();
        regProFormBean.setLoadOriginCode(loadOriginCode);
        String[] loadOriginCodeList = loadOriginCode.split("");
        if (loadOriginCodeList != null && loadOriginCodeList.length > 0) {
            regProFormBean.setLoadOriginCode1(loadOriginCodeList[0]);
            regProFormBean.setLoadOriginCode2(loadOriginCodeList[1]);
            regProFormBean.setLoadOriginCode3(loadOriginCodeList[2]);
            regProFormBean.setLoadOriginCode4(loadOriginCodeList[3]);
            regProFormBean.setLoadOriginCode5(loadOriginCodeList[4]);
            regProFormBean.setLoadOriginCode6(loadOriginCodeList[5]);
                //regProFormBean.setLoadOriginCode7(Constants.ZERO);
                //regProFormBean.setLoadOriginCode8(Constants.ZERO);
                //regProFormBean.setLoadOriginCode9(Constants.ZERO);
        }
        regProFormBean.setCostCode1(Constants.ZERO);
        regProFormBean.setCostCode2(Constants.ZERO);
        regProFormBean.setCostCode3(Constants.ZERO);
            //regProFormBean.setCostCode4(Constants.ZERO);
        this.showProjectInfor(this.getEmailAddress());
        return SUCCESS;
    }

    /**
     * registerOrUpdateProject
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    public String registerOrUpdateProject() {
        if (!isValidateUser()) {
            return LOGIN;
        }
        UserInfo userInfo = getUserInfo(null, ServletActionContext.getRequest());
        int isManager = Constants.MANAGER_FALSE;
        if (regProFormBean != null) {
            if (regProFormBean.getProjectName() == null || regProFormBean.getProjectName().isEmpty()) {
                regProFormBean.setWarningMessage(ErrorCodes.ERRORS_CODE_INVALID_PROJECT_NAME);
                return SUCCESS;
            }
            project = projectBusiness.findProjectByName(regProFormBean.getProjectName());
            if (project != null) {
                String emailUserLogin = userInfo.getEmailAddress();
                String emailManagerProject = project.getManagerEmail();

                Support supportExisted = supporterBusiness.getSupportDb(userInfo.getEmailAddress());
                boolean permissonManager = emailUserLogin.equalsIgnoreCase(emailManagerProject);
                if (supportExisted != null || permissonManager) {// Check permisson manager
                    warningMsg = PropertiesUtil
                            .getMessageProperties("isv.project_existed_warning_message_confirm_update.txt");
                    resultRegisterProject = Constants.REGISTER_WARNING;
                } else {
                    warningMsg = PropertiesUtil.getMessageProperties("isv.project_existed_warning_message.txt");
                    resultRegisterProject = Constants.REGISTER_FAIL;
                }
                if (warningMsg != null) {
                    setWarningMsg(warningMsg);// set warningMsg
                    this.showProjectInfor(this.getEmailAddress());// show project infor
                    return SUCCESS;
                }
            } else {// if project was not existed in DB
                isManager = Constants.MANAGER_TRUE;
                project = new Project();
                //String loadOriginCode = (regProFormBean.getLoadOriginCode1())
                //        .concat(regProFormBean.getLoadOriginCode2())
                //        .concat(regProFormBean
                //                .getLoadOriginCode3()
                //                .concat(regProFormBean
                //                        .getLoadOriginCode4()
                //                        .concat(regProFormBean
                //                                .getLoadOriginCode5()
                //                                .concat(regProFormBean.getLoadOriginCode6().concat(
                //                                        Constants.DASH_CHARACTERS.concat(regProFormBean
                //                                                .getLoadOriginCode7().concat(
                //                                                        regProFormBean.getLoadOriginCode8().concat(
                //                                                                regProFormBean.getLoadOriginCode9()))))))));
                String loadOriginCode = regProFormBean.getLoadOriginCode1()
                		+regProFormBean.getLoadOriginCode2()
                		+regProFormBean.getLoadOriginCode3()
                		+regProFormBean.getLoadOriginCode4()
                		+regProFormBean.getLoadOriginCode5()
                		+regProFormBean.getLoadOriginCode6();
                project.setCreateDated(DateUtils.convertDateToString(new Date(), Constants.DATE_FORMAT_UPDATE));
                project.setProjectName(regProFormBean.getProjectName());
                project.setManagerName(regProFormBean.getManagerName());
                project.setManagerEmail(regProFormBean.getEmailAddress());
                project.setLoadOriginCode(loadOriginCode);
                String costCode1 = regProFormBean.getCostCode1();
                String costCode2 = regProFormBean.getCostCode2();
                String costCode3 = regProFormBean.getCostCode3();
                    //String costCode4 = regProFormBean.getCostCode4();
                //String costCode = costCode1.concat(Constants.DASH_CHARACTERS.concat(costCode2).concat(
                //        costCode3.concat(costCode4)));
                String costCode = costCode1+costCode2+costCode3;
                project.setCostCode(costCode);
                project.setStatus(Constants.UN_APPROVED_STATUS);
                project.setComment(regProFormBean.getComment());
                project.setProductNumber(regProFormBean.getProductNumber());

                project = projectBusiness.registerOrUpdateProject(project, isManager);
                this.showProjectInfor(this.getEmailAddress());// show project list
                if (project != null && project.getSeqNo() > 0) {// if insert success then send mail
                    try {
                        String mailList = supporterBusiness.getMailList();
                        String ccmail = userInfo.getEmailAddress();

                        boolean flagSendMail = EmailUtil.sendEmail(Constants.REGISTER_PROJECT_SUBJECT,
                                Constants.HEADER_TEMPLATE_REGISTER_PROJECT, Constants.FOOTER_TEMPLATE_REGISTER_PROJECT,
                                Constants.CONTENT_TEMPLATE_REGISTER_PROJECT, mailList, ccmail, userInfo.getUserName(),
                                userInfo.getUserBelongDepartmentName(), project.getProjectName(),
                                project.getManagerName(), userInfo.getUserBelongDepartmentCd(),
                                project.getLoadOriginCode(), project.getCostCode(), project.getProductNumber(),
                                project.getComment());
                        if (flagSendMail) {
                            warningMsg = PropertiesUtil.getMessageProperties("isv.email.send.success");
                            resultRegisterProject = Constants.REGISTER_SUCCESS;
                        }
                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                    }
                }
            }
            return SUCCESS;
        } else {
            exceptionMsg = ErrorCodes.ERRORS_CODE_REG_PRO_FORM_IS_NULL;
            return ERROR;
        }
    }

    /**
     * updateProjectInfo
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    public String updateProjectInfo() throws Exception {
        if (!isValidateUser()) {
            return LOGIN;
        }
        UserInfo userInfo = getUserInfo(null, ServletActionContext.getRequest());
        int isManager = Constants.MANAGER_TRUE;
        project = projectBusiness.findProjectByName(regProFormBean.getProjectName());
        if (project != null) {
            project.setManagerName(regProFormBean.getManagerName());
            project.setManagerEmail(regProFormBean.getEmailAddress());
            project.setLoadOriginCode(regProFormBean.getLoadOriginCode());
            project.setCostCode(regProFormBean.getCostCode());
            project.setStatus(Constants.UN_APPROVED_STATUS);
            project.setComment(regProFormBean.getComment());
            project.setProductNumber(regProFormBean.getProductNumber());
            project.setUpdateDated(DateUtils.convertDateToString(new Date(), Constants.DATE_FORMAT_UPDATE));

            PortalCoreAccessManager pcMgr = new PortalCoreAccessManager();
            List<String> emailList = new ArrayList<String>();
            emailList.add(project.getManagerEmail());
            List<MemberJsonDto> managerInfo = pcMgr.getMembersListById(emailList);// Get members by email from Portal core
            project = projectBusiness.updateProject(project, isManager);
            if (project != null) {// if update success then send mail
                try {
                    String mailList = supporterBusiness.getMailList();
                    String ccmail = project.getManagerEmail();

                    boolean flagSendMail = EmailUtil.sendEmail(Constants.UPDATE_PROJECT_SUBJECT,
                            Constants.HEADER_TEMPLATE_REGISTER_PROJECT, Constants.FOOTER_TEMPLATE_REGISTER_PROJECT,
                            Constants.CONTENT_TEMPLATE_REGISTER_PROJECT, mailList, ccmail, project.getManagerName(),
                            managerInfo.get(0).getDepartmentName(), project.getProjectName(), project.getManagerName(),
                            userInfo.getUserBelongDepartmentCd(), project.getLoadOriginCode(), project.getCostCode(),
                            project.getProductNumber(), project.getComment());
                    if (flagSendMail) {
                        warningMsg = PropertiesUtil.getMessageProperties("isv.email.send.success");
                        resultRegisterProject = Constants.REGISTER_SUCCESS;
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
            return SUCCESS;
        } else {
            exceptionMsg = ErrorCodes.ERRORS_CODE_IN_VALID_USER;
            return ERROR;
        }
    }

    /**
     * updateProjectRegister
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    public String updateProjectRegister() throws Exception {
        if (!isValidateUser()) {
            return LOGIN;
        }
        UserInfo userInfo = getUserInfo(null, ServletActionContext.getRequest());
        int isManager = Constants.MANAGER_TRUE;
        project = projectBusiness.findProjectByName(regProFormBean.getProjectName());
        if (project != null) {
            String loadOriginCode = (regProFormBean.getLoadOriginCode1()).concat(regProFormBean.getLoadOriginCode2())
                    .concat(regProFormBean.getLoadOriginCode3().concat(
                            regProFormBean.getLoadOriginCode4().concat(
                                    regProFormBean.getLoadOriginCode5().concat(
                                            regProFormBean.getLoadOriginCode6().concat(
                                                    Constants.DASH_CHARACTERS.concat(regProFormBean
                                                            .getLoadOriginCode7().concat(
                                                                    regProFormBean.getLoadOriginCode8().concat(
                                                                            regProFormBean.getLoadOriginCode9()))))))));
            String costCode = (regProFormBean.getCostCode1()).concat(Constants.DASH_CHARACTERS.concat(
                    regProFormBean.getCostCode2()).concat(
                    regProFormBean.getCostCode3().concat(regProFormBean.getCostCode4())));
            project.setManagerName(regProFormBean.getManagerName());
            project.setManagerEmail(regProFormBean.getEmailAddress());
            project.setLoadOriginCode(loadOriginCode);
            project.setCostCode(costCode);
            project.setStatus(Constants.UN_APPROVED_STATUS);
            project.setComment(regProFormBean.getComment());
            project.setProductNumber(regProFormBean.getProductNumber());
            project.setUpdateDated(DateUtils.convertDateToString(new Date(), Constants.DATE_FORMAT_UPDATE));

            PortalCoreAccessManager pcMgr = new PortalCoreAccessManager();
            List<String> emailList = new ArrayList<String>();
            emailList.add(project.getManagerEmail());
            List<MemberJsonDto> managerInfo = pcMgr.getMembersListById(emailList);// Get members email from Portal core
            project = projectBusiness.updateProject(project, isManager);
            if (project != null) {// if update success then send mail
                try {
                    String mailList = supporterBusiness.getMailList();
                    String ccmail = project.getManagerEmail();

                    boolean flagSendMail = EmailUtil.sendEmail(Constants.UPDATE_PROJECT_SUBJECT,
                            Constants.HEADER_TEMPLATE_REGISTER_PROJECT, Constants.FOOTER_TEMPLATE_REGISTER_PROJECT,
                            Constants.CONTENT_TEMPLATE_REGISTER_PROJECT, mailList, ccmail, project.getManagerName(),
                            managerInfo.get(0).getDepartmentName(), project.getProjectName(), project.getManagerName(),
                            userInfo.getUserBelongDepartmentCd(), project.getLoadOriginCode(), project.getCostCode(),
                            project.getProductNumber(), project.getComment());
                    if (flagSendMail) {
                        warningMsg = PropertiesUtil.getMessageProperties("isv.email.send.success");
                        resultRegisterProject = Constants.REGISTER_SUCCESS;
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
            return SUCCESS;
        } else {
            exceptionMsg = ErrorCodes.ERRORS_CODE_PROJECT_NOT_EXIST;
            return ERROR;
        }
    }
    
    /**
     * showProjectMemberInfo
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    public String showProjectMemberInfo() throws ConfigurationException {
        if (!isValidateUser()) {
            return LOGIN;
        }
        UserInfo userInfo = getUserInfo(null, ServletActionContext.getRequest());
        userBelongCompanyName = userInfo.getUserBelongCompanyName();
        userBelongDepartmentName = userInfo.getUserBelongDepartmentName();

        Member member = memberBusiness.checkExistEmailMember(userInfo.getEmailAddress());
        if (member != null) {
            listPro = new ArrayList<Project>();
            listPro = projectBusiness.listAllProjectByMember(Constants.APPROVED_STATUS, member,
                    userInfo.getEmailAddress(), isSupportor);
        }
        boolean flag = isLoadFirstFlag();
        if (flag == Constants.LOAD_FIRST_FLAG) {
            if (listPro != null && listPro.size() > 0) {
                int projectIdPos1 = listPro.get(0).getSeqNo();
                setMbProjectName(listPro.get(0).getProjectName());
                listMember = memberBusiness.getMemberInfoList(projectIdPos1);

                PortalCoreAccessManager pcMgr = new PortalCoreAccessManager();
                List<String> emailList = new ArrayList<String>();
                Map<String, Integer> mapEmail = new HashMap<String, Integer>();
                
                this.setMembersList(pcMgr, emailList, mapEmail);// set Members list
            }
            setLoadFirstFlag(false);
        }
        return SUCCESS;
    }

    /**
     * getMemberInfoList
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    public String getMemberInfoList() throws ConfigurationException {
        if (!isValidateUser()) {
            return LOGIN;
        }
        Project projectDB = projectBusiness.findProjectBySeqNo(projectId);
        if (projectDB != null) {
            listMember = memberBusiness.getMemberInfoList(projectId);

            PortalCoreAccessManager pcMgr = new PortalCoreAccessManager();
            List<String> emailList = new ArrayList<String>();
            Map<String, Integer> mapEmail = new HashMap<String, Integer>();
            this.setMembersList(pcMgr, emailList, mapEmail);// set Members list
            
            setDisplayFlag(Constants.SHOW);
            setMbProjectName(projectDB.getProjectName());
            this.showProjectMemberInfo();// reload get all project
        } else {
            exceptionMsg = ErrorCodes.ERRORS_CODE_PROJECT_NOT_EXIST;
            return ERROR;
        }
        return SUCCESS;
    }

    /**
     * showProjectInfor
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    private void showProjectInfor(String email) {
        Member member = memberBusiness.checkExistEmailMember(email);
        if (member != null) {
            listPro = new ArrayList<Project>();
            listPro = projectBusiness.listAllProjectByManager(Constants.APPROVED_STATUS, member, email, isSupportor);
        }
    }
    
    /**
     * setMembersList
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    private void setMembersList(PortalCoreAccessManager pcMgr, List<String> emailList, Map<String, Integer> mapEmail) {
        String emailValue = StringUtils.EMPTY;
        String emailMember = StringUtils.EMPTY;
        String dateUpdate = StringUtils.EMPTY;
        String dateRegistion = StringUtils.EMPTY;
        ManagerAction managerAction = new ManagerAction();
        try {
            if (listMember != null && listMember.size() > 0) {
                for (int i = 0; i < listMember.size(); i++) {
                    emailValue = listMember.get(i).getEmail();
                    mapEmail.put(emailValue.toLowerCase(), i);
                    emailList.add(emailValue);
                }
                memberByIdList = pcMgr.getMembersListById(emailList);// Get members by emails from Portal core
                
                // START 20180126 - FPT - for #27465 - Add
                List<MemberJsonDto> listMemberAdd = managerAction.getMemberList(emailList, memberByIdList);
                memberByIdList.addAll(listMemberAdd);
                // END 20180126 - FPT - for #27465 - Add
                
                if (memberByIdList.size() > 0) {// Mapping list email & status
                    MemberJsonDto mem;
                    int indexStatus = 0;
                    for (int i = 0; i < memberByIdList.size(); i++) {
                        mem = memberByIdList.get(i);
                        emailMember = mem.getEmail();
                        if (mapEmail.get(emailMember.toLowerCase()) != null) {
                            indexStatus = mapEmail.get(emailMember.toLowerCase());
                        }
                        mem.setIsManager(listMember.get(indexStatus).getIsManager());
                        dateUpdate = listMember.get(indexStatus).getRegistrationDate();
                        dateRegistion = dateUpdate.replace("-", "/");// convert date
                        mem.setCreateDate(dateRegistion);
                        memberByIdList.set(i, mem);
                    }
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    /**
     * @param regProFormBean
     */
    public RegistrationProjectFormBean getRegProFormBean() {
        return regProFormBean;
    }

    /**
     * @param regProFormBean
     *            the regProFormBean to set
     */
    public void setRegProFormBean(RegistrationProjectFormBean regProFormBean) {
        this.regProFormBean = regProFormBean;
    }

    /**
     * @param project
     */
    public Project getProject() {
        return project;
    }

    /**
     * @param project
     *            the project to set
     */
    public void setProject(Project project) {
        this.project = project;
    }

    /**
     * @param listPro
     */
    public List<Project> getListPro() {
        return listPro;
    }

    /**
     * @param listPro
     *            the listPro to set
     */
    public void setListPro(List<Project> listPro) {
        this.listPro = listPro;
    }

    /**
     * @param listMember
     */
    public List<Member> getListMember() {
        return listMember;
    }

    /**
     * @param listMember
     *            the listMember to set
     */
    public void setListMember(List<Member> listMember) {
        this.listMember = listMember;
    }

    /**
     * @param projectId
     */
    public int getProjectId() {
        return projectId;
    }

    /**
     * @param projectId
     *            the projectId to set
     */
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    /**
     * @param displayFlag
     */
    public int getDisplayFlag() {
        return displayFlag;
    }

    /**
     * @param displayFlag
     *            the displayFlag to set
     */
    public void setDisplayFlag(int displayFlag) {
        this.displayFlag = displayFlag;
    }

    /**
     * @param mbProjectName
     */
    public String getMbProjectName() {
        return mbProjectName;
    }

    /**
     * @param mbProjectName
     *            the mbProjectName to set
     */
    public void setMbProjectName(String mbProjectName) {
        this.mbProjectName = mbProjectName;
    }

    /**
     * @param warningMsg
     */
    public String getWarningMsg() {
        return warningMsg;
    }

    /**
     * @param warningMsg
     *            the warningMsg to set
     */
    public void setWarningMsg(String warningMsg) {
        this.warningMsg = warningMsg;
    }

    /**
     * @param loadFirstFlag
     */
    public boolean isLoadFirstFlag() {
        return loadFirstFlag;
    }

    /**
     * @param loadFirstFlag
     *            the loadFirstFlag to set
     */
    public void setLoadFirstFlag(boolean loadFirstFlag) {
        this.loadFirstFlag = loadFirstFlag;
    }

    /**
     * @param userBelongCompanyName
     */
    public String getUserBelongCompanyName() {
        return userBelongCompanyName;
    }

    /**
     * @param userBelongCompanyName
     *            the userBelongCompanyName to set
     */
    public void setUserBelongCompanyName(String userBelongCompanyName) {
        this.userBelongCompanyName = userBelongCompanyName;
    }

    /**
     * @param userBelongDepartmentName
     */
    public String getUserBelongDepartmentName() {
        return userBelongDepartmentName;
    }

    /**
     * @param userBelongDepartmentName
     *            the userBelongDepartmentName to set
     */
    public void setUserBelongDepartmentName(String userBelongDepartmentName) {
        this.userBelongDepartmentName = userBelongDepartmentName;
    }
    
    /**
     * @param listProjectBelongInfo
     */
    public List<ProjectBelongInfo> getListProjectBelongInfo() {
        return listProjectBelongInfo;
    }

    /**
     * @param listProjectBelongInfo
     *            the listProjectBelongInfo to set
     */
    public void setListProjectBelongInfo(List<ProjectBelongInfo> listProjectBelongInfo) {
        this.listProjectBelongInfo = listProjectBelongInfo;
    }

    /**
     * @param resultRegisterProject
     */
    public int getResultRegisterProject() {
        return resultRegisterProject;
    }

    /**
     * @param resultRegisterProject
     *            the resultRegisterProject to set
     */
    public void setResultRegisterProject(int resultRegisterProject) {
        this.resultRegisterProject = resultRegisterProject;
    }

    /**
     * @param memberByIdList
     */
    public List<MemberJsonDto> getMemberByIdList() {
        return memberByIdList;
    }

    /**
     * @param memberByIdList
     *            the memberByIdList to set
     */
    public void setMemberByIdList(List<MemberJsonDto> memberByIdList) {
        this.memberByIdList = memberByIdList;
    }

}
