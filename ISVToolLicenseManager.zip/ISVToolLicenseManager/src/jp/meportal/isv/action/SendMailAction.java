package jp.meportal.isv.action;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.meportal.isv.business.SendMailBussiness;
import jp.meportal.isv.business.impl.SendMailBussinessImpl;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.entity.MailTemplate;
import jp.meportal.isv.util.EmailUtil;
import jp.meportal.isv.util.PropertiesUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

public class SendMailAction extends BaseAction {
    private static final long serialVersionUID = 1L;
    final static Logger logger = Logger.getLogger(SendMailAction.class);
    private SendMailBussiness sendMailBussiness;

    public List<MailTemplate> listTemplate;
    public List<MailTemplate> listTemplateContent;
    public String templateMail;
    public Boolean flagTitleMail;
    public Boolean flagContentMail;
    public Boolean flagFooterMail;
    public Boolean flagToMail;
    public Boolean flag;
    public String toMail;
    public String titleMail;
    public String contentMail;
    public String footerMail;
    public int sizeTomail;
    public int resultSendMail;
    public String warningMsg;

    private transient HttpSession session = ServletActionContext.getRequest().getSession();
    private transient HttpServletRequest request = ServletActionContext.getRequest();

    /**
     * SendMailAction
     */
    public SendMailAction() {
        sendMailBussiness = new SendMailBussinessImpl();
    }

    /**
     * loadSendMail
     * 
     * @author FPT
     * @date: 2018/01/02
     */
    public String loadSendMail() {
        if (!isValidateUser()) {
            return LOGIN;
        }
        MailTemplate template = null;
        listTemplateContent = null;
        flagTitleMail = true;
        flagContentMail = true;
        flagFooterMail = true;
        flagToMail = true;
        sizeTomail = 0;
        warningMsg = StringUtils.EMPTY;
        listTemplate = sendMailBussiness.getMailTemplateList();
        templateMail = request.getParameter("templateMail");

        DateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT_UPDATE);
        Date date = new Date();
        String currentDate = dateFormat.format(date);
        String currentYear = currentDate.substring(0, 4);
        // convert date to calendar to add date.
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, 7);
        date = calendar.getTime();
        String dateAfter7Day = dateFormat.format(date);
        String dayAfter7Day = dateAfter7Day.substring(5, 10);
        dayAfter7Day = dayAfter7Day.concat(Constants.DATE_AFTER_7_CHAR).toString();

        Date dateTwo = new Date();
        // convert date to calendar to add date.
        Calendar calendarTwo = Calendar.getInstance();
        calendarTwo.setTime(dateTwo);
        calendarTwo.add(Calendar.DATE, 8);
        dateTwo = calendarTwo.getTime();
        String dateAfter8Day = dateFormat.format(dateTwo);
        String dayAfter8Day = dateAfter8Day.substring(5, 10);
        dayAfter8Day = dayAfter8Day.concat(Constants.DATE_AFTER_8_CHAR).toString();

        if (listTemplate != null && listTemplate.size() > 0) {
            if (!StringUtils.isEmpty(templateMail)) {
                for (int i = 0; i < listTemplate.size(); i++) {
                    template = listTemplate.get(i);
                    if (Integer.valueOf(templateMail) == template.getSeqNo()) {
                        showData(template, currentYear, dayAfter7Day, dayAfter8Day);
                    }
                }
            } else {
                template = listTemplate.get(0);
                showData(template, currentYear, dayAfter7Day, dayAfter8Day);
            }
        } else {
            listTemplateContent = new ArrayList<MailTemplate>();
            template = new MailTemplate();
            template.setSeqNo(1);
            template.setLabel(StringUtils.EMPTY);
            template.setTitle(StringUtils.EMPTY);
            template.setContents(StringUtils.EMPTY);
            template.setFooter(StringUtils.EMPTY);
            template.setTo(StringUtils.EMPTY);
            listTemplateContent.add(template);
            warningMsg = PropertiesUtil.getMessageProperties("isv.send_mail.template_blank");
        }
        session.setAttribute("sizeTomail", sizeTomail);
        
        return SUCCESS;
    }

    /**
     * sendMail
     * 
     * @author FPT
     * @date: 2018/01/02
     */
    public String sendMail() {
        if (!isValidateUser()) {
            return LOGIN;
        }
        sizeTomail = 0;
        resultSendMail = 0;
        warningMsg = StringUtils.EMPTY;
        flag = true;
        flagTitleMail = true;
        flagContentMail = true;
        flagFooterMail = true;
        flagToMail = true;
        listTemplate = sendMailBussiness.getMailTemplateList();
        MailTemplate mailTemplate = null;
        if (listTemplate != null && listTemplate.size() > 0) {
            listTemplateContent = new ArrayList<MailTemplate>();
            mailTemplate = listTemplate.get(0);
            listTemplateContent.add(mailTemplate);
            sizeTomail = getSizeToMail(mailTemplate.getTo());
        } else {
            warningMsg = PropertiesUtil.getMessageProperties("isv.send_mail.template_blank");
            return SUCCESS;
        }
        titleMail = request.getParameter("hiden_txtTitleMail");
        contentMail = request.getParameter("hiden_txtContentMail");
        footerMail = request.getParameter("hiden_txtFooterMail");
        toMail = request.getParameter("hiden_txtToMail");
            try {
                boolean flagSendMail = EmailUtil.sendEmail(titleMail, StringUtils.EMPTY, footerMail, contentMail, toMail, null,
                        null, null, null, null, null, null, null, null, null);
                if (flagSendMail) {
                    resultSendMail = Constants.REGISTER_SUCCESS;
                }
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            }
        session.setAttribute("sizeTomail", sizeTomail);
        
        return SUCCESS;
    }

    /**
     * showData
     * 
     * @param template
     * @param currentYear
     * @param dayAfter7Day
     * @param dayAfter8Day
     */
    private void showData(MailTemplate template, String currentYear, String dayAfter7Day, String dayAfter8Day) {
        if (!StringUtils.isEmpty(template.getLabel())) {
            listTemplateContent = getContentMail(template, currentYear, dayAfter7Day, dayAfter8Day);
            sizeTomail = getSizeToMail(template.getTo());
        } else {
            warningMsg = PropertiesUtil.getMessageProperties("isv.send_mail.feild_blank");
            listTemplateContent = getContentMail(template, currentYear, dayAfter7Day, dayAfter8Day);
            sizeTomail = getSizeToMail(template.getTo());
        }
    }

    /**
     * getContentMail
     * 
     * @param template
     * @param currentYear
     * @param dayAfter7Day
     * @param dayAfter8Day
     */
    private List<MailTemplate> getContentMail(MailTemplate template, String currentYear, String dayAfter7Day,
            String dayAfter8Day) {
        List<MailTemplate> templatesList = new ArrayList<MailTemplate>();
        String contentYear = this.findAndReplace(template.getContents(), Constants.YEAR_FORMAT, currentYear);
        String contentdateAfter7Day = this.findAndReplace(contentYear, Constants.DATE_AFTER_7, dayAfter7Day);
        String contentdayAfter8Day = this.findAndReplace(contentdateAfter7Day, Constants.DATE_AFTER_8, dayAfter8Day);
        String titleYear = this.findAndReplace(template.getTitle(), Constants.YEAR_FORMAT, currentYear);
        template.setTitle(titleYear);
        template.setContents(contentdayAfter8Day);
        templatesList.add(template);
        
        return templatesList;
    }

    /**
     * findAndReplace
     * 
     * @param line
     * @param replace
     * @param replacement
     */
    private String findAndReplace(String line, String replace, String replacement) {
        String content = StringUtils.EMPTY;
        for (int i = 0; i < line.length(); i++) {
            content = line.replace(replace, replacement);
        }
        
        return content;
    }
    
    /**
     * getSizeToMail
     * 
     * @param toMail
     */
    private int getSizeToMail(String toMail) {
        sizeTomail = 0;
        if (!StringUtils.isEmpty(toMail)) {
            if (toMail.contains(",")) {
                toMail = toMail.replace(",", ";");
                String[] listTomail = toMail.split(";");
                sizeTomail = listTomail.length;
            } else {
                String[] listTomail = toMail.split(";");
                sizeTomail = listTomail.length;
            }
        }
        
        return sizeTomail;
    }

    /**
     * @param listTemplate
     */
    public List<MailTemplate> getListTemplate() {
        return listTemplate;
    }

    /**
     * @param listTemplate
     *            the listTemplate to set
     */
    public void setListTemplate(List<MailTemplate> listTemplate) {
        this.listTemplate = listTemplate;
    }

    /**
     * @param listTemplateContent
     */
    public List<MailTemplate> getListTemplateContent() {
        return listTemplateContent;
    }

    /**
     * @param listTemplateContent
     *            the listTemplateContent to set
     */
    public void setListTemplateContent(List<MailTemplate> listTemplateContent) {
        this.listTemplateContent = listTemplateContent;
    }

    /**
     * @param templateMail
     */
    public String getTemplateMail() {
        return templateMail;
    }

    /**
     * @param templateMail
     *            the templateMail to set
     */
    public void setTemplateMail(String templateMail) {
        this.templateMail = templateMail;
    }

    /**
     * @param flagTitleMail
     */
    public Boolean getFlagTitleMail() {
        return flagTitleMail;
    }

    /**
     * @param flagTitleMail
     *            the flagTitleMail to set
     */
    public void setFlagTitleMail(Boolean flagTitleMail) {
        this.flagTitleMail = flagTitleMail;
    }

    /**
     * @param flagContentMail
     */
    public Boolean getFlagContentMail() {
        return flagContentMail;
    }

    /**
     * @param flagContentMail
     *            the flagContentMail to set
     */
    public void setFlagContentMail(Boolean flagContentMail) {
        this.flagContentMail = flagContentMail;
    }

    /**
     * @param flagFooterMail
     */
    public Boolean getFlagFooterMail() {
        return flagFooterMail;
    }

    /**
     * @param flagFooterMail
     *            the flagFooterMail to set
     */
    public void setFlagFooterMail(Boolean flagFooterMail) {
        this.flagFooterMail = flagFooterMail;
    }

    /**
     * @param flagToMail
     */
    public Boolean getFlagToMail() {
        return flagToMail;
    }

    /**
     * @param flagToMail
     *            the flagToMail to set
     */
    public void setFlagToMail(Boolean flagToMail) {
        this.flagToMail = flagToMail;
    }

    /**
     * @param flag
     */
    public Boolean getFlag() {
        return flag;
    }

    /**
     * @param flag
     *            the flag to set
     */
    public void setFlag(Boolean flag) {
        this.flag = flag;
    }

    /**
     * @param resultSendMail
     */
    public int getResultSendMail() {
        return resultSendMail;
    }

    /**
     * @param resultSendMail
     *            the resultSendMail to set
     */
    public void setResultSendMail(int resultSendMail) {
        this.resultSendMail = resultSendMail;
    }

    /**
     * @param warningMsg
     */
    public String getWarningMsg() {
        return warningMsg;
    }

    /**
     * @param warningMsg
     *            the warningMsg to set
     */
    public void setWarningMsg(String warningMsg) {
        this.warningMsg = warningMsg;
    }
}
