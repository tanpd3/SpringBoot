﻿package jp.meportal.isv.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.text.Collator;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.meportal.isv.business.LicenseBusiness;
import jp.meportal.isv.business.ManagerLicenseBusiness;
import jp.meportal.isv.business.MemberBusiness;
import jp.meportal.isv.business.ProjectBusiness;
import jp.meportal.isv.business.SupporterBusiness;
import jp.meportal.isv.business.impl.LicenseBusinessImpl;
import jp.meportal.isv.business.impl.ManagerLicenseBusinessImpl;
import jp.meportal.isv.business.impl.MemberBusinessImpl;
import jp.meportal.isv.business.impl.ProjectBusinessImpl;
import jp.meportal.isv.business.impl.SupporterBusinessImpl;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.constant.ErrorCodes;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.LicenseUseInfor;
import jp.meportal.isv.entity.Member;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.Support;
import jp.meportal.isv.formbean.ExecuteTimeAndCountFormBean;
import jp.meportal.isv.formbean.LicenseManagerColumn;
import jp.meportal.isv.formbean.LicenseRegisterBean;
import jp.meportal.isv.formbean.LicenseTotalTaxBean;
import jp.meportal.isv.formbean.LicenseTotalTaxColumn;
import jp.meportal.isv.formbean.LicenseUsageDetailForDBFormBean;
import jp.meportal.isv.formbean.LicenseUsageForAccountFormBean;
import jp.meportal.isv.formbean.LicenseUsageForFeatureFormBean;
import jp.meportal.isv.formbean.LicenseUsageForHostFormBean;
import jp.meportal.isv.formbean.LicenseUsageForProductNumberFormBean;
import jp.meportal.isv.formbean.LicenseUsageForProjectFormBean;
import jp.meportal.isv.formbean.LicenseUsageForProjectToolNameFormBean;
import jp.meportal.isv.formbean.LicenseUsageForToolNameFormBean;
import jp.meportal.isv.formbean.LicenseUsageForVendorFormBean;
import jp.meportal.isv.formbean.LicenseUsedBean;
import jp.meportal.isv.formbean.ProjectSelectFormBean;
import jp.meportal.isv.util.CSVHead;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.csvreader.CsvWriter;

/**
 * Class Name: ManagerLicenseAction<br>
 * Created date: 2017/10/09<br>
 * 
 * @author FPT
 */
public class ManagerLicenseAction extends BaseAction {

    private static final long serialVersionUID = 1L;
    private static final Logger log = Logger.getLogger(ManagerLicenseAction.class);
    private static final String BLANK = StringUtils.EMPTY;

    public ProjectBusiness projectBusiness;
    public MemberBusiness memberBusiness;
    public SupporterBusiness supporterBusiness;
    public LicenseBusiness licenseBusiness;
    public ManagerLicenseBusiness managerLicenseBusiness;

    public List<LicenseTotalTaxBean> listShowTbl3;
    public List<LicenseManagerColumn> licenManaList;
    public List<LicenseTotalTaxColumn> licenTotalTax;
    
    public List<LicenseManagerColumn> recordList;
    public List<LicenseTotalTaxColumn> recordListTwo;
    public List<LicenseTotalTaxBean> recordListThree;
    public Map<Integer, List<LicenseTotalTaxBean>> mapTaxBeanTbl3 = null;
    public int sizePage = 1;
    public int indexRecordStart = 1;
    public int currentPage = 1;
    
    
    public Project projectSelect;
    public List<Project> listPro;
    public List<Integer> listYear;
    public List<Integer> listMonth;
    public List<Integer> listProjectId;
    public Member member;
    public int yearNow;
    public int monthNow;
    int sizeLicenManaList;
    public String projectSelected;
    public String yearSelected;
    public String monthSelected;
    public String warningMsg;
    public BigDecimal totalBudget;
    public BigDecimal totalActual;
    public BigDecimal totalBudgetPerPro;
    public BigDecimal totalActualPerPro;
    public String fileNameExport;
    public String fileNameExportSupporter;
    public Boolean isSupporter;

    public int monthSelectedInt;
    public int yearSelectedInt;
    public int projectSelectInt;
    public String fileName;
    private transient InputStream inputFileStream;
    //Value of some radio button
    public Boolean boolFilterTool;
    public Boolean boolFilterProduct;
    public Boolean boolFilterProject;
    public List<ProjectSelectFormBean> projectSelectedList;
    public ExecuteTimeAndCountFormBean executeInfo;
    public List<LicenseUsageForToolNameFormBean> luToolNameFilterList;
    public List<LicenseUsageForProjectFormBean> luProductNumberFilterList;
    public List<LicenseUsageForProjectFormBean> luProjectFilterList;
    public Map<Integer, List<String>> mapListName = new HashMap<Integer, List<String>>();
    List<String> listName = null;
    private transient HttpSession session = ServletActionContext.getRequest().getSession();
    private transient HttpServletRequest request = ServletActionContext.getRequest();

    public ManagerLicenseAction() {
        projectBusiness = new ProjectBusinessImpl();
        memberBusiness = new MemberBusinessImpl();
        licenseBusiness = new LicenseBusinessImpl();
        supporterBusiness = new SupporterBusinessImpl();
        managerLicenseBusiness = new ManagerLicenseBusinessImpl();
    }

    /**
     * exportCSVSupporterSumary
     * 
     * @author FPT
     * @date: 2017/12/04
     */
    @SuppressWarnings("unchecked")
    public String exportCSVSupporterSumary(){
        if (!isValidateUser()) {
            return LOGIN;
        }
        FileOutputStream csvStream = null;
        String yearSelected = (String) session.getAttribute("yearSelected");
        String monthSelected = (String) session.getAttribute("monthSelected");
        String projectSelected =(String) session.getAttribute("projectSelected");
        Map<Integer, List<String>> mapProject = (Map<Integer, List<String>>) session.getAttribute("mapProject");
        List<LicenseTotalTaxColumn> licenTotalTaxExport = (List<LicenseTotalTaxColumn>) session.getAttribute("licenTotalTax");

        if (StringUtils.isEmpty(yearSelected) || StringUtils.isEmpty(monthSelected)) {
            return ERROR;
        }
        if (Integer.parseInt(monthSelected) < 10) {
            monthSelected = Constants.ZERO + monthSelected;
        }

        if (StringUtils.isEmpty(projectSelected) || (Constants.ZERO).equals(projectSelected)) {
            projectSelected = CSVHead.getAllProject();
        } else {
            if (MapUtils.isEmpty(mapProject)) {
                return ERROR;
            } else {
                for (Map.Entry<Integer, List<String>> mapPro : mapProject.entrySet()) {
                    if (Integer.valueOf(projectSelected) == mapPro.getKey().intValue()) {
                        projectSelected = mapPro.getValue().get(0);
                        break;
                    }
                }
            }
        }

        Date date = new Date();
        String strDateFormat = Constants.DATE_TIME_CSV_FORMAT_SUPORTER;
        DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
        String formatDate = dateFormat.format(date);
        fileNameExportSupporter = Constants.CSV_EXPORT_NAME_SUPPORTER + yearSelected + monthSelected
                + Constants.DASH_UNDER + formatDate;

        File csvSupporterFile = null;
        yearSelected += CSVHead.getYearLable();
        monthSelected += CSVHead.getMonthLable();
        
        try {
            boolean checkExportSupporter = false;

            csvSupporterFile = File.createTempFile(fileNameExportSupporter, ".csv");// Create File
            csvStream = new FileOutputStream(csvSupporterFile);
            checkExportSupporter = this.writeSupporterSumaryCsv(csvStream, licenTotalTaxExport);
            this.inputFileStream = new FileInputStream(csvSupporterFile);
            if (checkExportSupporter) {
                return SUCCESS;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            if (csvSupporterFile != null)
                csvSupporterFile.delete();
            if (csvStream != null) {
                try {
                    csvStream.close();
                } catch (Exception e2) {/* in */
                }
            }
        }
        return ERROR;
    }

    /**
     * exportCSVSumary
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    @SuppressWarnings("unchecked")
    public String exportCSVSumary(){
        if (!isValidateUser()) {
            return LOGIN;
        }

        FileOutputStream csvStream = null;
        List<LicenseManagerColumn> licenManaListExport = (List<LicenseManagerColumn>) session.getAttribute("licenManaList");
        String projectSelected = (String) session.getAttribute("projectSelected");
        String yearSelected = (String) session.getAttribute("yearSelected");
        String monthSelected = (String) session.getAttribute("monthSelected");
        Map<Integer, List<String>> mapProject = (Map<Integer, List<String>>) session.getAttribute("mapProject");
        List<LicenseTotalTaxColumn> licenTotalTaxExport = (List<LicenseTotalTaxColumn>) session.getAttribute("licenTotalTax");
        BigDecimal totalBudgetExport = (BigDecimal) session.getAttribute("totalBudget");
        BigDecimal totalActualExport = (BigDecimal) session.getAttribute("totalActual");
        BigDecimal totalSumTbl3 = (BigDecimal) session.getAttribute("totalSumTbl3");
        List<LicenseTotalTaxBean> listShowTbl3Export = (List<LicenseTotalTaxBean>) session.getAttribute("listShowTbl3");

        Date date = new Date();
        String strDateFormat = Constants.DATE_TIME_FORMAT_CSV;
        DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
        String formatDate = dateFormat.format(date);
        fileNameExport = Constants.CSV_EXPORT_NAME_SUMARY + formatDate;
        File csvFile = null;

        if (StringUtils.isEmpty(yearSelected) || StringUtils.isEmpty(monthSelected)) {
            return ERROR;
        }

        if (StringUtils.isEmpty(projectSelected) || (Constants.ZERO).equals(projectSelected)) {
            projectSelected = CSVHead.getAllProject();
        } else {
            if (MapUtils.isEmpty(mapProject)) {
                return ERROR;
            } else {
                for (Map.Entry<Integer, List<String>> mapPro : mapProject.entrySet()) {
                    if (Integer.valueOf(projectSelected) == mapPro.getKey().intValue()) {
                        projectSelected = mapPro.getValue().get(0);
                        break;
                    }
                }
            }
        }
        monthSelected += CSVHead.getMonthLable();
        yearSelected += CSVHead.getYearLable();

        try {
            boolean checkExportSumary = false;

            csvFile = File.createTempFile(fileNameExport, ".csv");// Create File
            csvStream = new FileOutputStream(csvFile);
            checkExportSumary = this.writeSumaryCsv(csvStream, projectSelected, yearSelected, monthSelected,
                    licenManaListExport, licenTotalTaxExport, totalBudgetExport, totalActualExport, listShowTbl3Export,
                    totalSumTbl3);
            this.inputFileStream = new FileInputStream(csvFile);

            if (checkExportSumary) {
                return SUCCESS;
            }
        } catch (RuntimeException e1) {
            log.error(e1.getMessage(), e1);
        } catch (Exception e2) {
            log.error(e2.getMessage(), e2);
        }
        return ERROR;
    }

    /**
     * managerLicense
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    public String managerLicense() {
        if (!isValidateUser()) {
            return LOGIN;
        }
        String result = SUCCESS;
        String emaillogin = this.getEmailAddress();
        member = memberBusiness.checkExistEmailMember(emaillogin);
        if(member == null){
            warningMsg = Constants.USER_NOT_FOUND;
            result = SUCCESS;
        }
        if (session != null) {// remove all session
            session.removeAttribute("projectName");
        }
        LocalDate now = LocalDate.now();
        yearNow = now.getYear();
        monthNow = now.getMonthValue();

        projectSelected = request.getParameter("projectCombo");
        yearSelected = request.getParameter("yearCombo");
        monthSelected = request.getParameter("monthCombo");

        if (!StringUtils.isEmpty(yearSelected)) {// set current select
            yearSelected = request.getParameter("yearCombo");
        } else {
            yearSelected = String.valueOf(yearNow);
        }
        if (!StringUtils.isEmpty(monthSelected)) {
            monthSelected = request.getParameter("monthCombo");
        } else {
            monthSelected = String.valueOf(monthNow);
        }
        String selectedProject = request.getParameter("selectedProject");
        String selectedYear = request.getParameter("selectedYear");
        String selectedMonth = request.getParameter("selectedMonth");
       
        if(!StringUtils.isEmpty(selectedProject) || !StringUtils.isEmpty(selectedYear) || !StringUtils.isEmpty(selectedMonth)){
            projectSelected = selectedProject;
            yearSelected = selectedYear;
            monthSelected = selectedMonth;
        }
       
        // start set attribute to export
        if (session != null) {
            session.setAttribute("projectSelected", projectSelected);
            session.setAttribute("yearSelected", yearSelected);
            session.setAttribute("monthSelected", monthSelected);
        }
        // end set attribute to export
        
        request.setAttribute("selectedProject", request.getParameter("projectCombo"));
        request.setAttribute("selectedYear", request.getParameter("yearCombo"));
        request.setAttribute("selectedMonth", request.getParameter("monthCombo"));
        int yearInfor = 0;
        int monthInfor = 0;
        yearInfor = Integer.valueOf(yearSelected);
        monthInfor = Integer.valueOf(monthSelected);
        this.getInforLicense(emaillogin, result, yearInfor, monthInfor, projectSelected);
        int sizeLicenManaList = 0;
        if(licenManaList != null && licenManaList.size() > 0) {
           sizeLicenManaList = licenManaList.size();
        }
        if (session != null) {
            session.setAttribute("sizeLicenManaList", sizeLicenManaList);
            session.setAttribute("isSupporter", isSupporter);
        }
        return result;
    }

    /**
     * @param emaillogin
     */
    private void getInforLicense(String emaillogin, String result, int yearInfor, int monthInfor, String projectSelected) {
        listMonth = new ArrayList<Integer>();
            Support support = supporterBusiness.getSupportDb(emaillogin);
            if (support != null) {// list all project by supportor
                isSupporter = true;
                listPro = projectBusiness.listAllProject();
                if (listPro != null) {
                    listProjectId = new ArrayList<Integer>();
                    if (StringUtils.isEmpty(projectSelected) || (Constants.ZERO).equals(projectSelected)) {
                        for (Project project : listPro) {
                            listProjectId.add(project.getSeqNo());
                            getInforProject(project);
                        }
                    } else {
                        for (Project project : listPro) {
                           if(project.getSeqNo() == Integer.valueOf(projectSelected)){
                               getInforProject(project);
                           }
                        }
                        listProjectId.add(Integer.valueOf(projectSelected));
                    }
                } else {
                    listPro = new ArrayList<Project>();
                }
            } else if (support == null && member != null) {// list projects by email
                isSupporter = false;
                listPro = projectBusiness.listAllProjectByMember(1, member, emaillogin, isSupporter);
                if (listPro != null) {
                    listProjectId = new ArrayList<Integer>();
                    if (StringUtils.isEmpty(projectSelected) || (Constants.ZERO).equals(projectSelected)) {
                        for (Project project : listPro) {
                            listProjectId.add(project.getSeqNo());
                            getInforProject(project);
                        }
                    } else {
                        for (Project project : listPro) {
                            if(project.getSeqNo() == Integer.valueOf(projectSelected)){
                                getInforProject(project);
                            }
                         }
                        listProjectId.add(Integer.valueOf(projectSelected));
                    }
                } else {
                    listPro = new ArrayList<Project>();
                }
        } else {// check project to auto export.
            listPro = projectBusiness.listAllProject();
            if (listPro != null) {
                listProjectId = new ArrayList<Integer>();
                if (StringUtils.isEmpty(projectSelected) || (Constants.ZERO).equals(projectSelected)) {
                    for (Project project : listPro) {
                        listProjectId.add(project.getSeqNo());
                        getInforProject(project);
                    }
                }
            }
        }
        session.setAttribute("mapProject", mapListName);
        List<Integer> listYears = managerLicenseBusiness.getListYears();
        if (listYears != null) {
            listYear = new ArrayList<Integer>();
            for (Integer year : listYears) {// get Years from LicenseUserInfor.
                if(!listYears.contains(yearNow)) {
                    if(year > yearNow){
                        listYear.add(year);
                    } else if(year < yearNow && !listYear.contains(yearNow)){
                        listYear.add(yearNow);
                        listYear.add(year);
                    } else if (year < yearNow && listYear.contains(yearNow)){
                        listYear.add(year);
                    }
                } else {
                    listYear.add(year);
                }
            }
        } else {
            listYear = new ArrayList<Integer>();
        }
        
        /* Build List month of year finance - START */
        listMonth = new ArrayList<Integer>();
        for (int i = 0; i < 12; i++) {// get Months.
            if (i < 9) {
                listMonth.add(i + 4);
            } else {
                listMonth.add(i - 8);
            }
        }
        /* Build List month of year finance - END */
        int yearNomarl = yearInfor;
        String projectNameMap = BLANK;
        List<List<LicenseUsedBean>> ipUsedList = new ArrayList<List<LicenseUsedBean>>();
        for (int i = 0; i < 12; i++) {
            if (i < 9) {
                ipUsedList.add(managerLicenseBusiness.getLicenseUseInfor(yearInfor, i + 4));
            } else {
                ipUsedList.add(managerLicenseBusiness.getLicenseUseInfor(yearNomarl + 1, i - 8));
            }
        }
        List<String> listMonth = new ArrayList<String>();
        listMonth.add("ls.Apr");
        listMonth.add("ls.May");
        listMonth.add("ls.Jun");
        listMonth.add("ls.Jul");
        listMonth.add("ls.Aug");
        listMonth.add("ls.Sep");
        listMonth.add("ls.Oct");
        listMonth.add("ls.Nov");
        listMonth.add("ls.Dec");
        listMonth.add("ls.Jan");
        listMonth.add("ls.Feb");
        listMonth.add("ls.Mar");
        List<List<LicenseRegisterBean>> proRegisList = new ArrayList<List<LicenseRegisterBean>>();
        for (int i = 0; i < listMonth.size(); i++) {
            if(i < 9){
                proRegisList.add(managerLicenseBusiness.getLicenseRegisInfor(listProjectId, yearNomarl, listMonth.get(i)));
            } else {
                proRegisList.add(managerLicenseBusiness.getLicenseRegisInfor(listProjectId, yearNomarl + 1, listMonth.get(i)));
            }
        }
        List<LicenseUseInfor> licenseUseInforList = managerLicenseBusiness.getLicenUseInfor();
        if(licenseUseInforList != null && licenseUseInforList.size() > 0){
            if (proRegisList != null && proRegisList.size() > 0) {
                if (listProjectId != null && listProjectId.size() > 0) {
                    licenManaList = new ArrayList<LicenseManagerColumn>();
                    listShowTbl3 = new ArrayList<LicenseTotalTaxBean>();
                    LicenseManagerColumn columnMana = null;
                    List<LicenseTotalTaxBean> taxBeanTotalList = null;
                    mapTaxBeanTbl3 = new HashMap<Integer, List<LicenseTotalTaxBean>>();
                    for (int p = 0; p < listProjectId.size(); p++) {
                        int projectId = listProjectId.get(p);
                        List<Integer> ipListOfProject = managerLicenseBusiness.getListIpAddressByProjectId(projectId, yearInfor);
                        for (Map.Entry<Integer, List<String>> mapPro : mapListName.entrySet()) {
                            if(projectId == mapPro.getKey().intValue()){
                                projectNameMap = mapPro.getValue().get(0);
                                break;
                            }
                         }
                        taxBeanTotalList = new ArrayList<LicenseTotalTaxBean>();
                        String projectName = BLANK;
                        String productNumber = BLANK;
                        String loadOriginCode = BLANK;
                        
                        columnMana = new LicenseManagerColumn();
                        columnMana.setProjectName(projectNameMap);
                        columnMana.setBudgetMonth4Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setActualMonth4Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setBudgetMonth4(BigDecimal.ZERO);
                        columnMana.setActualMonth4(BigDecimal.ZERO);
                        
                        columnMana.setBudgetMonth5Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setActualMonth5Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setBudgetMonth5(BigDecimal.ZERO);
                        columnMana.setActualMonth5(BigDecimal.ZERO);
                        
                        columnMana.setBudgetMonth6Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setActualMonth6Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setBudgetMonth6(BigDecimal.ZERO);
                        columnMana.setActualMonth6(BigDecimal.ZERO);
                        
                        columnMana.setBudgetMonth7Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setActualMonth7Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setBudgetMonth7(BigDecimal.ZERO);
                        columnMana.setActualMonth7(BigDecimal.ZERO);
                        
                        columnMana.setBudgetMonth8Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setActualMonth8Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setBudgetMonth8(BigDecimal.ZERO);
                        columnMana.setActualMonth8(BigDecimal.ZERO);
                        
                        columnMana.setBudgetMonth9Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setActualMonth9Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setBudgetMonth9(BigDecimal.ZERO);
                        columnMana.setActualMonth9(BigDecimal.ZERO);
                        
                        columnMana.setBudgetMonth10Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setActualMonth10Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setBudgetMonth10(BigDecimal.ZERO);
                        columnMana.setActualMonth10(BigDecimal.ZERO);
                        
                        columnMana.setBudgetMonth11Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setActualMonth11Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setBudgetMonth11(BigDecimal.ZERO);
                        columnMana.setActualMonth11(BigDecimal.ZERO);
                        
                        columnMana.setBudgetMonth12Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setActualMonth12Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setBudgetMonth12(BigDecimal.ZERO);
                        columnMana.setActualMonth12(BigDecimal.ZERO);
                        
                        columnMana.setBudgetMonth1Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setActualMonth1Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setBudgetMonth1(BigDecimal.ZERO);
                        columnMana.setActualMonth1(BigDecimal.ZERO);
                        
                        columnMana.setBudgetMonth2Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setActualMonth2Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setBudgetMonth2(BigDecimal.ZERO);
                        columnMana.setActualMonth2(BigDecimal.ZERO);
                        
                        columnMana.setBudgetMonth3Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setActualMonth3Div1000(BigDecimal.ZERO.setScale(1, RoundingMode.DOWN));
                        columnMana.setBudgetMonth3(BigDecimal.ZERO);
                        columnMana.setActualMonth3(BigDecimal.ZERO);
                        
                        for (int j = 0; j < 12; j++) {
                            List<LicenseRegisterBean> regisListPro = proRegisList.get(j);
                            List<LicenseUsedBean> usedListIp = ipUsedList.get(j);
                            if (regisListPro != null && regisListPro.size() > 0) {
                                switch (j) {
                                case 0:
                                    List<LicenseTotalTaxColumn> listTotalTax4 = showdataMonth(regisListPro, usedListIp, ipListOfProject);
                                    LicenseTotalTaxBean licenseTotalTaxBean4 = reSetOrderListPro(listTotalTax4, projectId);
                                    if (licenseTotalTaxBean4 != null) {
                                        List<LicenseTotalTaxColumn> columnsTemp = licenseTotalTaxBean4.getTaxList();
                                        if (columnsTemp != null && columnsTemp.size() > 0) {
                                            setBugActPerMonth(columnsTemp);
                                            columnMana.setBudgetMonth4Div1000(totalBudgetPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setActualMonth4Div1000(totalActualPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setBudgetMonth4(totalBudgetPerPro);
                                            columnMana.setActualMonth4(totalActualPerPro);
                                        }
                                    } else {
                                        licenseTotalTaxBean4 = getInforTbl3(projectId, projectName, productNumber,loadOriginCode);
                                    }
                                    taxBeanTotalList.add(licenseTotalTaxBean4);
                                    break;
                                case 1:
                                    List<LicenseTotalTaxColumn> listTotalTax5 = showdataMonth(regisListPro, usedListIp, ipListOfProject);
                                    LicenseTotalTaxBean licenseTotalTaxBean5 = reSetOrderListPro(listTotalTax5, projectId);
                                    if (licenseTotalTaxBean5 != null) {
                                        List<LicenseTotalTaxColumn> columnsTemp = licenseTotalTaxBean5.getTaxList();
                                        if (columnsTemp != null && columnsTemp.size() > 0) {
                                            setBugActPerMonth(columnsTemp);
                                            columnMana.setBudgetMonth5Div1000(totalBudgetPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setActualMonth5Div1000(totalActualPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setBudgetMonth5(totalBudgetPerPro);
                                            columnMana.setActualMonth5(totalActualPerPro);
                                        }
                                    } else {
                                        licenseTotalTaxBean5 = getInforTbl3(projectId, projectName, productNumber,loadOriginCode);
                                    }
                                    taxBeanTotalList.add(licenseTotalTaxBean5);
                                    break;
                                case 2:
                                    List<LicenseTotalTaxColumn> listTotalTax6 = showdataMonth(regisListPro, usedListIp, ipListOfProject);
                                    LicenseTotalTaxBean licenseTotalTaxBean6 = reSetOrderListPro(listTotalTax6, projectId);
                                    if (licenseTotalTaxBean6 != null) {
                                        List<LicenseTotalTaxColumn> columnsTemp = licenseTotalTaxBean6.getTaxList();
                                        if (columnsTemp != null && columnsTemp.size() > 0) {
                                            setBugActPerMonth(columnsTemp);
                                            columnMana.setBudgetMonth6Div1000(totalBudgetPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setActualMonth6Div1000(totalActualPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setBudgetMonth6(totalBudgetPerPro);
                                            columnMana.setActualMonth6(totalActualPerPro);
                                        }
                                    } else {
                                        licenseTotalTaxBean6 = getInforTbl3(projectId, projectName, productNumber,loadOriginCode);
                                    }
                                    taxBeanTotalList.add(licenseTotalTaxBean6);
                                    break;
                                case 3:
                                    List<LicenseTotalTaxColumn> listTotalTax7 = showdataMonth(regisListPro, usedListIp, ipListOfProject);
                                    LicenseTotalTaxBean licenseTotalTaxBean7 = reSetOrderListPro(listTotalTax7, projectId);
                                    if (licenseTotalTaxBean7 != null) {
                                        List<LicenseTotalTaxColumn> columnsTemp = licenseTotalTaxBean7.getTaxList();
                                        if (columnsTemp != null && columnsTemp.size() > 0) {
                                            setBugActPerMonth(columnsTemp);
                                            columnMana.setBudgetMonth7Div1000(totalBudgetPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setActualMonth7Div1000(totalActualPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setBudgetMonth7(totalBudgetPerPro);
                                            columnMana.setActualMonth7(totalActualPerPro);
                                        }
                                    } else {
                                        licenseTotalTaxBean7 = getInforTbl3(projectId, projectName, productNumber,loadOriginCode);
                                    }
                                    taxBeanTotalList.add(licenseTotalTaxBean7);
                                    break;
                                case 4:
                                    List<LicenseTotalTaxColumn> listTotalTax8 = showdataMonth(regisListPro, usedListIp, ipListOfProject);
                                    LicenseTotalTaxBean licenseTotalTaxBean8 = reSetOrderListPro(listTotalTax8, projectId);
                                    if (licenseTotalTaxBean8 != null) {
                                        List<LicenseTotalTaxColumn> columnsTemp = licenseTotalTaxBean8.getTaxList();
                                        if (columnsTemp != null && columnsTemp.size() > 0) {
                                            setBugActPerMonth(columnsTemp);
                                            columnMana.setBudgetMonth8Div1000(totalBudgetPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setActualMonth8Div1000(totalActualPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setBudgetMonth8(totalBudgetPerPro);
                                            columnMana.setActualMonth8(totalActualPerPro);
                                        }
                                    } else {
                                        licenseTotalTaxBean8 = getInforTbl3(projectId, projectName, productNumber,loadOriginCode);
                                    }
                                    taxBeanTotalList.add(licenseTotalTaxBean8);
                                    break;
                                case 5:
                                    List<LicenseTotalTaxColumn> listTotalTax9 = showdataMonth(regisListPro, usedListIp, ipListOfProject);
                                    LicenseTotalTaxBean licenseTotalTaxBean9 = reSetOrderListPro(listTotalTax9, projectId);
                                    if (licenseTotalTaxBean9 != null) {
                                        List<LicenseTotalTaxColumn> columnsTemp = licenseTotalTaxBean9.getTaxList();
                                        if (columnsTemp != null && columnsTemp.size() > 0) {
                                            setBugActPerMonth(columnsTemp);
                                            columnMana.setBudgetMonth9Div1000(totalBudgetPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setActualMonth9Div1000(totalActualPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setBudgetMonth9(totalBudgetPerPro);
                                            columnMana.setActualMonth9(totalActualPerPro);
                                        }
                                    } else {
                                        licenseTotalTaxBean9 = getInforTbl3(projectId, projectName, productNumber,loadOriginCode);
                                    }
                                    taxBeanTotalList.add(licenseTotalTaxBean9);
                                    break;
                                case 6:
                                    List<LicenseTotalTaxColumn> listTotalTax10 = showdataMonth(regisListPro, usedListIp, ipListOfProject);
                                    LicenseTotalTaxBean licenseTotalTaxBean10 = reSetOrderListPro(listTotalTax10, projectId);
                                    if (licenseTotalTaxBean10 != null) {
                                        List<LicenseTotalTaxColumn> columnsTemp = licenseTotalTaxBean10.getTaxList();
                                        if (columnsTemp != null && columnsTemp.size() > 0) {
                                            setBugActPerMonth(columnsTemp);
                                            columnMana.setBudgetMonth10Div1000(totalBudgetPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setActualMonth10Div1000(totalActualPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setBudgetMonth10(totalBudgetPerPro);
                                            columnMana.setActualMonth10(totalActualPerPro);
                                        }
                                    } else {
                                        licenseTotalTaxBean10 = getInforTbl3(projectId, projectName, productNumber,loadOriginCode);
                                    }
                                    taxBeanTotalList.add(licenseTotalTaxBean10);
                                    break;
                                case 7:
                                    List<LicenseTotalTaxColumn> listTotalTax11 = showdataMonth(regisListPro, usedListIp, ipListOfProject);
                                    LicenseTotalTaxBean licenseTotalTaxBean11 = reSetOrderListPro(listTotalTax11, projectId);
                                    if (licenseTotalTaxBean11 != null) {
                                        List<LicenseTotalTaxColumn> columnsTemp = licenseTotalTaxBean11.getTaxList();
                                        if (columnsTemp != null && columnsTemp.size() > 0) {
                                            setBugActPerMonth(columnsTemp);
                                            columnMana.setBudgetMonth11Div1000(totalBudgetPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setActualMonth11Div1000(totalActualPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setBudgetMonth11(totalBudgetPerPro);
                                            columnMana.setActualMonth11(totalActualPerPro);
                                        }
                                    } else {
                                        licenseTotalTaxBean11 = getInforTbl3(projectId, projectName, productNumber,loadOriginCode);
                                    }
                                    taxBeanTotalList.add(licenseTotalTaxBean11);
                                    break;
                                case 8:
                                    List<LicenseTotalTaxColumn> listTotalTax12 = showdataMonth(regisListPro, usedListIp, ipListOfProject);
                                    LicenseTotalTaxBean licenseTotalTaxBean12 = reSetOrderListPro(listTotalTax12, projectId);
                                    if (licenseTotalTaxBean12 != null) {
                                        List<LicenseTotalTaxColumn> columnsTemp = licenseTotalTaxBean12.getTaxList();
                                        if (columnsTemp != null && columnsTemp.size() > 0) {
                                            setBugActPerMonth(columnsTemp);
                                            columnMana.setBudgetMonth12Div1000(totalBudgetPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setActualMonth12Div1000(totalActualPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setBudgetMonth12(totalBudgetPerPro);
                                            columnMana.setActualMonth12(totalActualPerPro);
                                        }
                                    } else {
                                        licenseTotalTaxBean12 = getInforTbl3(projectId, projectName, productNumber,loadOriginCode);
                                    }
                                    taxBeanTotalList.add(licenseTotalTaxBean12);
                                    break;
                                case 9:
                                    List<LicenseTotalTaxColumn> listTotalTax1 = showdataMonth(regisListPro, usedListIp, ipListOfProject);
                                    LicenseTotalTaxBean licenseTotalTaxBean1 = reSetOrderListPro(listTotalTax1, projectId);
                                    if (licenseTotalTaxBean1 != null) {
                                        List<LicenseTotalTaxColumn> columnsTemp = licenseTotalTaxBean1.getTaxList();
                                        if (columnsTemp != null && columnsTemp.size() > 0) {
                                            setBugActPerMonth(columnsTemp);
                                            columnMana.setBudgetMonth1Div1000(totalBudgetPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setActualMonth1Div1000(totalActualPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setBudgetMonth1(totalBudgetPerPro);
                                            columnMana.setActualMonth1(totalActualPerPro);
                                        }
                                    } else {
                                        licenseTotalTaxBean1 = getInforTbl3(projectId, projectName, productNumber,loadOriginCode);
                                    }
                                    taxBeanTotalList.add(licenseTotalTaxBean1);
                                    break;
                                case 10:
                                    List<LicenseTotalTaxColumn> listTotalTax2 = showdataMonth(regisListPro, usedListIp, ipListOfProject);
                                    LicenseTotalTaxBean licenseTotalTaxBean2 = reSetOrderListPro(listTotalTax2, projectId);
                                    if (licenseTotalTaxBean2 != null) {
                                        List<LicenseTotalTaxColumn> columnsTemp = licenseTotalTaxBean2.getTaxList();
                                        if (columnsTemp != null && columnsTemp.size() > 0) {
                                            setBugActPerMonth(columnsTemp);
                                            columnMana.setBudgetMonth2Div1000(totalBudgetPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setActualMonth2Div1000(totalActualPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setBudgetMonth2(totalBudgetPerPro);
                                            columnMana.setActualMonth2(totalActualPerPro);
                                        }
                                    } else {
                                        licenseTotalTaxBean2 = getInforTbl3(projectId, projectName, productNumber,loadOriginCode);
                                    }
                                    taxBeanTotalList.add(licenseTotalTaxBean2);
                                    break;
                                case 11:
                                    List<LicenseTotalTaxColumn> listTotalTax3 = showdataMonth(regisListPro, usedListIp, ipListOfProject);
                                    LicenseTotalTaxBean licenseTotalTaxBean3 = reSetOrderListPro(listTotalTax3, projectId);
                                    if (licenseTotalTaxBean3 != null) {
                                        List<LicenseTotalTaxColumn> columnsTemp = licenseTotalTaxBean3.getTaxList();
                                        if (columnsTemp != null && columnsTemp.size() > 0) {
                                            setBugActPerMonth(columnsTemp);
                                            columnMana.setBudgetMonth3Div1000(totalBudgetPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setActualMonth3Div1000(totalActualPerPro.divide(new BigDecimal(1000)).setScale(1, RoundingMode.DOWN));
                                            columnMana.setBudgetMonth3(totalBudgetPerPro);
                                            columnMana.setActualMonth3(totalActualPerPro);
                                        }
                                    } else {
                                        licenseTotalTaxBean3 = getInforTbl3(projectId, projectName, productNumber,loadOriginCode);
                                    }
                                    taxBeanTotalList.add(licenseTotalTaxBean3);
                                    break;
                                }
                            } else {
                                LicenseTotalTaxBean licenseTotalTaxBean = new LicenseTotalTaxBean();
                                licenseTotalTaxBean = getInforTbl3(projectId, projectName, productNumber,loadOriginCode);
                                taxBeanTotalList.add(licenseTotalTaxBean);
                            }
                        }
                        
                        columnMana.setActualSumQ1Div1000(columnMana.getActualMonth4Div1000().add(
                                columnMana.getActualMonth5Div1000().add(columnMana.getActualMonth6Div1000())));
                        columnMana.setActualSumQ2Div1000(columnMana.getActualMonth7Div1000().add(
                                columnMana.getActualMonth8Div1000().add(columnMana.getActualMonth9Div1000())));
                        columnMana.setActualSumQ3Div1000(columnMana.getActualMonth10Div1000().add(
                                columnMana.getActualMonth11Div1000().add(columnMana.getActualMonth12Div1000())));
                        columnMana.setActualSumQ4Div1000(columnMana.getActualMonth1Div1000().add(
                                columnMana.getActualMonth2Div1000().add(columnMana.getActualMonth3Div1000())));
                        columnMana
                                .setActualSumQ12Div1000(columnMana.getActualSumQ1Div1000().add(columnMana.getActualSumQ2Div1000()));
                        columnMana
                                .setActualSumQ34Div1000(columnMana.getActualSumQ3Div1000().add(columnMana.getActualSumQ4Div1000()));
                        columnMana.setActualTotalInYearDiv1000(columnMana.getActualSumQ12Div1000().add(
                                columnMana.getActualSumQ34Div1000()));

                        columnMana.setBudgetSumQ1Div1000(columnMana.getBudgetMonth4Div1000().add(
                                columnMana.getBudgetMonth5Div1000().add(columnMana.getBudgetMonth6Div1000())));
                        columnMana.setBudgetSumQ2Div1000(columnMana.getBudgetMonth7Div1000().add(
                                columnMana.getBudgetMonth8Div1000().add(columnMana.getBudgetMonth9Div1000())));
                        columnMana.setBudgetSumQ3Div1000(columnMana.getBudgetMonth10Div1000().add(
                                columnMana.getBudgetMonth11Div1000().add(columnMana.getBudgetMonth12Div1000())));
                        columnMana.setBudgetSumQ4Div1000(columnMana.getBudgetMonth1Div1000().add(
                                columnMana.getBudgetMonth2Div1000().add(columnMana.getBudgetMonth3Div1000())));
                        columnMana
                                .setBudgetSumQ12Div1000(columnMana.getBudgetSumQ1Div1000().add(columnMana.getBudgetSumQ2Div1000()));
                        columnMana
                                .setBudgetSumQ34Div1000(columnMana.getBudgetSumQ3Div1000().add(columnMana.getBudgetSumQ4Div1000()));
                        columnMana.setBudgetTotalInYearDiv1000(columnMana.getBudgetSumQ12Div1000().add(
                                columnMana.getBudgetSumQ34Div1000()));
                        
                        columnMana.setActualSumQ1(columnMana.getActualMonth4().add(
                                columnMana.getActualMonth5().add(columnMana.getActualMonth6())));
                        columnMana.setActualSumQ2(columnMana.getActualMonth7().add(
                                columnMana.getActualMonth8().add(columnMana.getActualMonth9())));
                        columnMana.setActualSumQ3(columnMana.getActualMonth10().add(
                                columnMana.getActualMonth11().add(columnMana.getActualMonth12())));
                        columnMana.setActualSumQ4(columnMana.getActualMonth1().add(
                                columnMana.getActualMonth2().add(columnMana.getActualMonth3())));
                        columnMana
                                .setActualSumQ12(columnMana.getActualSumQ1().add(columnMana.getActualSumQ2()));
                        columnMana
                                .setActualSumQ34(columnMana.getActualSumQ3().add(columnMana.getActualSumQ4()));
                        columnMana.setActualTotalInYear(columnMana.getActualSumQ12().add(
                                columnMana.getActualSumQ34()));

                        columnMana.setBudgetSumQ1(columnMana.getBudgetMonth4().add(
                                columnMana.getBudgetMonth5().add(columnMana.getBudgetMonth6())));
                        columnMana.setBudgetSumQ2(columnMana.getBudgetMonth7().add(
                                columnMana.getBudgetMonth8().add(columnMana.getBudgetMonth9())));
                        columnMana.setBudgetSumQ3(columnMana.getBudgetMonth10().add(
                                columnMana.getBudgetMonth11().add(columnMana.getBudgetMonth12())));
                        columnMana.setBudgetSumQ4(columnMana.getBudgetMonth1().add(
                                columnMana.getBudgetMonth2().add(columnMana.getBudgetMonth3())));
                        columnMana
                                .setBudgetSumQ12(columnMana.getBudgetSumQ1().add(columnMana.getBudgetSumQ2()));
                        columnMana
                                .setBudgetSumQ34(columnMana.getBudgetSumQ3().add(columnMana.getBudgetSumQ4()));
                        columnMana.setBudgetTotalInYear(columnMana.getBudgetSumQ12().add(
                                columnMana.getBudgetSumQ34()));
                        licenManaList.add(columnMana);
                        mapTaxBeanTbl3.put(projectId, taxBeanTotalList);
                    }
                } else {
                    listProjectId = new ArrayList<Integer>();
                }
                
                // Start pagination
                String strPageId = request.getParameter("pageId");
                int numRecordPerPage = 30;
                if (!StringUtils.isEmpty(strPageId)) {
                    indexRecordStart = Integer.valueOf(strPageId);
                }
                if (indexRecordStart > 1) {
                    indexRecordStart = (indexRecordStart - 1) * numRecordPerPage + 1;
                }
                currentPage = (int) Math.ceil(indexRecordStart/30) + 1;
                sizePage = (int) Math.ceil(licenManaList.size()/30) + 1;
                // End  Start pagination
                if (licenManaList != null && licenManaList.size() > 0) {

                    listShowTbl3 = showTblDetailTax(monthInfor, mapTaxBeanTbl3);// show interface Screen table3.

                    List<String> sortProjectName = new ArrayList<String>();
                    List<LicenseTotalTaxBean> listShowFilterTbl3 = new ArrayList<LicenseTotalTaxBean>();
                    if (listShowTbl3.size() > 0) {
                        for (int i = 0; i < listShowTbl3.size(); i++) {
                            LicenseTotalTaxBean beanTbl3 = listShowTbl3.get(i);
                            if (beanTbl3 != null) {
                                String projectName = beanTbl3.getProjectName();
                                sortProjectName.add(projectName);
                            }
                        }
                        Collections.sort(sortProjectName, Collator.getInstance());
                        for (int jj = 0; jj < sortProjectName.size(); jj++) {
                            String projectNameSort = sortProjectName.get(jj);
                            for (int j = 0; j < listShowTbl3.size(); j++) {
                                LicenseTotalTaxBean beanTemp3 = listShowTbl3.get(j);
                                if (beanTemp3 != null) {
                                    String projectNameCompare = beanTemp3.getProjectName();
                                    if (!StringUtils.isEmpty(projectNameSort) && projectNameSort.equals(projectNameCompare)) {
                                        listShowFilterTbl3.add(beanTemp3);
                                    }
                                }
                            }
                        }
                        listShowTbl3 = new ArrayList<LicenseTotalTaxBean>(listShowFilterTbl3);
                        session.setAttribute("listShowTbl3", listShowTbl3);
                        recordListThree = this.getRecordPageTblThree(indexRecordStart, numRecordPerPage, listShowTbl3);
                    }

                    if (listShowTbl3 != null && listShowTbl3.size() > 0) {
                        
                        licenTotalTax = showTblSumTaxOfMonth();// show interface Screen table2.

                        List<String> sortProjectNametbl2 = new ArrayList<String>();
                        List<LicenseTotalTaxColumn> listShowFilterTbl2 = new ArrayList<LicenseTotalTaxColumn>();
                        if (licenTotalTax.size() > 0) {
                            for (int i = 0; i < licenTotalTax.size(); i++) {
                                LicenseTotalTaxColumn column2 = licenTotalTax.get(i);
                                if (column2 != null) {
                                    String projectName = column2.getProjectName();
                                    sortProjectNametbl2.add(projectName);
                                }
                            }
                            Collections.sort(sortProjectNametbl2, Collator.getInstance());
                            for (int jj = 0; jj < sortProjectNametbl2.size(); jj++) {
                                String projectNameSort = sortProjectNametbl2.get(jj);
                                for (int j = 0; j < licenTotalTax.size(); j++) {
                                    LicenseTotalTaxColumn columnTemp2 = licenTotalTax.get(j);
                                    if (columnTemp2 != null) {
                                        String projectNameCompare = columnTemp2.getProjectName();
                                        if (!StringUtils.isEmpty(projectNameSort)
                                                && projectNameSort.equals(projectNameCompare)) {
                                            listShowFilterTbl2.add(columnTemp2);
                                        }
                                    }
                                }
                            }
                            licenTotalTax = new ArrayList<LicenseTotalTaxColumn>(listShowFilterTbl2);
                            session.setAttribute("licenTotalTax", licenTotalTax);
                            recordListTwo = this.getRecordPageTblTwo(indexRecordStart, numRecordPerPage, licenTotalTax);
                        }

                    } else {
                        result = SUCCESS;
                    }
                } else {
                    result = SUCCESS;
                }
                    session.setAttribute("licenManaList", licenManaList);//show interface Screen table1.
                    recordList = this.getRecordPage(indexRecordStart, numRecordPerPage, licenManaList);
                }
        warningMsg = BLANK;
      } else {
        warningMsg = Constants.LICENSE_USE_INFOR_NOT_DATA;
      }
    }

    /**
     * getInforTbl3
     * 
     * @param projectId
     * @param projectName
     * @param productNumber
     * @param loadOriginCode
     * @return
     */
    private LicenseTotalTaxBean getInforTbl3(int projectId, String projectName, String productNumber, String loadOriginCode) {
        LicenseTotalTaxBean licenseTotalTaxBean = new LicenseTotalTaxBean();
        for (Map.Entry<Integer, List<String>> mapProjectName : mapListName.entrySet()) {
            if (projectId == mapProjectName.getKey().intValue()) {
                projectName = mapProjectName.getValue().get(0);
                productNumber = mapProjectName.getValue().get(1);
                loadOriginCode = mapProjectName.getValue().get(2);
                break;
            }
        }
        licenseTotalTaxBean.setProjectId(projectId);
        licenseTotalTaxBean.setCatalogId(0);
        licenseTotalTaxBean.setLengthLicenseCatalog(1);
        licenseTotalTaxBean.setProjectName(projectName);
        licenseTotalTaxBean.setProductNumber(productNumber);
        licenseTotalTaxBean.setLoadOriginCode(loadOriginCode);

        LicenseTotalTaxColumn taxColumnTemp = new LicenseTotalTaxColumn();
        taxColumnTemp.setCatalogId(0);
        taxColumnTemp.setVenderName(Constants.NAME_CATALOG_EMPTY);
        taxColumnTemp.setToolName(Constants.NAME_CATALOG_EMPTY);
        taxColumnTemp.setFutureName(Constants.NAME_CATALOG_EMPTY);
        taxColumnTemp.setCountBudgetPerMonth(0);
        taxColumnTemp.setCountActualPerMonth(0);
        taxColumnTemp.setCountSubTractBudgetActual(0);
        taxColumnTemp.setMemberPrice(BigDecimal.ZERO);
        taxColumnTemp.setRegularPrice(BigDecimal.ZERO);
        taxColumnTemp.setMoneyBudgetPerMonth(BigDecimal.ZERO);
        taxColumnTemp.setMoneyActualPerMonth(BigDecimal.ZERO);
        taxColumnTemp.setMoreBudgetPerMonth(BigDecimal.ZERO);
        taxColumnTemp.setSumBudgetAndMoreBudget(BigDecimal.ZERO);
        List<LicenseTotalTaxColumn> taxListTemp = new ArrayList<LicenseTotalTaxColumn>();
        taxListTemp.add(taxColumnTemp);
        licenseTotalTaxBean.setTaxList(taxListTemp);
        return licenseTotalTaxBean;
    }

    /**
     * getInforProject
     * @param project
     */
    private void getInforProject(Project project) {
        listName = new ArrayList<String>();
        listName.add(project.getProjectName());
        listName.add(project.getProductNumber());
        listName.add(project.getLoadOriginCode());
        mapListName.put(project.getSeqNo(), listName);
    }

    /**
     * @param columnsTemp
     */
    private void setBugActPerMonth(List<LicenseTotalTaxColumn> columnsTemp) {
        totalBudgetPerPro = BigDecimal.ZERO;
        totalActualPerPro = BigDecimal.ZERO;
        for (int l = 0; l < columnsTemp.size(); l++) {
            totalBudgetPerPro = totalBudgetPerPro.add(columnsTemp.get(l).getMoneyBudgetPerMonth());
            totalActualPerPro = totalActualPerPro.add(columnsTemp.get(l).getSumBudgetAndMoreBudget());
        }
    }

    /**
     * viewDetailLicense
     * 
     * @author FPT
     * @date: 2017/09/22
     */
    public String viewDetailLicense() {
        if (!isValidateUser()) {
            return LOGIN;
        }
        String projectSelect = request.getParameter("projectCombox");
        yearSelected = request.getParameter("yearCombox");
        monthSelected = request.getParameter("monthCombox");
        /* Convert String to Integer - START */
        projectSelectInt = Integer.parseInt(projectSelect);
        yearSelectedInt = Integer.parseInt(yearSelected);
        monthSelectedInt = Integer.parseInt(monthSelected);
        /* Convert String to Integer - END */
        String filterTool = request.getParameter("filterTool");
        String filterProduct = request.getParameter("filterProduct");
        String filterProject = request.getParameter("filterProject");
        /* Convert String to Boolean - START */
        if (!StringUtils.isEmpty(filterTool) && !StringUtils.isEmpty(filterProduct) && !StringUtils.isEmpty(filterProject)) {
            boolFilterTool = Boolean.valueOf(filterTool);
            boolFilterProduct = Boolean.valueOf(filterProduct);
            boolFilterProject = Boolean.valueOf(filterProject);
        } else if(StringUtils.isEmpty(filterTool) && StringUtils.isEmpty(filterProduct) && StringUtils.isEmpty(filterProject)) {
            boolFilterTool = true;
            boolFilterProduct = false;
            boolFilterProject = false;
        }
        /* Convert String to Boolean - END */
        String emailLogin = this.getEmailAddress();
        Support support = supporterBusiness.getSupportDb(emailLogin); // check email permission supporter or member
        if (support != null) {
            listPro = projectBusiness.listAllProject(); // get List all Project by Supporter
        } else {
            member = memberBusiness.checkExistEmailMember(emailLogin);
            if (member != null) {
                listPro = projectBusiness.listAllProjectByMember(Constants.APPROVED_STATUS, member, emailLogin, false); // get List all Project by Member
            }
        }
        if (listPro != null && listPro.size() > 0) {
            List<Integer> listYears = managerLicenseBusiness.getListYears();// get List year in DB
            LocalDate now = LocalDate.now();
            yearNow = now.getYear();
            if (listYears != null) {
                listYear = new ArrayList<Integer>();
                for (Integer year : listYears) {// get Years from LicenseUserInfor.
                    if(!listYears.contains(yearNow)) {
                        if(year > yearNow){
                            listYear.add(year);
                        } else if(year < yearNow && !listYear.contains(yearNow)){
                            listYear.add(yearNow);
                            listYear.add(year);
                        } else if (year < yearNow && listYear.contains(yearNow)){
                            listYear.add(year);
                        }
                    } else {
                        listYear.add(year);
                    }
                }
            }
            /* get month and year in DB follow year finance - START */
            int yearDB = 0;
            if (Constants.MONTH_NEXT_YEAR.contains(monthSelected)) {
                yearDB = Integer.parseInt(yearSelected) + 1;
            } else {
                yearDB = Integer.parseInt(yearSelected);
            }
           
            /* get month and year in DB follow year finance - END */
            /* Build List month of year finance - START */
            listMonth = new ArrayList<Integer>();
            for (int i = 0; i < 12; i++) {// get Months.
                if (i < 9) {
                    listMonth.add(i + 4);
                } else {
                    listMonth.add(i - 8);
                }
            }
            /* Build List month of year finance - END */
            /* Append project all to list project in combo box - START */
            ProjectSelectFormBean pjSel = new ProjectSelectFormBean();
            projectSelectedList = new ArrayList<ProjectSelectFormBean>();
            pjSel.setSeqNo(0);
            pjSel.setProjectName(Constants.ALL_PROJECT);
            projectSelectedList.add(pjSel);
            for (Project pj: listPro) {
                pjSel = new ProjectSelectFormBean();
                pjSel.setSeqNo(pj.getSeqNo());
                pjSel.setProjectName(pj.getProjectName());
                projectSelectedList.add(pjSel);
            }
            /* Append project all to list project in combo box - END */
            List<LicenseUsageForProjectFormBean> luProjectList = new ArrayList<LicenseUsageForProjectFormBean>();
            List<LicenseUsageForToolNameFormBean> luToolAddList = new ArrayList<LicenseUsageForToolNameFormBean>();
            //
            if ((Constants.ZERO).equals(projectSelect)) {
                projectSelected = Constants.ALL_PROJECT;
                List<LicenseUsageForProductNumberFormBean> luProductNumberList = null;
                for (Project pj : listPro) {
                    List<LicenseUsageDetailForDBFormBean> licenseUsageDetailList = this.getLicenseUsageForDetail(pj, yearDB);
                    List<LicenseUsageForVendorFormBean> luVendorList = null;
                    if (licenseUsageDetailList != null && licenseUsageDetailList.size() > 0) {
                        List<LicenseUsageDetailForDBFormBean> licenseDetailToolList = new ArrayList<LicenseUsageDetailForDBFormBean>(licenseUsageDetailList);
                        luVendorList = this.getLicenseVendorList(licenseUsageDetailList);
                        List<LicenseUsageForToolNameFormBean> luToolList = this.getLicenseToolFilterList(pj, licenseDetailToolList); // Add all vendor List using filter by Tool Name
                        luToolAddList.addAll(luToolList);
                    } else {
                        luVendorList = this.getLicenseVendorEmptyList(); // Process when list license Detail equals null
                        // Set field to Object LicenseUsageForFeatureFormBean
                        List<LicenseUsageForFeatureFormBean> luFeatureEmptyList = new ArrayList<LicenseUsageForFeatureFormBean>();
                        LicenseUsageForFeatureFormBean luFeatureEmpty = new LicenseUsageForFeatureFormBean(Constants.NAME_CATALOG_EMPTY,
                                Constants.NO_VALUE);
                        luFeatureEmptyList.add(luFeatureEmpty);
                        // Set field to Object LicenseUsageForToolNameFormBean
                        LicenseUsageForToolNameFormBean luToolEmpty = new LicenseUsageForToolNameFormBean(pj.getProductNumber(), pj.getProjectName(),
                                Constants.NAME_CATALOG_EMPTY, Constants.NAME_CATALOG_EMPTY, luFeatureEmptyList, 1);
                        luToolAddList.add(luToolEmpty);
                    }
                    if (luVendorList != null && luVendorList.size() > 0) {
                        LicenseUsageForProjectFormBean luProject = this.getLicenseUsageForProject(pj, luVendorList); // Filter License Usage Status to Project
                        if (luProject != null) {
                            luProjectList.add(luProject);
                        }
                    }
                 }
                /* Filter by Project - START */
                if (boolFilterProject) {
                    luProjectFilterList = new ArrayList<LicenseUsageForProjectFormBean>();
                    for (Project pj : listPro) {
                        List<LicenseUsageDetailForDBFormBean> licenseUsageDetailList = this.getLicenseUsageForDetail(pj, yearDB);
                        List<LicenseUsageForVendorFormBean> luVendorFilterList = null;
                        if (licenseUsageDetailList != null && licenseUsageDetailList.size() > 0) {
                            List<LicenseUsageForToolNameFormBean> luToolList = this.getLicenseToolFilterList(pj, licenseUsageDetailList); // Add all vendor List using filter by Tool Name
                            if (luToolList != null && luToolList.size() > 0) {
                                luVendorFilterList = this.getLicenseVendorFilterList(luToolList);
                            }
                        } else {
                            luVendorFilterList = this.getLicenseVendorEmptyList(); // Process when list license Detail equals null
                        }
                        if (luVendorFilterList != null && luVendorFilterList.size() > 0) {
                            LicenseUsageForProjectFormBean luProject = this.getLicenseUsageForProject(pj, luVendorFilterList); // Filter License Usage Status to Project
                            if (luProject != null) {
                                luProjectFilterList.add(luProject);
                            }
                        }
                     }
                /* Filter by Project - END */
                /* Filter by Tool Name - START */
                } else if (boolFilterTool) {
                    if (luToolAddList != null && luToolAddList.size() > 0) {
                        luToolNameFilterList = this.getLicenseUsageToolNameFilterList(luToolAddList);
                    }
                /* Filter by Tool Name - END */
                /* Filter by Product Number - START */
                } else if (boolFilterProduct) {
                    luProjectFilterList = new ArrayList<LicenseUsageForProjectFormBean>();
                    for (Project pj : listPro) {
                        List<LicenseUsageDetailForDBFormBean> licenseUsageDetailList = this.getLicenseUsageForDetail(pj, yearDB);
                        List<LicenseUsageForVendorFormBean> luVendorFilterList = null;
                        if (licenseUsageDetailList != null && licenseUsageDetailList.size() > 0) {
                            List<LicenseUsageForToolNameFormBean> luToolList = this.getLicenseToolFilterList(pj, licenseUsageDetailList); // Add all vendor List using filter by Tool Name
                            if (luToolList != null && luToolList.size() > 0) {
                                luVendorFilterList = this.getLicenseVendorFilterList(luToolList);
                            }
                        } else {
                            luVendorFilterList = this.getLicenseVendorEmptyList(); // Process when list license Detail equals null
                        }
                        if (luVendorFilterList != null && luVendorFilterList.size() > 0) {
                            LicenseUsageForProjectFormBean luProject = this.getLicenseUsageForProject(pj, luVendorFilterList); // Filter License Usage Status to Project
                            if (luProject != null) {
                                luProjectFilterList.add(luProject);
                            }
                        }
                     }
                    List<LicenseUsageForProductNumberFormBean> luProductNumberTestList = null;
                    if (luProjectFilterList != null && luProjectFilterList.size() > 0) {
                        luProductNumberTestList = this.getLicenseUsageForProductList(luProjectFilterList);
                    }
                    //
                    if (luProductNumberTestList != null && luProductNumberTestList.size() > 0) {
                        luProductNumberFilterList = this.getLicenseUsageForProductFilterList(luProductNumberTestList);
                    }
                }
                /* Filter by Product Number - END */
                if (luProjectList != null && luProjectList.size() > 0) {
                    luProductNumberList = this.getLicenseUsageForProductList(luProjectList);
                }
                if (luProductNumberList != null && luProductNumberList.size() > 0) {
                    executeInfo = new ExecuteTimeAndCountFormBean();
                    int lengthProductNumber = luProductNumberList.size();
                    int grandTotalRunTime = 0;
                    int grandTotalRunNumber = 0;
                    for (int i = 0; i < lengthProductNumber; i++) {
                        LicenseUsageForProductNumberFormBean luProductNumberInfo = luProductNumberList.get(i);
                        //
                        grandTotalRunTime += luProductNumberInfo.getTotalRunTime();
                        grandTotalRunNumber += luProductNumberInfo.getTotalRunNumber();
                    }
                    String strTotalRunTime = this.getStrRunTime(grandTotalRunTime); // convert date from seconds to type HH:MM:SS
                    executeInfo.setGrandTotalRunTime(strTotalRunTime);
                    executeInfo.setGrandTotalRunNumber(grandTotalRunNumber);
                    executeInfo.setLicenseUsageForProductNumberList(luProductNumberList);
                }
            } else {
                for (Project pj : listPro) {
                    if (projectSelect.equals(String.valueOf(pj.getSeqNo()))) {
                        projectSelected = pj.getProjectName();
                        List<LicenseUsageDetailForDBFormBean> licenseUsageDetailList = this.getLicenseUsageForDetail(pj, yearDB);
                        List<LicenseUsageForProductNumberFormBean> luProductNumberList = null;
                        List<LicenseUsageForToolNameFormBean> luToolList = null;
                        List<LicenseUsageForVendorFormBean> luVendorList = null;
                        if (licenseUsageDetailList != null && licenseUsageDetailList.size() > 0) {
                            List<LicenseUsageDetailForDBFormBean> licenseDetailToolList = new ArrayList<LicenseUsageDetailForDBFormBean>(licenseUsageDetailList);
                            luVendorList = this.getLicenseVendorList(licenseUsageDetailList);
                            luToolList = this.getLicenseToolFilterList(pj, licenseDetailToolList); // Add all vendor List using filter by Tool Name
                        } else {
                            luVendorList = this.getLicenseVendorEmptyList(); // Process when list license Detail equals null
                            // Set field to Object LicenseUsageForFeatureFormBean
                            List<LicenseUsageForFeatureFormBean> luFeatureEmptyList = new ArrayList<LicenseUsageForFeatureFormBean>();
                            LicenseUsageForFeatureFormBean luFeatureEmpty = new LicenseUsageForFeatureFormBean(Constants.NAME_CATALOG_EMPTY,
                                    Constants.NO_VALUE);
                            luFeatureEmptyList.add(luFeatureEmpty);
                            // Set field to Object LicenseUsageForToolNameFormBean
                            LicenseUsageForToolNameFormBean luToolEmpty = new LicenseUsageForToolNameFormBean(pj.getProductNumber(), pj.getProjectName(),
                                    Constants.NAME_CATALOG_EMPTY, Constants.NAME_CATALOG_EMPTY, luFeatureEmptyList, 1);
                            luToolList = new ArrayList<LicenseUsageForToolNameFormBean>();
                            luToolList.add(luToolEmpty);
                        }
                        if (luVendorList != null && luVendorList.size() > 0) {
                            LicenseUsageForProjectFormBean luProject = this.getLicenseUsageForProject(pj, luVendorList); // Filter License Usage Status to Project
                            if (luProject != null) {
                                luProjectList.add(luProject);
                            }
                        }
                        if (luToolList != null && luToolList.size() > 0) {
                            luToolNameFilterList = this.getLicenseUsageToolNameFilterList(luToolList);
                        }
                        if (luProjectList != null && luProjectList.size() > 0) {
                            luProductNumberList = this.getLicenseUsageForProductList(luProjectList);
                        }
                        if (luProductNumberList != null && luProductNumberList.size() > 0) {
                            executeInfo = new ExecuteTimeAndCountFormBean();
                            executeInfo.setGrandTotalRunTime(luProductNumberList.get(0).getStrTotalRunTime());
                            executeInfo.setGrandTotalRunNumber(luProductNumberList.get(0).getTotalRunNumber());
                            executeInfo.setLicenseUsageForProductNumberList(luProductNumberList);
                        }
                        break;
                    }
                }
            }
        } else {
            exceptionMsg = ErrorCodes.ERRORS_CODE_PROJECT_NOT_EXIST;
            return ERROR;
        }
        return SUCCESS;
    }

    /**
     * exportDetailLicenseStatus
     * 
     * @author FPT
     * @date: 2017/10/03
     */
    public String exportDetailLicenseStatus() {
        if (!isValidateUser()) {
            return LOGIN;
        }
        String projectId = request.getParameter("projectComboxCsv");
        yearSelected = request.getParameter("yearComboxCsv");
        monthSelected = request.getParameter("monthComboxCsv");
        this.loadDataExportCSV(projectId); // Load all data using export file CSV
        File tempFile = null;
        FileOutputStream csvStream = null;
        DateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT_CSV);
        DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern(Constants.TIME_FORMAT_CSV);
        // Current date
        Date date = new Date();
        String issueDate = dateFormat.format(date);

        LocalDateTime now = LocalDateTime.now();
        String timeNow = timeFormat.format(now);
        try {
            Boolean check = false;
            fileName = Constants.CSV_EXPORT_NAME_DETAIL + issueDate + Constants.DASH_UNDER + timeNow;
            tempFile = File.createTempFile(fileName, ".csv");
            csvStream = new FileOutputStream(tempFile);
            check = this.writeQAToCsv(csvStream);
            this.inputFileStream = new FileInputStream(tempFile);
            if (check) {
                return SUCCESS;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            if (tempFile != null)
                tempFile.delete();
            if (csvStream != null) {
                try {
                    csvStream.close();
                } catch (Exception e2) {/* in */
                }
            }
        }
        return ERROR;
    }

    /**
     * getIdCatalogInfoList
     * @param Project
     * @return List<Integer>
     */
    private List<Integer> getIdCatalogInfoList (Project pj) {
        List<LicenseInfo> licenseInfoList = managerLicenseBusiness.getLicenseListByProject(pj);
        List<Integer> idCatalogList = null;
        if (licenseInfoList != null && licenseInfoList.size() > 0) {
            int sizeLicense = licenseInfoList.size();
            if (sizeLicense > 0) {
                idCatalogList = new ArrayList<Integer>();
                for (int i = 0; i < sizeLicense; i++) {
                    CatalogInfor ct = licenseInfoList.get(i).getCatalogId();
                    idCatalogList.add(ct.getSeqNo());
                }
            }
        }
        return idCatalogList;
    }

    /**
     * getStrRunTime
     * @param runTimeWithoutFew
     * @return String
     */
    private String getStrRunTime(int runTimeWithoutFew) {
        String strRunTime = BLANK;
        if (runTimeWithoutFew > 0) {
            long hours = TimeUnit.SECONDS.toHours(runTimeWithoutFew);
            runTimeWithoutFew -= TimeUnit.HOURS.toSeconds(hours);
            long minutes = TimeUnit.SECONDS.toMinutes(runTimeWithoutFew);
            runTimeWithoutFew -= TimeUnit.MINUTES.toSeconds(minutes);
            long seconds = TimeUnit.SECONDS.toSeconds(runTimeWithoutFew);
            strRunTime = String.format("%02d:%02d:%02d", hours, minutes, seconds);
        }
        return strRunTime;
    }

    /**
     * getLicenseUsageForDetail
     * @param Project
     * @param yearDB
     * @return List<LicenseUsageDetailForDBFormBean>
     */
    private List<LicenseUsageDetailForDBFormBean> getLicenseUsageForDetail(Project pj, int yearDB) {
        List<LicenseUsageDetailForDBFormBean> licenseUsageDetailList = null;
        boolean flag = false;
        List<Integer> ipAddList = managerLicenseBusiness.getIpAddressInfoListByProject(pj);// get List IP Address for Project
        List<Integer> idCatalogList = this.getIdCatalogInfoList(pj); // get List Catalog ID for Project
        // get List LicenseUsageDetail For DB
        if (ipAddList != null && ipAddList.size() > 0) {
            if (idCatalogList != null && idCatalogList.size() > 0) {
                flag = true;
            }
        }
        if (flag) {
            licenseUsageDetailList = managerLicenseBusiness
                    .getLicenseUsageDetailForDBList(ipAddList, idCatalogList, yearDB, monthSelected);
        }
        return licenseUsageDetailList;
    }
    /**
     * getLicenseUsageForProject
     * @param Project
     * @param luVendorFilterList
     * @return LicenseUsageForProjectFormBean
     */
    private LicenseUsageForProjectFormBean getLicenseUsageForProject(Project pj, List<LicenseUsageForVendorFormBean> luVendorFilterList) {
        LicenseUsageForProjectFormBean luProject = null;
        int runTimeForProject = 0;
        int runNumberForProject = 0;
        int lengthVendorFeature = 0;
            for (int i = 0; i < luVendorFilterList.size(); i++) {
                LicenseUsageForVendorFormBean luVendorInfo = luVendorFilterList.get(i);
                runTimeForProject += luVendorInfo.getRunTimeForVendor();
                runNumberForProject += luVendorInfo.getRunNumberForVendor();
                lengthVendorFeature += luVendorInfo.getLengthToolList();
            }
            /* Calculator total run time, run number, length feature in project - END */
            luProject = new LicenseUsageForProjectFormBean();
            luProject.setProductNumber(pj.getProductNumber());
            luProject.setProjectName(pj.getProjectName());
            luProject.setLoadOriginCode(pj.getLoadOriginCode());
            //
            luProject.setRunTimeForProject(runTimeForProject);
            luProject.setRunNumberForProject(runNumberForProject);
            luProject.setLengthVendorFeatureList(lengthVendorFeature);
            luProject.setLicenseUsageForVendorList(luVendorFilterList);

        return luProject;
    }

    /**
     * getLicenseUsageForVendorList
     * @param licenseUsageDetailList
     * @return List<LicenseUsageForVendorFormBean>
     */
    private List<LicenseUsageForVendorFormBean> getLicenseVendorList(
            List<LicenseUsageDetailForDBFormBean> licenseUsageDetailList) {
        LicenseUsageForVendorFormBean luVendor = null;
        List<LicenseUsageForVendorFormBean> luVendorList = new ArrayList<LicenseUsageForVendorFormBean>();
        List<LicenseUsageForVendorFormBean> luVendorFilterList = new ArrayList<LicenseUsageForVendorFormBean>();
        List<LicenseUsageDetailForDBFormBean> luDetailToolList = null;

        if (licenseUsageDetailList != null && licenseUsageDetailList.size() > 0) {
            int lengthDetailDB = licenseUsageDetailList.size();
            for (int ii = 0; ii < lengthDetailDB; ii++) {
                LicenseUsageDetailForDBFormBean luDetailFirst = licenseUsageDetailList.get(ii);
                luDetailToolList = new ArrayList<LicenseUsageDetailForDBFormBean>();
                luVendor = new LicenseUsageForVendorFormBean();
                String vendorNameFirst = luDetailFirst.getVendorName();
                luDetailToolList.add(luDetailFirst);
                for (int i = ii + 1; i < lengthDetailDB; i++) {
                    LicenseUsageDetailForDBFormBean luDetailSecond = licenseUsageDetailList.get(i);
                    String vendorNameSecond = luDetailSecond.getVendorName();
                    if (!StringUtils.isEmpty(vendorNameFirst) && vendorNameFirst.equals(vendorNameSecond)) {
                        luDetailToolList.add(luDetailSecond);
                        /* Process List when 2 tool same - START */
                        licenseUsageDetailList.remove(i);
                        lengthDetailDB--;
                        i--;
                        /* Process List when 2 tool same - END */
                    }
                }
                luVendor = new LicenseUsageForVendorFormBean(vendorNameFirst, luDetailToolList);
                luVendorList.add(luVendor);
            }
            LicenseUsageForVendorFormBean luVendorFilter = null;
            List<LicenseUsageForToolNameFormBean> luToolNameList = null;
            if (luVendorList != null && luVendorList.size() > 0) {
                for (int i = 0; i < luVendorList.size(); i++) {
                    LicenseUsageForVendorFormBean luVendorInfo = luVendorList.get(i);
                    String vendorName = luVendorInfo.getVendorName();

                    luToolNameList = this.getLicenseToolList(luVendorInfo);
                    // Calculation sum runtime and run number of Vendor
                    int runTimeForVendor = 0;
                    int runNumberForVendor = 0;
                    int lengthToolList = 0;
                    if (luToolNameList != null && luToolNameList.size() > 0) {
                        for (int j = 0; j < luToolNameList.size(); j++) {
                            LicenseUsageForToolNameFormBean luToolInfo = luToolNameList.get(j);
                            runTimeForVendor += luToolInfo.getRunTimeForTool();
                            runNumberForVendor += luToolInfo.getRunNumberForTool();
                            lengthToolList += luToolInfo.getLengthFeatureList();
                        }
                        // Set field to Object LicenseUsageForVendorFormBean
                        luVendorFilter = new LicenseUsageForVendorFormBean(vendorName, luToolNameList,
                                runTimeForVendor, runNumberForVendor, lengthToolList);
                        luVendorFilterList.add(luVendorFilter);
                    }
                }
            }
        }
        return luVendorFilterList;
    }

    /**
     * getLicenseToolFilterList
     * @param Project
     * @param licenseUsageDetailList
     * @return List<LicenseUsageForToolNameFormBean>
     */
    private List<LicenseUsageForToolNameFormBean> getLicenseToolFilterList(Project pj,
            List<LicenseUsageDetailForDBFormBean> licenseUsageDetailList) {
        LicenseUsageForToolNameFormBean luTool = null;
        List<LicenseUsageDetailForDBFormBean> luDetailFeatureList = null;
        List<LicenseUsageForToolNameFormBean> luToolNameList = new ArrayList<LicenseUsageForToolNameFormBean>();
        List<LicenseUsageForToolNameFormBean> luToolFilterList = new ArrayList<LicenseUsageForToolNameFormBean>();
            /* Compare 2 Tool Name in List Tool - START */
            int lengthDetailDB = licenseUsageDetailList.size();
            for (int ii = 0; ii < lengthDetailDB; ii++) {
                LicenseUsageDetailForDBFormBean luDetailFirst = licenseUsageDetailList.get(ii);
                luDetailFeatureList = new ArrayList<LicenseUsageDetailForDBFormBean>();
                String vendorNameFirst = luDetailFirst.getVendorName();
                String toolNameFirst = luDetailFirst.getToolName();
                luDetailFeatureList.add(luDetailFirst);
                for (int i = ii + 1; i < lengthDetailDB; i++) {
                    LicenseUsageDetailForDBFormBean luDetailSecond = licenseUsageDetailList.get(i);
                    String toolNameSecond = luDetailSecond.getToolName();
                    if (!StringUtils.isEmpty(toolNameFirst) && toolNameFirst.equals(toolNameSecond)) {
                        luDetailFeatureList.add(luDetailSecond);
                        /* Process List when 2 tool same - START */
                        licenseUsageDetailList.remove(i);
                        lengthDetailDB--;
                        i--;
                        /* Process List when 2 tool same - END */
                    }
                }
                luTool = new LicenseUsageForToolNameFormBean(vendorNameFirst, toolNameFirst, luDetailFeatureList);
                luToolNameList.add(luTool);
            }
            /* Compare 2 Tool Name in List Tool - END */
            List<LicenseUsageForFeatureFormBean> luFeatureList = null;
            LicenseUsageForToolNameFormBean luToolFilter = null;
            if (luToolNameList != null && luToolNameList.size() > 0) {
                for (int i = 0; i < luToolNameList.size(); i++) {
                    LicenseUsageForToolNameFormBean luToolInfo = luToolNameList.get(i);
                    String vendorName = luToolInfo.getVendorName();
                    String toolName = luToolInfo.getToolName();
                    luFeatureList = this.getLicenseFeatureFilterList(luToolInfo); // Filter by Host
                    if (luFeatureList != null && luFeatureList.size() > 0) {
                        int lengthFeature = luFeatureList.size();
                        luToolFilter = new LicenseUsageForToolNameFormBean(pj.getProductNumber(), pj.getProjectName(),
                                vendorName, toolName, luFeatureList, lengthFeature);
                        luToolFilterList.add(luToolFilter);
                    }
                }
            }
        return luToolFilterList;
    }

    /**
     * getLicenseFeatureFilterList
     * @param luToolInfo
     * @return List<LicenseUsageForFeatureFormBean>
     */
    private List<LicenseUsageForFeatureFormBean> getLicenseFeatureFilterList(
            LicenseUsageForToolNameFormBean luToolInfo) {
        LicenseUsageForFeatureFormBean luDetailDB = null;
        List<LicenseUsageDetailForDBFormBean> luDetailDBList = luToolInfo.getLicenseUsageDetailForDBList();
        List<LicenseUsageForFeatureFormBean> luFeatureList = new ArrayList<LicenseUsageForFeatureFormBean>();
        if (luDetailDBList != null && luDetailDBList.size() > 0) {
            int lengthDetail = luDetailDBList.size();
            for (int ii = 0; ii < lengthDetail; ii++) {
                LicenseUsageDetailForDBFormBean luDetailFirst = luDetailDBList.get(ii);
                String futureNameFirst = luDetailFirst.getFutureName();
                int sameTimeUseNumberFirst = luDetailFirst.getSameTimeUseNumber();
                for (int i = ii + 1; i < lengthDetail; i++) {
                    LicenseUsageDetailForDBFormBean luDetailSecond = luDetailDBList.get(i);
                    String futureNameSecond = luDetailSecond.getFutureName();
                    int sameTimeUseNumberSecond = luDetailSecond.getSameTimeUseNumber();
                    if (!StringUtils.isEmpty(futureNameFirst) && futureNameFirst.equals(futureNameSecond)) {
                        if (sameTimeUseNumberFirst < sameTimeUseNumberSecond) {
                            sameTimeUseNumberFirst = sameTimeUseNumberSecond;
                        }
                        /* Process List when 2 tool same - START */
                        luDetailDBList.remove(i);
                        lengthDetail--;
                        i--;
                        /* Process List when 2 tool same - END */
                    }
                }
                luDetailDB = new LicenseUsageForFeatureFormBean(futureNameFirst, sameTimeUseNumberFirst);
                luFeatureList.add(luDetailDB);
            }
        }
      return luFeatureList;
    }

    /**
     * getLicenseToolList
     * @param luVendorInfo
     * @return List<LicenseUsageForToolNameFormBean>
     */
    private List<LicenseUsageForToolNameFormBean> getLicenseToolList(
            LicenseUsageForVendorFormBean luVendorInfo) {
        LicenseUsageForToolNameFormBean luTool = null;
        List<LicenseUsageDetailForDBFormBean> luDetailFeatureList = null;
        List<LicenseUsageForToolNameFormBean> luToolNameList = new ArrayList<LicenseUsageForToolNameFormBean>();
        List<LicenseUsageForToolNameFormBean> luToolFilterList = new ArrayList<LicenseUsageForToolNameFormBean>();
        List<LicenseUsageDetailForDBFormBean> luDetailDBList = luVendorInfo.getLicenseUsageDetailForDBList();
        if (luDetailDBList != null && luDetailDBList.size() > 0) {
            int lengthDetailDB = luDetailDBList.size();
            /* Compare 2 Tool Name in List Tool - START */
            for (int ii = 0; ii < lengthDetailDB; ii++) {
                LicenseUsageDetailForDBFormBean luDetailFirst = luDetailDBList.get(ii);
                luDetailFeatureList = new ArrayList<LicenseUsageDetailForDBFormBean>();
                String vendorNameFirst = luDetailFirst.getVendorName();
                String toolNameFirst = luDetailFirst.getToolName();
                luDetailFeatureList.add(luDetailFirst);
                for (int i = ii + 1; i < lengthDetailDB; i++) {
                    LicenseUsageDetailForDBFormBean luDetailSecond = luDetailDBList.get(i);
                    String toolNameSecond = luDetailSecond.getToolName();
                    if (!StringUtils.isEmpty(toolNameFirst) && toolNameFirst.equals(toolNameSecond)) {
                        luDetailFeatureList.add(luDetailSecond);
                        /* Process List when 2 tool same - START */
                        luDetailDBList.remove(i);
                        lengthDetailDB--;
                        i--;
                        /* Process List when 2 tool same - END */
                    }
                }
                luTool = new LicenseUsageForToolNameFormBean(vendorNameFirst, toolNameFirst, luDetailFeatureList);
                luToolNameList.add(luTool);
            }
            /* Compare 2 Tool Name in List Tool - END */
            List<LicenseUsageForFeatureFormBean> luFeatureList = null;
            LicenseUsageForToolNameFormBean luToolFilter = null;
            if (luToolNameList != null && luToolNameList.size() > 0) {
                for (int i = 0; i < luToolNameList.size(); i++) {
                    LicenseUsageForToolNameFormBean luToolInfo = luToolNameList.get(i);
                    String toolName = luToolInfo.getToolName();
                    luFeatureList = this.getLicenseFeatureList(luToolInfo); // Filter by Host
                    // Calculation sum runtime and run number of Vendor
                    int runTimeForTool = 0;
                    int runNumberForTool = 0;
                    int lengthFeatureList = 0;
                    if (luFeatureList != null && luFeatureList.size() > 0) {
                        for (int j = 0; j < luFeatureList.size(); j++) {
                            LicenseUsageForFeatureFormBean luFeatureInfo = luFeatureList.get(j);
                            runTimeForTool += luFeatureInfo.getRunTimeForFeature();
                            runNumberForTool += luFeatureInfo.getRunNumberForFeature();
                            lengthFeatureList += luFeatureInfo.getLengthAccList();
                        }
                        // Set field to Object LicenseUsageForFeatureFormBean
                        luToolFilter = new LicenseUsageForToolNameFormBean(toolName, luFeatureList,
                                runTimeForTool, runNumberForTool, lengthFeatureList);
                        luToolFilterList.add(luToolFilter);
                    }
                }
            }
        }
        return luToolFilterList;
    }

    /**
     * getLicenseFeatureList
     * @param luToolInfo
     * @return List<LicenseUsageForFeatureFormBean>
     */
    private List<LicenseUsageForFeatureFormBean> getLicenseFeatureList(LicenseUsageForToolNameFormBean luToolInfo) {
        LicenseUsageForFeatureFormBean luFeature = null;
        List<LicenseUsageDetailForDBFormBean> luDetailFeatureList = null;
        List<LicenseUsageForFeatureFormBean> luFeatureList = new ArrayList<LicenseUsageForFeatureFormBean>();
        List<LicenseUsageForFeatureFormBean> luFeatureFilterList = new ArrayList<LicenseUsageForFeatureFormBean>();
        List<LicenseUsageDetailForDBFormBean> luDetailDBList = luToolInfo.getLicenseUsageDetailForDBList();
        if (luDetailDBList != null && luDetailDBList.size() > 0) {
            int lengthDetailDB = luDetailDBList.size();
            /* Compare 2 Tool Name in List Tool - START */
            for (int ii = 0; ii < lengthDetailDB; ii++) {
                LicenseUsageDetailForDBFormBean luDetailFirst = luDetailDBList.get(ii);
                luDetailFeatureList = new ArrayList<LicenseUsageDetailForDBFormBean>();
                String futureFirst = luDetailFirst.getFutureName();
                luDetailFeatureList.add(luDetailFirst);
                for (int i = ii + 1; i < lengthDetailDB; i++) {
                    LicenseUsageDetailForDBFormBean luDetailSecond = luDetailDBList.get(i);
                    String futureSecond = luDetailSecond.getFutureName();
                    if (!StringUtils.isEmpty(futureFirst) && futureFirst.equals(futureSecond)) {
                        luDetailFeatureList.add(luDetailSecond);
                        /* Process List when 2 tool same - START */
                        luDetailDBList.remove(i);
                        lengthDetailDB--;
                        i--;
                        /* Process List when 2 tool same - END */
                    }
                }
                luFeature = new LicenseUsageForFeatureFormBean(futureFirst, luDetailFeatureList);
                luFeatureList.add(luFeature);
            }
            /* Compare 2 Tool Name in List Tool - END */
            List<LicenseUsageForAccountFormBean> luAccList = null;
            LicenseUsageForFeatureFormBean luFeatureFilter = null;
            if (luFeatureList != null && luFeatureList.size() > 0) {
                for (int i = 0; i < luFeatureList.size(); i++) {
                    LicenseUsageForFeatureFormBean luFeatureInfo = luFeatureList.get(i);
                    String futureName = luFeatureInfo.getFutureName();
                    luAccList = this.getLicenseAccList(luFeatureInfo); // Filter by Host
                    // Calculation sum runtime and run number of Vendor
                    int runTimeForFeature = 0;
                    int runNumberForFeature = 0;
                    int lengthAccList = 0;
                    if (luAccList != null && luAccList.size() > 0) {
                        for (int j = 0; j < luAccList.size(); j++) {
                            LicenseUsageForAccountFormBean luAccInfo = luAccList.get(j);
                            runTimeForFeature += luAccInfo.getRunTimeForAcc();
                            runNumberForFeature += luAccInfo.getRunNumberForAcc();
                            lengthAccList += luAccInfo.getLengthHostList();
                        }
                        // Set field to Object LicenseUsageForFeatureFormBean
                        luFeatureFilter = new LicenseUsageForFeatureFormBean(futureName, luAccList,
                                runTimeForFeature, runNumberForFeature, lengthAccList);
                        luFeatureFilterList.add(luFeatureFilter);
                    }
                }
            }
        }
        return luFeatureFilterList;
    }

    /**
     * getLicenseAccList
     * @param luFeatureInfo
     * @return List<LicenseUsageForAccountFormBean>
     */
    private List<LicenseUsageForAccountFormBean> getLicenseAccList(LicenseUsageForFeatureFormBean luFeatureInfo) {
        LicenseUsageForAccountFormBean luAcc = null;
        List<LicenseUsageForAccountFormBean> luAccList = new ArrayList<LicenseUsageForAccountFormBean>();
        LicenseUsageForHostFormBean luHost = null;
        List<LicenseUsageForHostFormBean> luHostList = null;
        List<LicenseUsageDetailForDBFormBean> luDetailDB = luFeatureInfo.getLicenseUsageDetailForDBList();
        int lengDetailDB = luDetailDB.size();
        for (int ii = 0; ii < lengDetailDB; ii++) {
            luHostList = new ArrayList<LicenseUsageForHostFormBean>();
            luAcc = new LicenseUsageForAccountFormBean();
            LicenseUsageDetailForDBFormBean luDetailFirst = luDetailDB.get(ii);
            /* Get data from Object LicenseUsageDetailForDBFormBean - START */
            String accountFirst = luDetailFirst.getAccount();
            String hostFirst = luDetailFirst.getHost();
            int runTimeFirst = luDetailFirst.getRunTimeWithoutFew();
            int runNumberFirst = luDetailFirst.getRunNumberWithoutFew();
            String strIsChangeFirst = BLANK;
            if (luDetailFirst.getIsCharge() == 1) {
                strIsChangeFirst = Constants.IS_CHANGE_TRUE;
            }
            /* Get data from Object LicenseUsageDetailForDBFormBean - END */
            String strRunTimeFirst = this.getStrRunTime(luDetailFirst.getRunTimeWithoutFew()); // Set field to Object LicenseUsageForHostFormBean
            // Set field to Object LicenseUsageForHostFormBean
            luHost = new LicenseUsageForHostFormBean(hostFirst, runTimeFirst, runNumberFirst, strIsChangeFirst,
                    strRunTimeFirst);
            luHostList.add(luHost);
            for (int i = ii + 1; i < lengDetailDB; i++) {
                LicenseUsageDetailForDBFormBean luDetailSecond = luDetailDB.get(i);
                String accountSecond = luDetailSecond.getAccount();
                if (!StringUtils.isEmpty(accountFirst) && accountFirst.equals(accountSecond)) {
                    /* Get data from Object LicenseUsageDetailForDBFormBean - START */
                    String hostSecond = luDetailSecond.getHost();
                    int runTimeSecond = luDetailSecond.getRunTimeWithoutFew();
                    int runNumberSecond = luDetailSecond.getRunNumberWithoutFew();
                    String strIsChangeSecond = BLANK;
                    if (luDetailSecond.getIsCharge() == 1) {
                        strIsChangeSecond = Constants.IS_CHANGE_TRUE;
                    }
                    /* Get data from Object LicenseUsageDetailForDBFormBean - END */
                    String strRunTimeSecond = this.getStrRunTime(luDetailSecond.getRunTimeWithoutFew()); // convert date from seconds to type HH:MM:SS
                    // Set field to Object LicenseUsageForHostFormBean
                    luHost = new LicenseUsageForHostFormBean(hostSecond, runTimeSecond, runNumberSecond,
                            strIsChangeSecond, strRunTimeSecond);
                    luHostList.add(luHost);
                    // Process when 2 elements equal
                    luDetailDB.remove(i);
                    lengDetailDB--;
                    i--;
                }
            }
            // Calculation sum runtime and run number of Feature
            int runTimeForAcc = 0;
            int runNumberForAcc = 0;
            int lengthHostList = luHostList.size();
            for (int k = 0; k < lengthHostList; k++) {
                LicenseUsageForHostFormBean luHostInfo = luHostList.get(k);
                runTimeForAcc += luHostInfo.getRunTimeWithoutFew();
                runNumberForAcc += luHostInfo.getRunNumberWithoutFew();
            }
            // Set field to Object LicenseUsageForFeatureFormBean
            luAcc = new LicenseUsageForAccountFormBean(accountFirst, luHostList,
                    runTimeForAcc, runNumberForAcc, lengthHostList);
            luAccList.add(luAcc);
        }
        return luAccList;
    }

    /**
     * getLicenseVendorFilterList
     * @param luToolList
     * @return List<LicenseUsageForVendorFormBean>
     */
    private List<LicenseUsageForVendorFormBean> getLicenseVendorFilterList(
            List<LicenseUsageForToolNameFormBean> luToolList) {
        LicenseUsageForVendorFormBean luVendor = null;
        List<LicenseUsageForToolNameFormBean> luToolFilterList = null;
        List<LicenseUsageForVendorFormBean> luVendorList = new ArrayList<LicenseUsageForVendorFormBean>();
        int lengthTool = luToolList.size();
        for (int ii = 0; ii < lengthTool; ii++) {
            LicenseUsageForToolNameFormBean luToolFirst = luToolList.get(ii);
            luToolFilterList = new ArrayList<LicenseUsageForToolNameFormBean>();
            luVendor = new LicenseUsageForVendorFormBean();
            String vendorNameFirst = luToolFirst.getVendorName();
            luToolFilterList.add(luToolFirst);
            for (int i = ii + 1; i < lengthTool; i++) {
                LicenseUsageForToolNameFormBean luToolSecond = luToolList.get(i);
                String vendorNameSecond = luToolSecond.getVendorName();
                if (!StringUtils.isEmpty(vendorNameFirst) && vendorNameFirst.equals(vendorNameSecond)) {
                    luToolFilterList.add(luToolSecond);
                    /* Process List when 2 tool same - START */
                    luToolList.remove(i);
                    lengthTool--;
                    i--;
                    /* Process List when 2 tool same - END */
                }
            }
            // Calculation sum runtime and run number of Vendor
            int runTimeForVendor = 0;
            int runNumberForVendor = 0;
            int lengthToolList = 0;
            if (luToolFilterList != null && luToolFilterList.size() > 0) {
                for (int j = 0; j < luToolFilterList.size(); j++) {
                    LicenseUsageForToolNameFormBean luToolInfo = luToolFilterList.get(j);
                    runTimeForVendor += luToolInfo.getRunTimeForTool();
                    runNumberForVendor += luToolInfo.getRunNumberForTool();
                    lengthToolList += luToolInfo.getLengthFeatureList();
                }
                // Set field to Object LicenseUsageForFeatureFormBean
                luVendor = new LicenseUsageForVendorFormBean(vendorNameFirst, luToolFilterList,
                        runTimeForVendor, runNumberForVendor, lengthToolList);
                luVendorList.add(luVendor);
            }
        }
        return luVendorList;
    }

    /**
     * getLicenseVendorEmptyList
     * 
     * @return List<LicenseUsageForVendorFormBean>
     */
    private List<LicenseUsageForVendorFormBean> getLicenseVendorEmptyList() {
        // Set field to Object LicenseUsageForHostFormBean
        List<LicenseUsageForHostFormBean> luHostEmptyList = new ArrayList<LicenseUsageForHostFormBean>();
        LicenseUsageForHostFormBean luHostEmpty = new LicenseUsageForHostFormBean(
                Constants.NAME_CATALOG_EMPTY, Constants.NO_VALUE, Constants.NO_VALUE,
                Constants.NAME_CATALOG_EMPTY, Constants.NAME_CATALOG_EMPTY);
        luHostEmptyList.add(luHostEmpty);
        // Set field to Object LicenseUsageForFeatureFormBean
        List<LicenseUsageForAccountFormBean> luAccEmptyList = new ArrayList<LicenseUsageForAccountFormBean>();
        LicenseUsageForAccountFormBean luAccEmpty = new LicenseUsageForAccountFormBean(Constants.NAME_CATALOG_EMPTY,
                luHostEmptyList, Constants.NO_VALUE, Constants.NO_VALUE, 1);
        luAccEmptyList.add(luAccEmpty);
        // Set field to Object LicenseUsageForFeatureFormBean
        List<LicenseUsageForFeatureFormBean> luFeatureEmptyList = new ArrayList<LicenseUsageForFeatureFormBean>();
        LicenseUsageForFeatureFormBean luFeatureEmpty = new LicenseUsageForFeatureFormBean(Constants.NAME_CATALOG_EMPTY,
                luAccEmptyList, Constants.NO_VALUE, Constants.NO_VALUE, 1);
        luFeatureEmptyList.add(luFeatureEmpty);
        // Set field to Object LicenseUsageForFeatureFormBean
        List<LicenseUsageForToolNameFormBean> luToolEmptyList = new ArrayList<LicenseUsageForToolNameFormBean>();
        LicenseUsageForToolNameFormBean luToolEmpty = new LicenseUsageForToolNameFormBean(Constants.NAME_CATALOG_EMPTY,
                luFeatureEmptyList, Constants.NO_VALUE, Constants.NO_VALUE, 1);
        luToolEmptyList.add(luToolEmpty);
        // Set field to Object LicenseUsageForFeatureFormBean
        List<LicenseUsageForVendorFormBean> luVendorEmptyList = new ArrayList<LicenseUsageForVendorFormBean>();
        LicenseUsageForVendorFormBean luVendorEmpty = new LicenseUsageForVendorFormBean(Constants.NAME_CATALOG_EMPTY,
                luToolEmptyList, Constants.NO_VALUE, Constants.NO_VALUE, 1);
        luVendorEmptyList.add(luVendorEmpty);

        return luVendorEmptyList;
    }

    /**
     * compareLists
     * @param prevList
     * @param modelList
     * @return boolean
     */
    private boolean compareLists(List<LicenseUsageForFeatureFormBean> prevList,
            List<LicenseUsageForFeatureFormBean> modelList) {
        boolean indicator = false;
        if (prevList != null && modelList != null && prevList.size() == modelList.size()) {
            for (LicenseUsageForFeatureFormBean modelListdata : modelList) {
                String futureNameModel = modelListdata.getFutureName();
                int sameTimeUseNumberModel = modelListdata.getSameTimeUseNumber();
                for (LicenseUsageForFeatureFormBean prevListdata : prevList) {
                    String futureNamePrev = prevListdata.getFutureName();
                    int sameTimeUseNumberPrev = prevListdata.getSameTimeUseNumber();
                    if (futureNamePrev.equals(futureNameModel) && sameTimeUseNumberPrev == sameTimeUseNumberModel) {
                        indicator = true;
                        break;
                    } else {
                        indicator = false;
                    }
                }
                if (!indicator) {
                    break;
                }
            }
        }
        return indicator;
    }

    /**
     * getLicenseUsageToolNameFilterList
     * @param luToolList
     * @return List<LicenseUsageForToolNameFormBean>
     */
    private List<LicenseUsageForToolNameFormBean> getLicenseUsageToolNameFilterList (List<LicenseUsageForToolNameFormBean> luToolList) {
        int lengthTool = luToolList.size();
        List<LicenseUsageForToolNameFormBean> luToolNameList = new ArrayList<LicenseUsageForToolNameFormBean>();
        /* Compare 2 Tool Name in List Tool - START */
        for (int jj = 0; jj < lengthTool; jj++) {
            LicenseUsageForToolNameFormBean luToolFirst = luToolList.get(jj);
            // Declare tool Name
            LicenseUsageForToolNameFormBean luToolName = new LicenseUsageForToolNameFormBean();
            LicenseUsageForProjectToolNameFormBean luProjectForTool = new LicenseUsageForProjectToolNameFormBean();
            List<LicenseUsageForProjectToolNameFormBean> luProjectForToolList = new ArrayList<LicenseUsageForProjectToolNameFormBean>();
            String toolNameFirst = luToolFirst.getToolName();
            String vendorFirst = luToolFirst.getVendorName();

            luProjectForTool.setProjectName(luToolFirst.getProjectName());
            luProjectForTool.setProductNumber(luToolFirst.getProductNumber());
            luProjectForTool.setLicenseUsageForFeatureList(luToolFirst.getLicenseUsageForFeatureList());
            luProjectForToolList.add(luProjectForTool);
            if (!StringUtils.isEmpty(toolNameFirst) && !toolNameFirst.equals(Constants.NAME_CATALOG_EMPTY)) {
                for (int j = jj + 1; j < lengthTool; j++) {
                    LicenseUsageForToolNameFormBean luToolSecond = luToolList.get(j);
                    String toolNameSecond = luToolSecond.getToolName();
                    if (toolNameFirst.equals(toolNameSecond)) {
                        luProjectForTool = new LicenseUsageForProjectToolNameFormBean();
                        luProjectForTool.setProjectName(luToolSecond.getProjectName());
                        luProjectForTool.setProductNumber(luToolSecond.getProductNumber());
                        luProjectForTool.setLicenseUsageForFeatureList(luToolSecond.getLicenseUsageForFeatureList());
                        luProjectForToolList.add(luProjectForTool);
                        /* Process List when 2 tool same - START */
                        luToolList.remove(j);
                        lengthTool--;
                        j--;
                        /* Process List when 2 tool same - END */
                    }
                }
            }
            /* Add Tool Name to new List Tool - START */
            luToolName.setToolName(toolNameFirst);
            luToolName.setVendorName(vendorFirst);
            luToolName.setLicenseUsageForProjectToolNameList(luProjectForToolList);
            luToolNameList.add(luToolName);
            /* Add Tool Name to new List Tool - END */
        }
        /* Compare 2 Tool Name in List Tool - END */
        /* Compare 2 List Feature Name of Tool Name - START */
        List<LicenseUsageForProjectToolNameFormBean> luProjectFilterForToolNameList = null;
        LicenseUsageForProjectToolNameFormBean luProjectForTool = null;
        List<LicenseUsageForToolNameFormBean> luToolNameFilterList = new ArrayList<LicenseUsageForToolNameFormBean>();
        List<LicenseUsageForToolNameFormBean> luToolNameFilterSortList = new ArrayList<LicenseUsageForToolNameFormBean>();
        for (int i = 0; i < luToolNameList.size(); i++) {
            LicenseUsageForToolNameFormBean toolNameInfo = luToolNameList.get(i);
            String toolName = toolNameInfo.getToolName();
            List<LicenseUsageForProjectToolNameFormBean> luProjectForToolNameList = toolNameInfo
                    .getLicenseUsageForProjectToolNameList();
            luProjectFilterForToolNameList = new ArrayList<LicenseUsageForProjectToolNameFormBean>();
            LicenseUsageForToolNameFormBean luToolName = new LicenseUsageForToolNameFormBean();
            if (!StringUtils.isEmpty(toolName) && !toolName.equals(Constants.NAME_CATALOG_EMPTY)) {
                int lengthPjTool = luProjectForToolNameList.size();
                for (int jj = 0; jj < lengthPjTool; jj++) {
                    luProjectForTool = new LicenseUsageForProjectToolNameFormBean();
                    StringBuilder projectNameBuilder = new StringBuilder();
                    StringBuilder productNumberBuilder = new StringBuilder();
                    LicenseUsageForProjectToolNameFormBean luToolNameFirst = luProjectForToolNameList.get(jj);
                    String projectNameFirst = luToolNameFirst.getProjectName();
                    projectNameBuilder.append(projectNameFirst);
                    String productNumberFirst = luToolNameFirst.getProductNumber();
                    productNumberBuilder.append(productNumberFirst);
                    List<LicenseUsageForFeatureFormBean> luFeatureFirstList = luToolNameFirst
                            .getLicenseUsageForFeatureList();

                    for (int j = jj + 1; j < lengthPjTool; j++) {
                        LicenseUsageForProjectToolNameFormBean luToolNameSecond = luProjectForToolNameList.get(j);
                        String projectNameSecond = luToolNameSecond.getProjectName();
                        String productNumberSecond = luToolNameSecond.getProductNumber();
                        List<LicenseUsageForFeatureFormBean> luFeatureSecondList = luToolNameSecond
                                .getLicenseUsageForFeatureList();

                        boolean flagFeature = this.compareLists(luFeatureFirstList, luFeatureSecondList); // Compare 2 List Feature Name
                        if (flagFeature) {
                            projectNameBuilder.append(Constants.DOT_COMMA).append(projectNameSecond);
                            productNumberBuilder.append(Constants.DOT_COMMA).append(productNumberSecond);

                            luProjectForToolNameList.remove(j);
                            lengthPjTool--;
                            j--;
                        }
                    }

                    luProjectForTool.setProjectName(projectNameBuilder.toString());
                    luProjectForTool.setProductNumber(productNumberBuilder.toString());
                    luProjectForTool.setLicenseUsageForFeatureList(luFeatureFirstList);
                    luProjectForTool.setLengthFeatureList (luFeatureFirstList.size());
                    // Add list project for tool name
                    luProjectFilterForToolNameList.add(luProjectForTool);
                }
            } else {
                luProjectForToolNameList.get(0).setLengthFeatureList(1);
            }
            // Add list license project for tool in tool name
            luToolName.setToolName(toolNameInfo.getToolName());
            luToolName.setVendorName(toolNameInfo.getVendorName());
            if (!StringUtils.isEmpty(toolName) && !toolName.equals(Constants.NAME_CATALOG_EMPTY)) {
                luToolName.setLicenseUsageForProjectToolNameList(luProjectFilterForToolNameList);
                int lengthFeature = 0;
                for (LicenseUsageForProjectToolNameFormBean luTool: luProjectFilterForToolNameList) {
                    lengthFeature += luTool.getLengthFeatureList();
                }
                luToolName.setLengthFeatureAllList(lengthFeature);
            } else {
                luToolName.setLicenseUsageForProjectToolNameList(luProjectForToolNameList);
                luToolName.setLengthFeatureAllList(1);
            }
            luToolNameFilterList.add(luToolName);
        }
        /* Compare 2 List Feature Name of Tool Name - END */
        /* Sort List luToolNameFilter of Tool Name - START */
        List<String> sortToolName = new ArrayList<String>();
        if (luToolNameFilterList.size() > 0) {
            for (int i = 0; i < luToolNameFilterList.size(); i++) {
                LicenseUsageForToolNameFormBean toolNameInfo = luToolNameFilterList.get(i);
                String toolName = toolNameInfo.getToolName();
                if (!StringUtils.isEmpty(toolName) && !toolName.equals(Constants.NAME_CATALOG_EMPTY)) {
                    sortToolName.add(toolName);
                } else {
                    luToolNameFilterSortList.add(toolNameInfo);
                    luToolNameFilterList.remove(i);
                    i--;
                }
            }
            Collections.sort(sortToolName, Collator.getInstance());
            for (int jj = 0; jj < sortToolName.size(); jj++) {
                String toolNameSort = sortToolName.get(jj);
                for (int j = 0; j < luToolNameFilterList.size(); j++) {
                    String toolNameCompare = luToolNameFilterList.get(j).getToolName();
                    if (!StringUtils.isEmpty(toolNameCompare) && toolNameCompare.equals(toolNameSort)) {
                        luToolNameFilterSortList.add(jj, luToolNameFilterList.get(j));
                    }
                }
            }
        }
        /* Sort List luToolNameFilter of Tool Name - START */

        return luToolNameFilterSortList;
    }

    /**
     * getLicenseUsageForProductList
     * 
     * @param List<LicenseUsageForProjectFormBean>
     * @return List<LicenseUsageForProductNumberFormBean>
     */
    private List<LicenseUsageForProductNumberFormBean> getLicenseUsageForProductList (List<LicenseUsageForProjectFormBean> luProjectList) {
        LicenseUsageForProductNumberFormBean luProductNumber = null;
        List<LicenseUsageForProductNumberFormBean> luProductNumberList = new ArrayList<LicenseUsageForProductNumberFormBean>();
        //
            int lengthProject = luProjectList.size();
            if (lengthProject == 1) {
                LicenseUsageForProjectFormBean luProjectInfo = luProjectList.get(0);
                if (luProjectInfo != null) {
                    String strTotalRunTime = this.getStrRunTime(luProjectInfo.getRunTimeForProject()); // convert date from seconds to type HH:MM:SS
                    /* Set value in LicenseUsageForProductNumberFormBean - START */
                    luProductNumber = new LicenseUsageForProductNumberFormBean();
                    luProductNumber.setProductNumber(luProjectInfo.getProductNumber());
                    luProductNumber.setStrTotalRunTime(strTotalRunTime);
                    luProductNumber.setTotalRunTime(luProjectInfo.getRunTimeForProject());
                    luProductNumber.setTotalRunNumber(luProjectInfo.getRunNumberForProject());
                    luProductNumber.setLicenseUsageForProjectList(luProjectList);
                    luProductNumber.setLengthProjectFeatureList(luProjectInfo.getLengthVendorFeatureList());
                    /* Set value in LicenseUsageForProductNumberFormBean - END */
                    luProductNumberList.add(luProductNumber);
                }
            } else {
                luProductNumberList = new ArrayList<LicenseUsageForProductNumberFormBean>();
                /* Compare 2 product Number in List Project - START */
                for (int jj = 0; jj < lengthProject; jj++) {
                    LicenseUsageForProjectFormBean luProjectFirst = luProjectList.get(jj);
                    List<LicenseUsageForProjectFormBean> luProjectForProductNumberList = new ArrayList<LicenseUsageForProjectFormBean>();
                    luProductNumber = new LicenseUsageForProductNumberFormBean();
                    String productNumberFirst = luProjectFirst.getProductNumber();
                    luProjectForProductNumberList.add(luProjectFirst);
                    for (int j = jj + 1; j < lengthProject; j++) {
                        LicenseUsageForProjectFormBean luProjectSecond = luProjectList.get(j);
                        //
                        String productNumberSecond = luProjectSecond.getProductNumber();
                        if(!StringUtils.isEmpty(productNumberFirst) && !StringUtils.isEmpty(productNumberSecond)) {
                            if (productNumberFirst.equals(productNumberSecond)) {
                                luProjectForProductNumberList.add(luProjectSecond);
                                luProjectList.remove(j);
                                lengthProject--;
                                j--;
                            }
                        }
                    }
                    /* Compare 2 product Number in List Project - START */
                    /* Calculator total run time, run number, length feature in project - START */
                    int totalRunTime = 0;
                    int totalRunNumber = 0;
                    int lengthProjectFeatureList = 0;
                    for (int i = 0; i < luProjectForProductNumberList.size(); i++) {
                        LicenseUsageForProjectFormBean luProjectInfo = luProjectForProductNumberList.get(i);
                        //
                        totalRunTime += luProjectInfo.getRunTimeForProject();
                        totalRunNumber += luProjectInfo.getRunNumberForProject();
                        lengthProjectFeatureList += luProjectInfo.getLengthVendorFeatureList();
                    }
                    /* Calculator total run time, run number, length feature in project - END */
                    String strTotalRunTime = this.getStrRunTime(totalRunTime); // convert date from seconds to type HH:MM:SS
                    /* Set value in LicenseUsageForProductNumberFormBean - START */
                    luProductNumber.setProductNumber(productNumberFirst);
                    luProductNumber.setTotalRunTime(totalRunTime);
                    luProductNumber.setStrTotalRunTime(strTotalRunTime);
                    luProductNumber.setTotalRunNumber(totalRunNumber);
                    luProductNumber.setLengthProjectFeatureList(lengthProjectFeatureList);
                    luProductNumber.setLicenseUsageForProjectList(luProjectForProductNumberList);
                    /* Set value in LicenseUsageForProductNumberFormBean - END */
                    luProductNumberList.add(luProductNumber);
                }
            }
        return luProductNumberList;
    }

    /**
     * getLicenseUsageForProductFilterList
     * 
     * @param List<LicenseUsageForProductNumberFormBean>
     * @return List<LicenseUsageForProjectFormBean>
     */
    private List<LicenseUsageForProjectFormBean> getLicenseUsageForProductFilterList (List<LicenseUsageForProductNumberFormBean> luProductNumberList) {
        List<LicenseUsageForProjectFormBean> luProductFilterList = new ArrayList<LicenseUsageForProjectFormBean>();
        LicenseUsageForProjectFormBean luProductFilter = null;
        for (int i = 0; i < luProductNumberList.size(); i++) {
            LicenseUsageForProductNumberFormBean productNumberInfo = luProductNumberList.get(i);
            List<LicenseUsageForProjectFormBean> luProjectForProductList = productNumberInfo
                    .getLicenseUsageForProjectList();

            luProductFilter = new LicenseUsageForProjectFormBean();
            int lengthPjProduct = luProjectForProductList.size();
            StringBuilder projectNameBuilder = new StringBuilder();
            List<LicenseUsageForVendorFormBean> luVendorList = new ArrayList<LicenseUsageForVendorFormBean>();
            for (int j = 0; j < lengthPjProduct; j++) {
                LicenseUsageForProjectFormBean luProductFilterInfo = luProjectForProductList.get(j);
                // 1: IF
                String projectNameInfo = luProductFilterInfo.getProjectName();
                if (j == 0) {
                    projectNameBuilder.append(projectNameInfo);
                } else {
                    projectNameBuilder.append(Constants.DOT_COMMA).append(projectNameInfo);
                }
                luVendorList.addAll(luProductFilterInfo.getLicenseUsageForVendorList());
                }

                luProductFilter.setProductNumber(productNumberInfo.getProductNumber());
                luProductFilter.setProjectName(projectNameBuilder.toString());
                luProductFilter.setLicenseUsageForVendorList(luVendorList);
                /* Calculator total length feature in product - START */
                int lengthVendorFeatureList = 0;
                for (int k = 0; k < luVendorList.size(); k++) {
                    LicenseUsageForVendorFormBean luVendorInfo = luVendorList.get(k);
                    //
                    lengthVendorFeatureList += luVendorInfo.getLengthToolList();
                }
                /* Calculator total length feature in product - END */
                luProductFilter.setLengthVendorFeatureList(lengthVendorFeatureList);
                // Add list project for product Number
                luProductFilterList.add(luProductFilter);
            }
        /* Sort List luToolNameFilter of Tool Name - START */
        List<LicenseUsageForProjectFormBean> luProductFilterSortList = new ArrayList<LicenseUsageForProjectFormBean>();
        List<String> sortProductNumber = new ArrayList<String>();
        if (luProductFilterList.size() > 0) {
            for (int i = 0; i < luProductFilterList.size(); i++) {
                LicenseUsageForProjectFormBean toolProductInfo = luProductFilterList.get(i);
                String productNumber = toolProductInfo.getProductNumber();
                if (!StringUtils.isEmpty(productNumber) && !productNumber.equals(Constants.NAME_CATALOG_EMPTY)) {
                    sortProductNumber.add(productNumber);
                } else {
                    luProductFilterSortList.add(toolProductInfo);
                    luProductFilterList.remove(i);
                    i--;
                }
            }
            Collections.sort(sortProductNumber, Collator.getInstance());
            for (int jj = 0; jj < sortProductNumber.size(); jj++) {
                String productNumberSort = sortProductNumber.get(jj);
                for (int j = 0; j < luProductFilterList.size(); j++) {
                    String productNumberCompare = luProductFilterList.get(j).getProductNumber();
                    if (!StringUtils.isEmpty(productNumberCompare) && productNumberCompare.equals(productNumberSort)) {
                        luProductFilterSortList.add(jj, luProductFilterList.get(j));
                    }
                }
            }
        }
        /* Sort List luToolNameFilter of Tool Name - START */
    return luProductFilterSortList;
    }

    /**
     * writeSumaryCsv
     * 
     * @return Boolean
     */
    private Boolean writeSumaryCsv(FileOutputStream outputStream, String projectSelected, String yearSelected,
            String monthSelected, List<LicenseManagerColumn> licenManaListExport,
            List<LicenseTotalTaxColumn> licenTotalTaxExport, BigDecimal totalBudgetExport,
            BigDecimal totalActualExport, List<LicenseTotalTaxBean> listShowTbl3Export, BigDecimal totalSumTbl3) {
        try {
            CsvWriter csvOutput = new CsvWriter(outputStream, Constants.COMMA_CHAR, StandardCharsets.UTF_8);
            byte b[] = { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF };
            // insert BOM byte array into outputStream
            outputStream.write(b);

            // write header line
            csvOutput.writeRecord(new String[] { CSVHead.getProjectLable(), CSVHead.getYearLable(), CSVHead.getMonthLable(), BLANK });
            csvOutput.writeRecord(new String[] { projectSelected, yearSelected, monthSelected, BLANK });
            csvOutput.endRecord();

            csvOutput.writeRecord(new String[] { CSVHead.getTblBudAct(), BLANK });
            csvOutput.writeRecord(new String[] { CSVHead.getProjectLable(), CSVHead.getActual(), CSVHead.getQ1(), BLANK, BLANK,
                    BLANK, CSVHead.getQ2(), BLANK, BLANK, BLANK, CSVHead.getFirstSixMonth(), CSVHead.getQ3(), BLANK, BLANK,
                    BLANK, CSVHead.getQ4(), BLANK, BLANK, BLANK, CSVHead.getSecondSixMonth(), CSVHead.getTotalYear(), BLANK });

            csvOutput.writeRecord(new String[] { BLANK, BLANK, CSVHead.getMonth4(), CSVHead.getMonth5(), CSVHead.getMonth6(),
                    CSVHead.getCumulative(), CSVHead.getMonth7(), CSVHead.getMonth8(), CSVHead.getMonth9(),
                    CSVHead.getCumulative(), BLANK, CSVHead.getMonth10(), CSVHead.getMonth11(), CSVHead.getMonth12(),
                    CSVHead.getCumulative(), CSVHead.getMonth1(), CSVHead.getMonth2(), CSVHead.getMonth3(),
                    CSVHead.getCumulative(), BLANK, BLANK, BLANK });

            if (licenManaListExport != null && licenManaListExport.size() > 0) {
                for (int i = 0; i < licenManaListExport.size(); i++) {
                    LicenseManagerColumn licenseManaInfo = licenManaListExport.get(i);

                    String projectName = licenseManaInfo.getProjectName();
                    /* Get value license budget - START */
                    String budgetMonth4 = (licenseManaInfo.getBudgetMonth4Div1000()).toString();
                    String budgetMonth5 = (licenseManaInfo.getBudgetMonth5Div1000()).toString();
                    String budgetMonth6 = (licenseManaInfo.getBudgetMonth6Div1000()).toString();
                    String budgetSumQ1 = (licenseManaInfo.getBudgetSumQ1Div1000()).toString();
                    String budgetMonth7 = (licenseManaInfo.getBudgetMonth7Div1000()).toString();
                    String budgetMonth8 = (licenseManaInfo.getBudgetMonth8Div1000()).toString();
                    String budgetMonth9 = (licenseManaInfo.getBudgetMonth9Div1000()).toString();
                    String budgetSumQ2 = (licenseManaInfo.getBudgetSumQ2Div1000()).toString();
                    String budgetSumQ12 = (licenseManaInfo.getBudgetSumQ12Div1000()).toString();
                    String budgetMonth10 = (licenseManaInfo.getBudgetMonth10Div1000()).toString();
                    String budgetMonth11 = (licenseManaInfo.getBudgetMonth11Div1000()).toString();
                    String budgetMonth12 = (licenseManaInfo.getBudgetMonth12Div1000()).toString();
                    String budgetSumQ3 = (licenseManaInfo.getBudgetSumQ3Div1000()).toString();
                    String budgetMonth1 = (licenseManaInfo.getBudgetMonth1Div1000()).toString();
                    String budgetMonth2 = (licenseManaInfo.getBudgetMonth2Div1000()).toString();
                    String budgetMonth3 = (licenseManaInfo.getBudgetMonth3Div1000()).toString();
                    String budgetSumQ4 = (licenseManaInfo.getBudgetSumQ4Div1000()).toString();
                    String budgetSumQ34 = (licenseManaInfo.getBudgetSumQ34Div1000()).toString();
                    String budgetTotalInYear = (licenseManaInfo.getBudgetTotalInYearDiv1000()).toString();
                    /* Get value license budget - END */

                    /* Get value license actual - START */
                    String actualMonth4 = (licenseManaInfo.getActualMonth4Div1000()).toString();
                    String actualMonth5 = (licenseManaInfo.getActualMonth5Div1000()).toString();
                    String actualMonth6 = (licenseManaInfo.getActualMonth6Div1000()).toString();
                    String actualSumQ1 = (licenseManaInfo.getActualSumQ1Div1000()).toString();
                    String actualMonth7 = (licenseManaInfo.getActualMonth7Div1000()).toString();
                    String actualMonth8 = (licenseManaInfo.getActualMonth8Div1000()).toString();
                    String actualMonth9 = (licenseManaInfo.getActualMonth9Div1000()).toString();
                    String actualSumQ2 = (licenseManaInfo.getActualSumQ2Div1000()).toString();
                    String actualSumQ12 = (licenseManaInfo.getActualSumQ12Div1000()).toString();
                    String actualMonth10 = (licenseManaInfo.getActualMonth10Div1000()).toString();
                    String actualMonth11 = (licenseManaInfo.getActualMonth11Div1000()).toString();
                    String actualMonth12 = (licenseManaInfo.getActualMonth12Div1000()).toString();
                    String actualSumQ3 = (licenseManaInfo.getActualSumQ3Div1000()).toString();
                    String actualMonth1 = (licenseManaInfo.getActualMonth1Div1000()).toString();
                    String actualMonth2 = (licenseManaInfo.getActualMonth2Div1000()).toString();
                    String actualMonth3 = (licenseManaInfo.getActualMonth3Div1000()).toString();
                    String actualSumQ4 = (licenseManaInfo.getActualSumQ4Div1000()).toString();
                    String actualSumQ34 = (licenseManaInfo.getActualSumQ34Div1000()).toString();
                    String actualTotalInYear = (licenseManaInfo.getActualTotalInYearDiv1000()).toString();
                    /* Get value license actual - END */

                    csvOutput.writeRecord(new String[] { projectName, CSVHead.getBudget(), budgetMonth4, budgetMonth5,
                            budgetMonth6, budgetSumQ1, budgetMonth7, budgetMonth8, budgetMonth9, budgetSumQ2,
                            budgetSumQ12, budgetMonth10, budgetMonth11, budgetMonth12, budgetSumQ3, budgetMonth1,
                            budgetMonth2, budgetMonth3, budgetSumQ4, budgetSumQ34, budgetTotalInYear, BLANK });

                    csvOutput.writeRecord(new String[] { BLANK, CSVHead.getActual(), actualMonth4, actualMonth5,
                            actualMonth6, actualSumQ1, actualMonth7, actualMonth8, actualMonth9, actualSumQ2,
                            actualSumQ12, actualMonth10, actualMonth11, actualMonth12, actualSumQ3, actualMonth1,
                            actualMonth2, actualMonth3, actualSumQ4, actualSumQ34, actualTotalInYear, BLANK });
                }
            }
            csvOutput.endRecord();

            csvOutput.writeRecord(new String[] { CSVHead.getTotalPerMonth(), BLANK });
            csvOutput.writeRecord(new String[] { CSVHead.getProjectLable(), CSVHead.getTypeCharge(), CSVHead.getTaxRegis(),
                    CSVHead.getMoneyBudget(), CSVHead.getTaxUse(), CSVHead.getMoneyActual(), BLANK });

            if (licenTotalTaxExport != null && licenTotalTaxExport.size() > 0) {
                for (LicenseTotalTaxColumn totalTax : licenTotalTaxExport) {
                    String projectNameTotalTax = totalTax.getProjectName();
                    String moneyBudgetTotalTax = (totalTax.getMoneyBudgetPerMonth()).toString();
                    String moneyActualTotalTax = (totalTax.getMoneyActualPerMonth()).toString();

                    csvOutput.writeRecord(new String[] { projectNameTotalTax, CSVHead.getTaxUseRegis(), CSVHead.getStar1(),
                            moneyBudgetTotalTax, CSVHead.getStar2(), moneyActualTotalTax,
                            BLANK });
                }
            }

            String totalBudgetExportStr = totalBudgetExport.toString();
            String totalActualExportStr = totalActualExport.toString();

            csvOutput.writeRecord(new String[] { CSVHead.getSumaryPerMonth(), BLANK, CSVHead.getDashChar(),
                    totalBudgetExportStr, CSVHead.getDashChar(), totalActualExportStr,
                    BLANK });

            csvOutput.endRecord();
            csvOutput.writeRecord(new String[] { CSVHead.getBillingDetail(), BLANK });
            csvOutput.writeRecord(new String[] { CSVHead.getProjectLable(), CSVHead.getProductNumber(),
                    CSVHead.getTypeCharge(), BLANK, BLANK, BLANK, CSVHead.getUseLicense(), CSVHead.getRegisLicense(),
                    CSVHead.getBaseUsed(), CSVHead.getChargeUse(), CSVHead.getUnitPrice(), CSVHead.getCharge(), BLANK });

            if (listShowTbl3Export != null && listShowTbl3Export.size() > 0) {
                int tbl3ExportSize = listShowTbl3Export.size();
                List<LicenseTotalTaxColumn> taxColumns = null;
                
                String totalTbl3 = totalSumTbl3.toString();
                
                for (int j = 0; j < tbl3ExportSize; j++) {
                    LicenseTotalTaxBean showTbl3Export = listShowTbl3Export.get(j);

                    taxColumns = showTbl3Export.getTaxList();

                    String projectName = showTbl3Export.getProjectName();
                    String productNumber = showTbl3Export.getProductNumber();
                    String sumTaxMoneyPro = (showTbl3Export.getSumTaxMoneyPro()).toString();

                    String[] grossTotalProject = new String[] { BLANK, BLANK, CSVHead.getTotal(), BLANK, BLANK, BLANK,
                            BLANK, BLANK, BLANK, BLANK, BLANK, sumTaxMoneyPro, BLANK };

                    if (taxColumns != null && taxColumns.size() > 0) {
                        int taxLen = taxColumns.size();
                        for (int jj = 0; jj < taxLen; jj++) {
                            LicenseTotalTaxColumn tax = taxColumns.get(jj);

                            String venderNameTax = tax.getVenderName();
                            String toolNameTax = tax.getToolName();
                            String futureNameTax = tax.getFutureName();
                            String countActualTax = (tax.getCountActualPerMonth()).toString();
                            String countBudgetTax = (tax.getCountBudgetPerMonth()).toString();
                            String memberPriceTax = (tax.getMemberPrice()).toString();
                            String moneyBudgetTax = (tax.getMoneyBudgetPerMonth()).toString();
                            String countSubTractTax = (tax.getCountSubTractBudgetActual()).toString();
                            String regularPriceTax = (tax.getRegularPrice()).toString();
                            String moreBudgetTax = (tax.getMoreBudgetPerMonth()).toString();

                            if (jj == 0) {
                                String[] lineProject = new String[] { projectName, productNumber,
                                        CSVHead.getLicenseUseSame(), venderNameTax, toolNameTax, futureNameTax,
                                        countActualTax, countBudgetTax, CSVHead.getBasic(), countBudgetTax,
                                        memberPriceTax, moneyBudgetTax, BLANK };

                                csvOutput.writeRecord(lineProject);
                            } else {
                                String[] lineLicenseUse = new String[] { BLANK, BLANK, CSVHead.getLicenseUseSame(),
                                        venderNameTax, toolNameTax, futureNameTax, countActualTax, countBudgetTax,
                                        CSVHead.getBasic(), countBudgetTax, memberPriceTax, moneyBudgetTax, BLANK };

                                csvOutput.writeRecord(lineLicenseUse);
                            }

                            String[] lineQuanlity = new String[] { BLANK, BLANK, BLANK, BLANK, BLANK, BLANK, BLANK,
                                    BLANK, CSVHead.getQuanlity(), countSubTractTax, regularPriceTax, moreBudgetTax, BLANK };

                            csvOutput.writeRecord(lineQuanlity);
                        }
                        csvOutput.writeRecord(grossTotalProject);
                    }
                }
                csvOutput.writeRecord(new String[] { CSVHead.getSumaryPerMonth(), BLANK, BLANK, BLANK, BLANK, BLANK,
                        BLANK, BLANK, BLANK, BLANK, BLANK, totalTbl3, BLANK });

                csvOutput.endRecord();
                csvOutput.close();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return true;
    }

    /**
     * writeSupporterSumaryCsv
     * 
     * @param FileOutputStream
     * @return Boolean
     */
    private Boolean writeSupporterSumaryCsv(FileOutputStream outputStream,
            List<LicenseTotalTaxColumn> licenTotalTaxExport) {
        try {
            CsvWriter csvOutput = new CsvWriter(outputStream, Constants.COMMA_CHAR, StandardCharsets.UTF_8);
            byte b[] = { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF };
            // insert BOM byte array into outputStream
            outputStream.write(b);

           //write header line
            csvOutput.writeRecord(new String[] {CSVHead.getProjectName(), CSVHead.getProductNumberSupporter(),
                                CSVHead.getLoadOriginCodeSupporter(), CSVHead.getTotalPriceSupporter(), BLANK});

            if(licenTotalTaxExport  != null && licenTotalTaxExport.size() > 0) {
                for (int j = 0; j < licenTotalTaxExport.size(); j++) {
                    LicenseTotalTaxColumn licenTotalTaxExportInfo = licenTotalTaxExport.get(j);

                    String projectName = licenTotalTaxExportInfo.getProjectName();
                    String productNumber = licenTotalTaxExportInfo.getProductNumber();
                    String loadOriginCode = licenTotalTaxExportInfo.getLoadOriginCode();
                    String moneyActualPerMonth = (Long.valueOf(licenTotalTaxExportInfo.getMoneyActualPerMonth().longValue())).toString();

                    csvOutput.writeRecord(new String[] { projectName, productNumber, loadOriginCode,
                            moneyActualPerMonth, BLANK });
                }
            }

            csvOutput.endRecord();
            csvOutput.close();
            
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
        return true;
    }

    /**
     * writeQAToCsv
     * 
     * @param FileOutputStream
     * @return Boolean
     */
    private Boolean writeQAToCsv(FileOutputStream outputStream) {
        try {
            CsvWriter csvOutput = new CsvWriter(outputStream, Constants.COMMA_CHAR,
                    StandardCharsets.UTF_8);
            byte b[] = { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF };
            // insert BOM byte array into outputStream
            outputStream.write(b);
            // header line drop down List
            csvOutput.writeRecord(new String[] { CSVHead.getProjectLable(), CSVHead.getYearLable(),
                    CSVHead.getMonthLable(), BLANK, BLANK, BLANK, BLANK, BLANK, BLANK, BLANK, BLANK });
            // write out a few records
            String yearCsv = yearSelected + CSVHead.getYearLable();
            String monthCsv = monthSelected + CSVHead.getMonthLable();
            csvOutput.writeRecord(new String[] { projectSelected, yearCsv, monthCsv, BLANK, BLANK, BLANK, BLANK, BLANK,
                    BLANK, BLANK, BLANK });
            csvOutput.writeRecord(new String[] { System.getProperty("line.separator")});
            csvOutput.writeRecord(new String[] { CSVHead.getExecuteTimeCount(), BLANK, BLANK, BLANK, BLANK, BLANK,
                    BLANK, BLANK, BLANK, BLANK, BLANK });
            /* Output CSV data Execute Info - START */
            this.writeCsvByExecute(csvOutput);
            csvOutput.writeRecord(new String[] { System.getProperty("line.separator")});
            csvOutput.writeRecord(new String[] { CSVHead.getSimultaneousUseNumber(), BLANK, BLANK, BLANK, BLANK, BLANK,
                    BLANK, BLANK, BLANK, BLANK, BLANK });
            /* Filter Tool - START */
            csvOutput.writeRecord(new String[] { CSVHead.getFilterTool(), BLANK, BLANK, BLANK, BLANK, BLANK, BLANK,
                    BLANK, BLANK, BLANK, BLANK });
            this.writeCsvByTool(csvOutput);
            /* Filter Tool - END */
            /* Filter Product - START */
            csvOutput.writeRecord(new String[] { System.getProperty("line.separator")});
            csvOutput.writeRecord(new String[] { CSVHead.getFilterProduct(), BLANK, BLANK, BLANK, BLANK, BLANK, BLANK,
                    BLANK, BLANK, BLANK, BLANK });
            this.writeCsvByProduct(csvOutput);
            /* Filter Product - END */
            /* Filter Project - START */
            csvOutput.writeRecord(new String[] { System.getProperty("line.separator")});
            csvOutput.writeRecord(new String[] { CSVHead.getFilterProject(), BLANK, BLANK, BLANK, BLANK, BLANK, BLANK,
                    BLANK, BLANK, BLANK, BLANK });
            this.writeCsvByProject(csvOutput);
            /* Filter Project - END */
            csvOutput.endRecord();
            csvOutput.close();
            // write out a few records
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
        return true;
    }

    /**
     * writeCsvByExecute
     * 
     * @param CsvWriter
     * @return void
     */
    private void writeCsvByExecute(CsvWriter csvOutput) {
        try {
            String acount = CSVHead.getAccountName();
            acount = acount.replace("<br/>", String.valueOf("\r\n"));
            String strRunTime = CSVHead.getExecuteTime();
            strRunTime = strRunTime.replace("<br/>", String.valueOf("\r\n"));
            csvOutput.writeRecord(new String[] { CSVHead.getProductNumber(),
                    CSVHead.getProjectName(), CSVHead.getLoadOriginCode(),
                    acount, CSVHead.getVendorName(),
                    CSVHead.getToolName(), CSVHead.getFutureName(),
                    CSVHead.getHost(), strRunTime,
                    CSVHead.getExecuteNumber(), CSVHead.getReference()});
            //
            int countLengthCsv = 0;
            List<String> productNumberList = null;
            List<String> projectNameList = null;
            List<String> loadOriginCodeList = null;
            List<String> accountList = null;
            List<String> vendorNameList = null;
            List<String> toolNameList = null;
            List<String> futureNameList = null;
            List<String> hostList = null;
            List<String> strRuntimeList = null;
            List<String> runNumberWithoutFewList = null;
            List<String> strIsChargeList = null;
            if (executeInfo != null) {
                //
                productNumberList = new ArrayList<String>();
                projectNameList = new ArrayList<String>();
                loadOriginCodeList = new ArrayList<String>();
                accountList = new ArrayList<String>();
                vendorNameList = new ArrayList<String>();
                toolNameList = new ArrayList<String>();
                futureNameList = new ArrayList<String>();
                hostList = new ArrayList<String>();
                strRuntimeList = new ArrayList<String>();
                runNumberWithoutFewList = new ArrayList<String>();
                strIsChargeList = new ArrayList<String>();
                //
                String grandTotalRunTime = executeInfo.getGrandTotalRunTime();
                int grandTotalRunNumber = executeInfo.getGrandTotalRunNumber();
                int lengthProduct = executeInfo.getLicenseUsageForProductNumberList().size();
                for (int i = 0; i < lengthProduct; i++) {
                    LicenseUsageForProductNumberFormBean luProductNumber = executeInfo.getLicenseUsageForProductNumberList().get(i);
                    String productNumber = luProductNumber.getProductNumber();
                    String strTotalRunTime = luProductNumber.getStrTotalRunTime();
                    int totalRunNumber = luProductNumber.getTotalRunNumber();
                    int lengthProjectFeatureList = luProductNumber.getLengthProjectFeatureList();
                    countLengthCsv += lengthProjectFeatureList + 1;
                    if (lengthProjectFeatureList > 0) {
                        for (int ii = 0; ii < lengthProjectFeatureList; ii++) {
                            if (ii == 0) {
                                productNumberList.add(productNumber);
                            } else {
                                productNumberList.add(BLANK);
                            }
                        }
                    } else {
                        csvOutput.endRecord();
                    }
                    int lengthProject = luProductNumber.getLicenseUsageForProjectList().size();
                    for (int j = 0; j < lengthProject; j++) {
                        LicenseUsageForProjectFormBean luProject = luProductNumber.getLicenseUsageForProjectList().get(j);
                        String projectName = luProject.getProjectName();
                        String loadOriginCode = luProject.getLoadOriginCode();
                        int lengthVendorFeatureList = luProject.getLengthVendorFeatureList();
                        if (lengthVendorFeatureList > 0) {
                            for (int jj = 0; jj < lengthVendorFeatureList; jj++) {
                                if (jj == 0) {
                                    projectNameList.add(projectName);
                                    loadOriginCodeList.add(loadOriginCode);
                                } else {
                                    projectNameList.add(BLANK);
                                    loadOriginCodeList.add(BLANK);
                                }
                            }
                        } else {
                            csvOutput.endRecord();
                        }
                        int lengthVendor = luProject.getLicenseUsageForVendorList().size();
                        for (int k = 0; k < lengthVendor; k++) {
                            LicenseUsageForVendorFormBean luVendor = luProject.getLicenseUsageForVendorList().get(k);
                            String vendorName = luVendor.getVendorName();
                            int lengthToolList = luVendor.getLengthToolList();
                            if (lengthToolList > 0) {
                                for (int kk = 0; kk < lengthToolList; kk++) {
                                    if (kk == 0) {
                                        vendorNameList.add(vendorName);
                                    } else {
                                        vendorNameList.add(BLANK);
                                    }
                                }
                            } else {
                                csvOutput.endRecord();
                            }
                            int lengthTool = luVendor.getLicenseUsageForToolNameList().size();
                            for (int l = 0; l < lengthTool; l++) {
                                LicenseUsageForToolNameFormBean luTool = luVendor.getLicenseUsageForToolNameList().get(l);
                                String toolName = luTool.getToolName();
                                int lengthFeatureList = luTool.getLengthFeatureList();
                                if (lengthFeatureList > 0) {
                                    for (int ll = 0; ll < lengthFeatureList; ll++) {
                                        if (ll == 0) {
                                            toolNameList.add(toolName);
                                        } else {
                                            toolNameList.add(BLANK);
                                        }
                                    }
                                } else {
                                    csvOutput.endRecord();
                                }
                                int lengthFeature = luTool.getLicenseUsageForFeatureList().size();
                                for (int m = 0; m < lengthFeature; m++) {
                                    LicenseUsageForFeatureFormBean luFeature = luTool.getLicenseUsageForFeatureList().get(m);
                                    String futureName = luFeature.getFutureName();
                                    int lengthAccList = luFeature.getLengthAccList();
                                    if (lengthAccList > 0) {
                                        for (int mm = 0; mm < lengthAccList; mm++) {
                                            if (mm == 0) {
                                                futureNameList.add(futureName);
                                            } else {
                                                futureNameList.add(BLANK);
                                            }
                                        }
                                    } else {
                                        csvOutput.endRecord();
                                    }
                                    int lengthAcc = luFeature.getLicenseUsageForAccountList().size();
                                    for (int n = 0; n < lengthAcc; n++) {
                                        LicenseUsageForAccountFormBean luAcc = luFeature.getLicenseUsageForAccountList().get(n);
                                        String account = luAcc.getAccount();
                                        int lengthHostList = luAcc.getLengthHostList();
                                        if (lengthHostList > 0) {
                                            for (int nn = 0; nn < lengthHostList; nn++) {
                                                if (nn == 0) {
                                                    accountList.add(account);
                                                } else {
                                                    accountList.add(BLANK);
                                                }
                                            }
                                        } else {
                                            csvOutput.endRecord();
                                        }
                                        int lengthHost = luAcc.getLicenseUsageForHostList().size();
                                        for (int t = 0; t < lengthHost; t++) {
                                            LicenseUsageForHostFormBean luHost = luAcc.getLicenseUsageForHostList().get(t);
                                            String host = luHost.getHost();
                                            String strRuntime = luHost.getStrRuntime();
                                            int runNumberWithoutFew = luHost.getRunNumberWithoutFew();
                                            String strIsCharge = luHost.getStrIsCharge();
                                           //
                                            hostList.add(host);
                                            strRuntimeList.add(strRuntime);
                                            runNumberWithoutFewList.add(String.valueOf(runNumberWithoutFew));
                                            strIsChargeList.add(strIsCharge);
                                        }
                                    }
                                }
                                
                            }
                        }
                    }
                    productNumberList.add(CSVHead.getTotal());
                    projectNameList.add(BLANK);
                    loadOriginCodeList.add(BLANK);
                    accountList.add(BLANK);
                    vendorNameList.add(BLANK);
                    toolNameList.add(BLANK);
                    futureNameList.add(BLANK);
                    hostList.add(BLANK);
                    strRuntimeList.add(strTotalRunTime);
                    runNumberWithoutFewList.add(String.valueOf(totalRunNumber));
                    strIsChargeList.add(BLANK);
            }
            productNumberList.add(CSVHead.getGrandTotal());
            projectNameList.add(BLANK);
            loadOriginCodeList.add(BLANK);
            accountList.add(BLANK);
            vendorNameList.add(BLANK);
            toolNameList.add(BLANK);
            futureNameList.add(BLANK);
            hostList.add(BLANK);
            strRuntimeList.add(grandTotalRunTime);
            runNumberWithoutFewList.add(String.valueOf(grandTotalRunNumber));
            strIsChargeList.add(BLANK);
            //
            for (int i = 0; i < countLengthCsv + 1; i++) {
                csvOutput.writeRecord(new String[] { productNumberList.get(i),
                        projectNameList.get(i), loadOriginCodeList.get(i), accountList.get(i),
                        vendorNameList.get(i), toolNameList.get(i), futureNameList.get(i),
                        hostList.get(i), strRuntimeList.get(i), runNumberWithoutFewList.get(i),
                        strIsChargeList.get(i)});
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        
    }

    /**
     * writeCsvByTool
     * 
     * @param CsvWriter
     * @return void
     */
    private void writeCsvByTool(CsvWriter csvOutput) {
        try {
            csvOutput.writeRecord(new String[] { CSVHead.getProductNumber(),
                    CSVHead.getProjectName(), CSVHead.getVendorName(),
                    CSVHead.getToolName(), CSVHead.getFutureName(), 
                    CSVHead.getSimultaneousUseNumber()});
            int countLengthByTool = 0;
            int lengthToolResult = luToolNameFilterList.size();
            List<String> productNumberList = new ArrayList<String>();
            List<String> projectNameList = new ArrayList<String>();
            List<String> vendorNameList = new ArrayList<String>();
            List<String> toolNameList = new ArrayList<String>();
            List<String> futureNameList = new ArrayList<String>();
            List<String> simultaneousUseNumberList = new ArrayList<String>();
            for (int i = 0; i < lengthToolResult; i++) {
                LicenseUsageForToolNameFormBean luToolNameInfo = luToolNameFilterList.get(i);
                int lengthToolName = luToolNameInfo.getLicenseUsageForProjectToolNameList().size();
                countLengthByTool += luToolNameInfo.getLengthFeatureAllList();
                for (int j = 0; j < lengthToolName; j++) {
                    LicenseUsageForProjectToolNameFormBean luProjectToolName = luToolNameInfo.getLicenseUsageForProjectToolNameList().get(j);
                    int lengthFeatureList = luProjectToolName.getLicenseUsageForFeatureList().size();
                    //
                    String productNumber = luProjectToolName.getProductNumber();
                    productNumber = productNumber.replace(";", String.valueOf("\r\n"));
                    String projectName = luProjectToolName.getProjectName();
                    projectName = projectName.replace(";", String.valueOf("\r\n"));
                    //
                    if (lengthFeatureList > 0) {
                        for (int jj = 0; jj < lengthFeatureList; jj++) {
                            if (jj == 0) {
                                productNumberList.add(productNumber);
                                projectNameList.add(projectName);
                            } else {
                                productNumberList.add(BLANK);
                                projectNameList.add(BLANK);
                            }
                        }
                    } else {
                        csvOutput.endRecord();
                    }
                    int lengthFeatureAllList = luToolNameInfo.getLengthFeatureAllList();
                    String vendorName = luToolNameInfo.getVendorName();
                    String toolName = luToolNameInfo.getToolName();
                    if (lengthFeatureAllList > 0) {
                        for (int jj = 0; jj < lengthFeatureAllList; jj++) {
                            if (jj == 0) {
                                vendorNameList.add(vendorName);
                                toolNameList.add(toolName);
                            } else {
                                vendorNameList.add(BLANK);
                                toolNameList.add(BLANK);
                            }
                        }
                    } else {
                        csvOutput.endRecord();
                    }
                    int lengthFeatureTool = luProjectToolName.getLicenseUsageForFeatureList().size();
                    for (int k = 0; k < lengthFeatureTool; k++) {
                        LicenseUsageForFeatureFormBean luFeatureToolName = luProjectToolName.getLicenseUsageForFeatureList().get(k);
                        String futureName = luFeatureToolName.getFutureName();
                        String sameTimeUseNumber = String.valueOf(luFeatureToolName.getSameTimeUseNumber());
                        //
                        futureNameList.add(futureName);
                        simultaneousUseNumberList.add(sameTimeUseNumber);
                        //
                    }
                    //
                }
            }
            for (int i = 0; i < countLengthByTool; i++) {
                csvOutput.writeRecord(new String[] { productNumberList.get(i),
                        projectNameList.get(i), vendorNameList.get(i), toolNameList.get(i),
                        futureNameList.get(i), simultaneousUseNumberList.get(i) });
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * writeCsvByProject
     * 
     * @param CsvWriter
     * @return void
     */
    private void writeCsvByProject(CsvWriter csvOutput) {
        try {
            csvOutput.writeRecord(new String[] { CSVHead.getProductNumber(),
                    CSVHead.getProjectName(), CSVHead.getVendorName(),
                    CSVHead.getToolName(), CSVHead.getFutureName(), 
                    CSVHead.getSimultaneousUseNumber()});

            int lengthProjectResult = luProjectFilterList.size();
            int countLengthProject = 0;
            List<String> productNumberList = new ArrayList<String>();
            List<String> projectNameList = new ArrayList<String>();
            List<String> vendorNameList = new ArrayList<String>();
            List<String> toolNameList = new ArrayList<String>();
            List<String> futureNameList = new ArrayList<String>();
            List<String> simultaneousUseNumberList = new ArrayList<String>();
            for (int i = 0; i < lengthProjectResult; i++) {
                LicenseUsageForProjectFormBean projectNameInfo = luProjectFilterList.get(i);
                int lengthVendorFeatureList = projectNameInfo.getLengthVendorFeatureList();
                countLengthProject += lengthVendorFeatureList;
                String productNumber = projectNameInfo.getProductNumber();
                String projectName = projectNameInfo.getProjectName();
                if (lengthVendorFeatureList > 0) {
                    for (int ii = 0; ii < lengthVendorFeatureList; ii++) {
                        if (ii == 0) {
                            productNumberList.add(productNumber);
                            projectNameList.add(projectName);
                        } else {
                            productNumberList.add(BLANK);
                            projectNameList.add(BLANK);
                        }
                    }
                } else {
                    csvOutput.endRecord();
                }
                int lengthVendor = projectNameInfo.getLicenseUsageForVendorList().size();
                for (int j = 0; j < lengthVendor; j++) {
                    LicenseUsageForVendorFormBean luVendor = projectNameInfo.getLicenseUsageForVendorList().get(j);
                    int lengthToolList = luVendor.getLengthToolList();
                    String vendorName = luVendor.getVendorName();
                    if (lengthToolList > 0) {
                        for (int jj = 0; jj < lengthToolList; jj++) {
                            if (jj == 0) {
                                vendorNameList.add(vendorName);
                            } else {
                                vendorNameList.add(BLANK);
                            }
                        }
                    } else {
                        csvOutput.endRecord();
                    }
                    int lengthTool = luVendor.getLicenseUsageForToolNameList().size();
                    for (int k = 0; k < lengthTool; k++) {
                        LicenseUsageForToolNameFormBean luTool = luVendor.getLicenseUsageForToolNameList().get(k);
                        int lengthFeatureList = luTool.getLengthFeatureList();
                        String toolName = luTool.getToolName();
                        if (lengthFeatureList > 0) {
                            for (int kk = 0; kk < lengthFeatureList; kk++) {
                                if (kk == 0) {
                                    toolNameList.add(toolName);
                                } else {
                                    toolNameList.add(BLANK);
                                }
                            }
                        } else {
                            csvOutput.endRecord();
                        }
                        int lengthFeature = luTool.getLicenseUsageForFeatureList().size();
                        for (int l = 0; l < lengthFeature; l++) {
                            LicenseUsageForFeatureFormBean luFeature = luTool.getLicenseUsageForFeatureList().get(l);
                            String futureName = luFeature.getFutureName();
                            String sameTimeUseNumber = String.valueOf(luFeature.getSameTimeUseNumber());
                            //
                            futureNameList.add(futureName);
                            simultaneousUseNumberList.add(sameTimeUseNumber);
                        }
                    }
                }
            }
            for (int i = 0; i < countLengthProject; i++) {
                csvOutput.writeRecord(new String[] { productNumberList.get(i),
                        projectNameList.get(i), vendorNameList.get(i), toolNameList.get(i),
                        futureNameList.get(i), simultaneousUseNumberList.get(i) });
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * writeCsvByProduct
     * 
     * @param CsvWriter
     * @return void
     */
    private void writeCsvByProduct(CsvWriter csvOutput) {
        try {
            csvOutput.writeRecord(new String[] { CSVHead.getProductNumber(),
                    CSVHead.getProjectName(), CSVHead.getVendorName(),
                    CSVHead.getToolName(), CSVHead.getFutureName(), 
                    CSVHead.getSimultaneousUseNumber()});
            //
            List<String> productNumberList = new ArrayList<String>();
            List<String> projectNameList = new ArrayList<String>();
            List<String> vendorNameList = new ArrayList<String>();
            List<String> toolNameList = new ArrayList<String>();
            List<String> futureNameList = new ArrayList<String>();
            List<String> simultaneousUseNumberList = new ArrayList<String>();
            int lengthProductResult = luProductNumberFilterList.size();
            int countLengthProduct = 0;
            for (int i = 0; i < lengthProductResult; i++) {
                LicenseUsageForProjectFormBean productNumberInfo = luProductNumberFilterList.get(i);
                int lengthVendorFeatureList = productNumberInfo.getLengthVendorFeatureList();
                countLengthProduct += lengthVendorFeatureList;
                String productNumber = productNumberInfo.getProductNumber();
                String projectName = productNumberInfo.getProjectName();
                projectName = projectName.replace(";", String.valueOf("\r\n"));
                if (lengthVendorFeatureList > 0) {
                    for (int ii = 0; ii < lengthVendorFeatureList; ii++) {
                        if (ii == 0) {
                            productNumberList.add(productNumber);
                            projectNameList.add(projectName);
                        } else {
                            productNumberList.add(BLANK);
                            projectNameList.add(BLANK);
                        }
                    }
                } else {
                    csvOutput.endRecord();
                }
                int lengthVendor = productNumberInfo.getLicenseUsageForVendorList().size();
                for (int j = 0; j < lengthVendor; j++) {
                    LicenseUsageForVendorFormBean luVendor = productNumberInfo.getLicenseUsageForVendorList().get(j);
                    int lengthToolList = luVendor.getLengthToolList();
                    String vendorName = luVendor.getVendorName();
                    if (lengthToolList > 0) {
                        for (int jj = 0; jj < lengthToolList; jj++) {
                            if (jj == 0) {
                                vendorNameList.add(vendorName);
                            } else {
                                vendorNameList.add(BLANK);
                            }
                        }
                    } else {
                        csvOutput.endRecord();
                    }
                    int lengthTool = luVendor.getLicenseUsageForToolNameList().size();
                    for (int k = 0; k < lengthTool; k++) {
                        LicenseUsageForToolNameFormBean luTool = luVendor.getLicenseUsageForToolNameList().get(k);
                        int lengthFeatureList = luTool.getLengthFeatureList();
                        String toolName = luTool.getToolName();
                        if (lengthFeatureList > 0) {
                            for (int kk = 0; kk < lengthFeatureList; kk++) {
                                if (kk == 0) {
                                    toolNameList.add(toolName);
                                } else {
                                    toolNameList.add(BLANK);
                                }
                            }
                        } else {
                            csvOutput.endRecord();
                        }
                        int lengthFeature = luTool.getLicenseUsageForFeatureList().size();
                        for (int l = 0; l < lengthFeature; l++) {
                            LicenseUsageForFeatureFormBean luFeature = luTool.getLicenseUsageForFeatureList().get(l);
                            String futureName = luFeature.getFutureName();
                            String sameTimeUseNumber = String.valueOf(luFeature.getSameTimeUseNumber());
                            //
                            futureNameList.add(futureName);
                            simultaneousUseNumberList.add(sameTimeUseNumber);
                        }
                    }
                }
            }
            for (int i = 0; i < countLengthProduct; i++) {
                csvOutput.writeRecord(new String[] { productNumberList.get(i),
                        projectNameList.get(i), vendorNameList.get(i), toolNameList.get(i),
                        futureNameList.get(i), simultaneousUseNumberList.get(i) });
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * loadDataExportCSV
     * 
     * @param String
     * @return void
     */
    private void loadDataExportCSV(String projectId){
        String emailLogin = this.getEmailAddress();
        Support support = supporterBusiness.getSupportDb(emailLogin); // check email permission supporter or member
        if (support != null) {
            listPro = projectBusiness.listAllProject(); // get List all Project by Supporter
        } else {
            member = memberBusiness.checkExistEmailMember(emailLogin);
            if (member != null) {
                listPro = projectBusiness.listAllProjectByMember(Constants.APPROVED_STATUS, member, emailLogin, false); // get List all Project by Member
            }
        }
        if (listPro != null && listPro.size() > 0) {
            /* get month and year in DB follow year finance - START */
            int yearDB = 0;
            if (Constants.MONTH_NEXT_YEAR.contains(monthSelected)) {
                yearDB = Integer.parseInt(yearSelected) + 1;
            } else {
                yearDB = Integer.parseInt(yearSelected);
            }
            /* get month and year in DB follow year finance - END */
            if ((Constants.ZERO).equals(projectId)) {
                projectSelected = Constants.ALL_PROJECT;
                luProjectFilterList = new ArrayList<LicenseUsageForProjectFormBean>();
                List<LicenseUsageForProjectFormBean> luProjectList = new ArrayList<LicenseUsageForProjectFormBean>();
                List<LicenseUsageForToolNameFormBean> luToolAddList = new ArrayList<LicenseUsageForToolNameFormBean>();
                for (Project pj : listPro) {
                    List<LicenseUsageDetailForDBFormBean> licenseUsageDetailList = this.getLicenseUsageForDetail(pj, yearDB);
                    List<LicenseUsageForVendorFormBean> luVendorList = null;
                    if (licenseUsageDetailList != null && licenseUsageDetailList.size() > 0) {
                        List<LicenseUsageDetailForDBFormBean> licenseDetailToolList = new ArrayList<LicenseUsageDetailForDBFormBean>(licenseUsageDetailList);
                        luVendorList = this.getLicenseVendorList(licenseUsageDetailList);
                        List<LicenseUsageForToolNameFormBean> luToolList = this.getLicenseToolFilterList(pj, licenseDetailToolList); // Add all vendor List using filter by Tool Name
                        luToolAddList.addAll(luToolList);
                    } else {
                        luVendorList = this.getLicenseVendorEmptyList(); // Process when list license Detail equals null
                        // Set field to Object LicenseUsageForFeatureFormBean
                        List<LicenseUsageForFeatureFormBean> luFeatureEmptyList = new ArrayList<LicenseUsageForFeatureFormBean>();
                        LicenseUsageForFeatureFormBean luFeatureEmpty = new LicenseUsageForFeatureFormBean(Constants.NAME_CATALOG_EMPTY,
                                Constants.NO_VALUE);
                        luFeatureEmptyList.add(luFeatureEmpty);
                        // Set field to Object LicenseUsageForToolNameFormBean
                        LicenseUsageForToolNameFormBean luToolEmpty = new LicenseUsageForToolNameFormBean(pj.getProductNumber(), pj.getProjectName(),
                                Constants.NAME_CATALOG_EMPTY, Constants.NAME_CATALOG_EMPTY, luFeatureEmptyList, 1);
                        luToolAddList.add(luToolEmpty);
                    }
                    if (luVendorList != null && luVendorList.size() > 0) {
                        LicenseUsageForProjectFormBean luProject = this.getLicenseUsageForProject(pj, luVendorList); // Filter License Usage Status to Project
                        if (luProject != null) {
                            luProjectList.add(luProject);
                        }
                    }
                 }
                for (Project pj : listPro) {
                    List<LicenseUsageDetailForDBFormBean> licenseUsageDetailList = this.getLicenseUsageForDetail(pj, yearDB);
                    List<LicenseUsageForVendorFormBean> luVendorFilterList = null;
                    if (licenseUsageDetailList != null && licenseUsageDetailList.size() > 0) {
                        List<LicenseUsageForToolNameFormBean> luToolList = this.getLicenseToolFilterList(pj, licenseUsageDetailList); // Add all vendor List using filter by Tool Name
                        if (luToolList != null && luToolList.size() > 0) {
                            luVendorFilterList = this.getLicenseVendorFilterList(luToolList);
                        }
                    } else {
                        luVendorFilterList = this.getLicenseVendorEmptyList(); // Process when list license Detail equals null
                    }
                    if (luVendorFilterList != null && luVendorFilterList.size() > 0) {
                        LicenseUsageForProjectFormBean luProject = this.getLicenseUsageForProject(pj, luVendorFilterList); // Filter License Usage Status to Project
                        if (luProject != null) {
                            luProjectFilterList.add(luProject);
                        }
                    }
                 }
                /* Filter by Tool Name - START */
                if (luToolAddList != null && luToolAddList.size() > 0) {
                    luToolNameFilterList = this.getLicenseUsageToolNameFilterList(luToolAddList);
                }
                /* Filter by Tool Name - END */
                /* Filter by Product Number - START */
                List<LicenseUsageForProductNumberFormBean> luProductNumberTestList = null;
                if (luProjectFilterList != null && luProjectFilterList.size() > 0) {
                    List<LicenseUsageForProjectFormBean> luProjectTestList = new ArrayList<LicenseUsageForProjectFormBean>(luProjectFilterList);
                    luProductNumberTestList = this.getLicenseUsageForProductList(luProjectTestList);
                }
                //
                if (luProductNumberTestList != null && luProductNumberTestList.size() > 0) {
                    luProductNumberFilterList = this.getLicenseUsageForProductFilterList(luProductNumberTestList);
                }
                /* Filter by Product Number - END */
                List<LicenseUsageForProductNumberFormBean> luProductNumberList = null;
                if (luProjectList != null && luProjectList.size() > 0) {
                    luProductNumberList = this.getLicenseUsageForProductList(luProjectList);
                }
                if (luProductNumberList != null && luProductNumberList.size() > 0) {
                    executeInfo = new ExecuteTimeAndCountFormBean();
                    int lengthProductNumber = luProductNumberList.size();
                    int grandTotalRunTime = 0;
                    int grandTotalRunNumber = 0;
                    for (int i = 0; i < lengthProductNumber; i++) {
                        LicenseUsageForProductNumberFormBean luProductNumberInfo = luProductNumberList.get(i);
                        grandTotalRunTime += luProductNumberInfo.getTotalRunTime();
                        grandTotalRunNumber += luProductNumberInfo.getTotalRunNumber();
                    }
                    // convert date from seconds to type HH:MM:SS
                    String strTotalRunTime = this.getStrRunTime(grandTotalRunTime);

                    executeInfo.setGrandTotalRunTime(strTotalRunTime);
                    executeInfo.setGrandTotalRunNumber(grandTotalRunNumber);
                    executeInfo.setLicenseUsageForProductNumberList(luProductNumberList);
                }
            } else {
                for (Project pj : listPro) {
                    if (projectId.equals(String.valueOf(pj.getSeqNo()))) {
                        projectSelected = pj.getProjectName();
                        luProjectFilterList = new ArrayList<LicenseUsageForProjectFormBean>();
                        List<LicenseUsageForProjectFormBean> luProjectList = new ArrayList<LicenseUsageForProjectFormBean>();
                        List<LicenseUsageForProductNumberFormBean> luProductNumberList = null;
                        List<LicenseUsageForToolNameFormBean> luToolList = null;
                        List<LicenseUsageForVendorFormBean> luVendorList = null;
                        List<LicenseUsageDetailForDBFormBean> licenseUsageDetailList = this.getLicenseUsageForDetail(pj, yearDB);
                        if (licenseUsageDetailList != null && licenseUsageDetailList.size() > 0) {
                            /* Clone LicenseUsageDetailForDBFormBean - START */
                            List<LicenseUsageDetailForDBFormBean> licenseDetailToolList = new ArrayList<LicenseUsageDetailForDBFormBean>(licenseUsageDetailList);
                            List<LicenseUsageDetailForDBFormBean> licenseDetailVendorList = new ArrayList<LicenseUsageDetailForDBFormBean>(licenseUsageDetailList);
                            /* Clone LicenseUsageDetailForDBFormBean - END */
                            /* Filter by Project Name - START */
                            List<LicenseUsageForToolNameFormBean> luToolFilterList = this.getLicenseToolFilterList(pj, licenseUsageDetailList); // Add all vendor List using filter by Tool Name
                            if (luToolFilterList != null && luToolFilterList.size() > 0) {
                                List<LicenseUsageForVendorFormBean> luVendorFilterList = this.getLicenseVendorFilterList(luToolFilterList);
                                if (luVendorFilterList != null && luVendorFilterList.size() > 0) {
                                    LicenseUsageForProjectFormBean luProject = this.getLicenseUsageForProject(pj, luVendorFilterList); // Filter License Usage Status to Project
                                    if (luProject != null) {
                                        luProjectFilterList.add(luProject);
                                    }
                                }
                            }
                            /* Filter by Project Name - END */
                            /* Add Tool Name Filter - START */
                            luVendorList = this.getLicenseVendorList(licenseDetailVendorList);
                            if (luVendorList != null && luVendorList.size() > 0) {
                                LicenseUsageForProjectFormBean luProject = this.getLicenseUsageForProject(pj, luVendorList); // Filter License Usage Status to Project
                                if (luProject != null) {
                                    luProjectList.add(luProject);
                                }
                            }
                            luToolList = this.getLicenseToolFilterList(pj, licenseDetailToolList); // Add all vendor List using filter by Tool Name
                        }else {
                            luVendorList = this.getLicenseVendorEmptyList(); // Process when list license Detail equals null
                            // Set field to Object LicenseUsageForFeatureFormBean
                            List<LicenseUsageForFeatureFormBean> luFeatureEmptyList = new ArrayList<LicenseUsageForFeatureFormBean>();
                            LicenseUsageForFeatureFormBean luFeatureEmpty = new LicenseUsageForFeatureFormBean(Constants.NAME_CATALOG_EMPTY,
                                    Constants.NO_VALUE);
                            luFeatureEmptyList.add(luFeatureEmpty);
                            // Set field to Object LicenseUsageForToolNameFormBean
                            LicenseUsageForToolNameFormBean luToolEmpty = new LicenseUsageForToolNameFormBean(pj.getProductNumber(), pj.getProjectName(),
                                    Constants.NAME_CATALOG_EMPTY, Constants.NAME_CATALOG_EMPTY, luFeatureEmptyList, 1);
                            luToolList = new ArrayList<LicenseUsageForToolNameFormBean>();
                            luToolList.add(luToolEmpty);
                            if (luVendorList != null && luVendorList.size() > 0) {
                                LicenseUsageForProjectFormBean luProject = this.getLicenseUsageForProject(pj, luVendorList); // Filter License Usage Status to Project
                                if (luProject != null) {
                                    luProjectList.add(luProject);
                                    luProjectFilterList.add(luProject);
                                }
                            }
                        }
                        /* Filter by Tool Name - START */
                        if (luToolList != null && luToolList.size() > 0) {
                            luToolNameFilterList = this.getLicenseUsageToolNameFilterList(luToolList);
                        }
                        /* Filter by Tool Name - END */
                        /* Filter by Product Number - START */
                        List<LicenseUsageForProductNumberFormBean> luProductNumberTestList = null;
                        if (luProjectFilterList != null && luProjectFilterList.size() > 0) {
                            List<LicenseUsageForProjectFormBean> luProjectTestList = new ArrayList<LicenseUsageForProjectFormBean>(luProjectFilterList);
                            luProductNumberTestList = this.getLicenseUsageForProductList(luProjectTestList);
                        }
                        if (luProductNumberTestList != null && luProductNumberTestList.size() > 0) {
                            luProductNumberFilterList = this.getLicenseUsageForProductFilterList(luProductNumberTestList);
                        }
                        /* Filter by Product Number - END */
                        if (luProjectList != null && luProjectList.size() > 0) {
                            luProductNumberList = this.getLicenseUsageForProductList(luProjectList);
                        }
                        if (luProductNumberList != null && luProductNumberList.size() > 0) {
                            executeInfo = new ExecuteTimeAndCountFormBean();
                            executeInfo.setGrandTotalRunTime(luProductNumberList.get(0).getStrTotalRunTime());
                            executeInfo.setGrandTotalRunNumber(luProductNumberList.get(0).getTotalRunNumber());
                            executeInfo.setLicenseUsageForProductNumberList(luProductNumberList);
                        }
                        break;
                    }
                }
            }
        }
    }

    /**
     * showdataMonth
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    private List<LicenseTotalTaxColumn> showdataMonth(List<LicenseRegisterBean> regisListPro,
            List<LicenseUsedBean> usedListIp, List<Integer> ipListOfProject) {
        Integer countBudgetMonth = 0;
        Integer countAtualMonth = 0;
        Integer subtractBudgetAtual = 0;
        BigDecimal moneyBudgetMonth = BigDecimal.ZERO;
        BigDecimal moneyActualMonth = BigDecimal.ZERO;
        String projectName = BLANK;
        String productNumber = BLANK;
        String loadOriginCode = BLANK;
        Integer licenseUseInfoId = 0;
        Integer licenseRegisId = 0;
        List<LicenseTotalTaxColumn> listTotalTax = new ArrayList<LicenseTotalTaxColumn>();
        for (int k = 0; k < regisListPro.size(); k++) {
            List<Integer> listCatalog = new ArrayList<Integer>();
            if (ipListOfProject != null && ipListOfProject.size() > 0) {
                if (usedListIp != null && usedListIp.size() > 0) {// All listIp used in Month at all Project
                    for (int l = 0; l < usedListIp.size(); l++) {
                        LicenseTotalTaxColumn totalTaxCol = new LicenseTotalTaxColumn();
                        if (ipListOfProject.contains(usedListIp.get(l).getIpAddressId())) {
                            if (regisListPro.get(k).getCatalogId() == usedListIp.get(l).getCatalogId()) {// just a result per a foreach(usedListIp).
                                if (usedListIp.get(l).getUsedSumPerMonth() > regisListPro.get(k).getRegisterSumPerMonth()) {
                                    countBudgetMonth = regisListPro.get(k).getRegisterSumPerMonth();
                                    countAtualMonth = usedListIp.get(l).getUsedSumPerMonth();
                                    subtractBudgetAtual = countAtualMonth - countBudgetMonth;
                                    moneyBudgetMonth = regisListPro.get(k).getMemberPrice().multiply(new BigDecimal(countBudgetMonth));
                                    moneyActualMonth = moneyBudgetMonth.add(regisListPro.get(k)
                                            .getRegularPrice().multiply(new BigDecimal(subtractBudgetAtual)));
                                    projectName = regisListPro.get(k).getProjectName();
                                    productNumber = regisListPro.get(k).getProductNumber();
                                    loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                                    licenseUseInfoId = usedListIp.get(l).getLicenseUseInfoId();
                                    licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                                    setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                                            moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                                            listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
                                } else {
                                    countBudgetMonth = regisListPro.get(k).getRegisterSumPerMonth();
                                    countAtualMonth = usedListIp.get(l).getUsedSumPerMonth();
                                    subtractBudgetAtual = 0;
                                    moneyBudgetMonth = regisListPro.get(k).getMemberPrice().multiply(new BigDecimal(countBudgetMonth));
                                    moneyActualMonth = moneyBudgetMonth;
                                    projectName = regisListPro.get(k).getProjectName();
                                    productNumber = regisListPro.get(k).getProductNumber();
                                    loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                                    licenseUseInfoId = usedListIp.get(l).getLicenseUseInfoId();
                                    licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                                    setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                                            moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                                            listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
                                }
                            } else {//not map catalogID.
                                if(regisListPro.get(k).getRegisterSumPerMonth() > 0 && !listCatalog.contains(regisListPro.get(k).getCatalogId())){
                                    listCatalog.add(regisListPro.get(k).getCatalogId()); // check catalog is one project.
                                    countBudgetMonth = regisListPro.get(k).getRegisterSumPerMonth();
                                    countAtualMonth = 0;
                                    subtractBudgetAtual = 0;
                                    moneyBudgetMonth = regisListPro.get(k).getMemberPrice().multiply(new BigDecimal(countBudgetMonth));
                                    moneyActualMonth = BigDecimal.ZERO;
                                    projectName = regisListPro.get(k).getProjectName();
                                    productNumber = regisListPro.get(k).getProductNumber();
                                    loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                                    licenseUseInfoId = usedListIp.get(l).getLicenseUseInfoId();
                                    licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                                    setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                                            moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                                            listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
                                } else {
                                countBudgetMonth = 0;
                                countAtualMonth = 0;
                                subtractBudgetAtual = 0;
                                moneyBudgetMonth = BigDecimal.ZERO;
                                moneyActualMonth = BigDecimal.ZERO;
                                projectName = regisListPro.get(k).getProjectName();
                                productNumber = regisListPro.get(k).getProductNumber();
                                loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                                licenseUseInfoId = usedListIp.get(l).getLicenseUseInfoId();
                                licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                                setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                                        moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                                        listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
                                }
                            }
                        } else {// this project not regis license in this month.
                            List<Integer> listlicenseUseInfoId = new ArrayList<Integer>();
                            if(listlicenseUseInfoId.size() < 1){
                            countBudgetMonth = regisListPro.get(k).getRegisterSumPerMonth();
                            countAtualMonth = 0;
                            subtractBudgetAtual = 0;
                            moneyBudgetMonth = regisListPro.get(k).getMemberPrice().multiply(new BigDecimal(countBudgetMonth));
                            moneyActualMonth = BigDecimal.ZERO;
                            projectName = regisListPro.get(k).getProjectName();
                            productNumber = regisListPro.get(k).getProductNumber();
                            loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                            licenseUseInfoId = 0;
                            listlicenseUseInfoId.add(licenseUseInfoId);
                            licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                            setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                                    moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                                    listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
                            }
                        }
                    }
                } else {// this project not used license in this month.
                    LicenseTotalTaxColumn totalTaxCol = new LicenseTotalTaxColumn();
                    countBudgetMonth = regisListPro.get(k).getRegisterSumPerMonth();
                    countAtualMonth = 0;
                    subtractBudgetAtual = 0;
                    moneyBudgetMonth = regisListPro.get(k).getMemberPrice()
                            .multiply(new BigDecimal(countBudgetMonth));
                    moneyActualMonth = BigDecimal.ZERO;
                    projectName = regisListPro.get(k).getProjectName();
                    productNumber = regisListPro.get(k).getProductNumber();
                    loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                    licenseUseInfoId = 0;
                    licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                    setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                            moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                            listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
                }
            } else {// this project not regis license in this month.
                LicenseTotalTaxColumn totalTaxCol = new LicenseTotalTaxColumn();
                countBudgetMonth = regisListPro.get(k).getRegisterSumPerMonth();
                countAtualMonth = 0;
                subtractBudgetAtual = 0;
                moneyBudgetMonth = regisListPro.get(k).getMemberPrice()
                        .multiply(new BigDecimal(countBudgetMonth));
                moneyActualMonth = BigDecimal.ZERO;
                projectName = regisListPro.get(k).getProjectName();
                productNumber = regisListPro.get(k).getProductNumber();
                loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                licenseUseInfoId = 0;
                licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                        moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                        listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
            }
        }
        return listTotalTax;
    }

    /**
     * showTblDetailTax
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    private List<LicenseTotalTaxBean> showTblDetailTax(int monthSelect, Map<Integer, List<LicenseTotalTaxBean>> mapTaxBeanTbl3) {
        BigDecimal totalSumTbl3 = BigDecimal.ZERO;
        List<LicenseTotalTaxBean> taxBeanListTbl3 = new ArrayList<LicenseTotalTaxBean>();
        if (!MapUtils.isEmpty(mapTaxBeanTbl3)) {
            for (Map.Entry<Integer, List<LicenseTotalTaxBean>> mapTaxBean : mapTaxBeanTbl3.entrySet()) {
                List<LicenseTotalTaxBean> taxBeanTemp = mapTaxBean.getValue();
                switch (monthSelect) {
                case 1:
                    taxBeanListTbl3.add(taxBeanTemp.get(9));
                    break;
                case 2:
                    taxBeanListTbl3.add(taxBeanTemp.get(10));
                    break;
                case 3:
                    taxBeanListTbl3.add(taxBeanTemp.get(11));
                    break;
                case 4:
                    taxBeanListTbl3.add(taxBeanTemp.get(0));
                    break;
                case 5:
                    taxBeanListTbl3.add(taxBeanTemp.get(1));
                    break;
                case 6:
                    taxBeanListTbl3.add(taxBeanTemp.get(2));
                    break;
                case 7:
                    taxBeanListTbl3.add(taxBeanTemp.get(3));
                    break;
                case 8:
                    taxBeanListTbl3.add(taxBeanTemp.get(4));
                    break;
                case 9:
                    taxBeanListTbl3.add(taxBeanTemp.get(5));
                    break;
                case 10:
                    taxBeanListTbl3.add(taxBeanTemp.get(6));
                    break;
                case 11:
                    taxBeanListTbl3.add(taxBeanTemp.get(7));
                    break;
                case 12:
                    taxBeanListTbl3.add(taxBeanTemp.get(8));
                    break;
                }
            }
        }
        totalSumTbl3 = getTotalTbl3(totalSumTbl3, taxBeanListTbl3);
        session.setAttribute("totalSumTbl3", totalSumTbl3);
        return taxBeanListTbl3;
    }

    /**
     * @param totalSumTbl3
     */
    private BigDecimal getTotalTbl3(BigDecimal totalSumTbl3, List<LicenseTotalTaxBean> listShowTbl3) {
        totalSumTbl3 = BigDecimal.ZERO;
        if (listShowTbl3 != null && listShowTbl3.size() > 0) {
            for (int j = 0; j < listShowTbl3.size(); j++) {
                LicenseTotalTaxBean bean = listShowTbl3.get(j);
                if (bean != null) {
                    List<LicenseTotalTaxColumn> subOfsubListShow = bean.getTaxList();
                    if (subOfsubListShow != null && subOfsubListShow.size() > 0) {
                        for (int k = 0; k < subOfsubListShow.size(); k++) {
                            totalSumTbl3 = totalSumTbl3.add(subOfsubListShow.get(k).getSumBudgetAndMoreBudget());
                        }
                    }
                }
            }
        }
        return totalSumTbl3;
    }

    /**
     * showTblSumTaxOfMonth
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    private List<LicenseTotalTaxColumn> showTblSumTaxOfMonth() {
        totalBudget = BigDecimal.ZERO;
        totalActual = BigDecimal.ZERO;
        List<LicenseTotalTaxColumn> columnsTemp = null;
        List<LicenseTotalTaxColumn> licenTotalTax = new ArrayList<LicenseTotalTaxColumn>();
        if (listShowTbl3 != null && listShowTbl3.size() > 0) {
            for (int i = 0; i < listShowTbl3.size(); i++) {
                LicenseTotalTaxColumn taxColumn = new LicenseTotalTaxColumn();
                totalBudgetPerPro = BigDecimal.ZERO;
                totalActualPerPro = BigDecimal.ZERO;
                columnsTemp = listShowTbl3.get(i).getTaxList();
                showTblSumTax(totalBudgetPerPro, totalActualPerPro, columnsTemp, i, taxColumn);
                licenTotalTax.add(taxColumn);
            }
        }
        session.setAttribute("totalBudget", totalBudget);
        session.setAttribute("totalActual", totalActual);
        return licenTotalTax;
    }

    /**
     * @param totalBudgetPerPro
     * @param totalActualPerPro
     * @param columnsTemp
     * @param i
     * @param taxColumn
     */
    private void showTblSumTax(BigDecimal totalBudgetPerPro, BigDecimal totalActualPerPro,
            List<LicenseTotalTaxColumn> columnsTemp, int i, LicenseTotalTaxColumn taxColumn) {
        taxColumn.setProjectName(listShowTbl3.get(i).getProjectName());
        taxColumn.setProductNumber(listShowTbl3.get(i).getProductNumber());
        taxColumn.setLoadOriginCode(listShowTbl3.get(i).getLoadOriginCode());
        BigDecimal totalsumBudAndAct = BigDecimal.ZERO;
        for (int j = 0; j < columnsTemp.size(); j++) {
            totalBudgetPerPro = totalBudgetPerPro.add(columnsTemp.get(j).getMoneyBudgetPerMonth());
            totalActualPerPro = totalActualPerPro.add(columnsTemp.get(j).getSumBudgetAndMoreBudget());
            totalsumBudAndAct = totalsumBudAndAct.add(columnsTemp.get(j).getSumBudgetAndMoreBudget());
        }
        taxColumn.setMoneyBudgetPerMonth(totalBudgetPerPro);
        taxColumn.setMoneyActualPerMonth(totalActualPerPro);
        totalBudget = totalBudget.add(totalBudgetPerPro);
        totalActual = totalActual.add(totalActualPerPro);
        listShowTbl3.get(i).setSumTaxMoneyPro(totalsumBudAndAct);
    }

    /**
     * setOrderListPro
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    private void setOrderListPro(Integer countBudgetMonth, Integer countAtualMonth, Integer subtractBudgetAtual,
            BigDecimal moneyBudgetMonth, BigDecimal moneyActualMonth, String projectName, String productNumber,
            List<LicenseRegisterBean> regisListPro, List<LicenseTotalTaxColumn> listTotalTax, int k,
            LicenseTotalTaxColumn totalTaxCol, int licenseUseInfoId, int licenseRegisId, String loadOriginCode) {
        totalTaxCol.setLicenseUseInfoId(licenseUseInfoId);
        totalTaxCol.setLicenseRegisId(licenseRegisId);
        totalTaxCol.setProjectName(projectName);
        totalTaxCol.setProductNumber(productNumber);
        totalTaxCol.setProjectId(regisListPro.get(k).getProjectId());
        totalTaxCol.setCountBudgetPerMonth(countBudgetMonth);
        totalTaxCol.setCountActualPerMonth(countAtualMonth);
        totalTaxCol.setCountSubTractBudgetActual(subtractBudgetAtual);
        totalTaxCol.setMoneyBudgetPerMonth(moneyBudgetMonth);
        totalTaxCol.setMoneyActualPerMonth(moneyActualMonth);
        totalTaxCol.setVenderName(regisListPro.get(k).getVenderName());
        totalTaxCol.setToolName(regisListPro.get(k).getToolName());
        totalTaxCol.setFutureName(regisListPro.get(k).getFutureName());
        totalTaxCol.setMemberPrice(regisListPro.get(k).getMemberPrice());
        totalTaxCol.setRegularPrice(regisListPro.get(k).getRegularPrice());
        totalTaxCol.setCatalogId(regisListPro.get(k).getCatalogId());
        totalTaxCol.setLoadOriginCode(loadOriginCode);
        listTotalTax.add(totalTaxCol);// add list listTotalTax
    }

    /**
     * reSetOrderListPro
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    private LicenseTotalTaxBean reSetOrderListPro(List<LicenseTotalTaxColumn> listTotalTax, int projectId) {
        LicenseTotalTaxBean licenseTotalTaxBean = null;
        List<LicenseTotalTaxColumn> columnsTempTbl3 = new ArrayList<LicenseTotalTaxColumn>();
        List<Integer> projectIdList = new ArrayList<Integer>();
        
        if (listTotalTax != null && listTotalTax.size() > 0) {
            BigDecimal countMoneyBudgetMonth = BigDecimal.ZERO;
            BigDecimal countMoneyActualMonth = BigDecimal.ZERO;
            List<Integer> listCatalogtbl2 = new ArrayList<Integer>();
            for (int k = 0; k < listTotalTax.size(); k++) {// re-SetList project regis.
                if (projectId == listTotalTax.get(k).getProjectId()
                        && !listCatalogtbl2.contains(listTotalTax.get(k).getCatalogId())) {// used for table2.
                    countMoneyBudgetMonth = countMoneyBudgetMonth.add(listTotalTax.get(k).getMoneyBudgetPerMonth());
                    countMoneyActualMonth = countMoneyActualMonth.add(listTotalTax.get(k).getMoneyActualPerMonth());
                    listCatalogtbl2.add(listTotalTax.get(k).getCatalogId());// just add 1 catalog per 1 project.
                }
                
                if (projectId == listTotalTax.get(k).getProjectId()) {// used for table3.
                    LicenseTotalTaxColumn taxColumnTbl3 = new LicenseTotalTaxColumn();
                    taxColumnTbl3.setProjectId(listTotalTax.get(k).getProjectId());
                    taxColumnTbl3.setProjectName(listTotalTax.get(k).getProjectName());
                    taxColumnTbl3.setProductNumber(listTotalTax.get(k).getProductNumber());
                    taxColumnTbl3.setLoadOriginCode(listTotalTax.get(k).getLoadOriginCode());
                    taxColumnTbl3.setVenderName(listTotalTax.get(k).getVenderName());
                    taxColumnTbl3.setToolName(listTotalTax.get(k).getToolName());
                    taxColumnTbl3.setFutureName(listTotalTax.get(k).getFutureName());
                    taxColumnTbl3.setCountBudgetPerMonth(listTotalTax.get(k).getCountBudgetPerMonth());
                    taxColumnTbl3.setCountActualPerMonth(listTotalTax.get(k).getCountActualPerMonth());
                    taxColumnTbl3.setMemberPrice(listTotalTax.get(k).getMemberPrice());
                    taxColumnTbl3.setRegularPrice(listTotalTax.get(k).getRegularPrice());
                    taxColumnTbl3.setCatalogId(listTotalTax.get(k).getCatalogId());
                    taxColumnTbl3.setLicenseUseInfoId(listTotalTax.get(k).getLicenseUseInfoId());
                    taxColumnTbl3.setLicenseRegisId(listTotalTax.get(k).getLicenseRegisId());
                    if (listTotalTax.get(k).getCountActualPerMonth() > listTotalTax.get(k).getCountBudgetPerMonth()) {// special
                        taxColumnTbl3.setCountSubTractBudgetActual(listTotalTax.get(k).getCountSubTractBudgetActual());
                        taxColumnTbl3.setMoreBudgetPerMonth(taxColumnTbl3.getRegularPrice().multiply(new BigDecimal(taxColumnTbl3.getCountSubTractBudgetActual())));
                        taxColumnTbl3.setMoneyBudgetPerMonth(listTotalTax.get(k).getMemberPrice().multiply(new BigDecimal(listTotalTax.get(k).getCountBudgetPerMonth())));
                        taxColumnTbl3.setMoneyActualPerMonth(taxColumnTbl3.getMoneyBudgetPerMonth().add(taxColumnTbl3.getMoreBudgetPerMonth()));
                    } else {
                        taxColumnTbl3.setCountSubTractBudgetActual(0);
                        taxColumnTbl3.setMoreBudgetPerMonth(taxColumnTbl3.getRegularPrice().multiply(new BigDecimal(taxColumnTbl3.getCountSubTractBudgetActual())));
                        taxColumnTbl3.setMoneyBudgetPerMonth(listTotalTax.get(k).getMemberPrice().multiply(new BigDecimal(listTotalTax.get(k).getCountBudgetPerMonth())));
                        taxColumnTbl3.setMoneyActualPerMonth(taxColumnTbl3.getMoneyBudgetPerMonth());
                    }
                    taxColumnTbl3.setSumBudgetAndMoreBudget(taxColumnTbl3.getMoneyBudgetPerMonth().add(taxColumnTbl3.getMoreBudgetPerMonth()));
                    
                    if (!projectIdList.contains(projectId)){
                        projectIdList.add(projectId);
                        columnsTempTbl3 = new ArrayList<LicenseTotalTaxColumn>();
                        columnsTempTbl3.add(taxColumnTbl3);
                    } else {
                    columnsTempTbl3.add(taxColumnTbl3);
                    }
                }
            }
        }
        if (columnsTempTbl3 != null && columnsTempTbl3.size() > 0) {
            List<LicenseTotalTaxColumn> reSetTempTbl3List = new ArrayList<LicenseTotalTaxColumn>();
            List<Integer> listCatalog = null;
            List<Integer> listLicenUseId = null;
            List<Integer> listLicenseRegisId = null;
            for (int j = 0; j < columnsTempTbl3.size(); j++) {// re-set listMapTbl3 per a project in a month.
                if (!listShowTbl3.contains(projectId) && projectId == columnsTempTbl3.get(j).getProjectId() && reSetTempTbl3List.isEmpty()) {
                    licenseTotalTaxBean = new LicenseTotalTaxBean();
                    listCatalog = new ArrayList<Integer>();
                    listLicenUseId = new ArrayList<Integer>();
                    listLicenseRegisId = new ArrayList<Integer>();
                    reSetTempTbl3List.add(columnsTempTbl3.get(j));
                    listCatalog.add(columnsTempTbl3.get(j).getCatalogId());
                    listLicenUseId.add(columnsTempTbl3.get(j).getLicenseUseInfoId());
                    listLicenseRegisId.add(columnsTempTbl3.get(j).getLicenseRegisId());
                    licenseTotalTaxBean.setProjectId(columnsTempTbl3.get(j).getProjectId());
                    licenseTotalTaxBean.setProjectName(columnsTempTbl3.get(j).getProjectName());
                    licenseTotalTaxBean.setProductNumber(columnsTempTbl3.get(j).getProductNumber());
                    licenseTotalTaxBean.setLoadOriginCode(columnsTempTbl3.get(j).getLoadOriginCode());
                    licenseTotalTaxBean.setLengthLicenseCatalog(reSetTempTbl3List.size());
                    licenseTotalTaxBean.setTaxList(reSetTempTbl3List);
                } else {
                    for (int l = 0; l < reSetTempTbl3List.size(); l++) {
                        if (projectId == reSetTempTbl3List.get(l).getProjectId()
                                && columnsTempTbl3.get(j).getCatalogId() != reSetTempTbl3List.get(l).getCatalogId()
                                && !listCatalog.contains(columnsTempTbl3.get(j).getCatalogId())) {
                            reSetTempTbl3List.add(columnsTempTbl3.get(j));
                            listCatalog.add(columnsTempTbl3.get(j).getCatalogId());
                            listLicenUseId.add(columnsTempTbl3.get(j).getLicenseUseInfoId());
                            listLicenseRegisId.add(columnsTempTbl3.get(j).getLicenseRegisId());
                            licenseTotalTaxBean.setLengthLicenseCatalog(reSetTempTbl3List.size());
                            licenseTotalTaxBean.setTaxList(reSetTempTbl3List);
                        } else if (projectId == reSetTempTbl3List.get(l).getProjectId()
                                && !listLicenUseId.contains(columnsTempTbl3.get(j).getLicenseUseInfoId())
                                && columnsTempTbl3.get(j).getMoneyActualPerMonth().compareTo(BigDecimal.ZERO) == 1) {
                            reSetTempTbl3List.add(columnsTempTbl3.get(j));
                            listLicenUseId.add(columnsTempTbl3.get(j).getLicenseUseInfoId());
                            listLicenseRegisId.add(columnsTempTbl3.get(j).getLicenseRegisId());
                            licenseTotalTaxBean.setProjectId(columnsTempTbl3.get(j).getProjectId());
                            licenseTotalTaxBean.setProjectName(columnsTempTbl3.get(j).getProjectName());
                            licenseTotalTaxBean.setProductNumber(columnsTempTbl3.get(j).getProductNumber());
                            licenseTotalTaxBean.setLoadOriginCode(columnsTempTbl3.get(j).getLoadOriginCode());
                            licenseTotalTaxBean.setLengthLicenseCatalog(reSetTempTbl3List.size());
                            licenseTotalTaxBean.setTaxList(reSetTempTbl3List);
                        }
                    }
                }
            }
        }
        return licenseTotalTaxBean;
    }

    /**
     * getRecordPage
     * @param indexStart
     * @param total
     * @param listRecord
     * @return List<LicenseManagerColumn>
     */
    private List<LicenseManagerColumn> getRecordPage(int indexStart, int numRecordPerPage,
            List<LicenseManagerColumn> listRecord) {
        List<LicenseManagerColumn> recordList = new ArrayList<LicenseManagerColumn>();
        if (listRecord != null && listRecord.size() > 0) {
            indexStart = indexStart - 1;
            int temp = indexStart + numRecordPerPage;
            for (int i = indexStart; i < listRecord.size(); i++) {
                if (i < temp) {
                    recordList.add(listRecord.get(i));
                    } else {
                    break;
                }
            }
        }
        return recordList;
    }
    
    /**
     * getRecordPageTblTwo
     * @param indexStart
     * @param total
     * @param listRecord
     * @return List<LicenseManagerColumn>
     */
    private List<LicenseTotalTaxColumn> getRecordPageTblTwo(int indexStart, int numRecordPerPage,
            List<LicenseTotalTaxColumn> listRecord) {
        List<LicenseTotalTaxColumn> recordList = new ArrayList<LicenseTotalTaxColumn>();
        if (listRecord != null && listRecord.size() > 0) {
            indexStart = indexStart - 1;
            int temp = indexStart + numRecordPerPage;
            for (int i = indexStart; i < listRecord.size(); i++) {
                if (i < temp) {
                    recordList.add(listRecord.get(i));
                    } else {
                    break;
                }
            }
        }
        return recordList;
    }
    
    /**
     * getRecordPageTblThree
     * @param indexStart
     * @param total
     * @param listRecord
     * @return List<LicenseManagerColumn>
     */
    private List<LicenseTotalTaxBean> getRecordPageTblThree(int indexStart, int numRecordPerPage,
            List<LicenseTotalTaxBean> listRecord) {
        List<LicenseTotalTaxBean> recordList = new ArrayList<LicenseTotalTaxBean>();
        if (listRecord != null && listRecord.size() > 0) {
            indexStart = indexStart - 1;
            int temp = indexStart + numRecordPerPage;
            for (int i = indexStart; i < listRecord.size(); i++) {
                if (i < temp) {
                    recordList.add(listRecord.get(i));
                    } else {
                    break;
                }
            }
        }
        return recordList;
    }
    
    /**
     * @param listYear
     */
    public List<Integer> getListYear() {
        return listYear;
    }

    /**
     * @param listYear
     *            the listYear to set
     */
    public void setListYear(List<Integer> listYear) {
        this.listYear = listYear;
    }

    /**
     * @param listMonth
     */
    public List<Integer> getListMonth() {
        return listMonth;
    }

    /**
     * @param listMonth
     *            the listMonth to set
     */
    public void setListMonth(List<Integer> listMonth) {
        this.listMonth = listMonth;
    }

    
    /**
     * @param listProjectId
     */
    protected List<Integer> getListProjectId() {
        return listProjectId;
    }

    /**
     * @param listProjectId
     *            the listProjectId to set
     */
    protected void setListProjectId(List<Integer> listProjectId) {
        this.listProjectId = listProjectId;
    }

    /**
     * @param yearNow
     */
    protected Integer getYearNow() {
        return yearNow;
    }

    /**
     * @param yearNow
     *            the yearNow to set
     */
    protected void setYearNow(Integer yearNow) {
        this.yearNow = yearNow;
    }

    /**
     * @param monthNow
     */
    protected Integer getMonthNow() {
        return monthNow;
    }

    /**
     * @param monthNow
     *            the monthNow to set
     */
    protected void setMonthNow(Integer monthNow) {
        this.monthNow = monthNow;
    }

    /**
     * @param getMember
     */
    public Member getMember() {
        return member;
    }

    /**
     * @param setMember
     *            the setMember to set
     */
    public void setMember(Member member) {
        this.member = member;
    }

    /**
     * @param listPro
     */
    public List<Project> getListPro() {
        return listPro;
    }

    /**
     * @param listPro
     *            the listPro to set
     */
    public void setListPro(List<Project> listPro) {
        this.listPro = listPro;
    }

    /**
     * @param getLicenManaList
     */
    public List<LicenseManagerColumn> getLicenManaList() {
        return licenManaList;
    }

    /**
     * @param licenManaList
     *            the licenManaList to set
     */
    public void setLicenManaList(List<LicenseManagerColumn> licenManaList) {
        this.licenManaList = licenManaList;
    }

    /**
     * @param getLicenTotalTax
     */
    public List<LicenseTotalTaxColumn> getLicenTotalTax() {
        return licenTotalTax;
    }

    /**
     * @param licenTotalTax
     *            the licenTotalTax to set
     */
    public void setLicenTotalTax(List<LicenseTotalTaxColumn> licenTotalTax) {
        this.licenTotalTax = licenTotalTax;
    }

    /**
     * @param projectSelected
     */
    public String getProjectSelected() {
        return projectSelected;
    }

    /**
     * @param projectSelected
     *            the projectSelected to set
     */
    public void setProjectSelected(String projectSelected) {
        this.projectSelected = projectSelected;
    }

    /**
     * @param yearSelected
     */
    public String getYearSelected() {
        return yearSelected;
    }

    /**
     * @param yearSelected
     *            the yearSelected to set
     */
    public void setYearSelected(String yearSelected) {
        this.yearSelected = yearSelected;
    }

    /**
     * @param monthSelected
     */
    public String getMonthSelected() {
        return monthSelected;
    }

    /**
     * @param monthSelected
     *            the monthSelected to set
     */
    public void setMonthSelected(String monthSelected) {
        this.monthSelected = monthSelected;
    }

    /**
     * @param monthSelectedInt
     */
    public int getMonthSelectedInt() {
        return monthSelectedInt;
    }

    /**
     * @param monthSelectedInt
     *            the monthSelectedInt to set
     */
    public void setMonthSelectedInt(int monthSelectedInt) {
        this.monthSelectedInt = monthSelectedInt;
    }

    /**
     * @param yearSelectedInt
     */
    public int getYearSelectedInt() {
        return yearSelectedInt;
    }

    /**
     * @param yearSelectedInt
     *            the yearSelectedInt to set
     */
    public void setYearSelectedInt(int yearSelectedInt) {
        this.yearSelectedInt = yearSelectedInt;
    }

    /**
     * @param projectSelectInt
     */
    public int getProjectSelectInt() {
        return projectSelectInt;
    }

    /**
     * @param projectSelectInt
     *            the projectSelectInt to set
     */
    public void setProjectSelectInt(int projectSelectInt) {
        this.projectSelectInt = projectSelectInt;
    }

    /**
     * @param boolFilterTool
     */
    public Boolean getBoolFilterTool() {
        return boolFilterTool;
    }

    /**
     * @param boolFilterTool
     *            the boolFilterTool to set
     */
    public void setBoolFilterTool(Boolean boolFilterTool) {
        this.boolFilterTool = boolFilterTool;
    }

    /**
     * @param boolFilterProduct
     */
    public Boolean getBoolFilterProduct() {
        return boolFilterProduct;
    }

    /**
     * @param boolFilterProduct
     *            the boolFilterProduct to set
     */
    public void setBoolFilterProduct(Boolean boolFilterProduct) {
        this.boolFilterProduct = boolFilterProduct;
    }

    /**
     * @param boolFilterProject
     */
    public Boolean getBoolFilterProject() {
        return boolFilterProject;
    }

    /**
     * @param boolFilterProject
     *            the boolFilterProject to set
     */
    public void setBoolFilterProject(Boolean boolFilterProject) {
        this.boolFilterProject = boolFilterProject;
    }

    /**
     * @param luToolNameFilterList
     */
    public List<LicenseUsageForToolNameFormBean> getLuToolNameFilterList() {
        return luToolNameFilterList;
    }

    /**
     * @param luToolNameFilterList
     *            the luToolNameFilterList to set
     */
    public void setLuToolNameFilterList(List<LicenseUsageForToolNameFormBean> luToolNameFilterList) {
        this.luToolNameFilterList = luToolNameFilterList;
    }

    /**
     * @param luProductNumberFilterList
     */
    public List<LicenseUsageForProjectFormBean> getLuProductNumberFilterList() {
        return luProductNumberFilterList;
    }

    /**
     * @param luProductNumberFilterList
     *            the luProductNumberFilterList to set
     */
    public void setLuProductNumberFilterList(List<LicenseUsageForProjectFormBean> luProductNumberFilterList) {
        this.luProductNumberFilterList = luProductNumberFilterList;
    }

    /**
     * @param luProjectList
     */
    public List<LicenseUsageForProjectFormBean> getLuProjectFilterList() {
        return luProjectFilterList;
    }

    /**
     * @param luProjectList
     *            the luProjectList to set
     */
    public void setLuProjectFilterList(List<LicenseUsageForProjectFormBean> luProjectFilterList) {
        this.luProjectFilterList = luProjectFilterList;
    }

    /**
     * @param executeInfo
     */
    public ExecuteTimeAndCountFormBean getExecuteInfo() {
        return executeInfo;
    }

    /**
     * @param executeInfo
     *            the executeInfo to set
     */
    public void setExecuteInfo(ExecuteTimeAndCountFormBean executeInfo) {
        this.executeInfo = executeInfo;
    }

    /**
     * @param listShowTbl3
     */
    public List<LicenseTotalTaxBean> getListShowTbl3() {
        return listShowTbl3;
    }

    /**
     * @param listShowTbl3
     *            the listShowTbl3 to set
     */
    public void setListShowTbl3(List<LicenseTotalTaxBean> listShowTbl3) {
        this.listShowTbl3 = listShowTbl3;
    }

    /**
     * @param warningMsg
     */
    public String getWarningMsg() {
        return warningMsg;
    }

    /**
     * @param warningMsg
     *            the warningMsg to set
     */
    public void setWarningMsg(String warningMsg) {
        this.warningMsg = warningMsg;
    }

    /**
     * @param totalBudget
     */
    public BigDecimal getTotalBudget() {
        return totalBudget;
    }

    /**
     * @param totalBudget
     *            the totalBudget to set
     */
    public void setTotalBudget(BigDecimal totalBudget) {
        this.totalBudget = totalBudget;
    }

    /**
     * @param totalActual
     */
    public BigDecimal getTotalActual() {
        return totalActual;
    }

    /**
     * @param totalActual
     *            the totalActual to set
     */
    public void setTotalActual(BigDecimal totalActual) {
        this.totalActual = totalActual;
    }

    /**
     * @param totalBudgetPerPro
     */
    public BigDecimal getTotalBudgetPerPro() {
        return totalBudgetPerPro;
    }

    /**
     * @param totalBudgetPerPro
     *            the totalBudgetPerPro to set
     */
    public void setTotalBudgetPerPro(BigDecimal totalBudgetPerPro) {
        this.totalBudgetPerPro = totalBudgetPerPro;
    }

    /**
     * @param totalActualPerPro
     */
    public BigDecimal getTotalActualPerPro() {
        return totalActualPerPro;
    }

    /**
     * @param totalActualPerPro
     *            the totalActualPerPro to set
     */
    public void setTotalActualPerPro(BigDecimal totalActualPerPro) {
        this.totalActualPerPro = totalActualPerPro;
    }

    /**
     * @param yearNow
     *            the yearNow to set
     */
    public void setYearNow(int yearNow) {
        this.yearNow = yearNow;
    }

    /**
     * @param fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * @param fileName
     *            the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * @param inputFileStream
     */
    public InputStream getInputFileStream() {
        return inputFileStream;
    }

    /**
     * @param inputFileStream
     *            the inputFileStream to set
     */
    public void setInputFileStream(InputStream inputFileStream) {
        this.inputFileStream = inputFileStream;
    }

    /**
     * @param fileNameExport
     */
    public String getFileNameExport() {
        return fileNameExport;
    }

    /**
     * @param fileNameExport
     *            the fileNameExport to set
     */
    public void setFileNameExport(String fileNameExport) {
        this.fileNameExport = fileNameExport;
    }
    
    /**
     * @param fileNameExportSupporter
     */
    public String getFileNameExportSupporter() {
        return fileNameExportSupporter;
    }
    
    /**
     * @param fileNameExportSupporter
     *            the fileNameExportSupporter to set
     */
    public void setFileNameExportSupporter(String fileNameExportSupporter) {
        this.fileNameExportSupporter = fileNameExportSupporter;
    }

    /**
     * @param isSupporter
     */
    public Boolean getIsSupporter() {
        return isSupporter;
    }

    /**
     * @param isSupporter
     *            the isSupporter to set
     */
    public void setIsSupporter(Boolean isSupporter) {
        this.isSupporter = isSupporter;
    }
    
    /**
     * @param sizeLicenManaList
     */
    public int getSizeLicenManaList() {
        return sizeLicenManaList;
    }

    /**
     * @param sizeLicenManaList
     *            the sizeLicenManaList to set
     */
    public void setSizeLicenManaList(int sizeLicenManaList) {
        this.sizeLicenManaList = sizeLicenManaList;
    }

    /**
     * @param recordList
     */
    public List<LicenseManagerColumn> getRecordList() {
        return recordList;
    }

    /**
     * @param recordList
     *            the recordList to set
     */
    public void setRecordList(List<LicenseManagerColumn> recordList) {
        this.recordList = recordList;
    }

    /**
     * @param recordListTwo
     */
    public List<LicenseTotalTaxColumn> getRecordListTwo() {
        return recordListTwo;
    }

    /**
     * @param recordListTwo
     *            the recordListTwo to set
     */
    public void setRecordListTwo(List<LicenseTotalTaxColumn> recordListTwo) {
        this.recordListTwo = recordListTwo;
    }

    /**
     * @param recordListThree
     */
    public List<LicenseTotalTaxBean> getRecordListThree() {
        return recordListThree;
    }

    /**
     * @param recordListThree
     *            the recordListThree to set
     */
    public void setRecordListThree(List<LicenseTotalTaxBean> recordListThree) {
        this.recordListThree = recordListThree;
    }

    /**
     * @param indexRecordStart
     */
    public int getIndexRecordStart() {
        return indexRecordStart;
    }

    /**
     * @param indexRecordStart
     *            the indexRecordStart to set
     */
    public void setIndexRecordStart(int indexRecordStart) {
        this.indexRecordStart = indexRecordStart;
    }

    /**
     * @param currentPage
     */
    public int getCurrentPage() {
        return currentPage;
    }

    /**
     * @param currentPage
     *            the currentPage to set
     */
    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    /**
     * @param mapListName
     */
    public Map<Integer, List<String>> getMapListName() {
        return mapListName;
    }

    /**
     * @param mapListName
     *            the mapListName to set
     */
    public void setMapListName(Map<Integer, List<String>> mapListName) {
        this.mapListName = mapListName;
    }
}
