package jp.meportal.isv.action;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import jp.meportal.isv.business.LicenseBusiness;
import jp.meportal.isv.business.MemberBusiness;
import jp.meportal.isv.business.ProjectBusiness;
import jp.meportal.isv.business.SupporterBusiness;
import jp.meportal.isv.business.impl.LicenseBusinessImpl;
import jp.meportal.isv.business.impl.MemberBusinessImpl;
import jp.meportal.isv.business.impl.ProjectBusinessImpl;
import jp.meportal.isv.business.impl.SupporterBusinessImpl;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.constant.ErrorCodes;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.IpAddressInfo;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.Member;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ProjectBelongInfo;
import jp.meportal.isv.entity.UserInfo;
import jp.meportal.isv.formbean.LicenseApproveOrRejectBean;
import jp.meportal.isv.formbean.LicenseColumn;
import jp.meportal.isv.formbean.LicenseFormBean;
import jp.meportal.isv.util.DateUtils;
import jp.meportal.isv.util.EmailUtil;
import jp.meportal.isv.util.PropertiesUtil;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Class Name: LicenseAction<br>
 * Created date: 2017/05/05<br>
 * 
 * @author FPT
 */
public class LicenseAction extends BaseAction {
    
    private static final long serialVersionUID = 1L;

    private static final Logger log = Logger.getLogger(BaseAction.class);
    
    public ProjectBusiness projectBusiness;
    public MemberBusiness memberBusiness;
    public SupporterBusiness supporterBusiness;
    public LicenseBusiness licenseBusiness;
    public ProjectBelongInfo projectBelongInfo;
    public CatalogInfor catalogInfor;
    public Project project;
    public Project findPro;
    public List<CatalogInfor> listCatalogInfor;
    public List<LicenseColumn> listLicenseColumn;
    public List<LicenseFormBean> listLicenseFormBean;
    public List<ProjectBelongInfo> listProBelongInfo;
    public List<Project> listPro;
    public List<String> ipDeleteList;
    public List<String> ipInsertList;
    public List<IpAddressInfo> ipAddressInsertDBList;
    public List<Object> catalogIdChecked;
    public String errMsg;
    public List<LicenseApproveOrRejectBean> listLicenseAOR ;
    public String seqNo;
    public String warningMsg = StringUtils.EMPTY;
    public int catalogId;
    public int valueLicense;
    public int ipInsertLength;

    private transient HttpSession session = ServletActionContext.getRequest().getSession();
    private transient HttpServletRequest request = ServletActionContext.getRequest();
    
    public LicenseAction() {
        projectBusiness = new ProjectBusinessImpl();
        memberBusiness = new MemberBusinessImpl();
        licenseBusiness = new LicenseBusinessImpl();
        supporterBusiness = new SupporterBusinessImpl();
    }

    /**
     * registerLicense
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    public String registerLicense() {
        if (!isValidateUser()) {
            return LOGIN;
        }
        if (session != null) {// remove all session
            session.removeAttribute("projectName");
        }
        int seqNoProject = 0;
        exceptionMsg = StringUtils.EMPTY;
        String emailAddress = this.getEmailAddress();
        Member member = memberBusiness.checkExistEmailMember(emailAddress);
        if (member != null) {
            listPro = projectBusiness.listAllProjectByManager(Constants.APPROVED_STATUS, member, emailAddress, false);
        }
        if (listPro != null && listPro.size() > 0) {// Get first list project
            Project firstProject = listPro.get(0);
            if (firstProject != null) {
                if (session != null) {
                    session.setAttribute("projectId", firstProject.getSeqNo());
                    session.setAttribute("projectName", firstProject.getProjectName());
                    seqNoProject = firstProject.getSeqNo();
                }
            }
        } else {
            exceptionMsg = ErrorCodes.ERRORS_CODE_PROJECT_NOT_EXIST;
            request.setAttribute(exceptionMsg, exceptionMsg);
            return SUCCESS;
        }
        this.showLicenseInfor(seqNoProject); // show data license infor.
        ipAddressInsertDBList = licenseBusiness.listAllIpAddressByProjectId(seqNoProject);
        if (ipAddressInsertDBList != null && ipAddressInsertDBList.size() > 0) {
            ipInsertLength = ipAddressInsertDBList.size();
        }
        return SUCCESS;
    }

	/**
     * moreLoadRegisterLicense
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    public String moreLoadRegisterLicense() throws Exception {
        if (!isValidateUser()) {
            return LOGIN;
        }
        project = projectBusiness.findProjectBySeqNo(findPro.getSeqNo());
        int seqNoProject = 0;
        Member member = memberBusiness.checkExistEmailMember(this.getEmailAddress());
        if (member != null) {
            listPro = new ArrayList<Project>();
            listPro = projectBusiness.listAllProjectByManager(Constants.APPROVED_STATUS, member,
                    this.getEmailAddress(), false);
        }

        if (listPro != null && listPro.size() > 0) {
            session.setAttribute("projectId", project.getSeqNo());
            session.setAttribute("projectName", project.getProjectName());
            seqNoProject = project.getSeqNo();
        }
        this.showLicenseInfor(seqNoProject);
        ipAddressInsertDBList = licenseBusiness.listAllIpAddressByProjectId(seqNoProject);
        if (ipAddressInsertDBList != null && ipAddressInsertDBList.size() > 0) {
            ipInsertLength = ipAddressInsertDBList.size();
        }
        return SUCCESS;
    }
    
    /**
     * updateLicense
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    public String updateLicense() throws Exception {
        if (!isValidateUser()) {
            return LOGIN;
        }
        UserInfo userInfo = getUserInfo(null, ServletActionContext.getRequest());
        int projectId = (Integer) session.getAttribute("projectId");
        Project project = projectBusiness.findProjectBySeqNo(projectId);
        if (project == null) {
            exceptionMsg = ErrorCodes.ERRORS_CODE_PROJECT_NOT_EXIST;
            return SUCCESS;
        }
        // start check if a license registering then error.
        List<LicenseInfo> licenseInfosAll = licenseBusiness.listAllLicenseInfoByProjectId(projectId);
        List<LicenseInfo> licenseInfosZero = licenseBusiness.listAllLicenseInfoByProjectIdAndStatus(projectId, Constants.UN_APPROVED_STATUS);
        List<IpAddressInfo> ipAddressUnApprovedList = licenseBusiness.getIpAddressUnApproved(projectId, Constants.UN_APPROVED_STATUS, Constants.DELETED_STATUS);
        boolean flagValidateLicense = false;
        boolean flagValidateIp = false;
        boolean isListsNull = (licenseInfosAll == null || licenseInfosZero == null);
        if (!isListsNull && !licenseInfosAll.isEmpty() && !licenseInfosZero.isEmpty()) {
            flagValidateLicense = true;
        }
        if (ipAddressUnApprovedList != null && ipAddressUnApprovedList.size() > 0) {
            flagValidateIp = true;
        }
        if (flagValidateLicense || flagValidateIp) {
            errMsg = ErrorCodes.ERRORS_CODE_LICENSE_CAN_NOT_RIGISTER;
            return SUCCESS;
        }
        // end check if a license registering then error.
        errMsg = StringUtils.EMPTY;
        String[] objects = request.getParameterValues("arrayCatalogId");
        String[] ipAddList = request.getParameterValues("inputIPAddArr");
        String comment = request.getParameter("commentTxtArea");
        boolean flagProcessLicense = false;
        List<LicenseInfo> licenseRegisterList = null;
        if (objects != null) {

            Object objectList = objects[0];
            objectList.toString();
            String stringLicense = objectList.toString();
            JSONArray newJArray = new JSONArray(stringLicense);
            ArrayList<JSONObject> arrays = new ArrayList<JSONObject>();
            for (int i = 0; i < newJArray.length(); i++) {
                arrays.add(newJArray.getJSONObject(i));
            }
            JSONObject[] jsons = new JSONObject[arrays.size()];
            arrays.toArray(jsons);
            Calendar nowtime = Calendar.getInstance();// Gets the current date and time
            int currentYear = nowtime.get(Calendar.YEAR);
            int nextYear = currentYear + 1;
            int monthNow = nowtime.get(Calendar.MONTH) + 1;

            int catalogid = 0;
            String catalog_month_1 = StringUtils.EMPTY;
            String catalog_month_2 = StringUtils.EMPTY;
            String catalog_month_3 = StringUtils.EMPTY;
            String catalog_month_4 = StringUtils.EMPTY;
            String catalog_month_5 = StringUtils.EMPTY;
            String catalog_month_6 = StringUtils.EMPTY;
            String catalog_month_7 = StringUtils.EMPTY;
            String catalog_month_8 = StringUtils.EMPTY;
            String catalog_month_9 = StringUtils.EMPTY;
            String catalog_month_10 = StringUtils.EMPTY;
            String catalog_month_11 = StringUtils.EMPTY;
            String catalog_month_12 = StringUtils.EMPTY;

            List<String> catalogArr = null;
            List<Integer> catalogValidate = null;
            JSONObject jsonObject;
            String catalog_month = StringUtils.EMPTY;
            licenseRegisterList = new ArrayList<LicenseInfo>();
            List<Integer> totalRegisList = new ArrayList<Integer>();
            // Validate license was approved
            for (int i = 0; i < arrays.size(); i++) {
                jsonObject = arrays.get(i);
                catalogid = jsonObject.getInt("catalogId");
                catalogArr = new ArrayList<String>();
                catalogValidate = new ArrayList<Integer>();
                int total = 0;
                for (int j = 1; j <= 12; j++) {
                    int sumary = 0;
                    catalog_month = "catalog_month_" + j;
                    catalogArr.add(jsonObject.getString(catalog_month));
                    if (StringUtils.isEmpty(jsonObject.getString(catalog_month))) {
                        catalogValidate.add(0);
                        sumary = 0;
                    } else {
                        catalogValidate.add(Integer.parseInt(jsonObject.getString(catalog_month)));
                        sumary = Integer.parseInt(jsonObject.getString(catalog_month));
                    }
                    total = total + sumary;
                }
                totalRegisList.add(total);
                
                List<LicenseInfo> licenseByCatalogId = licenseBusiness.getLicenseInfoById(projectId, catalogid);
                List<Integer> licenseByCatalogIdList = null;
                if (licenseByCatalogId != null && licenseByCatalogId.size() > 0) {
                    LicenseInfo licenseCatalogInfo = null;
                    licenseByCatalogIdList = new ArrayList<Integer>();
                    if(licenseByCatalogId.size() == 1) {
                        licenseCatalogInfo = licenseByCatalogId.get(0);
                        licenseByCatalogIdList = new ArrayList<Integer>();
                        licenseByCatalogIdList.add(licenseCatalogInfo.getJan());
                        licenseByCatalogIdList.add(licenseCatalogInfo.getFeb());
                        licenseByCatalogIdList.add(licenseCatalogInfo.getMar());
                        licenseByCatalogIdList.add(licenseCatalogInfo.getApr());
                        licenseByCatalogIdList.add(licenseCatalogInfo.getMay());
                        licenseByCatalogIdList.add(licenseCatalogInfo.getJun());
                        licenseByCatalogIdList.add(licenseCatalogInfo.getJul());
                        licenseByCatalogIdList.add(licenseCatalogInfo.getAug());
                        licenseByCatalogIdList.add(licenseCatalogInfo.getSep());
                        licenseByCatalogIdList.add(licenseCatalogInfo.getOct());
                        licenseByCatalogIdList.add(licenseCatalogInfo.getNov());
                        licenseByCatalogIdList.add(licenseCatalogInfo.getDec());
                    } else if(licenseByCatalogId.size() > 1) {
                        licenseByCatalogIdList = new ArrayList<Integer>();
                        LicenseInfo licenseInfo = licenseByCatalogId.get(0);
                        LicenseInfo licenseInfoGetOne = licenseByCatalogId.get(1);

                        licenseByCatalogIdList.add(licenseInfoGetOne.getJan());
                        licenseByCatalogIdList.add(licenseInfoGetOne.getFeb());
                        licenseByCatalogIdList.add(licenseInfoGetOne.getMar());
                        licenseByCatalogIdList.add(licenseInfo.getApr());
                        licenseByCatalogIdList.add(licenseInfo.getMay());
                        licenseByCatalogIdList.add(licenseInfo.getJun());
                        licenseByCatalogIdList.add(licenseInfo.getJul());
                        licenseByCatalogIdList.add(licenseInfo.getAug());
                        licenseByCatalogIdList.add(licenseInfo.getSep());
                        licenseByCatalogIdList.add(licenseInfo.getOct());
                        licenseByCatalogIdList.add(licenseInfo.getNov());
                        licenseByCatalogIdList.add(licenseInfo.getDec());
                    }
                }
                if (licenseByCatalogIdList != null) {
                    boolean flagCompareValue = false;
                    for (int k = 0; k < 12; k++) {
                        int cat = catalogValidate.get(k);
                        int lic = licenseByCatalogIdList.get(k);
                        if (cat != lic) {
                            flagCompareValue = false;
                            break;
                        } else {
                            flagCompareValue = true;
                        }
                    }
                    if (flagCompareValue) {
                        errMsg = ErrorCodes.ERRORS_CODE_LICENSE_CAN_NOT_RIGISTER_NOT_DATA_CHANGE;
                        return SUCCESS;
                    }
                } else if (licenseByCatalogIdList == null && totalRegisList.get(i) == 0) {
                    errMsg = ErrorCodes.ERRORS_CODE_LICENSE_CAN_NOT_RIGISTER_NOT_DATA_CHANGE;
                    return SUCCESS;
                }
            }
            // Register license
            for (int i = 0; i < arrays.size(); i++) {
                jsonObject = arrays.get(i);
                catalogid = jsonObject.getInt("catalogId");
                catalogArr = new ArrayList<String>();
                for (int j = 1; j <= 12; j++) {
                    catalog_month = "catalog_month_" + j;
                    catalogArr.add(jsonObject.getString(catalog_month));
                }
                for (String em : catalogArr) {
                    if (!em.isEmpty()) {
                        flagProcessLicense = true;
                        break;
                    } else {
                        flagProcessLicense = false;
                    }
                }
                
                if (flagProcessLicense) {
                    CatalogInfor catalogInfor = licenseBusiness.findCatalogInforBySeqNo(catalogid);
                    List<LicenseInfo> licenseInfos = licenseBusiness.findLicensebyCatalogIdandProjectId(projectId,
                            catalogid, currentYear);
                    List<LicenseInfo> licenseInfosNY = licenseBusiness.findLicensebyCatalogIdandProjectId(projectId,
                            catalogid, nextYear);
                    switch (monthNow) {
                    case 4:
                        if(!licenseInfos.isEmpty()){//update
                            for (LicenseInfo licenseInfo : licenseInfos) {
                                catalog_month_4 = jsonObject.getString("catalog_month_4");
                                if (!StringUtils.isEmpty(catalog_month_4)) {
                                    licenseInfo.setAprUpdated(Integer.valueOf(catalog_month_4));
                                }
                                catalog_month_5 = jsonObject.getString("catalog_month_5");
                                if (!StringUtils.isEmpty(catalog_month_5)) {
                                    licenseInfo.setMayUpdated(Integer.valueOf(catalog_month_5));
                                }
                                catalog_month_6 = jsonObject.getString("catalog_month_6");
                                if (!StringUtils.isEmpty(catalog_month_6)) {
                                    licenseInfo.setJunUpdated(Integer.valueOf(catalog_month_6));
                                }
                                catalog_month_7 = jsonObject.getString("catalog_month_7");
                                if (!StringUtils.isEmpty(catalog_month_7)) {
                                    licenseInfo.setJulUpdated(Integer.valueOf(catalog_month_7));
                                }
                                catalog_month_8 = jsonObject.getString("catalog_month_8");
                                if (!StringUtils.isEmpty(catalog_month_8)) {
                                    licenseInfo.setAugUpdated(Integer.valueOf(catalog_month_8));
                                }
                                catalog_month_9 = jsonObject.getString("catalog_month_9");
                                if (!StringUtils.isEmpty(catalog_month_9)) {
                                    licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                                }
                                licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                      Constants.DATE_FORMAT_UPDATE));
                              licenseInfo.setStatus(0);
                              licenseRegisterList.add(licenseInfo);
                              flagProcessLicense = true;
                            }
                        } else {//insert
                              LicenseInfo licenseInfo = new LicenseInfo();
                              licenseInfo.setProjectId(project);
                              licenseInfo.setCatalogId(catalogInfor);
                              licenseInfo.setYear(currentYear);
                              licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                      Constants.DATE_FORMAT_UPDATE));
                              licenseInfo.setStatus(0);
                              catalog_month_4 = jsonObject.getString("catalog_month_4");
                              if (!StringUtils.isEmpty(catalog_month_4)) {
                                  licenseInfo.setAprUpdated(Integer.valueOf(catalog_month_4));
                              }
                              catalog_month_5 = jsonObject.getString("catalog_month_5");
                              if (!StringUtils.isEmpty(catalog_month_5)) {
                                  licenseInfo.setMayUpdated(Integer.valueOf(catalog_month_5));
                              }
                              catalog_month_6 = jsonObject.getString("catalog_month_6");
                              if (!StringUtils.isEmpty(catalog_month_6)) {
                                  licenseInfo.setJunUpdated(Integer.valueOf(catalog_month_6));
                              }
                              catalog_month_7 = jsonObject.getString("catalog_month_7");
                              if (!StringUtils.isEmpty(catalog_month_7)) {
                                  licenseInfo.setJulUpdated(Integer.valueOf(catalog_month_7));
                              }
                              catalog_month_8 = jsonObject.getString("catalog_month_8");
                              if (!StringUtils.isEmpty(catalog_month_8)) {
                                  licenseInfo.setAugUpdated(Integer.valueOf(catalog_month_8));
                              }
                              catalog_month_9 = jsonObject.getString("catalog_month_9");
                              if (!StringUtils.isEmpty(catalog_month_9)) {
                                  licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                              }
                              licenseRegisterList.add(licenseInfo);
                              flagProcessLicense = true;
                        }
                        break;
                    case 5:
                        if(!licenseInfos.isEmpty()){//update
                            for (LicenseInfo licenseInfo : licenseInfos) {
                                catalog_month_5 = jsonObject.getString("catalog_month_5");
                                if (!StringUtils.isEmpty(catalog_month_5)) {
                                    licenseInfo.setMayUpdated(Integer.valueOf(catalog_month_5));
                                }
                                catalog_month_6 = jsonObject.getString("catalog_month_6");
                                if (!StringUtils.isEmpty(catalog_month_6)) {
                                    licenseInfo.setJunUpdated(Integer.valueOf(catalog_month_6));
                                }
                                catalog_month_7 = jsonObject.getString("catalog_month_7");
                                if (!StringUtils.isEmpty(catalog_month_7)) {
                                    licenseInfo.setJulUpdated(Integer.valueOf(catalog_month_7));
                                }
                                catalog_month_8 = jsonObject.getString("catalog_month_8");
                                if (!StringUtils.isEmpty(catalog_month_8)) {
                                    licenseInfo.setAugUpdated(Integer.valueOf(catalog_month_8));
                                }
                                catalog_month_9 = jsonObject.getString("catalog_month_9");
                                if (!StringUtils.isEmpty(catalog_month_9)) {
                                    licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                                }
                                licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                      Constants.DATE_FORMAT_UPDATE));
                              licenseInfo.setStatus(0);
                              licenseRegisterList.add(licenseInfo);
                              flagProcessLicense = true;
                            }
                        } else {//insert
                            LicenseInfo licenseInfo = new LicenseInfo();
                            licenseInfo.setProjectId(project);
                            licenseInfo.setCatalogId(catalogInfor);
                            licenseInfo.setYear(currentYear);
                            licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                    Constants.DATE_FORMAT_UPDATE));
                            licenseInfo.setStatus(0);
                            catalog_month_5 = jsonObject.getString("catalog_month_5");
                            if (!StringUtils.isEmpty(catalog_month_5)) {
                                licenseInfo.setMayUpdated(Integer.valueOf(catalog_month_5));
                            }
                            catalog_month_6 = jsonObject.getString("catalog_month_6");
                            if (!StringUtils.isEmpty(catalog_month_6)) {
                                licenseInfo.setJunUpdated(Integer.valueOf(catalog_month_6));
                            }
                            catalog_month_7 = jsonObject.getString("catalog_month_7");
                            if (!StringUtils.isEmpty(catalog_month_7)) {
                                licenseInfo.setJulUpdated(Integer.valueOf(catalog_month_7));
                            }
                            catalog_month_8 = jsonObject.getString("catalog_month_8");
                            if (!StringUtils.isEmpty(catalog_month_8)) {
                                licenseInfo.setAugUpdated(Integer.valueOf(catalog_month_8));
                            }
                            catalog_month_9 = jsonObject.getString("catalog_month_9");
                            if (!StringUtils.isEmpty(catalog_month_9)) {
                                licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                            }
                            licenseRegisterList.add(licenseInfo);
                            flagProcessLicense = true;
                        }
                        break;
                    case 6:
                        if(!licenseInfos.isEmpty()){//update
                            for (LicenseInfo licenseInfo : licenseInfos) {
                                catalog_month_6 = jsonObject.getString("catalog_month_6");
                                if (!StringUtils.isEmpty(catalog_month_6)) {
                                    licenseInfo.setJunUpdated(Integer.valueOf(catalog_month_6));
                                }
                                catalog_month_7 = jsonObject.getString("catalog_month_7");
                                if (!StringUtils.isEmpty(catalog_month_7)) {
                                    licenseInfo.setJulUpdated(Integer.valueOf(catalog_month_7));
                                }
                                catalog_month_8 = jsonObject.getString("catalog_month_8");
                                if (!StringUtils.isEmpty(catalog_month_8)) {
                                    licenseInfo.setAugUpdated(Integer.valueOf(catalog_month_8));
                                }
                                catalog_month_9 = jsonObject.getString("catalog_month_9");
                                if (!StringUtils.isEmpty(catalog_month_9)) {
                                    licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                                }
                                licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                      Constants.DATE_FORMAT_UPDATE));
                              licenseInfo.setStatus(0);
                              licenseRegisterList.add(licenseInfo);
                              flagProcessLicense = true;
                            }
                        } else {//insert
                            LicenseInfo licenseInfo = new LicenseInfo();
                            licenseInfo.setProjectId(project);
                            licenseInfo.setCatalogId(catalogInfor);
                            licenseInfo.setYear(currentYear);
                            licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                    Constants.DATE_FORMAT_UPDATE));
                            licenseInfo.setStatus(0);
                            catalog_month_6 = jsonObject.getString("catalog_month_6");
                            if (!StringUtils.isEmpty(catalog_month_6)) {
                                licenseInfo.setJunUpdated(Integer.valueOf(catalog_month_6));
                            }
                            catalog_month_7 = jsonObject.getString("catalog_month_7");
                            if (!StringUtils.isEmpty(catalog_month_7)) {
                                licenseInfo.setJulUpdated(Integer.valueOf(catalog_month_7));
                            }
                            catalog_month_8 = jsonObject.getString("catalog_month_8");
                            if (!StringUtils.isEmpty(catalog_month_8)) {
                                licenseInfo.setAugUpdated(Integer.valueOf(catalog_month_8));
                            }
                            catalog_month_9 = jsonObject.getString("catalog_month_9");
                            if (!StringUtils.isEmpty(catalog_month_9)) {
                                licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                            }
                            licenseRegisterList.add(licenseInfo);
                            flagProcessLicense = true;
                        }
                        break;
                    case 7:
                        if(!licenseInfos.isEmpty()){//update
                            for (LicenseInfo licenseInfo : licenseInfos) {
                                catalog_month_7 = jsonObject.getString("catalog_month_7");
                                if (!StringUtils.isEmpty(catalog_month_7)) {
                                    licenseInfo.setJulUpdated(Integer.valueOf(catalog_month_7));
                                }
                                catalog_month_8 = jsonObject.getString("catalog_month_8");
                                if (!StringUtils.isEmpty(catalog_month_8)) {
                                    licenseInfo.setAugUpdated(Integer.valueOf(catalog_month_8));
                                }
                                catalog_month_9 = jsonObject.getString("catalog_month_9");
                                if (!StringUtils.isEmpty(catalog_month_9)) {
                                    licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                                }
                                licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                      Constants.DATE_FORMAT_UPDATE));
                              licenseInfo.setStatus(0);
                              licenseRegisterList.add(licenseInfo);
                              flagProcessLicense = true;
                            }
                        } else {//insert
                            LicenseInfo licenseInfo = new LicenseInfo();
                            licenseInfo.setProjectId(project);
                            licenseInfo.setCatalogId(catalogInfor);
                            licenseInfo.setYear(currentYear);
                            licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                    Constants.DATE_FORMAT_UPDATE));
                            licenseInfo.setStatus(0);
                            catalog_month_7 = jsonObject.getString("catalog_month_7");
                            if (!StringUtils.isEmpty(catalog_month_7)) {
                                licenseInfo.setJulUpdated(Integer.valueOf(catalog_month_7));
                            }
                            catalog_month_8 = jsonObject.getString("catalog_month_8");
                            if (!StringUtils.isEmpty(catalog_month_8)) {
                                licenseInfo.setAugUpdated(Integer.valueOf(catalog_month_8));
                            }
                            catalog_month_9 = jsonObject.getString("catalog_month_9");
                            if (!StringUtils.isEmpty(catalog_month_9)) {
                                licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                            }
                            licenseRegisterList.add(licenseInfo);
                            flagProcessLicense = true;
                        }
                        break;
                    case 8:
                        if(!licenseInfos.isEmpty()){//update
                            for (LicenseInfo licenseInfo : licenseInfos) {
                                catalog_month_8 = jsonObject.getString("catalog_month_8");
                                if (!StringUtils.isEmpty(catalog_month_8)) {
                                    licenseInfo.setAugUpdated(Integer.valueOf(catalog_month_8));
                                }
                                catalog_month_9 = jsonObject.getString("catalog_month_9");
                                if (!StringUtils.isEmpty(catalog_month_9)) {
                                    licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                                }
                                licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                      Constants.DATE_FORMAT_UPDATE));
                              licenseInfo.setStatus(0);
                              licenseRegisterList.add(licenseInfo);
                              flagProcessLicense = true;
                            }
                        } else {//insert
                            LicenseInfo licenseInfo = new LicenseInfo();
                            licenseInfo.setProjectId(project);
                            licenseInfo.setCatalogId(catalogInfor);
                            licenseInfo.setYear(currentYear);
                            licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                    Constants.DATE_FORMAT_UPDATE));
                            licenseInfo.setStatus(0);
                            catalog_month_8 = jsonObject.getString("catalog_month_8");
                            if (!StringUtils.isEmpty(catalog_month_8)) {
                                licenseInfo.setAugUpdated(Integer.valueOf(catalog_month_8));
                            }
                            catalog_month_9 = jsonObject.getString("catalog_month_9");
                            if (!StringUtils.isEmpty(catalog_month_9)) {
                                licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                            }
                            licenseRegisterList.add(licenseInfo);
                            flagProcessLicense = true;
                        }
                        break;
                    case 9:
                        catalog_month_9 = jsonObject.getString("catalog_month_9");
                        catalog_month_10 = jsonObject.getString("catalog_month_10");
                        catalog_month_11 = jsonObject.getString("catalog_month_11");
                        catalog_month_12 = jsonObject.getString("catalog_month_12");
                        if(!catalog_month_9.isEmpty() || !catalog_month_10.isEmpty() 
                                || !catalog_month_11.isEmpty() || !catalog_month_12.isEmpty()) {
                            if(!licenseInfos.isEmpty()){//update
                                for (LicenseInfo licenseInfo : licenseInfos) {
                                    if (!StringUtils.isEmpty(catalog_month_9)) {
                                        licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_10)) {
                                        licenseInfo.setOctUpdated(Integer.valueOf(catalog_month_10));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_11)) {
                                        licenseInfo.setNovUpdated(Integer.valueOf(catalog_month_11));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_12)) {
                                        licenseInfo.setDecUpdated(Integer.valueOf(catalog_month_12));
                                    }
                                    licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                          Constants.DATE_FORMAT_UPDATE));
                                  licenseInfo.setStatus(0);
                                  licenseRegisterList.add(licenseInfo);
                                  flagProcessLicense = true;
                                }
                            } else {//insert
                                LicenseInfo licenseInfo = new LicenseInfo();
                                licenseInfo.setProjectId(project);
                                licenseInfo.setCatalogId(catalogInfor);
                                licenseInfo.setYear(currentYear);
                                licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                        Constants.DATE_FORMAT_UPDATE));
                                licenseInfo.setStatus(0);
                                if (!StringUtils.isEmpty(catalog_month_9)) {
                                    licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                                }
                                if (!StringUtils.isEmpty(catalog_month_10)) {
                                    licenseInfo.setOctUpdated(Integer.valueOf(catalog_month_10));
                                }
                                if (!StringUtils.isEmpty(catalog_month_11)) {
                                    licenseInfo.setNovUpdated(Integer.valueOf(catalog_month_11));
                                }
                                if (!StringUtils.isEmpty(catalog_month_12)) {
                                    licenseInfo.setDecUpdated(Integer.valueOf(catalog_month_12));
                                }
                                licenseRegisterList.add(licenseInfo);
                                flagProcessLicense = true;
                            }
                        }
                        
                        catalog_month_1 = jsonObject.getString("catalog_month_1");
                        catalog_month_2 = jsonObject.getString("catalog_month_2");
                        catalog_month_3 = jsonObject.getString("catalog_month_3");
                        if(!catalog_month_1.isEmpty() || !catalog_month_2.isEmpty() || !catalog_month_3.isEmpty()){
                            if(!licenseInfosNY.isEmpty()){//update
                                for (LicenseInfo licenseInfo : licenseInfosNY) {
                                    if (!StringUtils.isEmpty(catalog_month_1)) {
                                        licenseInfo.setJanUpdated(Integer.valueOf(catalog_month_1));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_2)) {
                                        licenseInfo.setFebUpdated(Integer.valueOf(catalog_month_2));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_3)) {
                                        licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                                    }
                                    licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                          Constants.DATE_FORMAT_UPDATE));
                                  licenseInfo.setStatus(0);
                                  licenseRegisterList.add(licenseInfo);
                                  flagProcessLicense = true;
                                }
                            } else {//insert
                                LicenseInfo licenseInfo = new LicenseInfo();
                                licenseInfo.setProjectId(project);
                                licenseInfo.setCatalogId(catalogInfor);
                                licenseInfo.setYear(nextYear);
                                licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                        Constants.DATE_FORMAT_UPDATE));
                                licenseInfo.setStatus(0);
                                if (!StringUtils.isEmpty(catalog_month_1)) {
                                    licenseInfo.setJanUpdated(Integer.valueOf(catalog_month_1));
                                }
                                if (!StringUtils.isEmpty(catalog_month_2)) {
                                    licenseInfo.setFebUpdated(Integer.valueOf(catalog_month_2));
                                }
                                if (!StringUtils.isEmpty(catalog_month_3)) {
                                    licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                                }
                                licenseRegisterList.add(licenseInfo);
                                flagProcessLicense = true;
                            }
                        }
                        break;
                    case 10:
                        catalog_month_10 = jsonObject.getString("catalog_month_10");
                        catalog_month_11 = jsonObject.getString("catalog_month_11");
                        catalog_month_12 = jsonObject.getString("catalog_month_12");
                        if(!catalog_month_10.isEmpty() || !catalog_month_11.isEmpty() || !catalog_month_12.isEmpty()) {
                            if(!licenseInfos.isEmpty()){//update
                                for (LicenseInfo licenseInfo : licenseInfos) {
                                    if (!StringUtils.isEmpty(catalog_month_10)) {
                                        licenseInfo.setOctUpdated(Integer.valueOf(catalog_month_10));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_11)) {
                                        licenseInfo.setNovUpdated(Integer.valueOf(catalog_month_11));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_12)) {
                                        licenseInfo.setDecUpdated(Integer.valueOf(catalog_month_12));
                                    }
                                    licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                          Constants.DATE_FORMAT_UPDATE));
                                  licenseInfo.setStatus(0);
                                  licenseRegisterList.add(licenseInfo);
                                  flagProcessLicense = true;
                                }
                            } else {//insert
                                LicenseInfo licenseInfo = new LicenseInfo();
                                licenseInfo.setProjectId(project);
                                licenseInfo.setCatalogId(catalogInfor);
                                licenseInfo.setYear(currentYear);
                                licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                        Constants.DATE_FORMAT_UPDATE));
                                licenseInfo.setStatus(0);
                                if (!StringUtils.isEmpty(catalog_month_10)) {
                                    licenseInfo.setOctUpdated(Integer.valueOf(catalog_month_10));
                                }
                                if (!StringUtils.isEmpty(catalog_month_11)) {
                                    licenseInfo.setNovUpdated(Integer.valueOf(catalog_month_11));
                                }
                                if (!StringUtils.isEmpty(catalog_month_12)) {
                                    licenseInfo.setDecUpdated(Integer.valueOf(catalog_month_12));
                                }
                                licenseRegisterList.add(licenseInfo);
                                flagProcessLicense = true;
                            }
                        }
                        
                        catalog_month_1 = jsonObject.getString("catalog_month_1");
                        catalog_month_2 = jsonObject.getString("catalog_month_2");
                        catalog_month_3 = jsonObject.getString("catalog_month_3");
                        if(!catalog_month_1.isEmpty() || !catalog_month_2.isEmpty() || !catalog_month_3.isEmpty()){
                            if(!licenseInfosNY.isEmpty()){//update
                                for (LicenseInfo licenseInfo : licenseInfosNY) {
                                    if (!StringUtils.isEmpty(catalog_month_1)) {
                                        licenseInfo.setJanUpdated(Integer.valueOf(catalog_month_1));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_2)) {
                                        licenseInfo.setFebUpdated(Integer.valueOf(catalog_month_2));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_3)) {
                                        licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                                    }
                                    licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                          Constants.DATE_FORMAT_UPDATE));
                                  licenseInfo.setStatus(0);
                                  licenseRegisterList.add(licenseInfo);
                                  flagProcessLicense = true;
                                }
                            } else {//insert
                                LicenseInfo licenseInfo = new LicenseInfo();
                                licenseInfo.setProjectId(project);
                                licenseInfo.setCatalogId(catalogInfor);
                                licenseInfo.setYear(nextYear);
                                licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                        Constants.DATE_FORMAT_UPDATE));
                                licenseInfo.setStatus(0);
                                if (!StringUtils.isEmpty(catalog_month_1)) {
                                    licenseInfo.setJanUpdated(Integer.valueOf(catalog_month_1));
                                }
                                if (!StringUtils.isEmpty(catalog_month_2)) {
                                    licenseInfo.setFebUpdated(Integer.valueOf(catalog_month_2));
                                }
                                if (!StringUtils.isEmpty(catalog_month_3)) {
                                    licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                                }
                                licenseRegisterList.add(licenseInfo);
                                flagProcessLicense = true;
                            }
                        }
                        break;
                    case 11:
                        catalog_month_11 = jsonObject.getString("catalog_month_11");
                        catalog_month_12 = jsonObject.getString("catalog_month_12");
                        if(!catalog_month_11.isEmpty() || !catalog_month_12.isEmpty()) {
                            if(!licenseInfos.isEmpty()){//update
                                for (LicenseInfo licenseInfo : licenseInfos) {
                                    if (!StringUtils.isEmpty(catalog_month_11)) {
                                        licenseInfo.setNovUpdated(Integer.valueOf(catalog_month_11));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_12)) {
                                        licenseInfo.setDecUpdated(Integer.valueOf(catalog_month_12));
                                    }
                                    licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                          Constants.DATE_FORMAT_UPDATE));
                                  licenseInfo.setStatus(0);
                                  licenseRegisterList.add(licenseInfo);
                                  flagProcessLicense = true;
                                }
                            } else {//insert
                                LicenseInfo licenseInfo = new LicenseInfo();
                                licenseInfo.setProjectId(project);
                                licenseInfo.setCatalogId(catalogInfor);
                                licenseInfo.setYear(currentYear);
                                licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                        Constants.DATE_FORMAT_UPDATE));
                                licenseInfo.setStatus(0);
                                if (!StringUtils.isEmpty(catalog_month_11)) {
                                    licenseInfo.setNovUpdated(Integer.valueOf(catalog_month_11));
                                }
                                if (!StringUtils.isEmpty(catalog_month_12)) {
                                    licenseInfo.setDecUpdated(Integer.valueOf(catalog_month_12));
                                }
                                licenseRegisterList.add(licenseInfo);
                                flagProcessLicense = true;
                            }
                        }
                        
                        catalog_month_1 = jsonObject.getString("catalog_month_1");
                        catalog_month_2 = jsonObject.getString("catalog_month_2");
                        catalog_month_3 = jsonObject.getString("catalog_month_3");
                        if(!catalog_month_1.isEmpty() || !catalog_month_2.isEmpty() || !catalog_month_3.isEmpty()){
                            if(!licenseInfosNY.isEmpty()){//update
                                for (LicenseInfo licenseInfo : licenseInfosNY) {
                                    if (!StringUtils.isEmpty(catalog_month_1)) {
                                        licenseInfo.setJanUpdated(Integer.valueOf(catalog_month_1));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_2)) {
                                        licenseInfo.setFebUpdated(Integer.valueOf(catalog_month_2));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_3)) {
                                        licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                                    }
                                    licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                          Constants.DATE_FORMAT_UPDATE));
                                  licenseInfo.setStatus(0);
                                  licenseRegisterList.add(licenseInfo);
                                  flagProcessLicense = true;
                                }
                            } else {//insert
                                LicenseInfo licenseInfo = new LicenseInfo();
                                licenseInfo.setProjectId(project);
                                licenseInfo.setCatalogId(catalogInfor);
                                licenseInfo.setYear(nextYear);
                                licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                        Constants.DATE_FORMAT_UPDATE));
                                licenseInfo.setStatus(0);
                                if (!StringUtils.isEmpty(catalog_month_1)) {
                                    licenseInfo.setJanUpdated(Integer.valueOf(catalog_month_1));
                                }
                                if (!StringUtils.isEmpty(catalog_month_2)) {
                                    licenseInfo.setFebUpdated(Integer.valueOf(catalog_month_2));
                                }
                                if (!StringUtils.isEmpty(catalog_month_3)) {
                                    licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                                }
                                licenseRegisterList.add(licenseInfo);
                                flagProcessLicense = true;
                            }
                        }
                        break;
                    case 12:
                        catalog_month_12 = jsonObject.getString("catalog_month_12");
                        if(!catalog_month_12.isEmpty()) {
                            if(!licenseInfos.isEmpty()){//update
                                for (LicenseInfo licenseInfo : licenseInfos) {
                                    if (!StringUtils.isEmpty(catalog_month_12)) {
                                        licenseInfo.setDecUpdated(Integer.valueOf(catalog_month_12));
                                    }
                                    licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                          Constants.DATE_FORMAT_UPDATE));
                                  licenseInfo.setStatus(0);
                                  licenseRegisterList.add(licenseInfo);
                                  flagProcessLicense = true;
                                }
                            } else {//insert
                                LicenseInfo licenseInfo = new LicenseInfo();
                                licenseInfo.setProjectId(project);
                                licenseInfo.setCatalogId(catalogInfor);
                                licenseInfo.setYear(currentYear);
                                licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                        Constants.DATE_FORMAT_UPDATE));
                                licenseInfo.setStatus(0);
                                if (!StringUtils.isEmpty(catalog_month_12)) {
                                    licenseInfo.setDecUpdated(Integer.valueOf(catalog_month_12));
                                }
                                licenseRegisterList.add(licenseInfo);
                                flagProcessLicense = true;
                            }
                        }
                        
                        catalog_month_1 = jsonObject.getString("catalog_month_1");
                        catalog_month_2 = jsonObject.getString("catalog_month_2");
                        catalog_month_3 = jsonObject.getString("catalog_month_3");
                        if(!catalog_month_1.isEmpty() || !catalog_month_2.isEmpty() || !catalog_month_3.isEmpty()){
                            if(!licenseInfosNY.isEmpty()){//update
                                for (LicenseInfo licenseInfo : licenseInfosNY) {
                                    if (!StringUtils.isEmpty(catalog_month_1)) {
                                        licenseInfo.setJanUpdated(Integer.valueOf(catalog_month_1));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_2)) {
                                        licenseInfo.setFebUpdated(Integer.valueOf(catalog_month_2));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_3)) {
                                        licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                                    }
                                    licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                          Constants.DATE_FORMAT_UPDATE));
                                  licenseInfo.setStatus(0);
                                  licenseRegisterList.add(licenseInfo);
                                  flagProcessLicense = true;
                                }
                            } else {//insert
                                LicenseInfo licenseInfo = new LicenseInfo();
                                licenseInfo.setProjectId(project);
                                licenseInfo.setCatalogId(catalogInfor);
                                licenseInfo.setYear(nextYear);
                                licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                        Constants.DATE_FORMAT_UPDATE));
                                licenseInfo.setStatus(0);
                                if (!StringUtils.isEmpty(catalog_month_1)) {
                                    licenseInfo.setJanUpdated(Integer.valueOf(catalog_month_1));
                                }
                                if (!StringUtils.isEmpty(catalog_month_2)) {
                                    licenseInfo.setFebUpdated(Integer.valueOf(catalog_month_2));
                                }
                                if (!StringUtils.isEmpty(catalog_month_3)) {
                                    licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                                }
                                licenseRegisterList.add(licenseInfo);
                                flagProcessLicense = true;
                            }
                        }
                        break;
                    case 1:
                        catalog_month_1 = jsonObject.getString("catalog_month_1");
                        catalog_month_2 = jsonObject.getString("catalog_month_2");
                        catalog_month_3 = jsonObject.getString("catalog_month_3");
                            if(!licenseInfos.isEmpty()){//update
                                for (LicenseInfo licenseInfo : licenseInfos) {
                                    if (!StringUtils.isEmpty(catalog_month_1)) {
                                        licenseInfo.setJanUpdated(Integer.valueOf(catalog_month_1));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_2)) {
                                        licenseInfo.setFebUpdated(Integer.valueOf(catalog_month_2));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_3)) {
                                        licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                                    }

                                    licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                          Constants.DATE_FORMAT_UPDATE));
                                  licenseInfo.setStatus(0);
                                  licenseRegisterList.add(licenseInfo);
                                  flagProcessLicense = true;
                                }
                            } else {//insert
                                LicenseInfo licenseInfo = new LicenseInfo();
                                licenseInfo.setProjectId(project);
                                licenseInfo.setCatalogId(catalogInfor);
                                licenseInfo.setYear(currentYear);
                                licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                        Constants.DATE_FORMAT_UPDATE));
                                licenseInfo.setStatus(0);
                                if (!StringUtils.isEmpty(catalog_month_1)) {
                                    licenseInfo.setJanUpdated(Integer.valueOf(catalog_month_1));
                                }
                                if (!StringUtils.isEmpty(catalog_month_2)) {
                                    licenseInfo.setFebUpdated(Integer.valueOf(catalog_month_2));
                                }
                                if (!StringUtils.isEmpty(catalog_month_3)) {
                                    licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                                }
                                licenseRegisterList.add(licenseInfo);
                                flagProcessLicense = true;
                            }
                        break;
                    case 2:
                        catalog_month_2 = jsonObject.getString("catalog_month_2");
                        catalog_month_3 = jsonObject.getString("catalog_month_3");
                            if(!licenseInfos.isEmpty()){//update
                                for (LicenseInfo licenseInfo : licenseInfos) {
                                    if (!StringUtils.isEmpty(catalog_month_2)) {
                                        licenseInfo.setFebUpdated(Integer.valueOf(catalog_month_2));
                                    }
                                    if (!StringUtils.isEmpty(catalog_month_3)) {
                                        licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                                    }
                                    licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                          Constants.DATE_FORMAT_UPDATE));
                                  licenseInfo.setStatus(0);
                                  licenseRegisterList.add(licenseInfo);
                                  flagProcessLicense = true;
                                }
                            } else {//insert
                                LicenseInfo licenseInfo = new LicenseInfo();
                                licenseInfo.setProjectId(project);
                                licenseInfo.setCatalogId(catalogInfor);
                                licenseInfo.setYear(currentYear);
                                licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                        Constants.DATE_FORMAT_UPDATE));
                                licenseInfo.setStatus(0);
                                if (!StringUtils.isEmpty(catalog_month_2)) {
                                    licenseInfo.setFebUpdated(Integer.valueOf(catalog_month_2));
                                }
                                if (!StringUtils.isEmpty(catalog_month_3)) {
                                    licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                                }
                                licenseRegisterList.add(licenseInfo);
                                flagProcessLicense = true;
                            }
                        break;
                    case 3:
                        if(!licenseInfos.isEmpty()){//update
                            for (LicenseInfo licenseInfo : licenseInfos) {
                                catalog_month_3 = jsonObject.getString("catalog_month_3");
                                if (!StringUtils.isEmpty(catalog_month_3)) {
                                    licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                                }
                                catalog_month_4 = jsonObject.getString("catalog_month_4");
                                if (!StringUtils.isEmpty(catalog_month_4)) {
                                    licenseInfo.setAprUpdated(Integer.valueOf(catalog_month_4));
                                }
                                catalog_month_5 = jsonObject.getString("catalog_month_5");
                                if (!StringUtils.isEmpty(catalog_month_5)) {
                                    licenseInfo.setMayUpdated(Integer.valueOf(catalog_month_5));
                                }
                                catalog_month_6 = jsonObject.getString("catalog_month_6");
                                if (!StringUtils.isEmpty(catalog_month_6)) {
                                    licenseInfo.setJunUpdated(Integer.valueOf(catalog_month_6));
                                }
                                catalog_month_7 = jsonObject.getString("catalog_month_7");
                                if (!StringUtils.isEmpty(catalog_month_7)) {
                                    licenseInfo.setJulUpdated(Integer.valueOf(catalog_month_7));
                                }
                                catalog_month_8 = jsonObject.getString("catalog_month_8");
                                if (!StringUtils.isEmpty(catalog_month_8)) {
                                    licenseInfo.setAugUpdated(Integer.valueOf(catalog_month_8));
                                }
                                catalog_month_9 = jsonObject.getString("catalog_month_9");
                                if (!StringUtils.isEmpty(catalog_month_9)) {
                                    licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                                }
                                licenseInfo.setDateUpdated(DateUtils.convertDateToString(new Date(),
                                      Constants.DATE_FORMAT_UPDATE));
                              licenseInfo.setStatus(0);
                              licenseRegisterList.add(licenseInfo);
                              flagProcessLicense = true;
                            }
                        } else {//insert
                            LicenseInfo licenseInfo = new LicenseInfo();
                            licenseInfo.setProjectId(project);
                            licenseInfo.setCatalogId(catalogInfor);
                            licenseInfo.setYear(currentYear);
                            licenseInfo.setDateCreated(DateUtils.convertDateToString(new Date(),
                                    Constants.DATE_FORMAT_UPDATE));
                            licenseInfo.setStatus(0);
                            catalog_month_3 = jsonObject.getString("catalog_month_3");
                            if (!StringUtils.isEmpty(catalog_month_3)) {
                                licenseInfo.setMarUpdated(Integer.valueOf(catalog_month_3));
                            }
                            catalog_month_4 = jsonObject.getString("catalog_month_4");
                            if (!StringUtils.isEmpty(catalog_month_4)) {
                                licenseInfo.setAprUpdated(Integer.valueOf(catalog_month_4));
                            }
                            catalog_month_5 = jsonObject.getString("catalog_month_5");
                            if (!StringUtils.isEmpty(catalog_month_5)) {
                                licenseInfo.setMayUpdated(Integer.valueOf(catalog_month_5));
                            }
                            catalog_month_6 = jsonObject.getString("catalog_month_6");
                            if (!StringUtils.isEmpty(catalog_month_6)) {
                                licenseInfo.setJunUpdated(Integer.valueOf(catalog_month_6));
                            }
                            catalog_month_7 = jsonObject.getString("catalog_month_7");
                            if (!StringUtils.isEmpty(catalog_month_7)) {
                                licenseInfo.setJulUpdated(Integer.valueOf(catalog_month_7));
                            }
                            catalog_month_8 = jsonObject.getString("catalog_month_8");
                            if (!StringUtils.isEmpty(catalog_month_8)) {
                                licenseInfo.setAugUpdated(Integer.valueOf(catalog_month_8));
                            }
                            catalog_month_9 = jsonObject.getString("catalog_month_9");
                            if (!StringUtils.isEmpty(catalog_month_9)) {
                                licenseInfo.setSepUpdated(Integer.valueOf(catalog_month_9));
                            }
                            licenseRegisterList.add(licenseInfo);
                            flagProcessLicense = true;
                        }
                        break;
                    }
                }
            }
        }
        boolean flagProcessIPAdd = false;
        boolean flagIpDel = false;
        boolean flagIpInsert = false;
        List<IpAddressInfo> ipApproveList = null;
        if (ipAddList != null) {
            Object ipObjectList = ipAddList[0];
            ipObjectList.toString();
            String strIpAdd = ipObjectList.toString();
            JSONArray newIpJArray = new JSONArray(strIpAdd);
            ArrayList<JSONObject> ipArr = new ArrayList<JSONObject>();
            for (int i = 0; i < newIpJArray.length(); i++) {
                ipArr.add(newIpJArray.getJSONObject(i));
            }
            JSONObject[] ipJson = new JSONObject[ipArr.size()];
            ipArr.toArray(ipJson);

            int lenghIp = ipArr.size();
            if (lenghIp > 0) {
                String errMsgDel = StringUtils.EMPTY;
                String errMsgInsert = StringUtils.EMPTY;
                ipDeleteList = new ArrayList<>();
                ipInsertList = new ArrayList<>();
                for (int i = 0; i < lenghIp; i++) {
                    if ("1".equals(ipArr.get(i).getString("checkDel"))) {// add ipAdd of List insert or delete
                        ipDeleteList.add(ipArr.get(i).getString("ipAdd"));
                    } else {
                        ipInsertList.add(ipArr.get(i).getString("ipAdd"));
                    }
                }
                List<IpAddressInfo> ipAdDBList = licenseBusiness.listAllIpAddressByProjectId(projectId);// get List IP Address of project id

                ipApproveList = licenseBusiness.listIpAddressByStatus(projectId, Constants.APPROVED_STATUS);// get List IP Address was approved of project id

                if (ipDeleteList != null && ipDeleteList.size() > 0) {// validate exits ip address delete or insert
                    if (ipApproveList != null && ipApproveList.size() > 0) {
                        errMsgDel = this.isIPDeleteExists(ipDeleteList, ipApproveList);
                    } else {
                        errMsgDel += "IP Address delete not exits in DB";
                    }
                }
                if (ipInsertList != null && ipInsertList.size() > 0) {
                    if (ipAdDBList != null && ipAdDBList.size() > 0) {
                        errMsgInsert = this.isIPInsertNotExists(ipInsertList, ipAdDBList);
                    }
                }
                errMsg += errMsgDel + errMsgInsert;// append errMsgDel & errMsgInsert
                if (!errMsg.equals(StringUtils.EMPTY)) {
                    return SUCCESS;
                } else {
                    if (ipDeleteList != null && ipDeleteList.size() > 0) {
                        flagIpDel = true;
                    }
                }
                if (ipInsertList != null && ipInsertList.size() > 0) {
                    flagIpInsert = true;
                }
                if (flagIpDel || flagIpInsert) {
                    flagProcessIPAdd = true;
                }
            }
        }
        // start sending mail
        if (flagProcessLicense || flagProcessIPAdd) {
            if (flagProcessLicense) {
                for (LicenseInfo li: licenseRegisterList) {
                    licenseBusiness.insertOrUpdateLicense(li, projectId);
                }
            }
            if (flagProcessIPAdd) {
                if (ipDeleteList != null && ipDeleteList.size() > 0) {
                    this.deleteIPAddress(ipDeleteList, ipApproveList);// delete IP address in DB
                }
            }
            if (ipInsertList != null && ipInsertList.size() > 0) {
                this.insertIPAddress(ipInsertList, projectId);// Insert IP Address to DB
            }
            int isManager = Constants.MANAGER_TRUE;
            project.setComment(comment);
            project.setApprover(null);
            project.setDateApproved(null);
            Member member = memberBusiness.checkExistEmailMember(userInfo.getEmailAddress());
            if (member != null) {
                project.setUpdate(member.getSeqNo());
            }
            project = projectBusiness.updateProject(project, isManager);
            try {
                String mailUserLogin = userInfo.getEmailAddress();
                String mailManager = project.getManagerEmail();
                String ccMail = memberBusiness.getAllMailManager(projectId, mailUserLogin, mailManager);
                String toMail = supporterBusiness.getMailList();

                boolean flagSendMail = EmailUtil.sendEmail(Constants.REGISTER_LICENSE_SUBJECT,
                        Constants.HEADER_TEMPLATE_REGISTER_LICENSE, Constants.FOOTER_TEMPLATE_REGISTER_LICENSE,
                        Constants.CONTENT_TEMPLATE_REGISTER_LICENSE, toMail, ccMail, userInfo.getUserName(),
                        userInfo.getUserBelongDepartmentName(), null, null, null, null, null, null, null);

                if (flagSendMail) {
                    warningMsg = PropertiesUtil.getMessageProperties("isv.email.send.success");
                }
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        // end sending mail
        return SUCCESS;
    }

    /**
     * processLicenseFormBean
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    public List<LicenseFormBean> processLicenseFormBean(int seqNoProject, List<CatalogInfor> listCatalogInfor) {
        LocalDate now = LocalDate.now();
        int monthNow = now.getMonthValue();
        int yearNow = now.getYear();
        int nextYear = yearNow + 1;
        int preYear = yearNow - 1;
        Project project = projectBusiness.findProjectBySeqNo(seqNoProject);
        if (project == null) {// Project not found -> return null
            return null;
        }
        List<LicenseFormBean> listBean = new ArrayList<>();
        List<LicenseInfo> listLicenseInfo = null;
        LicenseFormBean formBean;
        LicenseFormBean bean;
        LicenseInfo licInfo;
        CatalogInfor catalogInfoToAdd;
        List<Integer> listMonth = new ArrayList<Integer>();
        listMonth.add(1);
        listMonth.add(2);
        listMonth.add(3);
        for (int i = 0; i < listCatalogInfor.size(); i++) {
            catalogInfoToAdd = listCatalogInfor.get(i);
            listLicenseInfo = licenseBusiness.listLicenseInfo(catalogInfoToAdd.getSeqNo(),
                    seqNoProject, monthNow, yearNow);// get list licenseInfo by projectId,CatalogId,Month,Year.
            if (listLicenseInfo.isEmpty()) {
                formBean = new LicenseFormBean(catalogInfoToAdd);// Create new bean with default value
                formBean.setMonth(monthNow);
                formBean.setNextYear(nextYear);
                formBean.setPreYear(preYear);
                formBean.setStatus(2);
                listBean.add(formBean);
                continue;
            }
            bean = new LicenseFormBean(catalogInfoToAdd);
            for (int j = 0; j < listLicenseInfo.size(); j++) {
                licInfo = listLicenseInfo.get(j);
                bean.setMonth(monthNow);
                bean.setNextYear(nextYear);
                bean.setPreYear(preYear);
                bean.setStatus(licInfo.getStatus());
                bean.setDateRegistation(licInfo.getDateCreated());
                bean.setDateUpdate(licInfo.getDateUpdated());

                if(!listMonth.contains(monthNow) && listLicenseInfo.size() == 2){
                    if(licInfo.getYear() == yearNow){
                        if(bean.getStatus() == 0){// set value to show new data.
                            bean.setValueColumnLisence1((licInfo.getAprUpdated() == null ? Integer.valueOf(0) : licInfo.getAprUpdated()));
                            bean.setValueColumnLisence2((licInfo.getMayUpdated() == null ? Integer.valueOf(0) : licInfo.getMayUpdated()));
                            bean.setValueColumnLisence3((licInfo.getJunUpdated() == null ? Integer.valueOf(0) : licInfo.getJunUpdated()));
                            bean.setValueColumnLisence4((licInfo.getJulUpdated() == null ? Integer.valueOf(0) : licInfo.getJulUpdated()));
                            bean.setValueColumnLisence5((licInfo.getAugUpdated() == null ? Integer.valueOf(0) : licInfo.getAugUpdated()));
                            bean.setValueColumnLisence6((licInfo.getSepUpdated() == null ? Integer.valueOf(0) : licInfo.getSepUpdated()));
                            bean.setValueColumnLisence7((licInfo.getOctUpdated() == null ? Integer.valueOf(0) : licInfo.getOctUpdated()));
                            bean.setValueColumnLisence8((licInfo.getNovUpdated() == null ? Integer.valueOf(0) : licInfo.getNovUpdated()));
                            bean.setValueColumnLisence9((licInfo.getDecUpdated() == null ? Integer.valueOf(0) : licInfo.getDecUpdated()));
                            
                            //set old-value to show detail license, just status = 0 then set.
                            bean.setValueColumnLisence01((licInfo.getApr() == 0 ? Integer.valueOf(0) : licInfo.getApr()));
                            bean.setValueColumnLisence02((licInfo.getMay() == 0 ? Integer.valueOf(0) : licInfo.getMay()));
                            bean.setValueColumnLisence03((licInfo.getJun() == 0 ? Integer.valueOf(0) : licInfo.getJun()));
                            bean.setValueColumnLisence04((licInfo.getJul() == 0 ? Integer.valueOf(0) : licInfo.getJul()));
                            bean.setValueColumnLisence05((licInfo.getAug() == 0 ? Integer.valueOf(0) : licInfo.getAug()));
                            bean.setValueColumnLisence06((licInfo.getSep() == 0 ? Integer.valueOf(0) : licInfo.getSep()));
                            bean.setValueColumnLisence07((licInfo.getOct() == 0 ? Integer.valueOf(0) : licInfo.getOct()));
                            bean.setValueColumnLisence08((licInfo.getNov() == 0 ? Integer.valueOf(0) : licInfo.getNov()));
                            bean.setValueColumnLisence09((licInfo.getDec() == 0 ? Integer.valueOf(0) : licInfo.getDec()));
                            continue;
                        } else {// set value to show old data.
                            bean.setValueColumnLisence01((licInfo.getApr() == 0 ? Integer.valueOf(0) : licInfo.getApr()));
                            bean.setValueColumnLisence02((licInfo.getMay() == 0 ? Integer.valueOf(0) : licInfo.getMay()));
                            bean.setValueColumnLisence03((licInfo.getJun() == 0 ? Integer.valueOf(0) : licInfo.getJun()));
                            bean.setValueColumnLisence04((licInfo.getJul() == 0 ? Integer.valueOf(0) : licInfo.getJul()));
                            bean.setValueColumnLisence05((licInfo.getAug() == 0 ? Integer.valueOf(0) : licInfo.getAug()));
                            bean.setValueColumnLisence06((licInfo.getSep() == 0 ? Integer.valueOf(0) : licInfo.getSep()));
                            bean.setValueColumnLisence07((licInfo.getOct() == 0 ? Integer.valueOf(0) : licInfo.getOct()));
                            bean.setValueColumnLisence08((licInfo.getNov() == 0 ? Integer.valueOf(0) : licInfo.getNov()));
                            bean.setValueColumnLisence09((licInfo.getDec() == 0 ? Integer.valueOf(0) : licInfo.getDec()));
                            continue;
                        }
                      } else if(licInfo.getYear() == yearNow + 1) {
                          if(bean.getStatus() == 0){// set value to show new data.
                              bean.setValueColumnLisence10((licInfo.getJanUpdated() == null ? Integer.valueOf(0) : licInfo.getJanUpdated()));
                              bean.setValueColumnLisence11((licInfo.getFebUpdated() == null ? Integer.valueOf(0) : licInfo.getFebUpdated()));
                              bean.setValueColumnLisence12((licInfo.getMarUpdated() == null ? Integer.valueOf(0) : licInfo.getMarUpdated()));
                              
                              //set old-value to show detail license, just status = 0 then set.
                              bean.setValueColumnLisence010((licInfo.getJan() == 0 ? Integer.valueOf(0) : licInfo.getJan()));
                              bean.setValueColumnLisence011((licInfo.getFeb() == 0 ? Integer.valueOf(0) : licInfo.getFeb()));
                              bean.setValueColumnLisence012((licInfo.getMar() == 0 ? Integer.valueOf(0) : licInfo.getMar()));
                          } else {// set value to show old data.
                              bean.setValueColumnLisence010((licInfo.getJan() == 0 ? Integer.valueOf(0) : licInfo.getJan()));
                              bean.setValueColumnLisence011((licInfo.getFeb() == 0 ? Integer.valueOf(0) : licInfo.getFeb()));
                              bean.setValueColumnLisence012((licInfo.getMar() == 0 ? Integer.valueOf(0) : licInfo.getMar()));
                          }
                      }
                      listBean.add(bean);
                      break;
                } else if(!listMonth.contains(monthNow)){
                    if(licInfo.getYear() == yearNow){
                        if(bean.getStatus() == 0){// set value to show new data.
                            bean.setValueColumnLisence1((licInfo.getAprUpdated() == null ? Integer.valueOf(0) : licInfo.getAprUpdated()));
                            bean.setValueColumnLisence2((licInfo.getMayUpdated() == null ? Integer.valueOf(0) : licInfo.getMayUpdated()));
                            bean.setValueColumnLisence3((licInfo.getJunUpdated() == null ? Integer.valueOf(0) : licInfo.getJunUpdated()));
                            bean.setValueColumnLisence4((licInfo.getJulUpdated() == null ? Integer.valueOf(0) : licInfo.getJulUpdated()));
                            bean.setValueColumnLisence5((licInfo.getAugUpdated() == null ? Integer.valueOf(0) : licInfo.getAugUpdated()));
                            bean.setValueColumnLisence6((licInfo.getSepUpdated() == null ? Integer.valueOf(0) : licInfo.getSepUpdated()));
                            bean.setValueColumnLisence7((licInfo.getOctUpdated() == null ? Integer.valueOf(0) : licInfo.getOctUpdated()));
                            bean.setValueColumnLisence8((licInfo.getNovUpdated() == null ? Integer.valueOf(0) : licInfo.getNovUpdated()));
                            bean.setValueColumnLisence9((licInfo.getDecUpdated() == null ? Integer.valueOf(0) : licInfo.getDecUpdated()));
                            
                            //set old-value to show detail license, just status = 0 then set.
                            bean.setValueColumnLisence01((licInfo.getApr() == 0 ? Integer.valueOf(0) : licInfo.getApr()));
                            bean.setValueColumnLisence02((licInfo.getMay() == 0 ? Integer.valueOf(0) : licInfo.getMay()));
                            bean.setValueColumnLisence03((licInfo.getJun() == 0 ? Integer.valueOf(0) : licInfo.getJun()));
                            bean.setValueColumnLisence04((licInfo.getJul() == 0 ? Integer.valueOf(0) : licInfo.getJul()));
                            bean.setValueColumnLisence05((licInfo.getAug() == 0 ? Integer.valueOf(0) : licInfo.getAug()));
                            bean.setValueColumnLisence06((licInfo.getSep() == 0 ? Integer.valueOf(0) : licInfo.getSep()));
                            bean.setValueColumnLisence07((licInfo.getOct() == 0 ? Integer.valueOf(0) : licInfo.getOct()));
                            bean.setValueColumnLisence08((licInfo.getNov() == 0 ? Integer.valueOf(0) : licInfo.getNov()));
                            bean.setValueColumnLisence09((licInfo.getDec() == 0 ? Integer.valueOf(0) : licInfo.getDec()));
                        } else {// set value to show old data.
                            bean.setValueColumnLisence01((licInfo.getApr() == 0 ? Integer.valueOf(0) : licInfo.getApr()));
                            bean.setValueColumnLisence02((licInfo.getMay() == 0 ? Integer.valueOf(0) : licInfo.getMay()));
                            bean.setValueColumnLisence03((licInfo.getJun() == 0 ? Integer.valueOf(0) : licInfo.getJun()));
                            bean.setValueColumnLisence04((licInfo.getJul() == 0 ? Integer.valueOf(0) : licInfo.getJul()));
                            bean.setValueColumnLisence05((licInfo.getAug() == 0 ? Integer.valueOf(0) : licInfo.getAug()));
                            bean.setValueColumnLisence06((licInfo.getSep() == 0 ? Integer.valueOf(0) : licInfo.getSep()));
                            bean.setValueColumnLisence07((licInfo.getOct() == 0 ? Integer.valueOf(0) : licInfo.getOct()));
                            bean.setValueColumnLisence08((licInfo.getNov() == 0 ? Integer.valueOf(0) : licInfo.getNov()));
                            bean.setValueColumnLisence09((licInfo.getDec() == 0 ? Integer.valueOf(0) : licInfo.getDec()));
                        }
                      } else if(licInfo.getYear() == yearNow + 1) {
                          if(bean.getStatus() == 0){// set value to show new data.
                                  bean.setValueColumnLisence10((licInfo.getJanUpdated() == null ? Integer.valueOf(0) : licInfo.getJanUpdated()));
                                  bean.setValueColumnLisence11((licInfo.getFebUpdated() == null ? Integer.valueOf(0) : licInfo.getFebUpdated()));
                                  bean.setValueColumnLisence12((licInfo.getMarUpdated() == null ? Integer.valueOf(0) : licInfo.getMarUpdated()));
                                  
                                  //set old-value to show detail license, just status = 0 then set.
                                  bean.setValueColumnLisence010((licInfo.getJan() == 0 ? Integer.valueOf(0) : licInfo.getJan()));
                                  bean.setValueColumnLisence011((licInfo.getFeb() == 0 ? Integer.valueOf(0) : licInfo.getFeb()));
                                  bean.setValueColumnLisence012((licInfo.getMar() == 0 ? Integer.valueOf(0) : licInfo.getMar()));
                              } else {// set value to show old data.
                                  bean.setValueColumnLisence010((licInfo.getJan() == 0 ? Integer.valueOf(0) : licInfo.getJan()));
                                  bean.setValueColumnLisence011((licInfo.getFeb() == 0 ? Integer.valueOf(0) : licInfo.getFeb()));
                                  bean.setValueColumnLisence012((licInfo.getMar() == 0 ? Integer.valueOf(0) : licInfo.getMar()));
                              }
                      }
                      listBean.add(bean);
                      break;
                } else {
                    if(monthNow == 3){
                        if(bean.getYear() == preYear){
                            if(bean.getStatus() == 0){// set value to show new data.
                                bean.setValueColumnLisence7((licInfo.getOctUpdated() == null ? Integer.valueOf(0) : licInfo.getOctUpdated()));
                                bean.setValueColumnLisence8((licInfo.getNovUpdated() == null ? Integer.valueOf(0) : licInfo.getNovUpdated()));
                                bean.setValueColumnLisence9((licInfo.getDecUpdated() == null ? Integer.valueOf(0) : licInfo.getDecUpdated()));
                                
                                //set old-value to show detail license, just status = 0 then set.
                                bean.setValueColumnLisence07((licInfo.getOct() == 0 ? Integer.valueOf(0) : licInfo.getOct()));
                                bean.setValueColumnLisence08((licInfo.getNov() == 0 ? Integer.valueOf(0) : licInfo.getNov()));
                                bean.setValueColumnLisence09((licInfo.getDec() == 0 ? Integer.valueOf(0) : licInfo.getDec()));
                            } else {// set value to show old data.
                                bean.setValueColumnLisence07((licInfo.getOct() == 0 ? Integer.valueOf(0) : licInfo.getOct()));
                                bean.setValueColumnLisence08((licInfo.getNov() == 0 ? Integer.valueOf(0) : licInfo.getNov()));
                                bean.setValueColumnLisence09((licInfo.getDec() == 0 ? Integer.valueOf(0) : licInfo.getDec()));
                            }
                        } else if(bean.getYear() == yearNow){
                            if(bean.getStatus() == 0){// set value to show new data.
                                bean.setValueColumnLisence10((licInfo.getJanUpdated() == null ? Integer.valueOf(0) : licInfo.getJanUpdated()));
                                bean.setValueColumnLisence11((licInfo.getFebUpdated() == null ? Integer.valueOf(0) : licInfo.getFebUpdated()));
                                bean.setValueColumnLisence12((licInfo.getMarUpdated() == null ? Integer.valueOf(0) : licInfo.getMarUpdated()));
                                bean.setValueColumnLisence1((licInfo.getAprUpdated() == null ? Integer.valueOf(0) : licInfo.getAprUpdated()));
                                bean.setValueColumnLisence2((licInfo.getMayUpdated() == null ? Integer.valueOf(0) : licInfo.getMayUpdated()));
                                bean.setValueColumnLisence3((licInfo.getJunUpdated() == null ? Integer.valueOf(0) : licInfo.getJunUpdated()));
                                bean.setValueColumnLisence4((licInfo.getJulUpdated() == null ? Integer.valueOf(0) : licInfo.getJulUpdated()));
                                bean.setValueColumnLisence5((licInfo.getAugUpdated() == null ? Integer.valueOf(0) : licInfo.getAugUpdated()));
                                bean.setValueColumnLisence6((licInfo.getSepUpdated() == null ? Integer.valueOf(0) : licInfo.getSepUpdated()));
                                
                                //set old-value to show detail license, just status = 0 then set.
                                bean.setValueColumnLisence010((licInfo.getJan() == 0 ? Integer.valueOf(0) : licInfo.getJan()));
                                bean.setValueColumnLisence011((licInfo.getFeb() == 0 ? Integer.valueOf(0) : licInfo.getFeb()));
                                bean.setValueColumnLisence012((licInfo.getMar() == 0 ? Integer.valueOf(0) : licInfo.getMar()));
                                bean.setValueColumnLisence01((licInfo.getApr() == 0 ? Integer.valueOf(0) : licInfo.getApr()));
                                bean.setValueColumnLisence02((licInfo.getMay() == 0 ? Integer.valueOf(0) : licInfo.getMay()));
                                bean.setValueColumnLisence03((licInfo.getJun() == 0 ? Integer.valueOf(0) : licInfo.getJun()));
                                bean.setValueColumnLisence04((licInfo.getJul() == 0 ? Integer.valueOf(0) : licInfo.getJul()));
                                bean.setValueColumnLisence05((licInfo.getAug() == 0 ? Integer.valueOf(0) : licInfo.getAug()));
                                bean.setValueColumnLisence06((licInfo.getSep() == 0 ? Integer.valueOf(0) : licInfo.getSep()));
                            } else {// set value to show old data.
                                bean.setValueColumnLisence010((licInfo.getJan() == 0 ? Integer.valueOf(0) : licInfo.getJan()));
                                bean.setValueColumnLisence011((licInfo.getFeb() == 0 ? Integer.valueOf(0) : licInfo.getFeb()));
                                bean.setValueColumnLisence012((licInfo.getMar() == 0 ? Integer.valueOf(0) : licInfo.getMar()));
                                bean.setValueColumnLisence01((licInfo.getApr() == 0 ? Integer.valueOf(0) : licInfo.getApr()));
                                bean.setValueColumnLisence02((licInfo.getMay() == 0 ? Integer.valueOf(0) : licInfo.getMay()));
                                bean.setValueColumnLisence03((licInfo.getJun() == 0 ? Integer.valueOf(0) : licInfo.getJun()));
                                bean.setValueColumnLisence04((licInfo.getJul() == 0 ? Integer.valueOf(0) : licInfo.getJul()));
                                bean.setValueColumnLisence05((licInfo.getAug() == 0 ? Integer.valueOf(0) : licInfo.getAug()));
                                bean.setValueColumnLisence06((licInfo.getSep() == 0 ? Integer.valueOf(0) : licInfo.getSep()));
                            }
                        }
                        listBean.add(bean);
                        break;
                    }
                     if(monthNow == 1 || monthNow == 2){
                        if(licInfo.getYear() == preYear){
                            if(bean.getStatus() == 0){// set value to show new data.
                                bean.setValueColumnLisence1((licInfo.getAprUpdated() == null ? Integer.valueOf(0) : licInfo.getAprUpdated()));
                                bean.setValueColumnLisence2((licInfo.getMayUpdated() == null ? Integer.valueOf(0) : licInfo.getMayUpdated()));
                                bean.setValueColumnLisence3((licInfo.getJunUpdated() == null ? Integer.valueOf(0) : licInfo.getJunUpdated()));
                                bean.setValueColumnLisence4((licInfo.getJulUpdated() == null ? Integer.valueOf(0) : licInfo.getJulUpdated()));
                                bean.setValueColumnLisence5((licInfo.getAugUpdated() == null ? Integer.valueOf(0) : licInfo.getAugUpdated()));
                                bean.setValueColumnLisence6((licInfo.getSepUpdated() == null ? Integer.valueOf(0) : licInfo.getSepUpdated()));
                                bean.setValueColumnLisence7((licInfo.getOctUpdated() == null ? Integer.valueOf(0) : licInfo.getOctUpdated()));
                                bean.setValueColumnLisence8((licInfo.getNovUpdated() == null ? Integer.valueOf(0) : licInfo.getNovUpdated()));
                                bean.setValueColumnLisence9((licInfo.getDecUpdated() == null ? Integer.valueOf(0) : licInfo.getDecUpdated()));
                                
                                //set old-value to show detail license, just status = 0 then set.
                                bean.setValueColumnLisence01((licInfo.getApr() == 0 ? Integer.valueOf(0) : licInfo.getApr()));
                                bean.setValueColumnLisence02((licInfo.getMay() == 0 ? Integer.valueOf(0) : licInfo.getMay()));
                                bean.setValueColumnLisence03((licInfo.getJun() == 0 ? Integer.valueOf(0) : licInfo.getJun()));
                                bean.setValueColumnLisence04((licInfo.getJul() == 0 ? Integer.valueOf(0) : licInfo.getJul()));
                                bean.setValueColumnLisence05((licInfo.getAug() == 0 ? Integer.valueOf(0) : licInfo.getAug()));
                                bean.setValueColumnLisence06((licInfo.getSep() == 0 ? Integer.valueOf(0) : licInfo.getSep()));
                                bean.setValueColumnLisence07((licInfo.getOct() == 0 ? Integer.valueOf(0) : licInfo.getOct()));
                                bean.setValueColumnLisence08((licInfo.getNov() == 0 ? Integer.valueOf(0) : licInfo.getNov()));
                                bean.setValueColumnLisence09((licInfo.getDec() == 0 ? Integer.valueOf(0) : licInfo.getDec()));
                            } else {// set value to show old data.
                                bean.setValueColumnLisence01((licInfo.getApr() == 0 ? Integer.valueOf(0) : licInfo.getApr()));
                                bean.setValueColumnLisence02((licInfo.getMay() == 0 ? Integer.valueOf(0) : licInfo.getMay()));
                                bean.setValueColumnLisence03((licInfo.getJun() == 0 ? Integer.valueOf(0) : licInfo.getJun()));
                                bean.setValueColumnLisence04((licInfo.getJul() == 0 ? Integer.valueOf(0) : licInfo.getJul()));
                                bean.setValueColumnLisence05((licInfo.getAug() == 0 ? Integer.valueOf(0) : licInfo.getAug()));
                                bean.setValueColumnLisence06((licInfo.getSep() == 0 ? Integer.valueOf(0) : licInfo.getSep()));
                                bean.setValueColumnLisence07((licInfo.getOct() == 0 ? Integer.valueOf(0) : licInfo.getOct()));
                                bean.setValueColumnLisence08((licInfo.getNov() == 0 ? Integer.valueOf(0) : licInfo.getNov()));
                                bean.setValueColumnLisence09((licInfo.getDec() == 0 ? Integer.valueOf(0) : licInfo.getDec()));
                            }
                          } else if(licInfo.getYear() == yearNow) {
                              if(bean.getStatus() == 0){// set value to show new data.
                                  bean.setValueColumnLisence10((licInfo.getJanUpdated() == null ? Integer.valueOf(0) : licInfo.getJanUpdated()));
                                  bean.setValueColumnLisence11((licInfo.getFebUpdated() == null ? Integer.valueOf(0) : licInfo.getFebUpdated()));
                                  bean.setValueColumnLisence12((licInfo.getMarUpdated() == null ? Integer.valueOf(0) : licInfo.getMarUpdated()));
                                  
                                  //set old-value to show detail license, just status = 0 then set.
                                  bean.setValueColumnLisence010((licInfo.getJan() == 0 ? Integer.valueOf(0) : licInfo.getJan()));
                                  bean.setValueColumnLisence011((licInfo.getFeb() == 0 ? Integer.valueOf(0) : licInfo.getFeb()));
                                  bean.setValueColumnLisence012((licInfo.getMar() == 0 ? Integer.valueOf(0) : licInfo.getMar()));
                              } else {// set value to show old data.
                                  bean.setValueColumnLisence010((licInfo.getJan() == 0 ? Integer.valueOf(0) : licInfo.getJan()));
                                  bean.setValueColumnLisence011((licInfo.getFeb() == 0 ? Integer.valueOf(0) : licInfo.getFeb()));
                                  bean.setValueColumnLisence012((licInfo.getMar() == 0 ? Integer.valueOf(0) : licInfo.getMar()));
                          }
                       }
                        listBean.add(bean);
                        break;
                    }
                }
            }
        }
        return listBean;
    }
    
    /**
     * showLicenseInfor
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    public List<LicenseFormBean> showLicenseInfor(int seqNoProject) {
        List<CatalogInfor> listCatalogInfor = licenseBusiness.listAllCatalogInfo();
        if (listCatalogInfor != null) {
            listLicenseFormBean = processLicenseFormBean(seqNoProject, listCatalogInfor);
        } else {
            exceptionMsg = ErrorCodes.ERRORS_CODE_CATALOG_NOT_EXIST;
            request.setAttribute(exceptionMsg, exceptionMsg);
        }
        return listLicenseFormBean;
    }
    
    /**
     * insertIPAddress
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    private void insertIPAddress(List<String> ipInsertList, int projectId) {
      Project project = projectBusiness.findProjectBySeqNo(projectId);
      for (String ipInsert : ipInsertList) {
          IpAddressInfo info = licenseBusiness.findIpAddressInfoByIP(projectId, ipInsert);
          if (info != null) {
              info.setDateUpdated(DateUtils.convertDateToString(new Date(), Constants.DATE_FORMAT_UPDATE));
              info.setStatus(Constants.UN_APPROVED_STATUS);
        } else {
          info = new IpAddressInfo();
          info.setProjectId(project);
          info.setIpaddress(ipInsert);
          info.setDateUpdated(DateUtils.convertDateToString(new Date(), Constants.DATE_FORMAT_UPDATE));
          info.setStatus(Constants.UN_APPROVED_STATUS);
          List<String> ipInsertSplit = splitIPAddressList(ipInsert);// split IP Address input
          info.setIpaddressOne(ipInsertSplit.get(0));
          String ipInsertTwo = ipInsertSplit.get(1);
          if (ipInsertTwo.equals(Constants.COLON_STAR)) {
              StringBuilder ipInputTwo = new StringBuilder();
              for (int i = 0; i < 256; i++) {
                  ipInputTwo.append(String.valueOf(i));
                  if (i < 255) {
                      ipInputTwo.append(Constants.COMMA);
                  }
              }
              info.setIpaddressTwo(ipInputTwo.toString());
            } else {
                if (!ipInsertTwo.contains(Constants.DASH)) {
                    info.setIpaddressTwo(ipInsertTwo);
                } else {
                    String[] ipSplit = ipInsertTwo.split(Constants.DASH_BRACKET);
                    int inputStart = Integer.parseInt(ipSplit[0]);
                    int inputEnd = Integer.parseInt(ipSplit[1]);
                    StringBuilder ipInputTwo = new StringBuilder();
                    for (int i = inputStart; i <= inputEnd; i++) {
                        ipInputTwo.append(String.valueOf(i));
                        if (i < inputEnd) {
                            ipInputTwo.append(Constants.COMMA);
                        }
                    }
                    info.setIpaddressTwo(ipInputTwo.toString());
                }
            }
        }
          //Insert IP Address
          licenseBusiness.insertIPAddress(info);
      }
  }

    /**
     * deleteIPAddress
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    private void deleteIPAddress(List<String> ipDeleteList, List<IpAddressInfo> ipApproveList) {
        List<String> ipDelSplit = null;
        String ipDel1 = StringUtils.EMPTY;
        String ipDel2 = StringUtils.EMPTY;
        IpAddressInfo toDelete = null;
        for (String ipDel : ipDeleteList) {
            ipDelSplit = splitIPAddressList(ipDel);
            ipDel1 = ipDelSplit.get(0);
            ipDel2 = ipDelSplit.get(1);
            if (ipApproveList != null && ipApproveList.size() > 0) {
                int length = ipApproveList.size();
                IpAddressInfo strIpAddressDB;
                String ipAddressOne = StringUtils.EMPTY;
                String ipAddressTwo = StringUtils.EMPTY;
                for (int i = 0; i < length; i++) {
                    strIpAddressDB = ipApproveList.get(i);
                    ipAddressOne = strIpAddressDB.getIpaddressOne();
                    ipAddressTwo = splitIPAddressList(strIpAddressDB.getIpaddress()).get(1);
                    if (ipDel1.equals(ipAddressOne)) {
                        if (ipDel2.equals(Constants.COLON_STAR)) {
                            if (ipAddressTwo.contains(Constants.COLON_STAR)) {
                                strIpAddressDB.setStatus(3);
                                licenseBusiness.deleteIPAddress(strIpAddressDB);
                                break;
                            }
                        }

                        int inputStart = 0, inputEnd = 0;
                        if (!ipDel2.contains(Constants.DASH)) {
                            inputStart = Integer.parseInt(ipDel2);
                            inputEnd = inputStart;
                        } else {
                            String[] split = ipDel2.split(Constants.DASH_BRACKET);
                            inputStart = Integer.parseInt(split[0]);
                            inputEnd = Integer.parseInt(split[1]);
                        }
                        toDelete = getIpAddressToProcess(inputStart, inputEnd, strIpAddressDB);// Process delete Ip Address
                        int resultStart = toDelete.getResultStart();
                        int resultEnd = toDelete.getResultEnd();

                        if (resultStart == inputStart && inputEnd == resultEnd) {
                            toDelete.setStatus(3);
                            licenseBusiness.deleteIPAddress(toDelete);
                            break;
                        } else if (resultStart < inputStart && inputEnd < resultEnd) {
                            List<IpAddressInfo> toInsertList = new ArrayList<>();
                            if (resultStart < inputStart) {
                                IpAddressInfo toInsert = (IpAddressInfo) SerializationUtils.clone(toDelete);
                                String range = StringUtils.EMPTY;
                                if (resultStart == (inputStart - 1)) {
                                    range = String.valueOf(resultStart);
                                } else {
                                    range = (resultStart + Constants.DASH + (inputStart - 1));
                                }
                                toInsert.setIpaddress(ipDel1 + range);
                                StringBuilder range2 = new StringBuilder();
                                for (int j = resultStart; j < inputStart; j++) {
                                    range2.append(j);
                                    if (j != (inputStart - 1)) {
                                        range2.append(Constants.COMMA);
                                    }
                                }
                                toInsert.setIpaddressTwo(range2.toString());
                                toInsertList.add(toInsert);
                            }
                            if (inputEnd < resultEnd) {
                                IpAddressInfo toInsert = (IpAddressInfo) SerializationUtils.clone(toDelete);
                                String range = StringUtils.EMPTY;
                                if (inputEnd == (resultEnd - 1)) {
                                    range = String.valueOf(resultEnd);
                                } else {
                                    range = ((inputEnd + 1) + Constants.DASH + resultEnd);
                                }
                                toInsert.setIpaddress(ipDel1 + range);
                                StringBuilder range2 = new StringBuilder();
                                for (int j = inputEnd + 1; j <= resultEnd; j++) {
                                    range2.append(j);
                                    if (j != (resultEnd)) {
                                        range2.append(Constants.COMMA);
                                    }
                                }
                                toInsert.setIpaddressTwo(range2.toString());
                                toInsertList.add(toInsert);
                            }
                            IpAddressInfo input = (IpAddressInfo) SerializationUtils.clone(toDelete);
                            if (inputStart == inputEnd) {
                                input.setIpaddress(ipDel1 + inputStart);
                                input.setIpaddressTwo(String.valueOf(inputStart));
                                input.setStatus(3);
                                toInsertList.add(input);
                            } else {
                                input.setIpaddress(ipDel1 + inputStart + Constants.DASH + inputEnd);
                                StringBuilder range2 = new StringBuilder();
                                for (int j = inputStart; j <= inputEnd; j++) {
                                    range2.append(j);
                                    if (j != inputEnd) {
                                        range2.append(Constants.COMMA);
                                    }
                                }
                                input.setIpaddressTwo(range2.toString());
                                input.setStatus(3);
                                toInsertList.add(input);
                            }
                            licenseBusiness.insertAfterDeleteIpAdd(toDelete, toInsertList);
                        }
                    }
                }
            }
        }
    }

    /**
     * getIpAddressToProcess
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    private IpAddressInfo getIpAddressToProcess(Integer inputStart, Integer inputEnd, IpAddressInfo strIpAddressDB) {
        IpAddressInfo result = strIpAddressDB;
        if (strIpAddressDB.getIpaddress().contains(Constants.COLON_STAR)) {
            result.setResultStart(0);
            result.setResultEnd(255);
        } else {
            String splitIpDel2 = strIpAddressDB.getIpaddress().split(Pattern.quote("."))[3];
            if (splitIpDel2.contains(Constants.DASH)) {
                String[] startEndSplit = splitIpDel2.split(Constants.DASH_BRACKET);
                result.setResultStart(Integer.valueOf(startEndSplit[0]));
                result.setResultEnd(Integer.valueOf(startEndSplit[1]));
            } else {
                result.setResultStart(Integer.valueOf(splitIpDel2));
                result.setResultEnd(Integer.valueOf(splitIpDel2));
            }
        }
        if (result.getResultStart() <= inputStart && inputEnd <= result.getResultEnd()) {
            result = strIpAddressDB;
        }
        return result;
    }

    /**
     * isIPInsertNotExists
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    private String isIPInsertNotExists(List<String> ipInsertList, List<IpAddressInfo> ipAdDBList) {
        String errMsgInsert = StringUtils.EMPTY;
        boolean isExits = false;
        List<String> ipInsertSplit = null;
        String ipAddressInput1 = StringUtils.EMPTY;
        String ipAddressInput2 = StringUtils.EMPTY;
        for (int i = 0; i < ipInsertList.size(); i++) {
            ipInsertSplit = splitIPAddressList(ipInsertList.get(i));
            ipAddressInput1 = ipInsertSplit.get(0);
            ipAddressInput2 = ipInsertSplit.get(1);
            isExits = this.compareIpAddress(ipAddressInput1, ipAddressInput2, ipAdDBList);
            if (isExits) {
                errMsgInsert += errMsg.concat("IpAddress ").concat(ipAddressInput1 + ipAddressInput2)
                        .concat(" insert exit in DB.").concat("<br/>");
            }
        }
        return errMsgInsert;
    }

    /**
     * isIPDeleteExists
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    private String isIPDeleteExists(List<String> ipDeleteList, List<IpAddressInfo> ipApproveList) {
        String errMsgDel = StringUtils.EMPTY;
        boolean isExist = false;
        List<String> ipDelSplit = null;
        String ipDel1 = StringUtils.EMPTY;
        String ipDel2 = StringUtils.EMPTY;
        for (int i = 0; i < ipDeleteList.size(); i++) {
            ipDelSplit = splitIPAddressList(ipDeleteList.get(i));
            ipDel1 = ipDelSplit.get(0);
            ipDel2 = ipDelSplit.get(1);
            isExist = this.compareIpAddress(ipDel1, ipDel2, ipApproveList);
            if (!isExist) {
                errMsgDel += errMsg.concat("IpAddress ").concat(ipDel1 + ipDel2).concat(" delete not exit in DB.")
                        .concat("<br/>");
            }
        }
        return errMsgDel;
    }

    /**
     * compareIpAddress
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    private boolean compareIpAddress(String ipAddressInput1, String ipAddressInput2, List<IpAddressInfo> ipAdDBList) {
        boolean isExist = false;
        IpAddressInfo strIpAddressDB;
        String ipAddressOne = StringUtils.EMPTY;
        String ipAddressTwo = StringUtils.EMPTY;
        for (int i = 0; i < ipAdDBList.size(); i++) {
            strIpAddressDB = ipAdDBList.get(i);
            ipAddressOne = strIpAddressDB.getIpaddressOne();
            ipAddressTwo = strIpAddressDB.getIpaddressTwo();
            if (ipAddressInput1.equals(ipAddressOne)) {// if ip exist xxx.xxx.xxx.*
                String[] ipAddressDB = null;
                ipAddressDB = strIpAddressDB.getIpaddress().split(Constants.DOT_SPLIT);
                if (ipAddressDB[3].equals(Constants.COLON_STAR) || ipAddressInput2.equals(Constants.COLON_STAR)) {
                    isExist = true;
                    return isExist;
                }
                if (!ipAddressInput2.contains(Constants.DASH)) {// format ipAddressInput2
                    String[] ipAddressTwoList = ipAddressTwo.split(Constants.COMMA);// only 1 number
                    for (String j : ipAddressTwoList) {
                        if (ipAddressInput2.equals(j)) {
                            isExist = true;
                            return isExist;
                        }
                    }
                } else { // ipAddressInput2 format xxx-xxx
                    String[] ipRange = ipAddressInput2.split(Constants.DASH_BRACKET);
                    StringBuilder sbRange = new StringBuilder();
                    int rangeBegin = Integer.parseInt(ipRange[0]);
                    int rangeEnd = Integer.parseInt(ipRange[1]);

                    for (int j = rangeBegin; j <= rangeEnd; j++) {
                        sbRange.append(j);
                        if (j != rangeEnd) {
                            sbRange.append(Constants.COMMA);
                        }
                    }
                    if (sbRange.toString().contains(ipAddressTwo) || ipAddressTwo.contains(sbRange.toString())) {
                        isExist = true;
                        return isExist;
                    }
                }
            }
        }
        return isExist;
    }

    /**
     * splitIPAddressList
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    private List<String> splitIPAddressList(String ipAddressInput) {
        String[] ipToken = ipAddressInput.split(Constants.DOT_SPLIT);
        StringBuilder ipAddressInput1 = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            ipAddressInput1.append(ipToken[i]);
            ipAddressInput1.append(Constants.DOT);
        }
        String ipAddressInput2 = ipToken[3];
        List<String> ipAddressInputList = new ArrayList<String>();
        ipAddressInputList.add(ipAddressInput1.toString());
        ipAddressInputList.add(ipAddressInput2);
        return ipAddressInputList;
    }

    /**
     * @param listPro
     */
    public List<Project> getListPro() {
        return listPro;
    }

    /**
     * @param listPro
     *            the listPro to set
     */
    public void setListPro(List<Project> listPro) {
        this.listPro = listPro;
    }

    /**
     * @param projectBusiness
     */
    public ProjectBusiness getProjectBusiness() {
        return projectBusiness;
    }

    /**
     * @param projectBusiness
     *            the projectBusiness to set
     */
    public void setProjectBusiness(ProjectBusiness projectBusiness) {
        this.projectBusiness = projectBusiness;
    }

    /**
     * @param memberBusiness
     */
    public MemberBusiness getMemberBusiness() {
        return memberBusiness;
    }

    /**
     * @param memberBusiness
     *            the memberBusiness to set
     */
    public void setMemberBusiness(MemberBusiness memberBusiness) {
        this.memberBusiness = memberBusiness;
    }

    /**
     * @param projectBelongInfo
     */
    public ProjectBelongInfo getProjectBelongInfo() {
        return projectBelongInfo;
    }

    /**
     * @param projectBelongInfo
     *            the projectBelongInfo to set
     */
    public void setProjectBelongInfo(ProjectBelongInfo projectBelongInfo) {
        this.projectBelongInfo = projectBelongInfo;
    }

    /**
     * @param listProBelongInfo
     */
    public List<ProjectBelongInfo> getListProBelongInfo() {
        return listProBelongInfo;
    }

    /**
     * @param listProBelongInfo
     *            the listProBelongInfo to set
     */
    public void setListProBelongInfo(List<ProjectBelongInfo> listProBelongInfo) {
        this.listProBelongInfo = listProBelongInfo;
    }

    /**
     * @param project
     */
    public Project getProject() {
        return project;
    }

    /**
     * @param project
     *            the project to set
     */
    public void setProject(Project project) {
        this.project = project;
    }

    /**
     * @param licenseBusiness
     */
    public LicenseBusiness getLicenseBusiness() {
        return licenseBusiness;
    }

    /**
     * @param licenseBusiness
     *            the licenseBusiness to set
     */
    public void setLicenseBusiness(LicenseBusiness licenseBusiness) {
        this.licenseBusiness = licenseBusiness;
    }

    /**
     * @param supporterBusiness
     */
    public SupporterBusiness getSupporterBusiness() {
        return supporterBusiness;
    }

    /**
     * @param supporterBusiness
     *            the supporterBusiness to set
     */
    public void setSupporterBusiness(SupporterBusiness supporterBusiness) {
        this.supporterBusiness = supporterBusiness;
    }

    /**
     * @param catalogInfor
     */
    public CatalogInfor getCatalogInfor() {
        return catalogInfor;
    }

    /**
     * @param catalogInfor
     *            the catalogInfor to set
     */
    public void setCatalogInfor(CatalogInfor catalogInfor) {
        this.catalogInfor = catalogInfor;
    }

    /**
     * @param listCatalogInfor
     */
    public List<CatalogInfor> getListCatalogInfor() {
        return listCatalogInfor;
    }

    /**
     * @param listCatalogInfor
     *            the listCatalogInfor to set
     */
    public void setListCatalogInfor(List<CatalogInfor> listCatalogInfor) {
        this.listCatalogInfor = listCatalogInfor;
    }

    /**
     * @param catalogIdChecked
     */
    public List<Object> getCatalogIdChecked() {
        return catalogIdChecked;
    }

    /**
     * @param catalogIdChecked
     *            the catalogIdChecked to set
     */
    public void setCatalogIdChecked(List<Object> catalogIdChecked) {
        this.catalogIdChecked = catalogIdChecked;
    }

    /**
     * @param catalogId
     */
    public int getCatalogId() {
        return catalogId;
    }

    /**
     * @param catalogId
     *            the catalogId to set
     */
    public void setCatalogId(int catalogId) {
        this.catalogId = catalogId;
    }

    /**
     * @param valueLicense
     */
    public int getValueLicense() {
        return valueLicense;
    }

    /**
     * @param valueLicense
     *            the valueLicense to set
     */
    public void setValueLicense(int valueLicense) {
        this.valueLicense = valueLicense;
    }

    /**
     * @param listLicenseColumn
     */
    public List<LicenseColumn> getListLicenseColumn() {
        return listLicenseColumn;
    }

    /**
     * @param listLicenseColumn
     *            the listLicenseColumn to set
     */
    public void setListLicenseColumn(List<LicenseColumn> listLicenseColumn) {
        this.listLicenseColumn = listLicenseColumn;
    }

    /**
     * @param listLicenseFormBean
     */
    public List<LicenseFormBean> getListLicenseFormBean() {
        return listLicenseFormBean;
    }

    /**
     * @param listLicenseFormBean
     *            the listLicenseFormBean to set
     */
    public void setListLicenseFormBean(List<LicenseFormBean> listLicenseFormBean) {
        this.listLicenseFormBean = listLicenseFormBean;
    }

    /**
     * @param findPro
     */
    public Project getFindPro() {
        return findPro;
    }

    /**
     * @param findPro
     *            the findPro to set
     */
    public void setFindPro(Project findPro) {
        this.findPro = findPro;
    }

    /**
     * @param warningMsg
     */
    public String getWarningMsg() {
        return warningMsg;
    }

    /**
     * @param warningMsg
     *            the warningMsg to set
     */
    public void setWarningMsg(String warningMsg) {
        this.warningMsg = warningMsg;
    }

    /**
     * @param ipDeleteList
     */
    public List<String> getIpDeleteList() {
        return ipDeleteList;
    }

    /**
     * @param ipDeleteList
     *            the ipDeleteList to set
     */
    public void setIpDeleteList(List<String> ipDeleteList) {
        this.ipDeleteList = ipDeleteList;
    }

    /**
     * @param ipInsertList
     */
    public List<String> getIpInsertList() {
        return ipInsertList;
    }

    /**
     * @param ipInsertList
     *            the ipInsertList to set
     */
    public void setIpInsertList(List<String> ipInsertList) {
        this.ipInsertList = ipInsertList;
    }

    /**
     * @param ipAddressInsertDBList
     */
    public List<IpAddressInfo> getIpAddressInsertDBList() {
        return ipAddressInsertDBList;
    }

    /**
     * @param ipAddressInsertDBList
     *            the ipAddressInsertDBList to set
     */
    public void setIpAddressInsertDBList(List<IpAddressInfo> ipAddressInsertDBList) {
        this.ipAddressInsertDBList = ipAddressInsertDBList;
    }

    /**
     * @param errMsg
     */
    public String getErrMsg() {
        return errMsg;
    }

    /**
     * @param errMsg
     *            the errMsg to set
     */
    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    /**
     * @param listLicenseAOR
     */
	public List<LicenseApproveOrRejectBean> getListLicenseAOR() {
		return listLicenseAOR;
	}

    /**
     * @param listLicenseAOR
     *            the listLicenseAOR to set
     */
	public void setListLicenseAOR(List<LicenseApproveOrRejectBean> listLicenseAOR) {
		this.listLicenseAOR = listLicenseAOR;
	}

}
