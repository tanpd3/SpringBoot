package jp.meportal.isv.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import jp.meportal.isv.business.ProjectBusiness;
import jp.meportal.isv.business.SupporterBusiness;
import jp.meportal.isv.business.impl.ProjectBusinessImpl;
import jp.meportal.isv.business.impl.SupporterBusinessImpl;
import jp.meportal.isv.common.PortalCoreAccessManager;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.constant.ErrorCodes;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.Support;
import jp.meportal.isv.entity.UserInfo;
import jp.meportal.isv.model.MemberJsonDto;
import jp.meportal.isv.util.DateUtils;
import jp.meportal.isv.util.EmailUtil;

/**
 * Class Name: SupporterAction<br>
 * Created date: 2017/05/05<br>
 * 
 * @author FPT
 */
public class SupporterAction extends BaseAction {
    private static final long serialVersionUID = 3330080403630053931L;
    final static Logger logger = Logger.getLogger(ManagerAction.class);
    
    public SupporterBusiness supporterBusiness;
    public ProjectBusiness projectBusiness;
    private Project project;
    private List<Project> listProject;
    private String userBelongCompanyName;
    private String userBelongDepartmentName;
    private String comment;
    private String projectId;
    private Long totalProjectApproved;
    private Long totalProjectUnApproved;
    private String warningMsg = StringUtils.EMPTY;

    /**
     * SupporterAction
     */
    public SupporterAction() {
        supporterBusiness = new SupporterBusinessImpl();
        projectBusiness = new ProjectBusinessImpl();
    }

    /**
     * initSupporterAction
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    public String initSupporterAction() {
        if (!isValidateUser()) {
            return LOGIN;
        }
        UserInfo userInfo = getUserInfo(null, ServletActionContext.getRequest());
        userBelongCompanyName = userInfo.getUserBelongCompanyName();
        userBelongDepartmentName = userInfo.getUserBelongDepartmentName();
        listProject = this.getListAllProject();// list all project
        return SUCCESS;
    }

    /**
     * approveProject
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    public String approveProject() throws Exception {
        if (!isValidateUser()) {
            return LOGIN;
        }
        String mailLogin = this.getEmailAddress();
        Support supportExisted = supporterBusiness.getSupportDb(mailLogin);
        if (supportExisted != null) {
            if (!StringUtils.isEmpty(projectId)) {
                Project project = projectBusiness.findProjectBySeqNo(Integer.parseInt(projectId));
                if (project != null) {
                    project.setComment(comment);
                    project.setStatus(Constants.APPROVED_STATUS);
                    project.setUpdateDated(DateUtils.convertDateToString(new Date(), Constants.DATE_FORMAT_UPDATE));
                    PortalCoreAccessManager pcMgr = new PortalCoreAccessManager();
                    List<String> emailList = new ArrayList<String>();
                    emailList.add(project.getManagerEmail());
                    List<MemberJsonDto> managerInfo = pcMgr.getMembersListById(emailList);// Get members by emails from Portal core
                    String departmentName = StringUtils.EMPTY;
                    if (managerInfo != null && managerInfo.size() > 0) {
                        departmentName = managerInfo.get(0).getDepartmentName();
                    }
                    boolean flagApproved = supporterBusiness.approveProject(project);
                    if (flagApproved) {
                        try {
                            String toMail = project.getManagerEmail();
                            String ccMail = supporterBusiness.getMailList();
                            EmailUtil.sendEmail(Constants.APPROVE_PROJECT_SUBJECT,
                                    Constants.HEADER_TEMPLATE_APPROVE_PROJECT,
                                    Constants.FOOTER_TEMPLATE_APPROVE_PROJECT,
                                    Constants.CONTENT_TEMPLATE_APPROVE_PROJECT, toMail, ccMail, null, departmentName, 
                                    project.getProjectName(), project.getManagerName(), null, project.getLoadOriginCode(),
                                    project.getCostCode(), null, project.getComment());
                        } catch (Exception e) {
                            logger.error(e.getMessage(), e);
                        }
                    } else {// if project was approved -->can not approve
                    warningMsg = ErrorCodes.ERRORS_CODE_CAN_NOT_APPROVE;
                    }
                } else
                    exceptionMsg = ErrorCodes.ERRORS_CODE_PROJECT_NOT_EXIST;
            }
        } else {
            exceptionMsg = ErrorCodes.ERRORS_CODE_IN_VALID_SUPPORT_DB;
            return ERROR;
        }
        return SUCCESS;
    }

    /**
     * rejectProject
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    public String rejectProject() throws Exception {
        if (!isValidateUser()) {
            return LOGIN;
        }
        String mailLogin = this.getEmailAddress();
        Support supportExisted = supporterBusiness.getSupportDb(mailLogin);
        if (supportExisted != null) {
            if (!StringUtils.isEmpty(projectId)) {
                Project project = projectBusiness.findProjectBySeqNo(Integer.parseInt(projectId));
                if (project != null) {
                    project.setComment(comment);
                    project.setStatus(Constants.REJECTED_STATUS);
                    project.setUpdateDated(DateUtils.convertDateToString(new Date(), Constants.DATE_FORMAT_UPDATE));
                    PortalCoreAccessManager pcMgr = new PortalCoreAccessManager();
                    List<String> emailList = new ArrayList<String>();
                    emailList.add(project.getManagerEmail());
                    List<MemberJsonDto> managerInfo = pcMgr.getMembersListById(emailList);// Get list member by list email from Portal core
                    boolean flagReject = supporterBusiness.rejectProject(project);
                    String departmentName = StringUtils.EMPTY;
                    if (managerInfo != null && managerInfo.size() > 0) {
                        departmentName = managerInfo.get(0).getDepartmentName();
                    }
                    if (flagReject) {
                        try {
                            String toMail = project.getManagerEmail();
                            String ccMail = supporterBusiness.getMailList();
                            EmailUtil.sendEmail(Constants.REJECT_PROJECT_SUBJECT,
                                    Constants.HEADER_TEMPLATE_REJECT_PROJECT, Constants.FOOTER_TEMPLATE_REJECT_PROJECT,
                                    Constants.CONTENT_TEMPLATE_REJECT_PROJECT, toMail, ccMail, null, departmentName, 
                                    project.getProjectName(), project.getManagerName(),
                                    null, project.getLoadOriginCode(), project.getCostCode(), null, project
                                            .getComment());
                        } catch (Exception e) {
                            logger.error(e.getMessage(), e);
                        }
                    } else {
                        warningMsg = ErrorCodes.ERRORS_CODE_CAN_NOT_REJECT;
                    }
                } else
                    exceptionMsg = ErrorCodes.ERRORS_CODE_PROJECT_NOT_EXIST;
            }
        } else {
            exceptionMsg = ErrorCodes.ERRORS_CODE_IN_VALID_SUPPORT_DB;
            return ERROR;
        }
        return SUCCESS;
    }

    /**
     * deleteProject
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    public String deleteProject() {
        if (!isValidateUser()) {
            return LOGIN;
        }
        String mailLogin = this.getEmailAddress();
        Support supportExisted = supporterBusiness.getSupportDb(mailLogin);
        if (supportExisted != null) {
            if (!StringUtils.isEmpty(projectId)) {
                Project project = projectBusiness.findProjectBySeqNo(Integer.parseInt(projectId));
                if (project != null) {
                    project.setComment(comment);
                    project.setStatus(Constants.DELETED_STATUS);
                    project.setUpdateDated(DateUtils.convertDateToString(new Date(), Constants.DATE_FORMAT_UPDATE));
                    supporterBusiness.deleteProject(project);
                } else
                    exceptionMsg = ErrorCodes.ERRORS_CODE_PROJECT_NOT_EXIST;
            }
        } else {
            exceptionMsg = ErrorCodes.ERRORS_CODE_IN_VALID_SUPPORT_DB;
            return ERROR;
        }
        return SUCCESS;
    }

    /**
     * getListAllProject
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    private List<Project> getListAllProject() {
        List<Integer> listStatus = new ArrayList<Integer>();
        listStatus.add(Constants.UN_APPROVED_STATUS);
        listStatus.add(Constants.APPROVED_STATUS);
        totalProjectUnApproved = projectBusiness.countAllProjectByStatus(Constants.UN_APPROVED_STATUS);
        totalProjectApproved = projectBusiness.countAllProjectByStatus(Constants.APPROVED_STATUS);
        listProject = projectBusiness.listAllProjectByListStatus(listStatus);

        return listProject;
    }

    /**
     * @param project
     */
    public Project getProject() {
        return project;
    }

    /**
     * @param project
     *            the project to set
     */
    public void setProject(Project project) {
        this.project = project;
    }

    /**
     * @param listProject
     */
    public List<Project> getListProject() {
        return listProject;
    }

    /**
     * @param listProject
     *            the listProject to set
     */
    public void setListProject(List<Project> listProject) {
        this.listProject = listProject;
    }

    /**
     * @param userBelongCompanyName
     */
    public String getUserBelongCompanyName() {
        return userBelongCompanyName;
    }

    /**
     * @param userBelongCompanyName
     *            the userBelongCompanyName to set
     */
    public void setUserBelongCompanyName(String userBelongCompanyName) {
        this.userBelongCompanyName = userBelongCompanyName;
    }

    /**
     * @param userBelongDepartmentName
     */
    public String getUserBelongDepartmentName() {
        return userBelongDepartmentName;
    }

    /**
     * @param userBelongDepartmentName
     *            the userBelongDepartmentName to set
     */
    public void setUserBelongDepartmentName(String userBelongDepartmentName) {
        this.userBelongDepartmentName = userBelongDepartmentName;
    }

    /**
     * @param projectId
     */
    public String getProjectId() {
        return projectId;
    }

    /**
     * @param projectId
     *            the projectId to set
     */
    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    /**
     * @param totalProjectApproved
     */
    public Long getTotalProjectApproved() {
        return totalProjectApproved;
    }

    /**
     * @param totalProjectApproved
     *            the totalProjectApproved to set
     */
    public void setTotalProjectApproved(Long totalProjectApproved) {
        this.totalProjectApproved = totalProjectApproved;
    }

    /**
     * @param totalProjectUnApproved
     */
    public Long getTotalProjectUnApproved() {
        return totalProjectUnApproved;
    }

    /**
     * @param totalProjectUnApproved
     *            the totalProjectUnApproved to set
     */
    public void setTotalProjectUnApproved(Long totalProjectUnApproved) {
        this.totalProjectUnApproved = totalProjectUnApproved;
    }

    /**
     * @param warningMsg
     */
    public String getWarningMsg() {
        return warningMsg;
    }

    /**
     * @param warningMsg
     *            the warningMsg to set
     */
    public void setWarningMsg(String warningMsg) {
        this.warningMsg = warningMsg;
    }

    /**
     * @param comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment
     *            the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }
}
