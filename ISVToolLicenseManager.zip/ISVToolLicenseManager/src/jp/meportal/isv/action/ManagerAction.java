package jp.meportal.isv.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.meportal.isv.business.MemberBusiness;
import jp.meportal.isv.business.ProjectBusiness;
import jp.meportal.isv.business.impl.MemberBusinessImpl;
import jp.meportal.isv.business.impl.ProjectBusinessImpl;
import jp.meportal.isv.common.PortalCoreAccessManager;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.constant.ErrorCodes;
import jp.meportal.isv.entity.DepartmentEntity;
import jp.meportal.isv.entity.DepartmentMasterEntity;
import jp.meportal.isv.entity.Member;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ProjectBelongInfo;
import jp.meportal.isv.formbean.MemberByProjectIdFormBean;
import jp.meportal.isv.model.MemberJsonDto;
import jp.meportal.isv.util.DateUtils;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.google.gson.Gson;

/**
 * Class Name: ManagerAction<br>
 * Created date: 2017/05/05<br>
 * 
 * @author FPT
 */
public class ManagerAction extends BaseAction {

    private static final long serialVersionUID = 3308831928180208183L;
    final static Logger logger = Logger.getLogger(ManagerAction.class);
    public static int isManagerOfCurrentMember;

    private ProjectBusiness projectBusiness;
    private MemberBusiness memberBusiness;
    public Member member;
    public Project project;
    public Project findPro;
    public ProjectBelongInfo projectBelongInfo;
    public ProjectBelongInfo proBelongInfo;
    private List<String> emailPermisson;
    public List<Project> listPro;
    public List<Member> listDetailMember;
    public List<MemberByProjectIdFormBean> listMemberByProjectId;
    public List<ProjectBelongInfo> listProBelongInfo;
    public List<MemberJsonDto> membersList;
    public String statusProject;
    public String seqNo;
    public String emailMemberAdd;
    public String statusPopUp;
    public String statusButton;
    private String addEmail;
    private String companyCode;
    private String departmentCode;
    private String errMsg;
    private String emailChecked;
   
    private transient HttpSession session = ServletActionContext.getRequest().getSession();
    private transient HttpServletRequest request = ServletActionContext.getRequest();
    
    /**
     * ManagerAction
     */
    public ManagerAction() {
        projectBusiness = new ProjectBusinessImpl();
        memberBusiness = new MemberBusinessImpl();
        this.initAction();
    }

    /**
     * registerProjectMember
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    public String registerProjectMember() throws Exception {
        if (!isValidateUser()) {
            return LOGIN;
        }
        if (session != null) {// remove all session
            session.removeAttribute("projectId");
            session.removeAttribute("projectName");
            session.removeAttribute("managerName");
            session.removeAttribute("managerEmail");
            session.removeAttribute("userEmail");
            session.removeAttribute("isManager");
            session.setAttribute("userEmail", this.getEmailAddress());
        }
        /* start set Permission */
        setStatusProject(Constants.STATUS_PROJECT_OFF);
        this.initRegisterProjectMember();
        setStatusPopUp(Constants.STATUS_BUTTON_TRUE);
        /* end set Permission */

        this.getDataPortalCore();// load data for combo box department

        return SUCCESS;
    }

    /**
     * moreLoadRegisterMember
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    public String moreLoadRegisterMember() throws Exception {
        if (!isValidateUser()) {
            return LOGIN;
        }
        PortalCoreAccessManager pcMgr = new PortalCoreAccessManager();
        project = projectBusiness.findProjectBySeqNo(findPro.getSeqNo());
        String email = (String) session.getAttribute("userEmail");
        if (project != null) {
            session.setAttribute("projectId", project.getSeqNo());
            session.setAttribute("projectName", project.getProjectName());
        }
        this.showProjectAndMemberList(email); // show Project and Member List.
        
        List<String> emailList = new ArrayList<String>();
        Map<String, Integer> mapEmail = new HashMap<String, Integer>();
        // set Member List
        this.setMemberList(pcMgr, emailList, mapEmail);

        // start set Permission
        setStatusProject(Constants.STATUS_PROJECT_ON);
        checkStatusIsManagerProject();
        setStatusPopUp(Constants.STATUS_BUTTON_TRUE);
        // end set Permission

        this.getDataPortalCore();// load data for combo box department
        return SUCCESS;
    }

    /**
     * moreLoadRegisterMemberById
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception 
     */
    public String moreLoadRegisterMemberById() throws Exception {
        if (!isValidateUser()) {
            return LOGIN;
        }
        PortalCoreAccessManager pcMgr = new PortalCoreAccessManager();
        int projectId = 0;
        if (session.getAttribute("projectId") != null) {
            projectId = (int) session.getAttribute("projectId");
        } else {
            return ERROR;
        }
        project = projectBusiness.findProjectBySeqNo(projectId);
        String email = (String) session.getAttribute("userEmail");
        if (project != null) {
            session.setAttribute("projectId", project.getSeqNo());
            session.setAttribute("projectName", project.getProjectName());
        }
        this.showProjectAndMemberList(email);// show project and member list.
        
        List<String> emailList = new ArrayList<String>();
        Map<String, Integer> mapEmail = new HashMap<String, Integer>();
        // set Member List.
        this.setMemberList(pcMgr, emailList, mapEmail);

        // start set Permission
        setStatusProject(Constants.STATUS_PROJECT_ON);
        this.checkStatusIsManagerProject();
        setStatusPopUp(Constants.STATUS_BUTTON_TRUE);
        // start set Permission

        this.getDataPortalCore();// load data for combo box department
        return SUCCESS;
    }

    /**
     * checkStatusIsManagerProject
     * 
     * @author FPT
     * @date: 2017/05/05
     * 
     */
    public void checkStatusIsManagerProject() {
        String userEmail = (String) session.getAttribute("userEmail");
        int seqNo = (int) session.getAttribute("projectId");

        isManagerOfCurrentMember = memberBusiness.getIsManagerOfMember(seqNo, userEmail);// Check IsManager Project of user
        if (isManagerOfCurrentMember == Constants.ISV_MEMBER) {// Member of project
            request.setAttribute("statusCheckbox", Constants.STATUS_BUTTON_TRUE);
            setStatusButton(Constants.STATUS_BUTTON_TRUE);
        } else if (isManagerOfCurrentMember == Constants.ISV_OTHER_MANAGER) {// other Manager of project
            request.setAttribute("statusCheckbox", Constants.NONE);
            setStatusButton(Constants.STATUS_BUTTON_FALSE);
        } else if (isManagerOfCurrentMember == Constants.ISV_MANAGER) {// Manager of Project
            request.setAttribute("statusCheckbox", Constants.NONE);
            setStatusButton(Constants.STATUS_BUTTON_FALSE);
        } else {// else
            request.setAttribute("statusCheckbox", Constants.STATUS_BUTTON_FALSE);
            setStatusButton(Constants.STATUS_BUTTON_FALSE);
        }
    }

    /**
     * updateMember
     * 
     * @author FPT
     * @date: 2017/05/05
     * 
     */
    public String updateMember() throws Exception {
        if (!isValidateUser()) {
            return LOGIN;
        }
        int projectId = 0;
        errMsg = StringUtils.EMPTY;
        if (session.getAttribute("projectId") != null && !session.getAttribute("projectId").equals(Constants.NONE)) {
            projectId = (int) session.getAttribute("projectId");
        }
        String email = (String) session.getAttribute("userEmail");
        this.checkStatusIsManagerProject();
        int isManagerOfMember = 0;
        String emailUpdate = StringUtils.EMPTY;
        if (emailChecked != null && !emailChecked.equals(StringUtils.EMPTY)) {
            String[] partEmail = emailChecked.split(",");
            checkIsManger(projectId, partEmail);// check is manager.
            if (errMsg.equals(StringUtils.EMPTY)) {
                for (int i = 0; i < partEmail.length; i++) {
                    emailUpdate = partEmail[i];
                    isManagerOfMember = memberBusiness.getIsManagerOfMember(projectId, emailUpdate);
                    Member member = memberBusiness.checkExistEmailMember(emailUpdate);
                    if (member != null) {
                        memberBusiness.updatePermissionMember(emailUpdate, projectId, isManagerOfMember, member);
                    }
                    setStatusButton(Constants.STATUS_BUTTON_FALSE);// set status member
                }
            }
        }
        this.showProjectAndMemberList(email); // show Project and Member List.
        this.getDataPortalCore();// load data for combo box department
        
        return Constants.MANAGER_ACTION_UPDATE_MEMBER;
    }

    /**
     * deleteMember
     * 
     * @author FPT
     * @date: 2017/05/05
     * 
     */
    public String deleteMember() throws Exception {
        if (!isValidateUser()) {
            return LOGIN;
        }
        int projectId = 0;
        errMsg = StringUtils.EMPTY;
        if (session.getAttribute("projectId") != null && !session.getAttribute("projectId").equals(Constants.NONE)) {
            projectId = (int) session.getAttribute("projectId");
        }
        String email = (String) session.getAttribute("userEmail");
        String emailDel = StringUtils.EMPTY;
        if (emailChecked != null && !emailChecked.equals(StringUtils.EMPTY)) {
            String[] partEmail = emailChecked.split(",");
            checkIsManger(projectId, partEmail);// check is manager.
            if (errMsg.equals(StringUtils.EMPTY)) {
                for (int i = 0; i < partEmail.length; i++) {
                    emailDel = partEmail[i];
                    Member member = memberBusiness.checkExistEmailMember(emailDel);
                    if (member != null) {// Delete member process
                        memberBusiness.deleteMember(emailDel, projectId, member);
                    }
                    setStatusButton(Constants.STATUS_BUTTON_FALSE);// set status member
                }
            }
        }
        this.showProjectAndMemberList(email); // show Project and Member List.
        this.getDataPortalCore();// load data for combo box department

        return Constants.MANAGER_ACTION_DELETE_MEMBER;
    }

    /**
     * addNewMemberExcecute
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    public String addNewMemberExcecute() throws Exception {
        if (!isValidateUser()) {
            return LOGIN;
        }
        PortalCoreAccessManager pcMgr = new PortalCoreAccessManager();
        String emailUserLogin = this.getEmailAddress();
        List<MemberJsonDto> membersList = null;
        int projectId = 0;
        errMsg = StringUtils.EMPTY;

        if (session.getAttribute("projectId") != null) {
            projectId = (int) session.getAttribute("projectId");
        } else {
            return ERROR;
        }
        if (!StringUtils.isEmpty(companyCode) && companyCode != null) {
            if (!StringUtils.isEmpty(departmentCode) && departmentCode != null) {
                membersList = pcMgr.getMembersList(emailUserLogin, addEmail, companyCode, departmentCode);
                if (membersList.size() == 0) {
                    errMsg += Constants.COMPANY_NOT_FOUND;
                    this.getDataPortalCore();// load data for combo box department
                    return SUCCESS;
                }
            }
        }
        if (!StringUtils.isEmpty(addEmail) && addEmail != null) {
            membersList = pcMgr.getMembersList(emailUserLogin, addEmail, companyCode, departmentCode);
            if (membersList.size() == 0) {
                errMsg += Constants.USER_NOT_FOUND;
                this.getDataPortalCore();// load data for combo box department
                return SUCCESS;
            }
        }
        if (membersList != null && membersList.size() > 0) {
            String manager = StringUtils.EMPTY;
            String link = StringUtils.EMPTY;
            int length = membersList.size();
            int status1 = 1;
            int status3 = 3;
            boolean insertMemberAndProjectBelongInfo3 = false;
            boolean insertMemberIntoProjectInfor1 = false;
            boolean updateMemberAndProjectInfo = false;
            boolean insertMemberAndProjectBelongInfo1 = false;
            boolean insertMemberAndProjectBelongInfo = false;
            boolean insertMemberIntoProjectInfor = false;
            Member mem = new Member();
            Member memberAddNew = new Member();
            Project pro = new Project();
            ProjectBelongInfo bl = new ProjectBelongInfo();

            for (int i = 0; i < length; i++) {
                mem.setEmail(membersList.get(i).getEmail());
                pro.setSeqNo(projectId);
                Member checkExistEmailMember = memberBusiness.checkExistEmailMember(membersList.get(i).getEmail());
                ProjectBelongInfo checkExistMemberOfProject = memberBusiness.checkExistMemberOfProjectAndStatus(
                        projectId, mem, status1);
                ProjectBelongInfo checkExistMemberOfProject3 = memberBusiness.checkExistMemberOfProjectAndStatus(
                        projectId, mem, status3);
                bl.setProject_id(pro);
                bl.setRegistrationDate(DateUtils.convertDateToString(new Date(), Constants.DATE_FORMAT_UPDATE));
                bl.setUpdateDate(DateUtils.convertDateToString(new Date(), Constants.DATE_FORMAT_UPDATE));
                bl.setStatus(Constants.APPROVED_STATUS);
                bl.setIsManager(Constants.ISV_MEMBER);

                if (checkExistMemberOfProject != null) {
                    if (length == 1) {
                        errMsg = Constants.CHECK_EMAIL_EXIST_ERROR;
                        break;
                    } else {
                        continue;
                    }
                } else if (checkExistEmailMember != null && checkExistMemberOfProject3 != null) {
                    checkExistMemberOfProject3.setIsManager(0);
                    checkExistMemberOfProject3.setStatus(1);
                    insertMemberAndProjectBelongInfo3 = memberBusiness
                            .updateMemberIntoProjectBelongInfo(checkExistMemberOfProject3);// Update Member for projectBelongInfor

                    this.addMemberToProject(bl, checkExistEmailMember);// add member to Project.
                    insertMemberIntoProjectInfor1 = memberBusiness.insertMemberIntoProjectInfor(project);

                    manager = checkExistEmailMember.getIsManager();
                    if (manager == null) {
                        manager = StringUtils.EMPTY;
                    }
                    link = checkExistEmailMember.getLink();
                    if (link == null) {
                        link = StringUtils.EMPTY;
                    }
                    // start do update member to another Project
                    updateMemberAndProjectInfo = memberBusiness.updateMemberAndProjectInfo(
                            checkExistEmailMember, link, String.valueOf(projectId), bl, manager,
                            String.valueOf(Constants.ISV_MEMBER));
                    // end do update member to another Project
                    
                    if (insertMemberAndProjectBelongInfo3 && insertMemberIntoProjectInfor1
                            && updateMemberAndProjectInfo) {
                        continue;
                    } else {
                        errMsg = Constants.EMAIL_UPDATE_ERROR;
                    }
                } else {
                    bl.setMember(checkExistEmailMember);
                    if (checkExistEmailMember != null) {
                        bl.setMember(checkExistEmailMember);
                        insertMemberAndProjectBelongInfo1 = memberBusiness
                                .insertMemberIntoProjectBelongInfo(bl);// Insert new Member for projectBelongInfor

                        this.addMemberToProject(bl, checkExistEmailMember);// add member to Project.
                        insertMemberIntoProjectInfor1 = memberBusiness.insertMemberIntoProjectInfor(project);

                         manager = checkExistEmailMember.getIsManager();
                        if (manager == null) {
                            manager = StringUtils.EMPTY;
                        }
                         link = checkExistEmailMember.getLink();
                        if (link == null) {
                            link = StringUtils.EMPTY;
                        }
                        // start do update member to another Project
                        updateMemberAndProjectInfo = memberBusiness.updateMemberAndProjectInfo(
                                checkExistEmailMember, link, String.valueOf(projectId), bl, manager,
                                String.valueOf(Constants.ISV_MEMBER));
                        // end do update member to another Project
                        
                        if (insertMemberAndProjectBelongInfo1 && insertMemberIntoProjectInfor1
                                && updateMemberAndProjectInfo) {
                            continue;
                        } else {
                            errMsg = Constants.EMAIL_UPDATE_ERROR;
                        }
                    } else {
                        memberAddNew.setEmail(membersList.get(i).getEmail());
                        memberAddNew.setLink(String.valueOf(projectId));
                        memberAddNew.setIsManager(String.valueOf(Constants.ISV_MEMBER));
                        memberAddNew.setSeqNo(projectId);
                        bl.setMember(memberAddNew);

                        insertMemberAndProjectBelongInfo = memberBusiness.insertMemberAndProjectBelongInfo(
                                memberAddNew, bl);// Insert new Member for project

                        this.addMemberToProject(bl, memberAddNew);// add member to Project.
                        insertMemberIntoProjectInfor = memberBusiness.insertMemberIntoProjectInfor(project);
                        if (insertMemberAndProjectBelongInfo && insertMemberIntoProjectInfor) {
                            continue;
                        } else {
                            errMsg = Constants.EMAIL_INSERT_ERROR;
                        }
                    }
                }
            }
        }
        this.getDataPortalCore();// load data for combo box department

        return SUCCESS;
    }

    /**
     * getDataPortalCore
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    public void getDataPortalCore() throws Exception {
        PortalCoreAccessManager pcMgr = new PortalCoreAccessManager();
        List<DepartmentEntity> dlist = null;
        HashMap<String, String> companyMap = new LinkedHashMap<String, String>();
        HashMap<String, ArrayList<DepartmentMasterEntity>> departmentMap = new HashMap<>();
        ArrayList<DepartmentMasterEntity> plist = null;

        dlist = pcMgr.getListComPany(null, false);// get data from Portal Core
        if (dlist != null && dlist.size() > 0) {
            List<DepartmentMasterEntity> dmeList = null;
            for (DepartmentEntity d : dlist) {
                companyMap.put(d.getCompanyCode(), d.getCompanyName());
                plist = departmentMap.get(d.getCompanyCode());
                if (plist == null) {
                    plist = new ArrayList<>();
                }
                // start set date to List
                dmeList = d.getDepartment();
                if (dmeList.size() > 0) {
                    DepartmentMasterEntity dme;
                    for (DepartmentMasterEntity de : dmeList) {
                        dme = new DepartmentMasterEntity();
                        dme.setCompanyCode(d.getCompanyCode());
                        dme.setCompanyName(d.getCompanyName());
                        dme.setDepartmentCode(de.getDepartmentCode());
                        dme.setDepartmentName(de.getDepartmentName());
                        plist.add(dme);
                    }
                }
                departmentMap.put(d.getCompanyCode(), plist);
                // end set date to List
            }
            Gson gson = new Gson();
            String departmentJson = gson.toJson(departmentMap);
            request.setAttribute("departmentJson", departmentJson);
            ArrayList<DepartmentMasterEntity> companyList = new ArrayList<>();
            Iterator<Map.Entry<String, String>> ite = companyMap.entrySet().iterator();
            String companyCode = StringUtils.EMPTY;
            String companyName = StringUtils.EMPTY;
            DepartmentMasterEntity dme;
            while (ite.hasNext()) {
                companyCode = ite.next().getKey();
                companyName = companyMap.get(companyCode);
                dme = new DepartmentMasterEntity();
                dme.setCompanyCode(companyCode);
                dme.setCompanyName(companyName);
                companyList.add(dme);// add List record in department Master
            }
            request.setAttribute("companyList", companyList);
        } else {
            errMsg = Constants.COMPANY_NOT_FOUND;
        }
    }

    /**
     * initRegisterProjectMember
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws ConfigurationException 
     * @throws Exception
     * 
     */
    private void initRegisterProjectMember() throws ConfigurationException {
        if (session != null) {
            String email = (String) session.getAttribute("userEmail");
            Member member = memberBusiness.checkExistEmailMember(email);
            if (member != null) {
                listPro = new ArrayList<Project>();
                listPro = projectBusiness.listAllProjectByManager(Constants.APPROVED_STATUS, member,
                        this.getEmailAddress(), isSupportor);
            }
        }
        if (Constants.STATUS_PROJECT_OFF.equals(getStatusProject())) {// first Load page
            if (listPro != null && listPro.size() > 0) {
                project = listPro.get(0);
                session.setAttribute("projectId", project.getSeqNo());
                session.setAttribute("projectName", project.getProjectName());
                listMemberByProjectId = new ArrayList<MemberByProjectIdFormBean>();
                listMemberByProjectId = projectBusiness.listMemberByProjectId(project.getSeqNo());

                PortalCoreAccessManager pcMgr = new PortalCoreAccessManager();
                List<String> emailList = new ArrayList<String>();
                Map<String, Integer> mapEmail = new HashMap<String, Integer>();
                // set Member List.
                setMemberList(pcMgr, emailList, mapEmail);
                checkStatusIsManagerProject();
            }
        }
    }
    
    /**
     * setMemberList
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     * 
     */
    private void setMemberList(PortalCoreAccessManager pcMgr, List<String> emailList, Map<String, Integer> mapEmail) {
        String emailValue = StringUtils.EMPTY;
        String emailMember = StringUtils.EMPTY;
        try {
            if (listMemberByProjectId.size() > 0) {
                for (int i = 0; i < listMemberByProjectId.size(); i++) {
                    emailValue = listMemberByProjectId.get(i).getEmail();
                    mapEmail.put(emailValue.toLowerCase(), i);
                    emailList.add(emailValue);
                }
                membersList = pcMgr.getMembersListById(emailList);// Get list member by list email from Portal core
                
                //START - 20180126 - FPT - for #27465 - Add
                List<MemberJsonDto> listMemberAdd = this.getMemberList(emailList, membersList);
                membersList.addAll(listMemberAdd);
                //END - 20180126 - FPT - for #27465 - Add
                
                if (membersList.size() > 0) {// Mapping list email & status
                    MemberJsonDto mem;
                    int indexStatus = 0;
                    String chkStatus = StringUtils.EMPTY;
                    for (int i = 0; i < membersList.size(); i++) {
                        mem = membersList.get(i);
                        emailMember = mem.getEmail();
                        if (mapEmail.get(emailMember.toLowerCase()) != null) {
                            indexStatus = mapEmail.get(emailMember.toLowerCase());
                        }
                        chkStatus = listMemberByProjectId.get(indexStatus).getCheckBoxStatus();
                        mem.setCheckBoxStatus(Boolean.valueOf(chkStatus));
                        mem.setCreateDate(listMemberByProjectId.get(indexStatus).getCreateDate());
                        mem.setUpdateDate(listMemberByProjectId.get(indexStatus).getUpdateDate());
                        membersList.set(i, mem);
                    }
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    /**
     * getMemberList
     * @param emailList
     * @param listMember
     */
    public List<MemberJsonDto> getMemberList(List<String> emailList, List<MemberJsonDto> listMember) {
        List<MemberJsonDto> listMemberAdd = new ArrayList<MemberJsonDto>();
        StringBuilder strMember = new StringBuilder();
        if (listMember != null && listMember.size() > 0) {
            for (int i = 0; i < listMember.size(); i++) {
                MemberJsonDto memberTemp = listMember.get(i);
                String emailTemp = memberTemp.getEmail();
                strMember.append("," + emailTemp);
            }
        }
        String strMemberLists = strMember.toString();
        if (emailList != null && emailList.size() > 0) {
            MemberJsonDto memberJson = null;
            for (int i = 0; i < emailList.size(); i++) {
                String emailTemp = emailList.get(i);
                if (!strMemberLists.contains(emailTemp)) {
                    memberJson = new MemberJsonDto();
                    memberJson.setEmail(emailTemp);
                    listMemberAdd.add(memberJson);
                }
            }
        }
        return listMemberAdd;
    }
    
    /**
     * checkIsManger
     * 
     * @author FPT
     * @date: 2017/05/05
     * 
     */
    private void checkIsManger(int projectId, String[] partEmail) {
        int isManagerOfMember = 0;
        String emailUpdate = StringUtils.EMPTY;
        for (int i = 0; i < partEmail.length; i++) {
            emailUpdate = partEmail[i];
            isManagerOfMember = memberBusiness.getIsManagerOfMember(projectId, emailUpdate);
            if (isManagerOfCurrentMember > isManagerOfMember) {
                continue;
            } else {// ERROR
                errMsg = errMsg.concat(ErrorCodes.ERRORS_CODE_HAVE_NOT_PERMISSION_UPDATE).concat(emailUpdate)
                        .concat("<br/>");
            }
        }
    }
    

    /**
     * showProjectAndMemberList
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    private void showProjectAndMemberList(String email) {
        Member member = memberBusiness.checkExistEmailMember(email);
        if (member != null) {
            listPro = new ArrayList<Project>();
            listPro = projectBusiness.listAllProjectByManager(Constants.APPROVED_STATUS, member, email, isSupportor);
        }
        listMemberByProjectId = new ArrayList<MemberByProjectIdFormBean>();
        if (project != null) {
            listMemberByProjectId = projectBusiness.listMemberByProjectId(project.getSeqNo());
        }
    }
    
    /**
     * add member into project
     * 
     * @author FPT
     * @date: 2017/05/05
     * @throws Exception
     */
    private void addMemberToProject(ProjectBelongInfo bl, Member memberAddNew) {
        project = projectBusiness.findProjectBySeqNo(bl.getProject_id().getSeqNo());
        Member member = memberBusiness.checkExistEmailMember(memberAddNew.getEmail());
        String strListMember = StringUtils.EMPTY;
        if (member != null) {
            if (project.getMember() != null) {
                strListMember = project.getMember();
            }
            if (strListMember != null && !strListMember.isEmpty()) {
                if (!project.getMember().contains(String.valueOf(member.getSeqNo()))) {
                    project.setMember(project.getMember().concat(",").concat(String.valueOf(member.getSeqNo())));
                }
            } else {
                project.setMember(String.valueOf(member.getSeqNo()));
            }
        }
    }
    
    /**
     * @return the listDetailMember
     */
    public List<Member> getListDetailMember() {
        return listDetailMember;
    }

    /**
     * @param listDetailMember
     *            the listDetailMember to set
     */
    public void setListDetailMember(List<Member> listDetailMember) {
        this.listDetailMember = listDetailMember;
    }

    /**
     * @return the project
     */
    public Project getProject() {
        return project;
    }

    /**
     * @param project
     *            the project to set
     */
    public void setProject(Project project) {
        this.project = project;
    }

    /**
     * @return the findPro
     */
    public Project getFindPro() {
        return findPro;
    }

    /**
     * @param findPro
     *            the findPro to set
     */
    public void setFindPro(Project findPro) {
        this.findPro = findPro;
    }

    /**
     * @return the statusProject
     */
    public String getStatusProject() {
        return statusProject;
    }

    /**
     * @param statusProject
     *            the statusProject to set
     */
    public void setStatusProject(String statusProject) {
        this.statusProject = statusProject;
    }

    /**
     * @return the listMemberByProjectId
     */
    public List<MemberByProjectIdFormBean> getListMemberByProjectId() {
        return listMemberByProjectId;
    }

    /**
     * @param listMemberByProjectId
     *            the listMemberByProjectId to set
     */
    public void setListMemberByProjectId(List<MemberByProjectIdFormBean> listMemberByProjectId) {
        this.listMemberByProjectId = listMemberByProjectId;
    }

    /**
     * @return the seqNo
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo
     *            the seqNo to set
     */
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @return the member
     */
    public Member getMember() {
        return member;
    }

    /**
     * @param member
     *            the member to set
     */
    public void setMember(Member member) {
        this.member = member;
    }

    /**
     * @return the emailMemberAdd
     */
    public String getEmailMemberAdd() {
        return emailMemberAdd;
    }

    /**
     * @param emailMemberAdd
     *            the emailMemberAdd to set
     */
    public void setEmailMemberAdd(String emailMemberAdd) {
        this.emailMemberAdd = emailMemberAdd;
    }

    /**
     * @return the statusPopUp
     */
    public String getStatusPopUp() {
        return statusPopUp;
    }

    /**
     * @param statusPopUp
     *            the statusPopUp to set
     */
    public void setStatusPopUp(String statusPopUp) {
        this.statusPopUp = statusPopUp;
    }

    /**
     * @return the statusButton
     */
    public String getStatusButton() {
        return statusButton;
    }

    /**
     * @param statusButton
     *            the statusButton to set
     */
    public void setStatusButton(String statusButton) {
        this.statusButton = statusButton;
    }

    /**
     * @return the listProBelongInfo
     */
    public List<ProjectBelongInfo> getListProBelongInfo() {
        return listProBelongInfo;
    }

    /**
     * @param listProBelongInfo
     *            the listProBelongInfo to set
     */
    public void setListProBelongInfo(List<ProjectBelongInfo> listProBelongInfo) {
        this.listProBelongInfo = listProBelongInfo;
    }

    /**
     * @return the proBelongInfo
     */
    public ProjectBelongInfo getProBelongInfo() {
        return proBelongInfo;
    }

    /**
     * @param proBelongInfo
     *            the proBelongInfo to set
     */
    public void setProBelongInfo(ProjectBelongInfo proBelongInfo) {
        this.proBelongInfo = proBelongInfo;
    }

    /**
     * @return the projectBelongInfo
     */
    public ProjectBelongInfo getProjectBelongInfo() {
        return projectBelongInfo;
    }

    /**
     * @param projectBelongInfo
     *            the projectBelongInfo to set
     */
    public void setProjectBelongInfo(ProjectBelongInfo projectBelongInfo) {
        this.projectBelongInfo = projectBelongInfo;
    }

    /**
     * @return the addEmail
     */
    public String getAddEmail() {
        return addEmail;
    }

    /**
     * @param addEmail
     *            the addEmail to set
     */
    public void setAddEmail(String addEmail) {
        this.addEmail = addEmail;
    }

    /**
     * @return the errMsg
     */
    public String getErrMsg() {
        return errMsg;
    }
    
    /**
     * @param errMsg
     *            the errMsg to set
     */
    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }
    
    /**
     * @param companyCode
     */
    public String getCompanyCode() {
        return companyCode;
    }

    /**
     * @param companyCode
     *            the companyCode to set
     */
    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    /**
     * @param departmentCode
     */
    public String getDepartmentCode() {
        return departmentCode;
    }

    /**
     * @param departmentCode
     *            the departmentCode to set
     */
    public void setDepartmentCode(String departmentCode) {
        this.departmentCode = departmentCode;
    }

    /**
     * @param emailChecked
     */
    public String getEmailChecked() {
        return emailChecked;
    }

    /**
     * @param emailChecked
     *            the emailChecked to set
     */
    public void setEmailChecked(String emailChecked) {
        this.emailChecked = emailChecked;
    }

    /**
     * @param emailPermisson
     */
    public List<String> getEmailPermisson() {
        return emailPermisson;
    }

    /**
     * @param emailPermisson
     *            the emailPermisson to set
     */
    public void setEmailPermisson(List<String> emailPermisson) {
        this.emailPermisson = emailPermisson;
    }

    /**
     * @param membersList
     */
    public List<MemberJsonDto> getMembersList() {
        return membersList;
    }

    /**
     * @param membersList
     *            the membersList to set
     */
    public void setMembersList(List<MemberJsonDto> membersList) {
        this.membersList = membersList;
    }

}
