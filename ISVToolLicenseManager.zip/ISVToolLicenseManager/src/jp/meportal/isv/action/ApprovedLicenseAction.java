package jp.meportal.isv.action;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.meportal.isv.business.ApprovedLicenseBussiness;
import jp.meportal.isv.business.LicenseBusiness;
import jp.meportal.isv.business.MemberBusiness;
import jp.meportal.isv.business.ProjectBusiness;
import jp.meportal.isv.business.SupporterBusiness;
import jp.meportal.isv.business.impl.ApprovedLicenseBussinessImpl;
import jp.meportal.isv.business.impl.LicenseBusinessImpl;
import jp.meportal.isv.business.impl.MemberBusinessImpl;
import jp.meportal.isv.business.impl.ProjectBusinessImpl;
import jp.meportal.isv.business.impl.SupporterBusinessImpl;
import jp.meportal.isv.common.PortalCoreAccessManager;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.constant.ErrorCodes;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.IpAddressInfo;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.Member;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ServerInfo;
import jp.meportal.isv.entity.Support;
import jp.meportal.isv.formbean.LicenseApproveOrRejectBean;
import jp.meportal.isv.formbean.LicenseFormBean;
import jp.meportal.isv.formbean.ProjectLicenseFromBean;
import jp.meportal.isv.model.MemberJsonDto;
import jp.meportal.isv.util.DateUtils;
import jp.meportal.isv.util.EmailUtil;
import jp.meportal.isv.util.PropertiesUtil;
import jp.meportal.isv.util.SSHFileUtils;
import jp.meportal.isv.util.ServerUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;

/**
 * Class Name: ApprovedLicenseAction<br>
 * Created date: 2017/05/05<br>
 * 
 * @author FPT
 */
public class ApprovedLicenseAction extends BaseAction {
    private static final long serialVersionUID = 1L;
    final static Logger logger = Logger.getLogger(ManagerAction.class);

    public ApprovedLicenseBussiness approvedLicenseBussiness;
    public ProjectBusiness projectBusiness;
    public MemberBusiness memberBusiness;
    public LicenseBusiness licenseBusiness;
    public SupporterBusiness supporterBusiness;
    private Project findPro;
    private List<Project> listPro;
    private List<LicenseApproveOrRejectBean> licenseList;
    private List<LicenseFormBean> listLicenseFormBean;
    private List<IpAddressInfo> ipAddressInsertDBList;
    private List<String> listIpAddress2;
    private int countIpAddress;
    private int countStt;
    private int totalLicenseUnApproved;
    private int totalLicenseApproved;
    public String projectIdList;
    private String comment;
    private String warningMsg;

    private transient HttpSession session = ServletActionContext.getRequest().getSession();
    private transient HttpServletRequest request = ServletActionContext.getRequest();   

    /**
     * ApprovedLicenseAction
     */
    public ApprovedLicenseAction() {
        projectBusiness = new ProjectBusinessImpl();
        approvedLicenseBussiness = new ApprovedLicenseBussinessImpl();
        memberBusiness = new MemberBusinessImpl();
        licenseBusiness = new LicenseBusinessImpl();
        supporterBusiness = new SupporterBusinessImpl();
    }

    /**
     * initApproveLicenseAction
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    public String initApproveLicenseAction() {
        if (!isValidateUser()) {
            return LOGIN;
        }
        String statusList = Constants.UN_APPROVED_STATUS + "," + Constants.APPROVED_STATUS + "," + Constants.DELETED_STATUS;
        List<ProjectLicenseFromBean> unApprovedLicenseList = approvedLicenseBussiness.licenseByStatusList(
                statusList, Constants.UN_APPROVED_STATUS, Constants.DELETED_STATUS);
        List<ProjectLicenseFromBean> approvedLicenseList = approvedLicenseBussiness.licenseByStatusList(statusList,
                Constants.APPROVED_STATUS, Constants.DELETED_STATUS);
        List<String> mailLicenseList = new ArrayList<String>();
        licenseList = new ArrayList<LicenseApproveOrRejectBean>();
        if (unApprovedLicenseList != null && unApprovedLicenseList.size() > 0) {// List License UnApproved
            totalLicenseUnApproved = unApprovedLicenseList.size();
            for (int i = 0; i < totalLicenseUnApproved; i++) {
                ProjectLicenseFromBean projectLicense = unApprovedLicenseList.get(i);
                LicenseApproveOrRejectBean licenseUnApproved = new LicenseApproveOrRejectBean();
                licenseUnApproved.setStatus(Constants.UN_APPROVED_STATUS);
                licenseUnApproved.setSeqNo(projectLicense.getSeqNo());
                licenseUnApproved.setProjectName(projectLicense.getProjectName());
                licenseUnApproved.setComment(projectLicense.getComment());
                
                DateFormat df = new SimpleDateFormat(Constants.DATE_FORMAT_UPDATE);
                String createdDate = df.format(projectLicense.getCreateDate());
                licenseUnApproved.setCreateDate(createdDate);
                licenseUnApproved.setMailRegister(projectLicense.getEmail());
                if (i == 0) {// add List mail Unapproved
                    mailLicenseList.add(projectLicense.getEmail());
                } else {
                    if (mailLicenseList.contains(projectLicense.getEmail())) {
                        licenseList.add(licenseUnApproved);
                        continue;
                    } else {
                        mailLicenseList.add(projectLicense.getEmail());
                    }
                }
                licenseList.add(licenseUnApproved);
            }
        } else {
            totalLicenseUnApproved = Constants.NO_LICENSE;
        }
        if (approvedLicenseList != null && approvedLicenseList.size() > 0) {// List License Approved
            totalLicenseApproved = approvedLicenseList.size();
            for (int i = 0; i < totalLicenseApproved; i++) {
                ProjectLicenseFromBean projectLicense = approvedLicenseList.get(i);
                LicenseApproveOrRejectBean licenseApproved = new LicenseApproveOrRejectBean();
                licenseApproved.setStatus(Constants.APPROVED_STATUS);
                licenseApproved.setSeqNo(projectLicense.getSeqNo());
                licenseApproved.setProjectName(projectLicense.getProjectName());
                licenseApproved.setComment(projectLicense.getComment());
                
                DateFormat df = new SimpleDateFormat(Constants.DATE_FORMAT_UPDATE);
                String createdDate = df.format(projectLicense.getCreateDate());
                licenseApproved.setCreateDate(createdDate);
                licenseApproved.setMailRegister(projectLicense.getEmail());
                licenseApproved.setApprover(projectLicense.getNameApprover());
                String approvedDate = df.format(projectLicense.getApproveDate());
                licenseApproved.setApproveDate(approvedDate);
                
                if (mailLicenseList != null && mailLicenseList.size() > 0) {// add List mail Approved
                    if (mailLicenseList.contains(projectLicense.getEmail())) {
                        licenseList.add(licenseApproved);
                        continue;
                    } else {
                        mailLicenseList.add(projectLicense.getEmail());
                    }
                } else {
                    mailLicenseList.add(projectLicense.getEmail());
                }
                licenseList.add(licenseApproved);
            }
        } else {
            totalLicenseApproved = Constants.NO_LICENSE;
        }
        
        List<Integer> listProId = new ArrayList<Integer>();
        if(licenseList != null && licenseList.size() > 0){
            for (int i = 0; i < licenseList.size(); i++) {
                listProId.add(licenseList.get(i).getSeqNo());
            }
        }
        List<Project> listAllPro = new ArrayList<Project>();
        listAllPro = projectBusiness.listAllProject();
        if(listAllPro != null && listAllPro.size() > 0){
            for (int i = 0; i < listAllPro.size(); i++) {
                if(!listProId.contains(listAllPro.get(i).getSeqNo())){
                    LicenseApproveOrRejectBean projectLicense = new LicenseApproveOrRejectBean();
                    projectLicense.setStatus(5);
                    projectLicense.setProjectName(listAllPro.get(i).getProjectName());
                    projectLicense.setComment(listAllPro.get(i).getComment());
                    projectLicense.setSeqNo(listAllPro.get(i).getSeqNo());
                    licenseList.add(projectLicense);
                }
            }
        }
        
        List<MemberJsonDto> registerInfo = getMemberByMailList(mailLicenseList);
        if (registerInfo != null && registerInfo.size() > 0) {
            for (MemberJsonDto reg : registerInfo) {
                for (int i = 0; i < licenseList.size(); i++) {// get Name register license of PortalCoreService
                    LicenseApproveOrRejectBean licenseInfo = licenseList.get(i);
                    if(!StringUtils.isEmpty(licenseInfo.getMailRegister())){
                        if (reg.getEmail().equals(licenseInfo.getMailRegister())) {
                            licenseInfo.setRegisteredUser(reg.getName());
                        }
                    } else {
                        licenseInfo.setRegisteredUser(StringUtils.EMPTY);
                    }
                }
            }
        }
        return SUCCESS;
    }
    
    /**
     * approveOrRejectLicense
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    public String approveOrRejectLicense() {
        if (!isValidateUser()) {
            return LOGIN;
        }
        Support support = supporterBusiness.getSupportDb(this.getEmailAddress());
        if (support != null) {
            String projectRejects = getProjectId();
            String cmt = getComment();
            String[] listprojectReject = projectRejects.split(",");
            List<Integer> listProId = new ArrayList<Integer>();
            for (int i = 0; i < listprojectReject.length; i++) {
                listProId.add(Integer.valueOf(listprojectReject[i]));
            }
            List<LicenseInfo> licenseInfosList = approvedLicenseBussiness.findLicenseInforByListProId(listProId);
            boolean flagLicense = false;
            if (licenseInfosList != null && licenseInfosList.size() > 0) {
                flagLicense = approvedLicenseBussiness.rejectLicense(listProId, licenseInfosList);
            }
//            boolean flagLicense = approvedLicenseBussiness.rejectLicense(listProId);
            boolean flagIpAddressLicense = approvedLicenseBussiness.rejectIpAddressLicense(listProId);
            if (flagLicense || flagIpAddressLicense) {
                int isManager = Constants.MANAGER_TRUE;
                int userIdUpdater = 0;
                String toMail = StringUtils.EMPTY;
                String userNameUpdater = StringUtils.EMPTY;
                String mailUserLogin = StringUtils.EMPTY;
                String listManager = StringUtils.EMPTY;
                String listSupportor = StringUtils.EMPTY;
                String ccMail = StringUtils.EMPTY;
                String mailManager = StringUtils.EMPTY;
                List<String> mailManagerList = new ArrayList<String>();
                List<MemberJsonDto> registerInfo = null;
                Member member = null;
                Project project = null;
                String departmentNameUpdater = StringUtils.EMPTY;
                for (int i = 0; i < listProId.size(); i++) {
                    project = projectBusiness.findProjectBySeqNo(listProId.get(i));
                    if (project != null) {
                        project.setComment(cmt);
                        project = projectBusiness.updateProject(project, isManager);
                        userIdUpdater = project.getUpdate();
                        member = memberBusiness.findMemberByMemberId(userIdUpdater);
                        if (member != null) {
                            toMail = member.getEmail();
                            // start get Name register license of PortalCoreService
                            mailManagerList.add(toMail);
                            registerInfo = getMemberByMailList(mailManagerList);
                            if (registerInfo != null && registerInfo.size() > 0) {
                                for (int j = 0; j < registerInfo.size(); j++) {
                                    userNameUpdater = registerInfo.get(j).getName();
                                    departmentNameUpdater = registerInfo.get(j).getDepartmentName();
                                }
                            }
                            // end get Name register license of PortalCoreService
                        }
                        try {
                            mailUserLogin = this.getEmailAddress();
                            mailManager = project.getManagerEmail();
                            listManager = memberBusiness
                                    .getAllMailManager(listProId.get(i), mailUserLogin, mailManager);
                            listSupportor = supporterBusiness.getMailList();
                            ccMail = listManager.concat(",").concat(listSupportor);
                            boolean flagSendMail = EmailUtil.sendEmail(Constants.REJECT_LICENSE_SUBJECT,
                                    Constants.HEADER_TEMPLATE_APPROVED_REJECT_LICENSE,
                                    Constants.FOOTER_TEMPLATE_APPROVED_REJECT_LICENSE,
                                    Constants.CONTENT_TEMPLATE_REJECT_LICENSE, toMail, ccMail, userNameUpdater,
                                    departmentNameUpdater, null, null, null, null, null, null, cmt);
                            if (flagSendMail) {
                                warningMsg = PropertiesUtil.getMessageProperties("isv.email.send.success");
                            }
                        } catch (Exception e) {
                            logger.error(e.getMessage(), e);
                        }
                    }
                }
            }
        } else {
            exceptionMsg = ErrorCodes.ERRORS_CODE_CAN_NOT_PERMISSION_REJECT_LICENSE;
            return ERROR;
        }
        return SUCCESS;
    }
    
    /**
     * getMemberByMailList
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    private List<MemberJsonDto> getMemberByMailList(List<String> mailLicenseList) {
        List<MemberJsonDto> memberRegisterLicenseList = null;
        try {
            PortalCoreAccessManager pcMgr = new PortalCoreAccessManager();
            memberRegisterLicenseList = pcMgr.getMembersListById(mailLicenseList);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return memberRegisterLicenseList;
    }

    /**
     * detailLicense
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    public String detailLicense() {
        if (!isValidateUser()) {
            return LOGIN;
        }
        Project project = projectBusiness.findProjectBySeqNo(findPro.getSeqNo());
        int seqNoProject = 0;
        exceptionMsg = StringUtils.EMPTY;
        String emailAddress = this.getEmailAddress();
        Member member = memberBusiness.checkExistEmailMember(emailAddress);
        if (member != null) {
            listPro = new ArrayList<Project>();
            listPro.add(project);
        }
        if (listPro != null && listPro.size() > 0) {
            // Get first list project
            Project firstProject = listPro.get(0);
            session.setAttribute("projectId", firstProject.getSeqNo());
            session.setAttribute("projectName", firstProject.getProjectName());
            // the first load data.
            seqNoProject = firstProject.getSeqNo();
        } else {
            exceptionMsg = ErrorCodes.ERRORS_CODE_PROJECT_NOT_EXIST;
            request.setAttribute(exceptionMsg, exceptionMsg);
            return SUCCESS;
        }
        LicenseAction licenseAction = new LicenseAction();
        listLicenseFormBean = licenseAction.showLicenseInfor(seqNoProject);// show license infor.

        ipAddressInsertDBList = licenseBusiness.listAllIpAddressByProjectId(seqNoProject);// show ipAddress
        if (ipAddressInsertDBList != null) {
            listIpAddress2 = new ArrayList<String>();
            countStt = 0;
            for (IpAddressInfo IpAddress : ipAddressInsertDBList) {
                listIpAddress2.add(IpAddress.getIpaddressTwo());
                countStt++;
                IpAddress.setCountStt(countStt);
            }
            countIpAddress = 0;
            for (int i = 0; i < listIpAddress2.size(); i++) {
                countIpAddress += listIpAddress2.get(i).split(",").length;
            }
            session.setAttribute("countIpAddress", countIpAddress);
        }
        return SUCCESS;
    }

    /**
     * processLicenseApprovedOrReject
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    public String processLicenseApproved () {
        if (!isValidateUser()) {
            return LOGIN;
        }
        boolean flagApproved = false;
        List<Integer> idList = null;
        Support supportExisted = supporterBusiness.getSupportDb(this.getEmailAddress());
        if (supportExisted != null) {
            List<CatalogInfor> catalogApprovedList = null;
            if (projectIdList != null) {
                String statusList = Constants.UN_APPROVED_STATUS + "," + Constants.APPROVED_STATUS;
                // get List catalog process approved with approved license
                catalogApprovedList = approvedLicenseBussiness.getCatalogApprovedList(projectIdList, statusList);
                String dateApproved = DateUtils.convertDateToString(new Date(), Constants.DATE_FORMAT_UPDATE);
                int approverId = supportExisted.getSeqNo();
                boolean updateLicense = approvedLicenseBussiness.approvedProjectLicense(projectIdList, dateApproved,
                        Constants.UN_APPROVED_STATUS);
                if (updateLicense) {
                    flagApproved = approvedLicenseBussiness.updateProjectLicense(approverId, projectIdList,
                            dateApproved, comment);
                }
                String[] splitProjectId = projectIdList.split(",");
                idList = new ArrayList<Integer>();
                for (int i = 0; i < splitProjectId.length; i++) {
                    idList.add(Integer.parseInt(splitProjectId[i]));
                }
            }
            if (flagApproved) {// send mail approved license success
                if (catalogApprovedList != null && catalogApprovedList.size() > 0) {
                    for (CatalogInfor ca : catalogApprovedList) {
                        List<Project> projectList = approvedLicenseBussiness.getProjectApprovedList(ca.getSeqNo(),
                                Constants.APPROVED_STATUS);
                        Map<Project, List<String>> mapIPProject = new HashMap<Project, List<String>>();
                        if (projectList != null && projectList.size() > 0) {
                            for (Project pj : projectList) {
                                List<String> ipAddressList = approvedLicenseBussiness.getAllIpAddressById(pj.getSeqNo(),
                                        Constants.APPROVED_STATUS);
                                if (ipAddressList != null && ipAddressList.size() > 0) {
                                    mapIPProject.put(pj, ipAddressList);
                                } else {
                                    mapIPProject.put(pj, null);
                                }
                            }
                        }
                        try {
                            this.processConfigFile(ca, mapIPProject);
                        } catch (Exception e) {
                            logger.error(e.getMessage(), e);
                        }
                    }
                }
                try {
                    String mailUser = StringUtils.EMPTY;
                    String userNameUpdater = StringUtils.EMPTY;
                    String departmentNameUpdater = StringUtils.EMPTY;
                    String toMail = StringUtils.EMPTY;
                    String ccMail = StringUtils.EMPTY;
                    String mailUpdater = StringUtils.EMPTY;
                    boolean flagSendMail = false;
                    PortalCoreAccessManager pcMgr = new PortalCoreAccessManager();
                    List<String> emailList = new ArrayList<String>();
                    int projectId = 0;
                    for (int i = 0; i < idList.size(); i++) {
                        projectId = idList.get(i);
                        mailUpdater = approvedLicenseBussiness.getMailUpdaterById(projectId);
                        if (i == 0) {
                            emailList.add(mailUpdater);
                        } else {
                            if (emailList.contains(mailUpdater)) {
                                continue;
                            } else {
                                emailList.add(mailUpdater);
                            }
                        }
                    }
                    // get Info updater in PortalCore Service
                    List<MemberJsonDto> managerInfo = pcMgr.getMembersListById(emailList);
                    if (managerInfo != null && managerInfo.size() > 0) {
                        for (int id : idList) {
                            Project project = projectBusiness.findProjectBySeqNo(id);
                            mailUpdater = approvedLicenseBussiness.getMailUpdaterById(id);
                            for (MemberJsonDto mem : managerInfo) {
                                if (mailUpdater.equals(mem.getEmail())) {
                                    userNameUpdater = mem.getName();
                                    departmentNameUpdater = mem.getDepartmentName();
                                    break;
                                }
                            }
                            toMail = mailUpdater;
                            // get all mail manager and support DB have flag = 1
                            String mailManager = project.getManagerEmail();
                            String mailAllManager = memberBusiness.getAllMailManager(id, mailUser, mailManager);
                            String mailSupportDB = supporterBusiness.getMailList();
                            if (mailAllManager.contains(mailSupportDB)) {
                                ccMail = mailAllManager;
                            } else {
                                ccMail = mailAllManager.concat(",").concat(mailSupportDB);
                            }
                            flagSendMail = EmailUtil.sendEmail(Constants.APPROVE_LICENSE_SUBJECT,
                                    Constants.HEADER_TEMPLATE_APPROVED_REJECT_LICENSE,
                                    Constants.FOOTER_TEMPLATE_APPROVED_REJECT_LICENSE,
                                    Constants.CONTENT_TEMPLATE_APPROVED_LICENSE, toMail, ccMail, userNameUpdater,
                                    departmentNameUpdater, null, null, null, null, null, null, null);
                        }
                        if (flagSendMail) {
                            warningMsg = PropertiesUtil.getMessageProperties("isv.email.send.success");
                        }
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
                return SUCCESS;
            }
        } else {
            exceptionMsg = ErrorCodes.ERRORS_CODE_CAN_NOT_APPROVE;
            return ERROR;
        }
        return SUCCESS;
    }

    public void processConfigFile(CatalogInfor catalogInfo, Map<Project, List<String>> mapIPProject) {
        ServerInfo serverInfo = approvedLicenseBussiness.getServerInfoBySeqNo(catalogInfo.getIpAddressServerId());
        if (serverInfo == null)
            return;

        String filePath = catalogInfo.getIpAddressFilePath();

        // SSH connect
        Session session = ServerUtils.getSession(
                  serverInfo.getAccount()
                , serverInfo.getPassword()
                , serverInfo.getServerName()
                , serverInfo.getPort());
        if (session == null)
            return;
        ChannelSftp channel = ServerUtils.getSftpChannel(session);
        if (channel == null)
            return;

        // Path validation
        boolean isFilePath = Pattern.compile(Constants.REGEX_LINUX_PATH).matcher(filePath).matches();
        if (!isFilePath) {
            logger.error("Invalid file path format: " + filePath);
            ServerUtils.disconnectChannel(channel);
            ServerUtils.disconnectSession(session);
            return;
        }

        // Read config file
        String content = SSHFileUtils.getFileContent(channel, filePath);
        Map<String, List<String>> mapProject = new HashMap<String, List<String>>();
        Map<String, List<String>> mapProjectToUpdate = buildMapProject(mapIPProject);
        if (!StringUtils.isEmpty(content)) {
        	content = content.replaceAll("(\\r)", "");
        	mapProject = mergeConfigToMap(mapProjectToUpdate, content);
		}

        content = mapProjectToString(mapProject);

        // write to file
        SSHFileUtils.createFile(channel, filePath, content);

        // Close resources
        ServerUtils.disconnectChannel(channel);
        ServerUtils.disconnectSession(session);
    }

    private String mapProjectToString(Map<String, List<String>> mapProject) {
        if (mapProject == null) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, List<String>> entry : mapProject.entrySet()) {
            // header
            sb.append(entry.getKey() + "\n");

            // body
            List<String> listEntryIP = entry.getValue();
            for (String ip : listEntryIP) {
                sb.append(ip + "\n");
            }

            // newline
            sb.append("\n");
        }

        return sb.toString();
    }

    private Map<String, List<String>> mergeConfigToMap(Map<String, List<String>> mapProjectToUpdate, String content) {
        boolean isContentEmpty = content.isEmpty();
        List<String> contentSplit = null;
        Map<String, List<String>> result = new LinkedHashMap<>();
        if (!isContentEmpty) {
            contentSplit = Arrays.asList(content.split("\n"));

            for (int i = 0; i < contentSplit.size(); i++) {
                String key = contentSplit.get(i);
                String valueContent = StringUtils.EMPTY;
                if (mapProjectToUpdate.containsKey(key)) {
                    // update new data
                    if (mapProjectToUpdate.get(key) != null && mapProjectToUpdate.get(key).size() > 0) {
                        result.put(key, mapProjectToUpdate.get(key));
                    }

                    // Move index to next project
                    i++;
                    if (i == contentSplit.size()) {
                        continue;
                    }
                    while (i < contentSplit.size()) {
                        valueContent = contentSplit.get(i);
                        if (valueContent.equals("")) {
                            break;
                        }
                        i++;
                    }

                    mapProjectToUpdate.remove(key); // done modify
                    continue;
                } else {
                    List<String> listIPValue = new ArrayList<>();
                    i++;
                    valueContent = contentSplit.get(i);
                    while (!valueContent.equals("") && !valueContent.equals("\n")) {
                        listIPValue.add(valueContent);
                        if(i < contentSplit.size() - 1) {
                            i++;
                            valueContent = contentSplit.get(i);
                        }
                        else {
                            break;
                        }
                    }
                    result.put(key, listIPValue);
                }
            }
        }
        // add remaining project to update
        for (Map.Entry<String, List<String>> entry : mapProjectToUpdate.entrySet()) {
            if (entry.getValue() != null) {
                result.put(entry.getKey(), entry.getValue());
            }
        }

        return result;
    }

    private Map<String, List<String>> buildMapProject(Map<Project, List<String>> mapIPProject) {
        if (mapIPProject == null)
            return null;

        Map<String, List<String>> result = new LinkedHashMap<>();
        for (Map.Entry<Project, List<String>> entry : mapIPProject.entrySet()) {
            Project p = entry.getKey();

            // build header
            String header = Constants.CONFIG_HEADER;
            header = header.replaceAll(Constants.VAR_PROJECT_NAME, p.getProjectName())
                    .replaceAll(Constants.VAR_SEQ_NO, String.valueOf(p.getSeqNo()));

            // build list config IP
            List<String> listConfigIP = null;
            if (entry.getValue() != null && entry.getValue().size() > 0) {
                List<String> l = entry.getValue();
                listConfigIP = new ArrayList<>();
                for (String ip : l) {
                    String configIP = Constants.CONFIG_IP;
                    configIP = configIP.replaceAll(Constants.VAR_IP_ADDRESS, ip);
                    listConfigIP.add(configIP);
                }
            }
            
            result.put(header, listConfigIP);
        }
        return result;
    }
    /**
     * @param licenseList
     */
    public List<LicenseApproveOrRejectBean> getLicenseList() {
        return licenseList;
    }

    /**
     * @param licenseList
     *            the licenseList to set
     */
    public void setLicenseList(List<LicenseApproveOrRejectBean> licenseList) {
        this.licenseList = licenseList;
    }

    /**
     * @param totalLicenseUnApproved
     */
    public int getTotalLicenseUnApproved() {
        return totalLicenseUnApproved;
    }

    /**
     * @param totalLicenseUnApproved
     *            the totalLicenseUnApproved to set
     */
    public void setTotalLicenseUnApproved(int totalLicenseUnApproved) {
        this.totalLicenseUnApproved = totalLicenseUnApproved;
    }

    /**
     * @param totalLicenseApproved
     */
    public int getTotalLicenseApproved() {
        return totalLicenseApproved;
    }

    /**
     * @param totalLicenseApproved
     *            the totalLicenseApproved to set
     */
    public void setTotalLicenseApproved(int totalLicenseApproved) {
        this.totalLicenseApproved = totalLicenseApproved;
    }

    /**
     * @return the listPro
     */
    public List<Project> getListPro() {
        return listPro;
    }

    /**
     * @param listPro 
     *            the listPro to set
     */
    public void setListPro(List<Project> listPro) {
        this.listPro = listPro;
    }

    /**
     * @return the findPro
     */
    public Project getFindPro() {
        return findPro;
    }

    /**
     * @param findPro 
     *            the findPro to set
     */
    public void setFindPro(Project findPro) {
        this.findPro = findPro;
    }

    /**
     * @return the ipAddressInsertDBList
     */
    public List<IpAddressInfo> getIpAddressInsertDBList() {
        return ipAddressInsertDBList;
    }

    /**
     * @param ipAddressInsertDBList 
     *                   the ipAddressInsertDBList to set
     */
    public void setIpAddressInsertDBList(List<IpAddressInfo> ipAddressInsertDBList) {
        this.ipAddressInsertDBList = ipAddressInsertDBList;
    }

    /**
     * @return the listIpAddress2
     */
    public List<String> getListIpAddress2() {
        return listIpAddress2;
    }

    /**
     * @param listIpAddress2 
     *                  the listIpAddress2 to set
     */
    public void setListIpAddress2(List<String> listIpAddress2) {
        this.listIpAddress2 = listIpAddress2;
    }

    /**
     * @return the countIpAddress
     */
    public int getCountIpAddress() {
        return countIpAddress;
    }

    /**
     * @param countIpAddress 
     *                  the countIpAddress to set
     */
    public void setCountIpAddress(int countIpAddress) {
        this.countIpAddress = countIpAddress;
    }

    /**
     * @return the countStt
     */
    public int getCountStt() {
        return countStt;
    }

    /**
     * @param countStt 
     *                  the countStt to set
     */
    public void setCountStt(int countStt) {
        this.countStt = countStt;
    }

    /**
     * @return the listLicenseFormBean
     */
    public List<LicenseFormBean> getListLicenseFormBean() {
        return listLicenseFormBean;
    }

    /**
     * @param listLicenseFormBean 
     *                   the listLicenseFormBean to set
     */
    public void setListLicenseFormBean(List<LicenseFormBean> listLicenseFormBean) {
        this.listLicenseFormBean = listLicenseFormBean;
    }

    /**
     * @return the projectIdList
     */
    public String getProjectId() {
        return projectIdList;
    }

    /**
     * @param projectIdList 
     *                   the projectIdList to set
     */
    public void setProjectId(String projectIdList) {
        this.projectIdList = projectIdList;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment 
     *             the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @return the warningMsg
     */
    public String getWarningMsg() {
        return warningMsg;
    }

    /**
     * @param warningMsg 
     *             the warningMsg to set
     */
    public void setWarningMsg(String warningMsg) {
        this.warningMsg = warningMsg;
    }
}
