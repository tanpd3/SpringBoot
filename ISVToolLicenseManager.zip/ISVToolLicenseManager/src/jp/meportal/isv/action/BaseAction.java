package jp.meportal.isv.action;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import jp.meportal.isv.common.PortalCoreAccessManager;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.dao.SupporterDao;
import jp.meportal.isv.dao.impl.SupporterDaoImpl;
import jp.meportal.isv.entity.Support;
import jp.meportal.isv.entity.UserInfo;
import jp.meportal.isv.model.LoginSession;
import jp.meportal.isv.model.UserInfoJsonObject.UserInfoData;
import jp.meportal.isv.util.PropertiesUtil;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.json.me.JSONException;

import com.opensymphony.xwork2.ActionSupport;

/**
 * Class Name: BaseAction<br>
 * Created date: 2017/05/05<br>
 * 
 * @author FPT
 */
public class BaseAction extends ActionSupport {

    private static final long serialVersionUID = 1L;
    private static final Logger log = Logger.getLogger(BaseAction.class);
    
    public static final String strStartHours = PropertiesUtil.getConfigTime(Constants.START_HOURS_CONFIG);
    public static final String strStartMinutes = PropertiesUtil.getConfigTime(Constants.START_MINUTES_CONFIG);
    public static final String strStartSeconds = PropertiesUtil.getConfigTime(Constants.START_SECONDS_CONFIG);
    public static final String strEndHours = PropertiesUtil.getConfigTime(Constants.END_HOURS_CONFIG);
    public static final String strEndMinutes = PropertiesUtil.getConfigTime(Constants.END_MINUTES_CONFIG);
    public static final String strEndSeconds = PropertiesUtil.getConfigTime(Constants.END_SECONDS_CONFIG);
    
    public static final String strStartHoursExportCSV = PropertiesUtil.getConfigTime(Constants.START_HOURS_CONFIG_EXPORT_CSV);
    public static final String strEndHoursExportCSV = PropertiesUtil.getConfigTime(Constants.END_HOURS_CONFIG_EXPORT_CSV);
    public static final String strDayExportCSV = PropertiesUtil.getConfigTime(Constants.DAY_CONFIG_EXPORT_CSV);
    
    private PortalCoreAccessManager pm;
    private SupporterDao supporterDao;
    public String exceptionMsg = "";
    public boolean isSupportor;

    /**
     * initAction
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    public String initAction() {
        supporterDao = new SupporterDaoImpl();
        isSupportor = false;
        String mail = getEmailAddress();
        Support supportorList = supporterDao.getSupportDb(mail);
        if (supportorList != null) {
            isSupportor = true;
        }
        return SUCCESS;
    }
	
    /**
     * isValidateUser
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    protected boolean isValidateUser() {
        boolean result = false;

        try {
            if (getUserInfo(null, ServletActionContext.getRequest()) != null) {
                result = true;
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return result;
    }

    /**
     * getUserInfo
     * 
     * @author FPT
     * @date: 2017/05/05
     */

    public UserInfo getUserInfo(Connection con, HttpServletRequest request) {
        UserInfo userInfo = null;

        try {
            pm = new PortalCoreAccessManager();
            String tokenId = pm.getRequestToTokenId(request);
            if (tokenId == null) {
                return userInfo;
            }

            LoginSession userBean = (LoginSession) request.getSession().getAttribute(Constants.SESSION_LOGIN_USER);

            if (loginCheck(pm, tokenId, request)) {
                if (userBean != null)
                    return userBean.getUser();
            }
            if (userBean != null) {
                if (userBean.getOpenAmTokenId().equals(tokenId)) {
                    userInfo = userBean.getUser();
                } else {
                    userInfo = getOpenAMUserInfo(pm, tokenId, request);
                }
            } else {
                userInfo = getOpenAMUserInfo(pm, tokenId, request);
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return userInfo;
    }

    /**
     * ログイン中チェック.
     * 
     * @param pcMgr
     * @param tokenId
     * @param request
     * @return true:ログイン中
     * @throws URISyntaxException
     * @throws IOException
     * @throws MalformedURLException
     * @throws ConfigurationException
     * @throws SQLException
     * @throws JSONException
     * @throws Exception
     */
    protected boolean loginCheck(PortalCoreAccessManager pcMgr, String tokenId, HttpServletRequest request)
            throws ServletException, MalformedURLException, IOException, URISyntaxException, ConfigurationException,
            SQLException, JSONException {

        LoginSession userBean = (LoginSession) request.getSession().getAttribute(Constants.SESSION_LOGIN_USER);
        if (userBean != null) {

            if (userBean.getOpenAmTokenId().equals(tokenId) && pcMgr.isTokenValid(tokenId)) {

                return true;
            }
            request.getSession().invalidate();
        }
        return false;
    }

    /**
     * Get user information from OpenAM
     * 
     * @author FPT
     * @date: 2017/10/04
     * @param pm
     * @param tokenId
     * @param request
     * @return UserInfo
     **/
    protected UserInfo getOpenAMUserInfo(PortalCoreAccessManager pm, String tokenId, HttpServletRequest request)
            throws ConfigurationException, SQLException, ClientProtocolException, IOException, URISyntaxException {

        UserInfoData openAmUserInfo = null;
        UserInfo userInfo = null;

        openAmUserInfo = pm.getUserInfo(tokenId);

        if (openAmUserInfo != null) {

            userInfo = new UserInfo();
            userInfo.setUid(openAmUserInfo.getUid());
            userInfo.setUserName(openAmUserInfo.getUserName());
            userInfo.setLastName(openAmUserInfo.getUserName());
            userInfo.setUserBelongCompanyCd(openAmUserInfo.getUserBelongCompanyCd());
            userInfo.setUserBelongCompanyName(openAmUserInfo.getUserBelongCompanyName());
            userInfo.setUserBelongDepartmentCd(openAmUserInfo.getUserBelongDepartmentCd());
            userInfo.setUserBelongDepartmentName(openAmUserInfo.getUserBelongDepartmentName());
            userInfo.setEmailAddress(openAmUserInfo.getEmailAddress());
            userInfo.setInnerTelNumber(openAmUserInfo.getInnerTelNumber());
            userInfo.setOuterTelNumber(openAmUserInfo.getOuterTelNumber());
            userInfo.setUserGroupID(openAmUserInfo.getUserGroupID());

            LoginSession newUser = new LoginSession();
            newUser.setUser(userInfo);
            newUser.setOpenAmTokenId(tokenId);

            request.getSession().setAttribute(Constants.SESSION_LOGIN_USER, newUser);

        }

        return userInfo;
    }

    /**
     * getEmailAddress
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    protected String getEmailAddress() {
        UserInfo userInfo = null;
        String emailAddress = null;
        try {
            userInfo = getUserInfo(null, ServletActionContext.getRequest());
            if (userInfo != null) {
                emailAddress = userInfo.getEmailAddress();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return emailAddress;
    }

    /**
     * getUserRole
     * 
     * @author FPT
     * @date: 2017/05/05
     */
    protected String getUserRole() {
        LoginSession userBean = (LoginSession) ServletActionContext.getRequest().getSession()
                .getAttribute(Constants.SESSION_LOGIN_USER);
        return userBean.getUserType();
    }

    /**
     * @param exceptionMsg
     */
    public String getExceptionMsg() {
        return exceptionMsg;
    }

    /**
     * @param exceptionMsg
     *            the exceptionMsg to set
     */
    public void setExceptionMsg(String exceptionMsg) {
        this.exceptionMsg = exceptionMsg;
    }
    
    /**
     * @param isSupportor
     */
    public Boolean getIsSupportor() {
        return isSupportor;
    }

    /**
     * @param isSupportor
     *            the isSupportor to set
     */
    public void setIsSupportor(Boolean isSupportor) {
        this.isSupportor = isSupportor;
    }

}
