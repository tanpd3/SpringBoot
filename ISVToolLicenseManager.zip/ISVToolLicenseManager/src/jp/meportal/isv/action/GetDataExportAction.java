package jp.meportal.isv.action;

import java.math.BigDecimal;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import jp.meportal.isv.business.ManagerLicenseBusiness;
import jp.meportal.isv.business.ProjectBusiness;
import jp.meportal.isv.business.impl.ManagerLicenseBusinessImpl;
import jp.meportal.isv.business.impl.ProjectBusinessImpl;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.entity.LicenseUseInfor;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.formbean.LicenseRegisterBean;
import jp.meportal.isv.formbean.LicenseTotalTaxBean;
import jp.meportal.isv.formbean.LicenseTotalTaxColumn;
import jp.meportal.isv.formbean.LicenseUsedBean;
import org.apache.commons.lang.StringUtils;

public class GetDataExportAction extends BaseAction {
    
    private static final long serialVersionUID = 1L;
    private static final String BLANK = StringUtils.EMPTY;

    public ProjectBusiness projectBusiness;
    public ManagerLicenseBusiness managerLicenseBusiness;

    public List<LicenseTotalTaxBean> listShowTbl3;
    public List<Project> listPro;
    public List<Integer> listYear;
    public List<Integer> listMonth;
    public List<Integer> listProjectId;
    public BigDecimal totalBudget;
    public BigDecimal totalActual;
    public BigDecimal totalBudgetPerPro;
    public BigDecimal totalActualPerPro;

    public Map<Integer, String> mapProject = new HashMap<Integer, String>();
    public Map<Integer, String> mapProductNumber = new HashMap<Integer, String>();
    public Map<Integer, String> mapLoadOriginCode = new HashMap<Integer, String>();
    
    public GetDataExportAction() {
        projectBusiness = new ProjectBusinessImpl();
        managerLicenseBusiness = new ManagerLicenseBusinessImpl();
    }
    
    /**
     * getInforLicenseExport
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    public List<LicenseTotalTaxColumn> getInforLicenseExport(int yearInfor, int monthInfor) {
        List<LicenseTotalTaxColumn> licenTotalTax = null;
        listPro = projectBusiness.listAllProject();
        if (listPro != null) {
            listProjectId = new ArrayList<Integer>();
            for (Project project : listPro) {
                listProjectId.add(project.getSeqNo());
                mapProject.put(project.getSeqNo(), project.getProjectName());
                mapProductNumber.put(project.getSeqNo(), project.getProductNumber());
                mapLoadOriginCode.put(project.getSeqNo(), project.getLoadOriginCode());
            }
        }
        /* Build List month of year finance - END */
        List<LicenseTotalTaxBean> listTbl3Select = new ArrayList<LicenseTotalTaxBean>();
        int yearNomarl = yearInfor;
        List<LicenseUsedBean> ipUsedList = new ArrayList<LicenseUsedBean>();
        ipUsedList = managerLicenseBusiness.getLicenseUseInfor(yearInfor, monthInfor);
        List<String> listMonth = new ArrayList<String>();
        listMonth.add("ls.Apr");
        listMonth.add("ls.May");
        listMonth.add("ls.Jun");
        listMonth.add("ls.Jul");
        listMonth.add("ls.Aug");
        listMonth.add("ls.Sep");
        listMonth.add("ls.Oct");
        listMonth.add("ls.Nov");
        listMonth.add("ls.Dec");
        listMonth.add("ls.Jan");
        listMonth.add("ls.Feb");
        listMonth.add("ls.Mar");
        List<LicenseRegisterBean> proRegisList = new ArrayList<LicenseRegisterBean>();

        for (int i = 0; i < listMonth.size(); i++) {
            if (i < 9) {
                if (i == (monthInfor - 4)) {
                    proRegisList = managerLicenseBusiness.getLicenseRegisInfor(listProjectId, yearNomarl,
                            listMonth.get(i));
                    break;
                }
            } else {
                if (i == (monthInfor + 8)) {
                    proRegisList = managerLicenseBusiness.getLicenseRegisInfor(listProjectId, yearNomarl + 1,
                            listMonth.get(i));
                    break;
                }
            }
        }
        List<LicenseUseInfor> licenseUseInforList = managerLicenseBusiness.getLicenUseInfor();
        List<List<LicenseTotalTaxBean>> listshowTable3 = new ArrayList<List<LicenseTotalTaxBean>>();
        if (licenseUseInforList != null && licenseUseInforList.size() > 0) {
            if (proRegisList != null && proRegisList.size() > 0) {
                if (listProjectId != null && listProjectId.size() > 0) {
                    for (int p = 0; p < listProjectId.size(); p++) {
                        List<Integer> ipListOfProject = managerLicenseBusiness.getListIpAddressByProjectId(
                                listProjectId.get(p), yearInfor);
                        if (proRegisList != null && proRegisList.size() > 0) {
                            List<LicenseTotalTaxColumn> listTotalTax = showdataMonth(proRegisList, ipUsedList,
                                    ipListOfProject);
                            List<LicenseTotalTaxColumn> licenseTotal = new ArrayList<LicenseTotalTaxColumn>();
                            reSetOrderListPro(listTotalTax, licenseTotal, listTbl3Select, mapProject, p,
                                    listshowTable3, listProjectId);
                        } else {
                            String productNumber = BLANK;
                            String proName = BLANK;
                            String loadOriginCode = BLANK;
                            List<LicenseTotalTaxBean> listShowTbl3 = new ArrayList<LicenseTotalTaxBean>();
                            for (Map.Entry<Integer, String> mapProjectName : mapProject.entrySet()) {
                                if (listProjectId.get(p) == mapProjectName.getKey().intValue()) {
                                    proName = mapProjectName.getValue();
                                }
                            }
                            for (Map.Entry<Integer, String> mapProductNumber : mapProductNumber.entrySet()) {
                                if (listProjectId.get(p) == mapProductNumber.getKey().intValue()) {
                                    productNumber = mapProductNumber.getValue();
                                }
                            }
                            for (Map.Entry<Integer, String> mapLoadOriginCode : mapLoadOriginCode.entrySet()) {
                                if (listProjectId.get(p) == mapLoadOriginCode.getKey().intValue()) {
                                    loadOriginCode = mapLoadOriginCode.getValue();
                                }
                            }
                            LicenseTotalTaxBean taxBeanTemp = new LicenseTotalTaxBean();
                            taxBeanTemp.setProjectId(listProjectId.get(p));
                            taxBeanTemp.setCatalogId(0);
                            taxBeanTemp.setLengthLicenseCatalog(1);
                            taxBeanTemp.setProjectName(proName);
                            taxBeanTemp.setProductNumber(productNumber);
                            taxBeanTemp.setLoadOriginCode(loadOriginCode);

                            LicenseTotalTaxColumn taxColumnTemp = new LicenseTotalTaxColumn();
                            taxColumnTemp.setCatalogId(0);
                            taxColumnTemp.setVenderName(Constants.NAME_CATALOG_EMPTY);
                            taxColumnTemp.setToolName(Constants.NAME_CATALOG_EMPTY);
                            taxColumnTemp.setFutureName(Constants.NAME_CATALOG_EMPTY);
                            taxColumnTemp.setCountBudgetPerMonth(0);
                            taxColumnTemp.setCountActualPerMonth(0);
                            taxColumnTemp.setCountSubTractBudgetActual(0);
                            taxColumnTemp.setMemberPrice(BigDecimal.ZERO);
                            taxColumnTemp.setRegularPrice(BigDecimal.ZERO);
                            taxColumnTemp.setMoneyBudgetPerMonth(BigDecimal.ZERO);
                            taxColumnTemp.setMoneyActualPerMonth(BigDecimal.ZERO);
                            taxColumnTemp.setMoreBudgetPerMonth(BigDecimal.ZERO);
                            taxColumnTemp.setSumBudgetAndMoreBudget(BigDecimal.ZERO);
                            List<LicenseTotalTaxColumn> taxListTemp = new ArrayList<LicenseTotalTaxColumn>();
                            taxListTemp.add(taxColumnTemp);
                            taxBeanTemp.setTaxList(taxListTemp);
                            listShowTbl3.add(taxBeanTemp);
                            listshowTable3.add(listShowTbl3);
                        }
                    }
                }
                listShowTbl3 = showTblDetailTax(monthInfor, listshowTable3);// show interface Screen table3.
                if (listShowTbl3 != null && listShowTbl3.size() > 0) {
                    licenTotalTax = showTblSumTaxOfMonth();// show interface Screen table2.
                    List<String> sortProjectNametbl2 = new ArrayList<String>();
                    List<LicenseTotalTaxColumn> listShowFilterTbl2 = new ArrayList<LicenseTotalTaxColumn>();
                    if (licenTotalTax.size() > 0) {
                        for (int i = 0; i < licenTotalTax.size(); i++) {
                            String projectName = licenTotalTax.get(i).getProjectName();
                            sortProjectNametbl2.add(projectName);
                        }
                        Collections.sort(sortProjectNametbl2, Collator.getInstance());
                        for (int jj = 0; jj < sortProjectNametbl2.size(); jj++) {
                            String projectNameSort = sortProjectNametbl2.get(jj);
                            for (int j = 0; j < licenTotalTax.size(); j++) {
                                String projectNameCompare = licenTotalTax.get(j).getProjectName();
                                if (!StringUtils.isEmpty(projectNameSort) && projectNameSort.equals(projectNameCompare)) {
                                    listShowFilterTbl2.add(licenTotalTax.get(j));
                                }
                            }
                        }
                        licenTotalTax = new ArrayList<LicenseTotalTaxColumn>(listShowFilterTbl2);
                    }
                }
            } else {
                return licenTotalTax;
            }
        } else {
            return licenTotalTax;
        }
        return licenTotalTax;
    }

    /**
     * showdataMonth
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    public List<LicenseTotalTaxColumn> showdataMonth(List<LicenseRegisterBean> regisListPro,
            List<LicenseUsedBean> usedListIp, List<Integer> ipListOfProject) {
        Integer countBudgetMonth = 0;
        Integer countAtualMonth = 0;
        Integer subtractBudgetAtual = 0;
        BigDecimal moneyBudgetMonth = BigDecimal.ZERO;
        BigDecimal moneyActualMonth = BigDecimal.ZERO;
        String projectName = BLANK;
        String productNumber = BLANK;
        String loadOriginCode = BLANK;
        Integer licenseUseInfoId = 0;
        Integer licenseRegisId = 0;
        List<LicenseTotalTaxColumn> listTotalTax = new ArrayList<LicenseTotalTaxColumn>();
        for (int k = 0; k < regisListPro.size(); k++) {
            List<Integer> listCatalog = new ArrayList<Integer>();
            if (ipListOfProject != null && ipListOfProject.size() > 0) {
                if (usedListIp != null && usedListIp.size() > 0) {// All listIp used in Month at all Project
                    for (int l = 0; l < usedListIp.size(); l++) {
                        LicenseTotalTaxColumn totalTaxCol = new LicenseTotalTaxColumn();
                        if (ipListOfProject.contains(usedListIp.get(l).getIpAddressId())) {
                            if (regisListPro.get(k).getCatalogId() == usedListIp.get(l).getCatalogId()) {// just a result per a foreach(usedListIp).
                                if (usedListIp.get(l).getUsedSumPerMonth() > regisListPro.get(k).getRegisterSumPerMonth()) {
                                    countBudgetMonth = regisListPro.get(k).getRegisterSumPerMonth();
                                    countAtualMonth = usedListIp.get(l).getUsedSumPerMonth();
                                    subtractBudgetAtual = countAtualMonth - countBudgetMonth;
                                    moneyBudgetMonth = regisListPro.get(k).getMemberPrice().multiply(new BigDecimal(countBudgetMonth));
                                    moneyActualMonth = moneyBudgetMonth.add(regisListPro.get(k)
                                            .getRegularPrice().multiply(new BigDecimal(subtractBudgetAtual)));
                                    projectName = regisListPro.get(k).getProjectName();
                                    productNumber = regisListPro.get(k).getProductNumber();
                                    loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                                    licenseUseInfoId = usedListIp.get(l).getLicenseUseInfoId();
                                    licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                                    setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                                            moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                                            listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
                                } else {
                                    countBudgetMonth = regisListPro.get(k).getRegisterSumPerMonth();
                                    countAtualMonth = usedListIp.get(l).getUsedSumPerMonth();
                                    subtractBudgetAtual = 0;
                                    moneyBudgetMonth = regisListPro.get(k).getMemberPrice().multiply(new BigDecimal(countBudgetMonth));
                                    moneyActualMonth = moneyBudgetMonth;
                                    projectName = regisListPro.get(k).getProjectName();
                                    productNumber = regisListPro.get(k).getProductNumber();
                                    loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                                    licenseUseInfoId = usedListIp.get(l).getLicenseUseInfoId();
                                    licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                                    setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                                            moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                                            listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
                                }
                            } else {//not map catalogID.
                                if(regisListPro.get(k).getRegisterSumPerMonth() > 0 && !listCatalog.contains(regisListPro.get(k).getCatalogId())){
                                    listCatalog.add(regisListPro.get(k).getCatalogId()); // check catalog is one project.
                                    countBudgetMonth = regisListPro.get(k).getRegisterSumPerMonth();
                                    countAtualMonth = 0;
                                    subtractBudgetAtual = 0;
                                    moneyBudgetMonth = regisListPro.get(k).getMemberPrice().multiply(new BigDecimal(countBudgetMonth));
                                    moneyActualMonth = BigDecimal.ZERO;
                                    projectName = regisListPro.get(k).getProjectName();
                                    productNumber = regisListPro.get(k).getProductNumber();
                                    loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                                    licenseUseInfoId = usedListIp.get(l).getLicenseUseInfoId();
                                    licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                                    setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                                            moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                                            listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
                                } else {
                                countBudgetMonth = 0;
                                countAtualMonth = 0;
                                subtractBudgetAtual = 0;
                                moneyBudgetMonth = BigDecimal.ZERO;
                                moneyActualMonth = BigDecimal.ZERO;
                                projectName = regisListPro.get(k).getProjectName();
                                productNumber = regisListPro.get(k).getProductNumber();
                                loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                                licenseUseInfoId = usedListIp.get(l).getLicenseUseInfoId();
                                licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                                setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                                        moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                                        listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
                                }
                            }
                        } else {// this project not regis license in this month.
                            List<Integer> listlicenseUseInfoId = new ArrayList<Integer>();
                            if(listlicenseUseInfoId.size() < 1){
                            countBudgetMonth = regisListPro.get(k).getRegisterSumPerMonth();
                            countAtualMonth = 0;
                            subtractBudgetAtual = 0;
                            moneyBudgetMonth = regisListPro.get(k).getMemberPrice().multiply(new BigDecimal(countBudgetMonth));
                            moneyActualMonth = BigDecimal.ZERO;
                            projectName = regisListPro.get(k).getProjectName();
                            productNumber = regisListPro.get(k).getProductNumber();
                            loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                            licenseUseInfoId = 0;
                            listlicenseUseInfoId.add(licenseUseInfoId);
                            licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                            setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                                    moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                                    listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
                            }
                        }
                    }
                } else {// this project not used license in this month.
                    LicenseTotalTaxColumn totalTaxCol = new LicenseTotalTaxColumn();
                    countBudgetMonth = regisListPro.get(k).getRegisterSumPerMonth();
                    countAtualMonth = 0;
                    subtractBudgetAtual = 0;
                    moneyBudgetMonth = regisListPro.get(k).getMemberPrice()
                            .multiply(new BigDecimal(countBudgetMonth));
                    moneyActualMonth = BigDecimal.ZERO;
                    projectName = regisListPro.get(k).getProjectName();
                    productNumber = regisListPro.get(k).getProductNumber();
                    loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                    licenseUseInfoId = 0;
                    licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                    setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                            moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                            listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
                }
            } else {// this project not regis license in this month.
                LicenseTotalTaxColumn totalTaxCol = new LicenseTotalTaxColumn();
                countBudgetMonth = regisListPro.get(k).getRegisterSumPerMonth();
                countAtualMonth = 0;
                subtractBudgetAtual = 0;
                moneyBudgetMonth = regisListPro.get(k).getMemberPrice()
                        .multiply(new BigDecimal(countBudgetMonth));
                moneyActualMonth = BigDecimal.ZERO;
                projectName = regisListPro.get(k).getProjectName();
                productNumber = regisListPro.get(k).getProductNumber();
                loadOriginCode = regisListPro.get(k).getLoadOriginCode();
                licenseUseInfoId = 0;
                licenseRegisId = regisListPro.get(k).getLicenseRegisId();
                setOrderListPro(countBudgetMonth, countAtualMonth, subtractBudgetAtual,
                        moneyBudgetMonth, moneyActualMonth, projectName, productNumber, regisListPro,
                        listTotalTax, k, totalTaxCol,licenseUseInfoId, licenseRegisId, loadOriginCode);
            }
        }
        return listTotalTax;
    }

    /**
     * showTblDetailTax
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    public List<LicenseTotalTaxBean> showTblDetailTax(int monthSelect, List<List<LicenseTotalTaxBean>> listshowTable3) {
        BigDecimal totalSumTbl3 = BigDecimal.ZERO;
        List<LicenseTotalTaxBean> listShowTbl3 = new ArrayList<LicenseTotalTaxBean>();
        if (listshowTable3 != null && listshowTable3.size() > 0) {
            for (int i = 0; i < listshowTable3.size(); i++) {
                if (monthSelect < 4) {
                    listShowTbl3 = listshowTable3.get(monthSelect + 5);
                } else {
                    listShowTbl3 = listshowTable3.get(monthSelect - 4);
                }
                totalSumTbl3 = getTotalTbl3(totalSumTbl3, listShowTbl3);
                listShowTbl3 = insertProjectNotDataToShow(listShowTbl3, listProjectId);
            }
        }
        return listShowTbl3;
    }

    /**
     * insertProjectNotDataToShow
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    public List<LicenseTotalTaxBean> insertProjectNotDataToShow(List<LicenseTotalTaxBean> listShowTbl3, List<Integer> listProjectId) {
        String projectName = BLANK;
        String productNumber = BLANK;
        String loadOriginCode = BLANK;
        List<Integer> listProId = new ArrayList<Integer>();
        for (int j = 0; j < listShowTbl3.size(); j++) {
            listProId.add(listShowTbl3.get(j).getProjectId());
        }
        for (int k = 0; k < listProjectId.size(); k++) {
            if(!listProId.contains(listProjectId.get(k))){
                for (Map.Entry<Integer, String> mapProjectName : mapProject.entrySet()) {
                    if(listProjectId.get(k) == mapProjectName.getKey().intValue()){
                        projectName = mapProjectName.getValue();
                    }
                 }
                for (Map.Entry<Integer, String> mapProductNumber : mapProductNumber.entrySet()) {
                    if(listProjectId.get(k) == mapProductNumber.getKey().intValue()){
                        productNumber = mapProductNumber.getValue();
                    }
                 }
                for (Map.Entry<Integer, String> mapLoadOriginCode : mapLoadOriginCode.entrySet()) {
                    if(listProjectId.get(k) == mapLoadOriginCode.getKey().intValue()){
                        loadOriginCode = mapLoadOriginCode.getValue();
                    }
                 }
                LicenseTotalTaxBean taxBeanTemp = new LicenseTotalTaxBean();
                taxBeanTemp.setProjectId(listProjectId.get(k));
                taxBeanTemp.setCatalogId(0);
                taxBeanTemp.setLengthLicenseCatalog(1);
                taxBeanTemp.setProjectName(projectName);
                taxBeanTemp.setProductNumber(productNumber);
                taxBeanTemp.setLoadOriginCode(loadOriginCode);
                
                LicenseTotalTaxColumn taxColumnTemp = new LicenseTotalTaxColumn();
                taxColumnTemp.setCatalogId(0);
                taxColumnTemp.setVenderName(Constants.NAME_CATALOG_EMPTY);
                taxColumnTemp.setToolName(Constants.NAME_CATALOG_EMPTY);
                taxColumnTemp.setFutureName(Constants.NAME_CATALOG_EMPTY);
                taxColumnTemp.setCountBudgetPerMonth(0);
                taxColumnTemp.setCountActualPerMonth(0);
                taxColumnTemp.setCountSubTractBudgetActual(0);
                taxColumnTemp.setMemberPrice(BigDecimal.ZERO);
                taxColumnTemp.setRegularPrice(BigDecimal.ZERO);
                taxColumnTemp.setMoneyBudgetPerMonth(BigDecimal.ZERO);
                taxColumnTemp.setMoneyActualPerMonth(BigDecimal.ZERO);
                taxColumnTemp.setMoreBudgetPerMonth(BigDecimal.ZERO);
                taxColumnTemp.setSumBudgetAndMoreBudget(BigDecimal.ZERO);
                List<LicenseTotalTaxColumn> taxListTemp = new ArrayList<LicenseTotalTaxColumn>();
                taxListTemp.add(taxColumnTemp);
                taxBeanTemp.setTaxList(taxListTemp);
                
                listProId.add(listProjectId.get(k));
                listShowTbl3.add(taxBeanTemp);
            }
        }
        return listShowTbl3;
    }

    /**
     * getTotalTbl3
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    public BigDecimal getTotalTbl3(BigDecimal totalSumTbl3, List<LicenseTotalTaxBean> listShowTbl3) {
        totalSumTbl3 = BigDecimal.ZERO;
        if(listShowTbl3 != null && listShowTbl3.size() > 0){
            for (int j = 0; j < listShowTbl3.size(); j++) {
                List<LicenseTotalTaxColumn> subOfsubListShow  = listShowTbl3.get(j).getTaxList();
                for (int k = 0; k < subOfsubListShow.size(); k++) {
                    totalSumTbl3 = totalSumTbl3.add(subOfsubListShow.get(k).getSumBudgetAndMoreBudget());
                }
            }
        }
        return totalSumTbl3;
    }

    /**
     * showTblSumTaxOfMonth
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    public List<LicenseTotalTaxColumn> showTblSumTaxOfMonth() {
        totalBudget = BigDecimal.ZERO;
        totalActual = BigDecimal.ZERO;
        List<LicenseTotalTaxColumn> columnsTemp = null;
        List<LicenseTotalTaxColumn> licenTotalTax = new ArrayList<LicenseTotalTaxColumn>();
        if (listShowTbl3 != null && listShowTbl3.size() > 0) {
            for (int i = 0; i < listShowTbl3.size(); i++) {
                LicenseTotalTaxColumn taxColumn = new LicenseTotalTaxColumn();
                totalBudgetPerPro = BigDecimal.ZERO;
                totalActualPerPro = BigDecimal.ZERO;
                columnsTemp = listShowTbl3.get(i).getTaxList();
                showTblSumTax(totalBudgetPerPro, totalActualPerPro, columnsTemp, i, taxColumn, listShowTbl3,
                        totalBudget, totalActual);
                licenTotalTax.add(taxColumn);
            }
        }
        return licenTotalTax;
    }

    /**
     * showTblSumTax
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    public void showTblSumTax(BigDecimal totalBudgetPerPro, BigDecimal totalActualPerPro,
            List<LicenseTotalTaxColumn> columnsTemp, int i, LicenseTotalTaxColumn taxColumn, List<LicenseTotalTaxBean> listShowTbl3
            , BigDecimal totalBudget, BigDecimal totalActual) {
        taxColumn.setProjectName(listShowTbl3.get(i).getProjectName());
        taxColumn.setProductNumber(listShowTbl3.get(i).getProductNumber());
        taxColumn.setLoadOriginCode(listShowTbl3.get(i).getLoadOriginCode());
        BigDecimal totalsumBudAndAct = BigDecimal.ZERO;
         for (int j = 0; j < columnsTemp.size(); j++) {
             totalBudgetPerPro = totalBudgetPerPro.add(columnsTemp.get(j).getMoneyBudgetPerMonth());
             totalActualPerPro = totalActualPerPro.add(columnsTemp.get(j).getSumBudgetAndMoreBudget());
             totalsumBudAndAct = totalsumBudAndAct.add(columnsTemp.get(j).getSumBudgetAndMoreBudget());
         }
         taxColumn.setMoneyBudgetPerMonth(totalBudgetPerPro);
         taxColumn.setMoneyActualPerMonth(totalActualPerPro);
         totalBudget = totalBudget.add(totalBudgetPerPro);
         totalActual = totalActual.add(totalActualPerPro);
         listShowTbl3.get(i).setSumTaxMoneyPro(totalsumBudAndAct);
    }

    /**
     * setOrderListPro
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    public void setOrderListPro(Integer countBudgetMonth, Integer countAtualMonth, Integer subtractBudgetAtual,
            BigDecimal moneyBudgetMonth, BigDecimal moneyActualMonth, String projectName, String productNumber,
            List<LicenseRegisterBean> regisListPro, List<LicenseTotalTaxColumn> listTotalTax, int k,
            LicenseTotalTaxColumn totalTaxCol, int licenseUseInfoId, int licenseRegisId, String loadOriginCode) {
        totalTaxCol.setLicenseUseInfoId(licenseUseInfoId);
        totalTaxCol.setLicenseRegisId(licenseRegisId);
        totalTaxCol.setProjectName(projectName);
        totalTaxCol.setProductNumber(productNumber);
        totalTaxCol.setProjectId(regisListPro.get(k).getProjectId());
        totalTaxCol.setCountBudgetPerMonth(countBudgetMonth);
        totalTaxCol.setCountActualPerMonth(countAtualMonth);
        totalTaxCol.setCountSubTractBudgetActual(subtractBudgetAtual);
        totalTaxCol.setMoneyBudgetPerMonth(moneyBudgetMonth);
        totalTaxCol.setMoneyActualPerMonth(moneyActualMonth);
        totalTaxCol.setVenderName(regisListPro.get(k).getVenderName());
        totalTaxCol.setToolName(regisListPro.get(k).getToolName());
        totalTaxCol.setFutureName(regisListPro.get(k).getFutureName());
        totalTaxCol.setMemberPrice(regisListPro.get(k).getMemberPrice());
        totalTaxCol.setRegularPrice(regisListPro.get(k).getRegularPrice());
        totalTaxCol.setCatalogId(regisListPro.get(k).getCatalogId());
        totalTaxCol.setLoadOriginCode(loadOriginCode);
        listTotalTax.add(totalTaxCol);// add list listTotalTax
    }

    /**
     * reSetOrderListPro
     * 
     * @author FPT
     * @date: 2017/10/06
     */
    public void reSetOrderListPro(List<LicenseTotalTaxColumn> listTotalTax, List<LicenseTotalTaxColumn> licenseTotal, 
            List<LicenseTotalTaxBean> listShowTbl3, Map<Integer, String> mapProject, int p, List<List<LicenseTotalTaxBean>> listshowTable3, List<Integer> listProjectId) {
        String projectName = BLANK;
            LicenseTotalTaxColumn taxColumn = new LicenseTotalTaxColumn();
            List<LicenseTotalTaxColumn> columnsTempTbl3 = new ArrayList<LicenseTotalTaxColumn>();
            if (listTotalTax != null && listTotalTax.size() > 0) {
                BigDecimal countMoneyBudgetMonth = BigDecimal.ZERO;
                BigDecimal countMoneyActualMonth = BigDecimal.ZERO;
                List<Integer> listCatalogtbl2 = new ArrayList<Integer>();
                for (int k = 0; k < listTotalTax.size(); k++) {//re-SetList project regis.
                    if (listProjectId.get(p) == listTotalTax.get(k).getProjectId() 
                            && !listCatalogtbl2.contains(listTotalTax.get(k).getCatalogId())) {//used for table2.
                        countMoneyBudgetMonth = countMoneyBudgetMonth.add(listTotalTax.get(k)
                                .getMoneyBudgetPerMonth());
                        countMoneyActualMonth = countMoneyActualMonth.add(listTotalTax.get(k)
                                .getMoneyActualPerMonth());
                        projectName = listTotalTax.get(k).getProjectName();
                        listCatalogtbl2.add(listTotalTax.get(k).getCatalogId());//just add 1 catalog per 1 project.
                    }
                    if(listProjectId.get(p) == listTotalTax.get(k).getProjectId()){//used for table3.
                        LicenseTotalTaxColumn taxColumnTbl3 = new LicenseTotalTaxColumn();
                        taxColumnTbl3.setProjectId(listTotalTax.get(k).getProjectId());
                        taxColumnTbl3.setProjectName(listTotalTax.get(k).getProjectName());
                        taxColumnTbl3.setProductNumber(listTotalTax.get(k).getProductNumber());
                        taxColumnTbl3.setLoadOriginCode(listTotalTax.get(k).getLoadOriginCode());
                        taxColumnTbl3.setVenderName(listTotalTax.get(k).getVenderName());
                        taxColumnTbl3.setToolName(listTotalTax.get(k).getToolName());
                        taxColumnTbl3.setFutureName(listTotalTax.get(k).getFutureName());
                        taxColumnTbl3.setCountBudgetPerMonth(listTotalTax.get(k).getCountBudgetPerMonth());
                        taxColumnTbl3.setCountActualPerMonth(listTotalTax.get(k).getCountActualPerMonth());
                        taxColumnTbl3.setMemberPrice(listTotalTax.get(k).getMemberPrice());
                        taxColumnTbl3.setRegularPrice(listTotalTax.get(k).getRegularPrice());
                        taxColumnTbl3.setCatalogId(listTotalTax.get(k).getCatalogId());
                        taxColumnTbl3.setLicenseUseInfoId(listTotalTax.get(k).getLicenseUseInfoId());
                        taxColumnTbl3.setLicenseRegisId(listTotalTax.get(k).getLicenseRegisId());
                        if(listTotalTax.get(k).getCountActualPerMonth() > listTotalTax.get(k).getCountBudgetPerMonth()){//special
                            taxColumnTbl3.setCountSubTractBudgetActual(listTotalTax.get(k).getCountSubTractBudgetActual());
                            taxColumnTbl3.setMoreBudgetPerMonth(taxColumnTbl3.getRegularPrice().multiply(new BigDecimal(taxColumnTbl3.getCountSubTractBudgetActual())));
                            taxColumnTbl3.setMoneyBudgetPerMonth(listTotalTax.get(k).getMemberPrice().multiply(new BigDecimal(listTotalTax.get(k).getCountBudgetPerMonth())));
                            taxColumnTbl3.setMoneyActualPerMonth(taxColumnTbl3.getMoneyBudgetPerMonth().add(taxColumnTbl3.getMoreBudgetPerMonth()));
                        } else {
                            taxColumnTbl3.setCountSubTractBudgetActual(0);
                            taxColumnTbl3.setMoreBudgetPerMonth(taxColumnTbl3.getRegularPrice().multiply(new BigDecimal(taxColumnTbl3.getCountSubTractBudgetActual())));
                            taxColumnTbl3.setMoneyBudgetPerMonth(listTotalTax.get(k).getMemberPrice().multiply(new BigDecimal(listTotalTax.get(k).getCountBudgetPerMonth())));
                            taxColumnTbl3.setMoneyActualPerMonth(taxColumnTbl3.getMoneyBudgetPerMonth());
                        }
                        taxColumnTbl3.setSumBudgetAndMoreBudget(taxColumnTbl3.getMoneyBudgetPerMonth().add(taxColumnTbl3.getMoreBudgetPerMonth()));
                        columnsTempTbl3.add(taxColumnTbl3);
                    }
                }
                taxColumn.setProjectId(listProjectId.get(p));
                taxColumn.setProjectName(projectName);
                taxColumn.setMoneyBudgetPerMonth(countMoneyBudgetMonth);
                taxColumn.setMoneyActualPerMonth(countMoneyActualMonth);
            }
            licenseTotal.add(taxColumn);
            if (columnsTempTbl3 != null && columnsTempTbl3.size() > 0) {
                List<LicenseTotalTaxColumn> reSetTempTbl3List = new ArrayList<LicenseTotalTaxColumn>();
                LicenseTotalTaxBean licenseTotalTaxBean = null;
                List<Integer> listCatalog = null;
                List<Integer> listLicenUseId = null;
                List<Integer> listLicenseRegisId = null;
                for (int j = 0; j < columnsTempTbl3.size(); j++) {//re-set listMapTbl3 per a project in a month.
                    if(!listShowTbl3.contains(listProjectId.get(p))
                            && listProjectId.get(p) == columnsTempTbl3.get(j).getProjectId() 
                            && reSetTempTbl3List.isEmpty()){
                      licenseTotalTaxBean = new LicenseTotalTaxBean();
                      listCatalog = new ArrayList<Integer>();
                      listLicenUseId = new ArrayList<Integer>();
                      listLicenseRegisId = new ArrayList<Integer>();
                      reSetTempTbl3List.add(columnsTempTbl3.get(j));
                      listCatalog.add(columnsTempTbl3.get(j).getCatalogId());
                      listLicenUseId.add(columnsTempTbl3.get(j).getLicenseUseInfoId());
                      listLicenseRegisId.add(columnsTempTbl3.get(j).getLicenseRegisId());
                      licenseTotalTaxBean.setProjectId(columnsTempTbl3.get(j).getProjectId());
                      licenseTotalTaxBean.setProjectName(columnsTempTbl3.get(j).getProjectName());
                      licenseTotalTaxBean.setProductNumber(columnsTempTbl3.get(j).getProductNumber());
                      licenseTotalTaxBean.setLoadOriginCode(columnsTempTbl3.get(j).getLoadOriginCode());
                      licenseTotalTaxBean.setLengthLicenseCatalog(reSetTempTbl3List.size());
                      licenseTotalTaxBean.setTaxList(reSetTempTbl3List);
                    } else {
                        for (int l = 0; l < reSetTempTbl3List.size(); l++) {
                          if (listProjectId.get(p) == reSetTempTbl3List.get(l).getProjectId()
                                  && columnsTempTbl3.get(j).getCatalogId() != reSetTempTbl3List.get(l).getCatalogId()
                                  && !listCatalog.contains(columnsTempTbl3.get(j).getCatalogId())) {
                              reSetTempTbl3List.add(columnsTempTbl3.get(j));
                              listCatalog.add(columnsTempTbl3.get(j).getCatalogId());
                              listLicenUseId.add(columnsTempTbl3.get(j).getLicenseUseInfoId());
                              listLicenseRegisId.add(columnsTempTbl3.get(j).getLicenseRegisId());
                              licenseTotalTaxBean.setLengthLicenseCatalog(reSetTempTbl3List.size());
                              licenseTotalTaxBean.setTaxList(reSetTempTbl3List);
                          } else if(listProjectId.get(p) == reSetTempTbl3List.get(l).getProjectId()
                                  && !listLicenUseId.contains(columnsTempTbl3.get(j).getLicenseUseInfoId())
                                  && columnsTempTbl3.get(j).getMoneyActualPerMonth().compareTo(BigDecimal.ZERO) == 1){
                              reSetTempTbl3List.add(columnsTempTbl3.get(j));
                              listLicenUseId.add(columnsTempTbl3.get(j).getLicenseUseInfoId());
                              listLicenseRegisId.add(columnsTempTbl3.get(j).getLicenseRegisId());
                              licenseTotalTaxBean.setProjectId(columnsTempTbl3.get(j).getProjectId());
                              licenseTotalTaxBean.setProjectName(columnsTempTbl3.get(j).getProjectName());
                              licenseTotalTaxBean.setProductNumber(columnsTempTbl3.get(j).getProductNumber());
                              licenseTotalTaxBean.setLoadOriginCode(columnsTempTbl3.get(j).getLoadOriginCode());
                              licenseTotalTaxBean.setLengthLicenseCatalog(reSetTempTbl3List.size());
                              licenseTotalTaxBean.setTaxList(reSetTempTbl3List);
                          } 
                        }
                      }
                    }
                    listShowTbl3.add(licenseTotalTaxBean);//add licenseTotalTaxBean to show data table3 per month.
                }
                listshowTable3.add(listShowTbl3);
            }
}
