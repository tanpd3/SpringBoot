﻿package jp.meportal.isv.action;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import jp.meportal.isv.business.FileConvertBusiness;
import jp.meportal.isv.business.LicenseBusiness;
import jp.meportal.isv.business.ManagerLicenseBusiness;
import jp.meportal.isv.business.impl.FileConvertBusinessImpl;
import jp.meportal.isv.business.impl.LicenseBusinessImpl;
import jp.meportal.isv.business.impl.ManagerLicenseBusinessImpl;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.ServerInfo;
import jp.meportal.isv.fileconvert.db.DBUpdater;
import jp.meportal.isv.fileconvert.read.BeforeFileMap;
import jp.meportal.isv.fileconvert.read.BeforeFileReader;
import jp.meportal.isv.fileconvert.write.AfterFileWriter;
import jp.meportal.isv.formbean.LicenseTotalTaxColumn;
import jp.meportal.isv.util.CSVHead;
import jp.meportal.isv.util.ExecuteCommand;
import jp.meportal.isv.util.ServerUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import com.jcraft.jsch.Session;

/**
 * File Convert Action ファイル変換Action
 * 
 * @author T.Obara@tsr
 * @since 2017.09.13
 */
public class FileConvertAction extends BaseAction implements Runnable {

    private static final long serialVersionUID = 1L;

    /**
     * Logger
     */
    private static final Logger logger = Logger.getLogger(FileConvertAction.class);

    /**
     * FileConvertBusiness
     */
    public FileConvertBusiness fileConvertBusiness;

    /**
     * LicenseBusiness
     */
    public LicenseBusiness licenseBusiness;

    /**
     * licenTotalTax
     */
    public List<LicenseTotalTaxColumn> licenTotalTax;

    /**
     * managerLicenseBusiness
     */
    public ManagerLicenseBusiness managerLicenseBusiness;

    /**
     * Constructor
     */
    public FileConvertAction() {
        fileConvertBusiness = new FileConvertBusinessImpl();
        licenseBusiness = new LicenseBusinessImpl();
        managerLicenseBusiness = new ManagerLicenseBusinessImpl();
    }

    /**
     * Auto convert file at time from 8:00:00 to 8:59:59 (AM) by config on
     * "configTime.properties" FPT
     */
    @Override
    public void run() {
        int startHours = 0;
        int startMinutes = 0;
        int startSeconds = 0;
        int endHours = 0;
        int endMinutes = 0;
        int endSeconds = 0;

        int startHoursExport = 0;
        int endHoursExport = 0;

        if (!StringUtils.isEmpty(strStartHours)) {
            startHours = Integer.valueOf(strStartHours.trim());
        }
        if (!StringUtils.isEmpty(strStartMinutes)) {
            startMinutes = Integer.valueOf(strStartMinutes.trim());
        }
        if (!StringUtils.isEmpty(strStartSeconds)) {
            startSeconds = Integer.valueOf(strStartSeconds.trim());
        }
        if (!StringUtils.isEmpty(strEndHours)) {
            endHours = Integer.valueOf(strEndHours.trim());
        }
        if (!StringUtils.isEmpty(strEndMinutes)) {
            endMinutes = Integer.valueOf(strEndMinutes.trim());
        }
        if (!StringUtils.isEmpty(strEndSeconds)) {
            endSeconds = Integer.valueOf(strEndSeconds.trim());
        }
        if (!StringUtils.isEmpty(strStartHoursExportCSV)) {
            startHoursExport = Integer.valueOf(strStartHoursExportCSV.trim());
        }
        if (!StringUtils.isEmpty(strEndHoursExportCSV)) {
            endHoursExport = Integer.valueOf(strEndHoursExportCSV.trim());
        }

        Calendar timeStart = Calendar.getInstance();
        timeStart.set(Calendar.HOUR_OF_DAY, startHours);
        timeStart.set(Calendar.MINUTE, startMinutes);
        timeStart.set(Calendar.SECOND, startSeconds);
        timeStart.set(Calendar.HOUR_OF_DAY, startHoursExport);

        Calendar timeEnd = Calendar.getInstance();
        timeEnd.set(Calendar.HOUR_OF_DAY, endHours);
        timeEnd.set(Calendar.MINUTE, endMinutes);
        timeEnd.set(Calendar.SECOND, endSeconds);
        timeEnd.set(Calendar.HOUR_OF_DAY, endHoursExport);

        Calendar timeStartExport = Calendar.getInstance();
        timeStartExport.set(Calendar.HOUR_OF_DAY, startHoursExport);
        timeStartExport.set(Calendar.MINUTE, startMinutes);
        timeStartExport.set(Calendar.SECOND, startSeconds);

        Calendar timeEndExport = Calendar.getInstance();
        timeEndExport.set(Calendar.HOUR_OF_DAY, endHoursExport);
        timeEndExport.set(Calendar.MINUTE, endMinutes);
        timeEndExport.set(Calendar.SECOND, endSeconds);

        Calendar now = Calendar.getInstance();
        // check if time now is ranger on time config (start to end)
        if (now.getTime().after(timeStart.getTime()) && now.getTime().before(timeEnd.getTime())) {
            //String resultConvertFile = this.convertFile();
            //if (ERROR.equals(resultConvertFile)) {
            //    logger.info("run auto convertFile error");
            //}
            String resultOutputDB = this.outputDB();
            if (ERROR.equals(resultOutputDB)) {
                logger.info("run auto outputDB error");
            }
        }

        // update #26156 - START
        int dayExport = now.get(Calendar.DATE);
        // check if time now is ranger on time config (start to end)
        if (dayExport == Integer.valueOf(strDayExportCSV) && now.getTime().after(timeStartExport.getTime())
                && now.getTime().before(timeEndExport.getTime())) {
            String resultExportFile = this.timerExportCSV();
            if (ERROR.equals(resultExportFile)) {
                logger.info("run auto export CSV error");
            }
        }
        // update #26156 - END
    }

    /**
     * timerExportCSV
     * 
     * @author FPT
     * @date: 2017/12/14
     */
    public String timerExportCSV() {
        // getTime() returns the current date in default time zone
        Calendar now = Calendar.getInstance();
        int monthExport = now.get(Calendar.MONTH) + 1;
        int yearExport = now.get(Calendar.YEAR);
        if (monthExport == 1) {
            monthExport = 12;
            yearExport = yearExport - 1;
        } else {
            monthExport = monthExport - 1;
        }
        Date date = new Date();
        String strDateFormat = Constants.DATE_TIME_CSV_FORMAT_SUPORTER;
        DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
        String formatDate = dateFormat.format(date);
        String fileName = Constants.CSV_EXPORT_NAME_SUPPORTER + yearExport + monthExport + Constants.DASH_UNDER
                + formatDate + ".csv";
        boolean errorFlag = false;
        List<ServerInfo> listServerInfor = managerLicenseBusiness.getServerInforList();

        if (listServerInfor != null && listServerInfor.size() > 0) {
            for (int i = 0; i < listServerInfor.size(); i++) {
                if (listServerInfor.get(i) != null) {
                    Session session = null;
                    // SSHで接続
                    session = this.getSessionConnect(listServerInfor.get(i));
                    if (session == null) {
                        errorFlag = true;
                        continue;
                    }
                    String dirPath = listServerInfor.get(i).getAccountingFolder();
                    if (!StringUtils.isEmpty(dirPath)) {
                        // check if accounting_folder is null then not execute.
                        String filePath = dirPath + Constants.SlASH_CHARACTERS + fileName;
                        // 変換実行
                        if (!this.writeExport(session, dirPath, filePath, yearExport, monthExport)) {
                            errorFlag = true;
                            session.disconnect();
                            continue;
                        }
                        if (session != null) {
                            session.disconnect();
                        }
                    }
                }
            }
        }
        if (errorFlag) {
            return ERROR;
        }
        return SUCCESS;
    }

    /**
     * writeExport
     * 
     * @author FPT
     * @date: 2017/11/27
     */
    private boolean writeExport(Session session, String dirPath, String filePath, int year, int month) {
        boolean successAll = true;
        GetDataExportAction getDataExportAction = new GetDataExportAction();
        // call function check forlder
        this.makeDirectory(session, dirPath);
        // 出力ファイルが既にあったらバックアップを取っておく
        if (this.isExistsFile(session, filePath) == true) {
            // if exits file then delete file.
            this.deleteFile(session, filePath);
        }
        // 変換後ファイルの一行を作成
        StringBuilder line = new StringBuilder();
        String resultExport = StringUtils.EMPTY;
        List<LicenseTotalTaxColumn> licenTotalTaxExport = null;
        //get data from DB
        licenTotalTaxExport = getDataExportAction.getInforLicenseExport(year, month);
        // get title columns
        line.append(CSVHead.getProjectName()).append(Constants.COMMA);
        line.append(CSVHead.getProductNumberSupporter()).append(Constants.COMMA);
        line.append(CSVHead.getLoadOriginCodeSupporter()).append(Constants.COMMA);
        line.append(CSVHead.getTotalPriceSupporter()).append(Constants.COMMA).append(Constants.LINE_SEPARATOR);

        if (licenTotalTaxExport != null) {
         // Export data to csv file
            for (LicenseTotalTaxColumn licenseTotalTaxColumn : licenTotalTaxExport) {
                String projectName = licenseTotalTaxColumn.getProjectName();
                String productNumber = licenseTotalTaxColumn.getProductNumber();
                String loadOriginCode = licenseTotalTaxColumn.getLoadOriginCode();
                String moneyActualPerMonth = (Long.valueOf(licenseTotalTaxColumn.getMoneyActualPerMonth()
                        .longValue())).toString();

                line.append(projectName).append(Constants.COMMA);
                line.append(productNumber).append(Constants.COMMA);
                line.append(loadOriginCode).append(Constants.COMMA);
                line.append(moneyActualPerMonth).append(Constants.COMMA);
                line.append(Constants.LINE_SEPARATOR);
            }
        }
        resultExport = line.toString();
        String strExport = StringUtils.EMPTY;
        try {
            byte[] byteText = resultExport.getBytes(Charset.forName("UTF-8"));
            // To get original string from byte.
            strExport = new String(byteText, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            logger.error(e.getMessage(), e);
        }
        if (!this.appendFile(session, filePath, strExport)) {
            logger.error("Failed to write file: " + filePath);
            return false;
        }
        return successAll;
    }

    /**
     * Delete file
     * ファイル削除
     * @param session   Session
     * @param filePath  ファイルパス
     * @return  true: 成功 / false: 失敗
     */
    private boolean deleteFile(Session session, String filePath) {
        String command = Constants.COMMAND_RM + filePath;

        // コマンド実行
        ExecuteCommand executeCommand = new ExecuteCommand();
        executeCommand.executeCommand(session, command);
        if (executeCommand.exitStatus != 0) {
            return false;
        }

        return true;
    }

    /**
     * Append to file
     * ファイルに追記
     * @param session   Session
     * @param filePath  ファイルパス
     * @param contents  追記する内容
     * @return  true: 正常終了 / false: 異常終了
     */
    private boolean appendFile(Session session, String filePath, String contents) {
        String command = "echo " + "'" + contents + "'" + " >> " + filePath;

        // コマンド実行
        ExecuteCommand executeCommand = new ExecuteCommand();
        executeCommand.executeCommand(session, command);
        if (executeCommand.exitStatus != 0) {
            return false;
        }
        return true;
    }

    /**
     * Make directory
     * ディレクトリ作成
     * @param session   Session
     * @param dirPath   ディレクトリパス
     * @return  true: 成功 / false: 失敗
     */
    private boolean makeDirectory(Session session, String dirPath) {
        String command = Constants.COMMAND_MKDIR_IF_EXISTS + dirPath;

        // コマンド実行
        ExecuteCommand executeCommand = new ExecuteCommand();
        executeCommand.executeCommand(session, command);
        if (executeCommand.exitStatus != 0) {
            return false;
        }

        return true;
    }

    /**
     * Convert file
     * ファイル変換
     * @return String
     */
    public String convertFile() {
        boolean errorFlag = false;

        List<CatalogInfor> listCatalogInfor = this.getCatalogInfor();

        if (listCatalogInfor != null && listCatalogInfor.size() > 0) {
            for (CatalogInfor catalogInfor : listCatalogInfor) {
                ServerInfo serverInfo = getServerInfo(catalogInfor);
                Session session = null;

                if (serverInfo != null) {
                    // SSHで接続
                    session = this.getSessionConnect(serverInfo);
                    if (session == null) {
                        errorFlag = true;
                        continue;
                    }
                }
                // 変換前ファイルの読み込み
                BeforeFileMap map = this.readBeforeFile(session, catalogInfor);
                if (map == null) {
                    // errorFlag = true;
                    logger.info("convertFile : map is null");
                    session.disconnect();
                    continue;
                }

                // 変換実行
                if (!this.writeAfterFile(session, map, catalogInfor)) {
                    errorFlag = true;
                    session.disconnect();
                    continue;
                }

                if (session != null) {
                    session.disconnect();
                }
            }
        }
        if (errorFlag) {
            return ERROR;
        }
        return SUCCESS;
    }

    /**
     * Output DB
     * DB出力
     * @return String
     */
    public String outputDB() {
        boolean errorFlag = false;

        List<CatalogInfor> listCatalogInfor = this.getCatalogInfor();

        if (listCatalogInfor != null && listCatalogInfor.size() > 0) {
            for (CatalogInfor catalogInfor : listCatalogInfor) {
                ServerInfo serverInfo = getServerInfo(catalogInfor);
                Session session = null;

                if (serverInfo != null) {
                    // SSHで接続
                    session = this.getSessionConnect(serverInfo);
                    if (session == null) {
                        errorFlag = true;
                        continue;
                    }
                }

                // 変換前ファイルの読み込み
                BeforeFileMap map = this.readBeforeFile(session, catalogInfor);
                if (map == null) {
                    // errorFlag = true;
                    logger.info("outputDB : map is null");
                    session.disconnect();
                    continue;
                }

                // DB出力
                if (!this.outputDB(session, map, catalogInfor)) {
                    errorFlag = true;
                    if (session != null) {
                        session.disconnect();
                    }
                    continue;
                }

                if (session != null) {
                    session.disconnect();
                }
            }
        }

        if (errorFlag) {
            return ERROR;
        }
        return SUCCESS;
    }

    /**
     * Get catalog infor
     * カタログ情報の取得
     * @return  カタログ情報
     */
    private List<CatalogInfor> getCatalogInfor() {
        List<CatalogInfor> listCatalogInfor = this.licenseBusiness.listAllCatalogInfo();
        return listCatalogInfor;
    }

    /**
     * Get server info
     * サーバー情報の取得
     * @param catalogInfor  カタログ情報
     * @return  サーバー情報
     */
    private ServerInfo getServerInfo(CatalogInfor catalogInfor) {
        int seqNo = catalogInfor.getResultServerId();
        ServerInfo serverInfo = this.fileConvertBusiness.findServerInfoBySeqNo(seqNo);
        return serverInfo;
    }

    /**
     * SSH接続のSessionを取得
     * Get session by SSH
     * @param serverInfo    サーバー情報
     * @return  Session
     * @see jp.meportal.hpc.action.BaseAction#getSessionConnect()
     */
    private Session getSessionConnect(ServerInfo serverInfo) {
        String username = serverInfo.getAccount();
        String password = serverInfo.getPassword();
        String host = serverInfo.getServerName();
        int port = serverInfo.getPort();
        if (username != null && password != null && host != null && port > 0) {
            Session session = ServerUtils.getSession(username, password, host, port);
            return session;
        }
        return null;
    }

    /**
     * Read before file
     * 変換前ファイルの読み込み
     * @param session       Session
     * @param catalogInfor  カタログ情報
     * @return  変換前ファイルのデータ(読み込み失敗時はnull)
     */
    private BeforeFileMap readBeforeFile(Session session, CatalogInfor catalogInfor) {
        String beforeFilePath = catalogInfor.getResultFileBeforePath();
        if (beforeFilePath == null || beforeFilePath.isEmpty()) {
            logger.error("Before file path is null or empty");
            return null;
        }

        // 変換前ファイルがなければ終わり
        if (!this.isExistsFile(session, beforeFilePath)) {
            // ファイルがないときは読み込み失敗にしない
            return new BeforeFileMap();
        }

        BeforeFileReader reader = new BeforeFileReader();
        if (!reader.read(session, beforeFilePath)) {
            return null;
        }

        BeforeFileMap map = reader.getBeforeFileMap();
        return map;
    }

    /**
     * Write after file
     * 変換後ファイルの書き込み
     * @param session           Session
     * @param beforeFileMap     変換前ファイルのデータ
     * @param catalogInfor      カタログ情報
     * @return  true: 正常終了 / false: 異常終了
     */
    private boolean writeAfterFile(Session session, BeforeFileMap beforeFileMap, CatalogInfor catalogInfor) {
        String afterFilePath = catalogInfor.getResultFileAfterPath();
        if (afterFilePath == null || afterFilePath.isEmpty()) {
            logger.error("After file path is null or empty");
            return false;
        }

        AfterFileWriter writer = new AfterFileWriter();
        boolean bWrite = writer.write(session, afterFilePath, beforeFileMap, catalogInfor);
        return bWrite;
    }

    /**
     * Check file exists
     * ファイル存在チェック
     * @param session   Session
     * @param filePath  ファイルパス
     * @return  true: 存在する / false: 存在しない
     */
    private boolean isExistsFile(Session session, String filePath) {
        String command = "[ -f " + filePath + " ] && " + Constants.COMMAND_ECHO_YES_NO;

        // コマンド実行
        ExecuteCommand executeCommand = new ExecuteCommand();
        List<String> result = executeCommand.executeCommand(session, command);
        if (result != null && result.size() > 0) {
            if (Constants.FILE_EXISTS.equals(result.get(0))) {
                return true;
            }
        }

        return false;
    }

    /**
     * Output DB
     * DB出力
     * @param session           Session
     * @param beforeFileMap     変換前ファイルのデータ
     * @param catalogInfor      カタログ情報
     * @return  true: 正常終了 / false: 異常あり
     */
    private boolean outputDB(Session session,
                             BeforeFileMap beforeFileMap,
                             CatalogInfor catalogInfor)
    {
        DBUpdater db = new DBUpdater();
        boolean success = db.update(beforeFileMap, catalogInfor);
        return success;
    }

}