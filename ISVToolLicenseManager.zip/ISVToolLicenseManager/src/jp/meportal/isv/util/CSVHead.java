package jp.meportal.isv.util;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import jp.meportal.isv.constant.Constants;

public class CSVHead {
    private static final Logger log = Logger.getLogger(CSVHead.class);
    private static PropertiesConfiguration properties = null;

    static {
        try {
            properties = new PropertiesConfiguration(
                    Constants.PROPERETIES_CSV_PATH);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private static String getString(String key) {
        String value = StringUtils.EMPTY;
        if (properties != null)
            value = properties.getString(key);

        return value;
    }

    public static String getProjectLable() {
        return getString("isv.project_csv");
    }

    public static String getYearLable() {
        return getString("isv.year_csv");
    }

    public static String getMonthLable() {
        return getString("isv.month_csv");
    }

    public static String getExecuteTimeCount() {
        return getString("isv.execution_time_count");
    }

    public static String getProductNumber() {
        return getString("isv.product_number.label");
    }

    public static String getProjectName() {
        return getString("isv.project_name.label");
    }

    public static String getLoadOriginCode() {
        return getString("isv.load_origin_code.label");
    }

    public static String getProductNumberSupporter() {
        return getString("isv.product_number_supporter.label");
    }

    public static String getLoadOriginCodeSupporter() {
        return getString("isv.load_origin_code_supporter.label");
    }

    public static String getTotalPriceSupporter() {
        return getString("isv.total_price_supporter.label");
    }

    public static String getAccountName() {
        return getString("isv.account_name");
    }

    public static String getVendorName() {
        return getString("isv.vendor_name");
    }

    public static String getToolName() {
        return getString("isv.tool_name");
    }

    public static String getFutureName() {
        return getString("isv.future_name");
    }

    public static String getHost() {
        return getString("isv.host");
    }

    public static String getExecuteTime() {
        return getString("isv.execute_time");
    }

    public static String getExecuteNumber() {
        return getString("isv.execute_number");
    }

    public static String getReference() {
        return getString("isv.reference");
    }

    public static String getTotal() {
        return getString("isv.total");
    }

    public static String getGrandTotal() {
        return getString("isv.grand_total");
    }

    public static String getSimultaneousUseNumber() {
        return getString("isv.simultaneous_use_number");
    }

    public static String getFilterTool() {
        return getString("isv.filter_tool");
    }

    public static String getFilterProduct() {
        return getString("isv.filter_product_number");
    }

    public static String getFilterProject() {
        return getString("isv.filter_project");
    }

    public static String getAllProject() {
        return getString("isv.all_project");
    }

    public static String getTblBudAct() {
        return getString("isv.tbl_bud_act");
    }

    public static String getActual() {
        return getString("isv.actual");
    }

    public static String getBudget() {
        return getString("isv.budget");
    }

    public static String getQ1() {
        return getString("isv.q1");
    }

    public static String getQ2() {
        return getString("isv.q2");
    }

    public static String getQ3() {
        return getString("isv.q3");
    }

    public static String getQ4() {
        return getString("isv.q4");
    }

    public static String getFirstSixMonth() {
        return getString("isv.first_6_month");
    }

    public static String getSecondSixMonth() {
        return getString("isv.second_6_month");
    }

    public static String getTotalYear() {
        return getString("isv.total_year");
    }

    public static String getMonth1() {
        return getString("isv.month_1");
    }

    public static String getMonth2() {
        return getString("isv.month_2");
    }

    public static String getMonth3() {
        return getString("isv.month_3");
    }

    public static String getMonth4() {
        return getString("isv.month_4");
    }

    public static String getMonth5() {
        return getString("isv.month_5");
    }

    public static String getMonth6() {
        return getString("isv.month_6");
    }

    public static String getMonth7() {
        return getString("isv.month_7");
    }

    public static String getMonth8() {
        return getString("isv.month_8");
    }

    public static String getMonth9() {
        return getString("isv.month_9");
    }

    public static String getMonth10() {
        return getString("isv.month_10");
    }

    public static String getMonth11() {
        return getString("isv.month_11");
    }

    public static String getMonth12() {
        return getString("isv.month_12");
    }

    public static String getCumulative() {
        return getString("isv.cumulative");
    }

    public static String getTotalPerMonth() {
        return getString("isv.total_permonth");
    }

    public static String getTypeCharge() {
        return getString("isv.type_charge");
    }

    public static String getTaxRegis() {
        return getString("isv.tax_regis");
    }

    public static String getMoneyBudget() {
        return getString("isv.money_budget");
    }
    
    public static String getMoneyActual() {
        return getString("isv.money_actual");
    }

    public static String getTaxUse() {
        return getString("isv.tax_use");
    }

    public static String getStar1() {
        return getString("isv.star1");
    }

    public static String getStar2() {
        return getString("isv.star2");
    }

    public static String getSumaryPerMonth() {
        return getString("isv.sumary_per_month");
    }

    public static String getTaxUseRegis() {
        return getString("isv.tax_use_regis");
    }

    public static String getDashChar() {
        return getString("isv.dash_char");
    }

    public static String getBillingDetail() {
        return getString("isv.billing_detail");
    }

    public static String getUseLicense() {
        return getString("isv.use_license");
    }

    public static String getRegisLicense() {
        return getString("isv.regis_license");
    }

    public static String getBaseUsed() {
        return getString("isv.base_used");
    }
    
    public static String getChargeUse() {
        return getString("isv.charge_use");
    }

    public static String getUnitPrice() {
        return getString("isv.unit_price");
    }

    public static String getCharge() {
        return getString("isv.charge");
    }

    public static String getLicenseUseSame() {
        return getString("isv.license_use_same");
    }

    public static String getBasic() {
        return getString("isv.basic");
    }

    public static String getQuanlity() {
        return getString("isv.quanlity");
    }
}

