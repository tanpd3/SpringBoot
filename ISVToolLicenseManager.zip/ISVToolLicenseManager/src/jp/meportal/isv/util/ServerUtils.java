package jp.meportal.isv.util;

import java.util.Properties;

import org.apache.log4j.Logger;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class ServerUtils {
    // INSTANCE;
    private static final Logger log = Logger.getLogger(ServerUtils.class);
    private static final int SESSION_TIMEOUT = 3000;

    public ServerUtils() {
        super();
    }

    /**
     * Connect to SSH
     * 
     * @param USERNAME
     * @param PASSWORD
     * @param HOST
     * @param PORT
     * @return SSH Session
     */
    public static Session getSession(String USERNAME, String PASSWORD, String HOST, int PORT) {
        Session session = null;
        JSch jsch = new JSch();
        try {
            session = jsch.getSession(USERNAME, HOST, PORT);
        } catch (JSchException e) {
            log.error(e.getMessage());
            return null;
        }

        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        config.put("PreferredAuthentications", "password");
        session.setConfig(config);
        session.setPassword(PASSWORD);

        try {
            session.connect(SESSION_TIMEOUT);
        } catch (JSchException e) {
            log.error(e.getMessage());
        }

        return session;
    }

    /**
     * Disconnect session
     * 
     * @param session
     */
    public static void disconnectSession(Session session) {
        if (session != null) {
            session.disconnect();
        }
    }

    /**
     * Open SFTP Channel
     * 
     * @param session
     * @return Channel
     * @throws JSchException
     */
    public static ChannelSftp getSftpChannel(Session session) {
        ChannelSftp channel = null;

        if (session != null) {
            try {
                channel = (ChannelSftp) session.openChannel("sftp");
                channel.connect();
            } catch (JSchException e) {
                log.error(e.getMessage());
            }
        }

        return channel;
    }

    /**
     * Close Channel
     * 
     * @param channel
     */
    public static void disconnectChannel(Channel channel) {
        if (channel != null) {
            channel.disconnect();
        }
    }
}
