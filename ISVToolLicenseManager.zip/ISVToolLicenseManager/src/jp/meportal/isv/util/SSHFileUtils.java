package jp.meportal.isv.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.SftpException;

public class SSHFileUtils {
    static final Logger log = Logger.getLogger(SSHFileUtils.class);

    public SSHFileUtils() {
        super();
    }

    /**
     * Read file content from given filePath
     * 
     * @param channel
     * @param filePath
     * @return content
     */
    public static String getFileContent(ChannelSftp channel, String filePath) {
        String result = null;
        InputStream is = null;
        ByteArrayOutputStream baos = null;
        Path path = Paths.get(filePath);
        String fileName = path.getFileName().toString();
        String pathFolder = path.getParent().toString();
        pathFolder = pathFolder.replaceAll("\\\\", "/"); // linux file path
        ensurePathFolder(channel, pathFolder);
        boolean isFileExists = false;
        try {
            @SuppressWarnings("unchecked")
            Vector<LsEntry> vLs = (Vector<LsEntry>) channel.ls(pathFolder);
            for (LsEntry ls : vLs) {
                if (ls.getFilename().equals(fileName)) {
                    is = channel.get(filePath);
                    isFileExists = true;
                    break;
                }
            }
        } catch (SftpException e) {
            log.error(e.getMessage());
        }

        // If not exist, create new file
        if (!isFileExists) {
            try {
                result = "";
                channel.cd(pathFolder);
                channel.put(new ByteArrayInputStream(result.getBytes(StandardCharsets.UTF_8)), fileName);
            } catch (SftpException e) {
                log.error(e.getMessage());
            }
        } else {
            baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int length;
            try {
                while ((length = is.read(buffer)) != -1) {
                    baos.write(buffer, 0, length);
                }
                result = baos.toString(StandardCharsets.UTF_8.toString());
            } catch (IOException e) {
                log.error(e.getMessage());
            } finally {
                if (is != null) {
                    try {
                        is.close();
                    } catch (IOException ex1) {
                        log.error(ex1.getMessage());
                    }
                }
                if (baos != null) {
                    try {
                        baos.close();
                    } catch (IOException ex2) {
                        log.error(ex2.getMessage());
                    }
                }
            }
        }
        return result;
    }

    /**
     * Ensure that pathFolder exists. Create any folder that not exist on
     * pathFolder.
     * 
     * @param channel
     * @param pathFolder
     */
    private static void ensurePathFolder(ChannelSftp channel, String pathFolder) {
        String[] pathSplit = pathFolder.split("/");
        StringBuilder sbPath = new StringBuilder();
        try {
            for (int i = 0; i < pathSplit.length - 1; i++) {
                sbPath.append(pathSplit[i] + "/");
                @SuppressWarnings("unchecked")
                Vector<LsEntry> vLs = (Vector<LsEntry>) channel.ls(sbPath.toString());

                String checkFolder = pathSplit[i + 1]; // next subfolder
                boolean foundFolder = false;
                for (LsEntry ls : vLs) {
                    if (ls.getFilename().equals(checkFolder)) {
                        foundFolder = true;
                        break;
                    }
                }
                if (!foundFolder) {
                    // if not found, mkdir the next folder
                    channel.mkdir(sbPath.toString() + checkFolder + "/");
                }
            }
        } catch (SftpException e) {
            log.error(e.getMessage());
        }

    }

    /**
     * Create/overwrite filePath with given content
     * 
     * @param channel
     * @param filePath
     * @param content
     */
    public static void createFile(ChannelSftp channel, String filePath, String content) {
        Path path = Paths.get(filePath);
        String fileName = path.getFileName().toString();
        String pathFolder = path.getParent().toString();
        pathFolder = pathFolder.replaceAll("\\\\", "/"); // linux file path
        InputStream is = null;

        try {
            channel.cd(pathFolder);
            is = new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8));
            channel.put(is, fileName);
            is.close();
        } catch (IOException | SftpException e) {
            log.error(e.getMessage());
        }

    }
}
