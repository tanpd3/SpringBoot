package jp.meportal.isv.util;

import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.mail.Address;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.model.EmailInfo;

public class EmailUtil {

    private static String password;
    private static String account;
    private static String SMPT;
    private static String port;
    protected static Logger logger = Logger.getLogger(EmailUtil.class);
    private Pattern pattern;
    private Matcher matcher;

    private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
            + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

    /**
     * EmailUtil
     * 
     * @return Pattern
     **/
    public EmailUtil() {
        pattern = Pattern.compile(EMAIL_PATTERN);
    }

    /**
     * sendEmail
     * 
     * @return boolean
     **/
    public static boolean sendEmail(String subject, String headerTemplate, String footerTemplate,
            String contentTemplate, String tomail, String ccmail, String userName,
            String departmentName, String projectName, String managerName, String userBelongDepartmentCd,
            String loadOriginCode, String costCode, String productNumber, String comment)
            {
        boolean res = false;
        try {
            EmailInfo emailInfo = new EmailInfo();

            String content = new String("<html><body><div style='text-align:left'>" 
					+ Constants.HEADER_TEMPLATE
					+ headerTemplate + "\n"
                    + contentTemplate + "\n" + footerTemplate);
            
            if (!StringUtils.isEmpty(userName))
                content = content.replace("[USER_NAME]", userName);
            if (!StringUtils.isEmpty(departmentName))
                content = content.replace("[DEPARTMENTNAME]", departmentName);
            if (!StringUtils.isEmpty(projectName))
                content = content.replace("[PROJECT_NAME]", projectName);
            if (!StringUtils.isEmpty(managerName))
                content = content.replace("[MANAGER_NAME]", managerName);
            if (!StringUtils.isEmpty(userBelongDepartmentCd))
                content = content.replace("[USER_BELONG_DEPARTMENT_CD]", userBelongDepartmentCd);
            if (!StringUtils.isEmpty(loadOriginCode))
                content = content.replace("[LOAD_ORIGIN_CODE]", loadOriginCode);
            if (!StringUtils.isEmpty(costCode))
                content = content.replace("[COST_CODE]", costCode);
            if (!StringUtils.isEmpty(productNumber))
                content = content.replace("[PRODUCT_NUMBER]", productNumber);
            if (!StringUtils.isEmpty(comment)) {
                content = content.replace("[COMMENT]", comment);
            } else {
                content = content.replace("[COMMENT]", "");
            }
            
            content = content.replace("[TOP]", emailInfo.getTop());
            content = content.replaceAll("\n", "</br>");
            content = content + "</div></body></html>";
            tomail += "," + emailInfo.getAccount();// サポ�EチELをTOに追加しておく
            res = send(tomail, ccmail, subject, content, emailInfo);
        } catch(RuntimeException e) {
        	logger.error(e.getMessage(), e);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return res;
    }

    /**
     * send
     * 
     * @return boolean
     **/
    public static boolean send(String toMail, String ccMail, String subject, String content, EmailInfo emailInfo)
            throws javax.mail.MessagingException, ConfigurationException {

        SMPT = emailInfo.getSmtp();
        port = emailInfo.getPort();
        account = emailInfo.getAccount();
        password = emailInfo.getPassword();
        // Start get the session object
        Properties props = new Properties();
        props.put("mail.smtp.host", SMPT);
        props.put("mail.smtp.socketFactory.port", port);
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.port", port);
        // End get the session object

        Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(account, password);
            }
        });
        
        MimeMessage message = new MimeMessage(session);// MIME compose message
        message.setFrom(new InternetAddress(account));// from Address
        message.setSubject(subject, "UTF-8");// set subject
        message.setText(content, "UTF-8", "html");// set content
        if (!StringUtils.isEmpty(toMail)) {// toMail Address
            toMail = toMail.replaceAll(",", ";");
            String[] tomailList = toMail.split(";");
            for (String recipient : tomailList) {
                try {
                    if (!StringUtils.isEmpty(recipient)) {
                        InternetAddress toAddress = new InternetAddress(recipient.trim());
                        toAddress.validate();
                        message.addRecipient(RecipientType.TO, toAddress);
                    }
                } catch (AddressException ex) {
                    logger.error(ex.getMessage(), ex);
                    return false;
                }
            }
        }
        if (!StringUtils.isEmpty(ccMail)) {// ccMail Address
            ccMail = ccMail.replaceAll(",", ";");
            String[] ccMailList = ccMail.split(";");
            for (String recipient : ccMailList) {// CCの宛�EがTOに含まれてぁE��場合�ECCの宛�Eに含まれなぁE
                try {
                    boolean existedMail = false;
                    for (Address existedRecipient : message.getAllRecipients()) {
                        if (existedRecipient.toString().trim().equals(recipient.trim())) {
                            existedMail = true;
                            break;
                        }
                    }
                    if (!existedMail) {
                        InternetAddress ccAddress = new InternetAddress(recipient.trim());
                        ccAddress.validate();
                        message.addRecipient(RecipientType.CC, ccAddress);
                    }
                } catch (AddressException ex) {
                    logger.error(ex.getMessage(), ex);
                    return false;
                }
            }
        }
        message.saveChanges();
        try {
            Transport.send(message);// send message
            return true;
        } catch (MessagingException ex) {
            logger.error(ex.getMessage(), ex);
            return false;
        }
    }

    /**
     * validate
     * 
     * @return boolean
     **/
    public boolean validate(final String hex) {
        matcher = pattern.matcher(hex);
        return matcher.matches();
    }

    /**
     * validateEmail
     * 
     * @return boolean
     **/
    public String validateEmail(final String hex) {
        String message = StringUtils.EMPTY;
        if (!StringUtils.isEmpty(hex)) {
            matcher = pattern.matcher(hex);
            boolean matches = matcher.matches();
            if (matches) {
                message = Constants.NONE;
            } else {
                message = Constants.EMAIL_INVALID;
            }
        } else {
            message = Constants.EMAIL_F5;
        }
        return message;
    }
}