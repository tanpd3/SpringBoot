package jp.meportal.isv.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.Session;

import jp.meportal.isv.constant.Constants;

/**
 * @see jp.meportal.hpc.util.ExecuteCommand
 */
public class ExecuteCommand {

	static final Logger logger = Logger.getLogger(ExecuteCommand.class);
	public int exitStatus = 1;

	public ExecuteCommand() {
		super();
	}

	/**
     * Execute Command
     *
     * @return message
     **/
    public List<String> executeCommand(Session session, String strCommand) {
        exitStatus = 1;
        InputStream in = null;
        BufferedReader reader = null;
        InputStreamReader inReader = null;
        List<String> result = new ArrayList<String>();
        ChannelExec channelExec = null;
        try {
            if (session == null) {
                return null;
            }
            channelExec = (ChannelExec) session.openChannel("exec");

            in = channelExec.getInputStream();
            channelExec.setCommand(strCommand);
            ((ChannelExec) channelExec).setErrStream(System.err);
            channelExec.connect();
            String line;
            while (true) {
                inReader = new InputStreamReader(in, Constants.UTF_8);
                reader = new BufferedReader(inReader);
                while ((line = reader.readLine()) != null) {
					if( line.indexOf("WARNING:") >= 0 ) continue ;
                    result.add(line);
                }
                if (channelExec.isClosed()) {
                    if (in.available() > 0) {
                        continue;
                    }
                    exitStatus = channelExec.getExitStatus();
                    break;
                }
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;

        } finally {
            if (channelExec != null) {
                channelExec.disconnect();
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    in = null;
                }
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    reader = null;
                }
            }
            if (inReader != null) {
                try {
                    inReader.close();
                } catch (IOException e) {
                    inReader = null;
                }
            }
        }
        return result;
    }
    public Map<String,List<String>> executeCommands(Session session, String strCommand) {
        exitStatus = 1;
        InputStream in = null;
        BufferedReader reader = null;
        InputStreamReader inReader = null;
        Map<String, List<String>> results = new HashMap<String, List<String>>();
        ChannelExec channelExec = null;
        try {
            if (session == null) {
                return null;
            }

            channelExec = (ChannelExec) session.openChannel("exec");
            in = channelExec.getInputStream();

             	List<String> result = new ArrayList<String>();

            channelExec.setCommand(strCommand);
            ((ChannelExec) channelExec).setErrStream(System.err);
            channelExec.connect();

            String line;
            String key = "" ;
           while (true) {
                inReader = new InputStreamReader(in, Constants.UTF_8);
                reader = new BufferedReader(inReader);
                  while ((line = reader.readLine()) != null) {
                	  if( line.isEmpty()) continue ;
					if( line.indexOf("WARNING:") >= 0 ) continue ;


					if( line.indexOf("QUEUE: ")>=0)
					{

						if( result.size() > 0 )
						{
						results.put(key, result);
						//result.clear();
						result = new ArrayList<String>();
						//continue ;
						}
						key = line.replace("QUEUE: ", "");
					}
                    result.add(line);
                  }
                 results.put(key, result);

               if (channelExec.isClosed()) {
                    if (in.available() > 0) {
                        continue;
                    }
                    exitStatus = channelExec.getExitStatus();
                    break;
                }
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;

        } finally {
            if (channelExec != null) {
                channelExec.disconnect();
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    in = null;
                }
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    reader = null;
                }
            }
            if (inReader != null) {
                try {
                    inReader.close();
                } catch (IOException e) {
                    inReader = null;
                }
            }
        }


        return results;
    }
    public String executeCommand2String(Session session, String strCommand) {
        exitStatus = 1;
        InputStream in = null;
        BufferedReader reader = null;
        InputStreamReader inReader = null;
        String result = "";
		StringBuffer sb = new StringBuffer();
        ChannelExec channelExec = null;
        try {
            if (session == null) {
                return null;
            }
            channelExec = (ChannelExec) session.openChannel("exec");

            in = channelExec.getInputStream();
            channelExec.setCommand(strCommand);
            ((ChannelExec) channelExec).setErrStream(System.err);
            channelExec.connect();
            String line;
            while (true) {
                inReader = new InputStreamReader(in, Constants.UTF_8);
                reader = new BufferedReader(inReader);
                while ((line = reader.readLine()) != null) {
					if( line.indexOf("WARNING:") >= 0 ) continue ;
                    sb.append(line+"\n");
                }
                if (channelExec.isClosed()) {
                    if (in.available() > 0) {
                        continue;
                    }
                    exitStatus = channelExec.getExitStatus();
                    break;
                }
            }

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;

        } finally {
            if (channelExec != null) {
                channelExec.disconnect();
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    in = null;
                }
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    reader = null;
                }
            }
            if (inReader != null) {
                try {
                    inReader.close();
                } catch (IOException e) {
                    inReader = null;
                }
            }
        }
		result = sb.toString();
        return result;
    }
}
