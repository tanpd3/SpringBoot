package jp.meportal.isv.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.log4j.Logger;
import jp.meportal.isv.action.BaseAction;
import jp.meportal.isv.constant.Constants;

public class DateUtils {

    private static final Logger log = Logger.getLogger(BaseAction.class);
    
    /**
     * getCurrentDate
     * 
     * @author FPT
     * @date: 2017/05/05
     * @return Date
     */
    public static Date getCurrentDate() {
        Date dateWithoutTime = null;
        SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMAT_UPDATE);
        try {
            dateWithoutTime = sdf.parse(sdf.format(new Date()));
        } catch (ParseException e) {
            log.error(e.getMessage(), e);
        }
        return dateWithoutTime;

    }

    /**
     * getDateUpdate
     * 
     * @author FPT
     * @date: 2017/05/05
     * @return String
     */
    public static String getDateUpdate(String date) {
        String substring = null;
        try {
            substring = date.substring(0, 10).replace(Constants.DASH_CHARACTERS, Constants.SlASH_CHARACTERS);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return substring;
    }

    /**
     * parseDate
     * 
     * @author FPT
     * @date: 2017/05/05
     * @return Date
     */
    public static Date parseDate(Date input, String format) {
        Date dt = null;
        try {
            SimpleDateFormat sm = new SimpleDateFormat(format);
            String strDate = sm.format(input);
            dt = sm.parse(strDate);
        } catch (ParseException ex) {
            ex.printStackTrace();
        }
        return dt;
    }

    /**
     * convertDateToString
     * 
     * @author FPT
     * @date: 2017/05/05
     * @return String
     */
    public static String convertDateToString(Date input, String format) {
        String formattedDate = "";
        try {
            SimpleDateFormat sm = new SimpleDateFormat(format);
            formattedDate = sm.format(input);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return formattedDate;
    }
    
    /**
     * Convert seconds to "h:mm:ss"
     * 遘呈焚繧・h:mm:ss"縺ｮ蠖｢蠑上↓螟画鋤縺励∪縺吶
     *
     * NOTE: Negative values are not supported.
     *       雋縺ｮ謨ｰ縺ｫ縺ｯ蟇ｾ蠢懊＠縺ｦ縺・∪縺帙ｓ縲
     *
     * @param seconds   遘呈焚
     * @return  "h:mm:ss"縺ｮ蠖｢蠑上↓螟画鋤縺励◆譁・ｭ怜・
     */
    public static String convertSecondsToString(int seconds) {
        final int MINUTE = 60;
        final int HOUR = 3600;

        // 譎ょ・遘偵↓蛻・￠繧
        int hours = seconds / HOUR;
        int hoursRemainder = seconds % HOUR;
        int minutes = hoursRemainder / MINUTE;
        int minutesRemainder = hoursRemainder % MINUTE;

        String str = Long.toString(hours) + ":" +
                     String.format("%02d", minutes) + ":" +
                     String.format("%02d", minutesRemainder);

        return str;
    }
}
