package jp.meportal.isv.util;

import jp.meportal.isv.constant.Constants;

/**
 * Utility methods of IPAddress
 * IPAddress関連のユーティリティ関数をまとめたクラス
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
public class IpAddressUtils {
    /**
     * Matches IPAddressPattern
     * IPアドレスパターンが合致するかどうかの判定
     * @param ipaddressPattern  IPアドレスパターン(例1: "10.11.12.13", 例2: "10.11.12.*", 例3: "10.11.12.10-20")
     * @param ipaddress         IPアドレス
     * @return  true: 含まれる / false: 含まれない
     */
    public static boolean matchesIpAddress(String ipAddressPattern, String ipAddress) {
        final String SEPARATOR = "\\.";
        final int SEPARATE_COUNT = 4;
        final String WILDCARD = Constants.COLON_STAR;

        // "."区切りにして個々にチェック
        String[] infoArray = ipAddressPattern.split(SEPARATOR);
        String[] ipArray = ipAddress.split(SEPARATOR);
        if (infoArray.length != SEPARATE_COUNT) {
            return false;
        }
        if (ipArray.length != SEPARATE_COUNT) {
            return false;
        }

        for (int i = 0; i < SEPARATE_COUNT; i++) {
            // アドレスが等しい
            if (infoArray[i].equals(ipArray[i])) {
                continue;
            }

            // "*"の場合は等しいと扱う
            if (infoArray[i].equals(WILDCARD)) {
                continue;
            }

            // "-"が含まれる場合はfrom-toを調べる
            if (IpAddressUtils.containsFromTo(infoArray[i], ipArray[i])) {
                continue;
            }

            return false;
        }

        return true;
    }

    /**
     * Contains number in from-to
     * 数値がfrom-toに含まれるかどうかの判定
     * @param fromTo    from-to ex.) "0-100"
     * @param number    数値
     * @return  true: 含まれる / false: 含まれない
     */
    private static boolean containsFromTo(String fromTo, String number) {
        final String FROM_TO = "-";
        final String FROM_MIN = "0";
        final String TO_MAX = "255";

        // "-"がなければ終了
        if (fromTo.indexOf(FROM_TO) < 0) {
            return false;
        }

        // "-"で分割
        String[] fromToArray = fromTo.split(FROM_TO, -1);

        // fromが省略されている場合
        if (fromToArray[0].isEmpty()) {
            fromToArray[0] = FROM_MIN;
        }
        // toが省略されている場合
        if (fromToArray[1].isEmpty()) {
            fromToArray[1] = TO_MAX;
        }

        int from = 0;
        int to = 255;
        int num = -1;
        try {
            from = Integer.parseInt(fromToArray[0]);
            to = Integer.parseInt(fromToArray[1]);
            num = Integer.parseInt(number);
        } catch (NumberFormatException ex) {
            return false;
        }

        boolean b = (from <= num) && (num <= to);
        return b;
    }
}
