package jp.meportal.isv.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.IpAddressInfo;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.LicenseUseInfor;
import jp.meportal.isv.entity.MailTemplate;
import jp.meportal.isv.entity.Member;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ProjectBelongInfo;
import jp.meportal.isv.entity.ServerInfo;
import jp.meportal.isv.entity.Support;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HibernateUtil {

    private static final SessionFactory sessionFactory = buildSessionFactory();

    private static SessionFactory buildSessionFactory() {

        FileInputStream fis = null;
        try {
            fis = new FileInputStream(Constants.PROPERETIES_HIBERNATE_PATH);
            Properties props = new Properties();
            props.load(fis);
            AnnotationConfiguration configuration = new AnnotationConfiguration();
            configuration.setProperties(props);

            // mapping object
            configuration.addAnnotatedClass(Member.class);
            configuration.addAnnotatedClass(Project.class);
            configuration.addAnnotatedClass(ProjectBelongInfo.class);
            configuration.addAnnotatedClass(Support.class);
            configuration.addAnnotatedClass(CatalogInfor.class);
            configuration.addAnnotatedClass(IpAddressInfo.class);
            configuration.addAnnotatedClass(LicenseInfo.class);
            configuration.addAnnotatedClass(ServerInfo.class);
            configuration.addAnnotatedClass(LicenseUseInfor.class);
            configuration.addAnnotatedClass(MailTemplate.class);
            SessionFactory sessionFactory = configuration.buildSessionFactory();

            // Create the SessionFactory from hibernate.cfg.xml
            return sessionFactory;

        } catch (Throwable ex) {
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        } finally {
            try {
                fis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

}
