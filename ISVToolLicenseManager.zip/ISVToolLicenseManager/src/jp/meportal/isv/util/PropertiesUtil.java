package jp.meportal.isv.util;

import jp.meportal.isv.constant.Constants;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.lang.StringUtils;

public class PropertiesUtil {

    private static PropertiesConfiguration messageProperties = null;
    private static PropertiesConfiguration emailProperties = null;
    private static PropertiesConfiguration configTimeProperties = null;
    
    private static PropertiesConfiguration dirService_config = null;
    private static PropertiesConfiguration file_config = null;
    private static PropertiesConfiguration env_config = null;
    private static Object lock = new Object();
    
    static {
        try {
            messageProperties = new PropertiesConfiguration(Constants.PROPERETIES_MESSAGE_PATH);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        try {
            configTimeProperties = new PropertiesConfiguration(
                    Constants.PROPERETIES_CONFIG_TIME_PATH);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getMessageProperties(String key) {
        String value = StringUtils.EMPTY;
        if (messageProperties != null)
            value = messageProperties.getString(key);
        return value;
    }

    public static PropertiesConfiguration getEmailSettingConfig() throws ConfigurationException {
        emailSettingLoadConfig();
        return emailProperties;
    }

    private static void emailSettingLoadConfig() throws ConfigurationException {
        PropertiesConfiguration loadconfig = new PropertiesConfiguration(Constants.PROPERETIES_EMAIL_PATH);
        // keyを取り出す
        if (emailProperties == null) {
            // 未ロード、またはメッセージファイルが更新された場合はロードする.
            synchronized (lock) {
                emailProperties = loadconfig;
            }
        }
    }

    public static PropertiesConfiguration getDirServiceConfig() throws ConfigurationException {
        dirServiceLoadConfig();
        return dirService_config;
    }

    private static void filePathLocaConfig() throws ConfigurationException {
        if (file_config == null) {
            synchronized (lock) {
                file_config = new PropertiesConfiguration(Constants.PROPERETIES_FILE_CONFIG);;
            }
        }
    }

    public static PropertiesConfiguration getFilePathConfig() throws ConfigurationException {
        filePathLocaConfig();
        return file_config;
    }

    private static void dirServiceLoadConfig() throws ConfigurationException {
        String path = getFilePathConfig().getString(Constants.PROPERETIES_DIRSERVICEKEY);
        if (dirService_config == null) {
            synchronized (lock) {
                dirService_config = new PropertiesConfiguration(path);
            }
        }
    }

    private static void envLoadConfig() throws ConfigurationException {
        String envPath = getFilePathConfig().getString(Constants.PROPERETIES_ENVKEY);
        if (env_config == null) {
            synchronized (lock) {
                env_config = new PropertiesConfiguration(envPath);
            }
        }
    }

    public static PropertiesConfiguration getEnvConfig() throws ConfigurationException {
        envLoadConfig();
        return env_config;
    }
    
    public static String getConfigTime(String key) {
        String value = StringUtils.EMPTY;
        if (configTimeProperties != null)
            value = configTimeProperties.getString(key);
        return value;
    }
}