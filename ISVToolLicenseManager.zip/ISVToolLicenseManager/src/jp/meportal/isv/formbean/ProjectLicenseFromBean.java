package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.util.Date;

public class ProjectLicenseFromBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private int seqNo;
    private String projectName;
    private String comment;
    private String mailRegister;
    private Date dateRegister;
    private String nameApprover;
    private Date approval_dated;

    /**
     * ProjectLicenseFromBean
     */
    public ProjectLicenseFromBean() {}

    /**
     * @param seqNo
     * @param projectName
     * @param comment
     * @param mailRegister
     * @param dateRegister
     * @param nameApprover
     * @param approval_dated
     */
    public ProjectLicenseFromBean(int seqNo, String projectName, String comment, String mailRegister, Date dateRegister,
            String nameApprover, Date approval_dated) {
        this.seqNo = seqNo;
        this.projectName = projectName;
        this.comment = comment;
        this.mailRegister = mailRegister;
        this.dateRegister = dateRegister;
        this.nameApprover = nameApprover;
        this.approval_dated = approval_dated;
    }

    /**
     * @param seqNo
     */
    public int getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo
     *            the seqNo to set
     */
    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment
     *            the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @param mailRegister
     */
    public String getEmail() {
        return mailRegister;
    }

    /**
     * @param mailRegister
     *            the mailRegister to set
     */
    public void setEmail(String mailRegister) {
        this.mailRegister = mailRegister;
    }

    /**
     * @param dateRegister
     */
    public Date getCreateDate() {
        return dateRegister;
    }

    /**
     * @param dateRegister
     *            the dateRegister to set
     */
    public void setCreateDate(Date dateRegister) {
        this.dateRegister = dateRegister;
    }

    /**
     * @param nameApprover
     */
    public String getNameApprover() {
        return nameApprover;
    }

    /**
     * @param nameApprover
     *            the nameApprover to set
     */
    public void setNameApprover(String nameApprover) {
        this.nameApprover = nameApprover;
    }

    /**
     * @param approval_dated
     */
    public Date getApproveDate() {
        return approval_dated;
    }

    /**
     * @param approval_dated
     *            the approval_dated to set
     */
    public void setApproveDate(Date approval_dated) {
        this.approval_dated = approval_dated;
    }
}
