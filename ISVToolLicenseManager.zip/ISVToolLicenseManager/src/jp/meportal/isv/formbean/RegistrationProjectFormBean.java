package jp.meportal.isv.formbean;

import java.io.Serializable;

public class RegistrationProjectFormBean implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String projectName;
    private String managerName;
    private String emailAddress;
    private String loadOriginCode;
    private String costCode;
    private String productNumber;
    private String comment;
    private String loadOriginCode1;
    private String loadOriginCode2;
    private String loadOriginCode3;
    private String loadOriginCode4;
    private String loadOriginCode5;
    private String loadOriginCode6;
    private String loadOriginCode7;
    private String loadOriginCode8;
    private String loadOriginCode9;
    private String costCode1;
    private String costCode2;
    private String costCode3;
    private String costCode4;
    private String warningMessage;

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param managerName
     */
    public String getManagerName() {
        return managerName;
    }

    /**
     * @param managerName
     *            the managerName to set
     */
    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    /**
     * @param emailAddress
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * @param emailAddress
     *            the emailAddress to set
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * @param loadOriginCode
     */
    public String getLoadOriginCode() {
        return loadOriginCode;
    }

    /**
     * @param loadOriginCode
     *            the loadOriginCode to set
     */
    public void setLoadOriginCode(String loadOriginCode) {
        this.loadOriginCode = loadOriginCode;
    }

    /**
     * @param costCode
     */
    public String getCostCode() {
        return costCode;
    }

    /**
     * @param costCode
     *            the costCode to set
     */
    public void setCostCode(String costCode) {
        this.costCode = costCode;
    }

    /**
     * @param productNumber
     */
    public String getProductNumber() {
        return productNumber;
    }

    /**
     * @param productNumber
     *            the productNumber to set
     */
    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    /**
     * @param comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment
     *            the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @param loadOriginCode1
     */
    public String getLoadOriginCode1() {
        return loadOriginCode1;
    }

    /**
     * @param loadOriginCode1
     *            the loadOriginCode1 to set
     */
    public void setLoadOriginCode1(String loadOriginCode1) {
        this.loadOriginCode1 = loadOriginCode1;
    }

    /**
     * @param loadOriginCode2
     */
    public String getLoadOriginCode2() {
        return loadOriginCode2;
    }

    /**
     * @param loadOriginCode2
     *            the loadOriginCode2 to set
     */
    public void setLoadOriginCode2(String loadOriginCode2) {
        this.loadOriginCode2 = loadOriginCode2;
    }

    /**
     * @param loadOriginCode3
     */
    public String getLoadOriginCode3() {
        return loadOriginCode3;
    }

    /**
     * @param loadOriginCode3
     *            the loadOriginCode3 to set
     */
    public void setLoadOriginCode3(String loadOriginCode3) {
        this.loadOriginCode3 = loadOriginCode3;
    }

    /**
     * @param loadOriginCode4
     */
    public String getLoadOriginCode4() {
        return loadOriginCode4;
    }

    /**
     * @param loadOriginCode4
     *            the loadOriginCode4 to set
     */
    public void setLoadOriginCode4(String loadOriginCode4) {
        this.loadOriginCode4 = loadOriginCode4;
    }

    /**
     * @param loadOriginCode5
     */
    public String getLoadOriginCode5() {
        return loadOriginCode5;
    }

    /**
     * @param loadOriginCode5
     *            the loadOriginCode5 to set
     */
    public void setLoadOriginCode5(String loadOriginCode5) {
        this.loadOriginCode5 = loadOriginCode5;
    }

    /**
     * @param loadOriginCode6
     */
    public String getLoadOriginCode6() {
        return loadOriginCode6;
    }

    /**
     * @param loadOriginCode6
     *            the loadOriginCode6 to set
     */
    public void setLoadOriginCode6(String loadOriginCode6) {
        this.loadOriginCode6 = loadOriginCode6;
    }

    /**
     * @param loadOriginCode7
     */
    public String getLoadOriginCode7() {
        return loadOriginCode7;
    }

    /**
     * @param loadOriginCode7
     *            the loadOriginCode7 to set
     */
    public void setLoadOriginCode7(String loadOriginCode7) {
        this.loadOriginCode7 = loadOriginCode7;
    }

    /**
     * @param loadOriginCode8
     */
    public String getLoadOriginCode8() {
        return loadOriginCode8;
    }

    /**
     * @param loadOriginCode8
     *            the loadOriginCode8 to set
     */
    public void setLoadOriginCode8(String loadOriginCode8) {
        this.loadOriginCode8 = loadOriginCode8;
    }

    /**
     * @param loadOriginCode9
     */
    public String getLoadOriginCode9() {
        return loadOriginCode9;
    }

    /**
     * @param loadOriginCode9
     *            the loadOriginCode9 to set
     */
    public void setLoadOriginCode9(String loadOriginCode9) {
        this.loadOriginCode9 = loadOriginCode9;
    }

    /**
     * @param costCode1
     */
    public String getCostCode1() {
        return costCode1;
    }

    /**
     * @param costCode1
     *            the costCode1 to set
     */
    public void setCostCode1(String costCode1) {
        this.costCode1 = costCode1;
    }

    /**
     * @param costCode2
     */
    public String getCostCode2() {
        return costCode2;
    }

    /**
     * @param costCode2
     *            the costCode2 to set
     */
    public void setCostCode2(String costCode2) {
        this.costCode2 = costCode2;
    }

    /**
     * @param costCode3
     */
    public String getCostCode3() {
        return costCode3;
    }

    /**
     * @param costCode3
     *            the costCode3 to set
     */
    public void setCostCode3(String costCode3) {
        this.costCode3 = costCode3;
    }

    /**
     * @param costCode4
     */
    public String getCostCode4() {
        return costCode4;
    }

    /**
     * @param costCode4
     *            the costCode4 to set
     */
    public void setCostCode4(String costCode4) {
        this.costCode4 = costCode4;
    }

    /**
     * @param warningMessage
     */
    public String getWarningMessage() {
        return warningMessage;
    }

    /**
     * @param warningMessage
     *            the warningMessage to set
     */
    public void setWarningMessage(String warningMessage) {
        this.warningMessage = warningMessage;
    }
}
