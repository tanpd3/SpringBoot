package jp.meportal.isv.formbean;

import java.io.Serializable;

public class RegistrationProjectMemberFormBean implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private int seq_no;
    private String email;
    private String link;

    /**
     * @param seq_no
     */
    public int getSeq_no() {
        return seq_no;
    }

    /**
     * @param seq_no
     *            the seq_no to set
     */
    public void setSeq_no(int seq_no) {
        this.seq_no = seq_no;
    }

    /**
     * @param email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email
     *            the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @param link
     */
    public String getLink() {
        return link;
    }

    /**
     * @param link
     *            the link to set
     */
    public void setLink(String link) {
        this.link = link;
    }
}
