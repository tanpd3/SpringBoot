﻿package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.util.List;

public class LicenseUsageForFeatureFormBean implements Serializable{
    private static final long serialVersionUID = 1L;

    private String futureName;
    private List<LicenseUsageDetailForDBFormBean> licenseUsageDetailForDBList;
    private List<LicenseUsageForAccountFormBean> licenseUsageForAccountList;
    private int runTimeForFeature;
    private int runNumberForFeature;
    private int lengthAccList;
    private int sameTimeUseNumber;

    /**
     * Default constructor
     */
    public LicenseUsageForFeatureFormBean() {
        super();
    }

    /**
    * constructor for LicenseUsageForFeatureFormBean
    */
    public LicenseUsageForFeatureFormBean(String futureName, int sameTimeUseNumber) {
        super();
        this.futureName = futureName;
        this.sameTimeUseNumber = sameTimeUseNumber;
    }

    /**
    * constructor for LicenseUsageForFeatureFormBean
    */
    public LicenseUsageForFeatureFormBean(String futureName,
            List<LicenseUsageDetailForDBFormBean> licenseUsageDetailForDBList) {
        super();
        this.futureName = futureName;
        this.licenseUsageDetailForDBList = licenseUsageDetailForDBList;
    }

    /**
    * constructor for LicenseUsageForFeatureFormBean
    */
    public LicenseUsageForFeatureFormBean(String futureName,
            List<LicenseUsageForAccountFormBean> licenseUsageForAccountList,
            int runTimeForFeature, int runNumberForFeature, int lengthAccList) {
        super();
        this.futureName = futureName;
        this.licenseUsageForAccountList = licenseUsageForAccountList;
        this.runTimeForFeature = runTimeForFeature;
        this.runNumberForFeature = runNumberForFeature;
        this.lengthAccList = lengthAccList;
    }

    /**
     * @param futureName
     */
    public String getFutureName() {
        return futureName;
    }

    /**
     * @param futureName
     *            the futureName to set
     */
    public void setFutureName(String futureName) {
        this.futureName = futureName;
    }

    /**
     * @param runTimeForFeature
     */
    public int getRunTimeForFeature() {
        return runTimeForFeature;
    }

    /**
     * @param runTimeForFeature
     *            the runTimeForFeature to set
     */
    public void setRunTimeForFeature(int runTimeForFeature) {
        this.runTimeForFeature = runTimeForFeature;
    }

    /**
     * @param runNumberForFeature
     */
    public int getRunNumberForFeature() {
        return runNumberForFeature;
    }

    /**
     * @param runNumberForFeature
     *            the runNumberForFeature to set
     */
    public void setRunNumberForFeature(int runNumberForFeature) {
        this.runNumberForFeature = runNumberForFeature;
    }

    /**
     * @param licenseUsageDetailForDBList
     */
    public List<LicenseUsageDetailForDBFormBean> getLicenseUsageDetailForDBList() {
        return licenseUsageDetailForDBList;
    }

    /**
     * @param licenseUsageDetailForDBList
     *            the licenseUsageDetailForDBList to set
     */
    public void setLicenseUsageDetailForDBList(List<LicenseUsageDetailForDBFormBean> licenseUsageDetailForDBList) {
        this.licenseUsageDetailForDBList = licenseUsageDetailForDBList;
    }

    /**
     * @param licenseUsageForAccountList
     */
    public List<LicenseUsageForAccountFormBean> getLicenseUsageForAccountList() {
        return licenseUsageForAccountList;
    }

    /**
     * @param licenseUsageForAccountList
     *            the licenseUsageForAccountList to set
     */
    public void setLicenseUsageForAccountList(List<LicenseUsageForAccountFormBean> licenseUsageForAccountList) {
        this.licenseUsageForAccountList = licenseUsageForAccountList;
    }

    /**
     * @param lengthAccList
     */
    public int getLengthAccList() {
        return lengthAccList;
    }

    /**
     * @param lengthAccList
     *            the lengthAccList to set
     */
    public void setLengthAccList(int lengthAccList) {
        this.lengthAccList = lengthAccList;
    }

    /**
     * @param sameTimeUseNumber
     */
    public int getSameTimeUseNumber() {
        return sameTimeUseNumber;
    }

    /**
     * @param sameTimeUseNumber
     *            the sameTimeUseNumber to set
     */
    public void setSameTimeUseNumber(int sameTimeUseNumber) {
        this.sameTimeUseNumber = sameTimeUseNumber;
    }

}
