package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.util.List;

public class LicenseUsageForVendorFormBean implements Serializable{
    private static final long serialVersionUID = 1L;

    private String productNumber;
    private String projectName;
    private String account;
    private String vendorName;
    private String toolName;
    private List<LicenseUsageDetailForDBFormBean> licenseUsageDetailForDBList;
    private List<LicenseUsageForFeatureFormBean> licenseUsageForFeatureList;
    private List<LicenseUsageForToolNameFormBean> licenseUsageForToolNameList;
    private int runTimeForVendor;
    private int runNumberForVendor;
    private int lengthToolList;
    private int lengthFeatureList;

    /**
     * Default constructor
     */
    public LicenseUsageForVendorFormBean() {
        super();
    }

    /**
    * constructor for LicenseUsageForFeatureFormBean
    */
    public LicenseUsageForVendorFormBean(String vendorName,
            List<LicenseUsageDetailForDBFormBean> licenseUsageDetailForDBList) {
        super();
        // this.account = account;
        this.vendorName = vendorName;
        this.licenseUsageDetailForDBList = licenseUsageDetailForDBList;
    }

    /**
    * constructor for LicenseUsageForFeatureFormBean
    */
    public LicenseUsageForVendorFormBean(String vendorName,
            List<LicenseUsageForToolNameFormBean> licenseUsageForToolNameList, int runTimeForVendor,
            int runNumberForVendor, int lengthToolList) {
        super();
        this.vendorName = vendorName;
        this.licenseUsageForToolNameList = licenseUsageForToolNameList;
        this.runTimeForVendor = runTimeForVendor;
        this.runNumberForVendor = runNumberForVendor;
        this.lengthToolList = lengthToolList;
    }

    /**
     * @param account
     */
    public String getAccount() {
        return account;
    }

    /**
     * @param account
     *            the account to set
     */
    public void setAccount(String account) {
        this.account = account;
    }

    /**
     * @param vendorName
     */
    public String getVendorName() {
        return vendorName;
    }

    /**
     * @param vendorName
     *            the vendorName to set
     */
    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    /**
     * @param toolName
     */
    public String getToolName() {
        return toolName;
    }

    /**
     * @param toolName
     *            the toolName to set
     */
    public void setToolName(String toolName) {
        this.toolName = toolName;
    }

    /**
     * @param licenseUsageForFeatureList
     */
    public List<LicenseUsageForFeatureFormBean> getLicenseUsageForFeatureList() {
        return licenseUsageForFeatureList;
    }

    /**
     * @param licenseUsageForFeatureList
     *            the licenseUsageForFeatureList to set
     */
    public void setLicenseUsageForFeatureList(List<LicenseUsageForFeatureFormBean> licenseUsageForFeatureList) {
        this.licenseUsageForFeatureList = licenseUsageForFeatureList;
    }

    /**
     * @param runTimeForVendor
     */
    public int getRunTimeForVendor() {
        return runTimeForVendor;
    }

    /**
     * @param runTimeForVendor
     *            the runTimeForVendor to set
     */
    public void setRunTimeForVendor(int runTimeForVendor) {
        this.runTimeForVendor = runTimeForVendor;
    }

    /**
     * @param runNumberForVendor
     */
    public int getRunNumberForVendor() {
        return runNumberForVendor;
    }

    /**
     * @param runNumberForVendor
     *            the runNumberForVendor to set
     */
    public void setRunNumberForVendor(int runNumberForVendor) {
        this.runNumberForVendor = runNumberForVendor;
    }

    /**
     * @param lengthFeatureList
     */
    public int getLengthFeatureList() {
        return lengthFeatureList;
    }

    /**
     * @param lengthFeatureList
     *            the lengthFeatureList to set
     */
    public void setLengthFeatureList(int lengthFeatureList) {
        this.lengthFeatureList = lengthFeatureList;
    }

    /**
     * @param productNumber
     */
    public String getProductNumber() {
        return productNumber;
    }

    /**
     * @param productNumber
     *            the productNumber to set
     */
    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public List<LicenseUsageForToolNameFormBean> getLicenseUsageForToolNameList() {
        return licenseUsageForToolNameList;
    }

    public void setLicenseUsageForToolNameList(List<LicenseUsageForToolNameFormBean> licenseUsageForToolNameList) {
        this.licenseUsageForToolNameList = licenseUsageForToolNameList;
    }

    public int getLengthToolList() {
        return lengthToolList;
    }

    public void setLengthToolList(int lengthToolList) {
        this.lengthToolList = lengthToolList;
    }

    public List<LicenseUsageDetailForDBFormBean> getLicenseUsageDetailForDBList() {
        return licenseUsageDetailForDBList;
    }

    public void setLicenseUsageDetailForDBList(List<LicenseUsageDetailForDBFormBean> licenseUsageDetailForDBList) {
        this.licenseUsageDetailForDBList = licenseUsageDetailForDBList;
    }

}
