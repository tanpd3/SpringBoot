package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.math.BigDecimal;

public class LicenseUsedBean implements Serializable{
    private static final long serialVersionUID = 1L;
    
    private int licenseUseInfoId;
    private int ipAddressId;
    private int catalogId;
    private Integer usedSumPerMonth;
    private BigDecimal memberPrice;
    private BigDecimal regularPrice;
    public String venderName;
    public String toolName;
    public String futureName;

    /**
     * LicenseUsedBean
     * 
     * @param ipAddressId
     * @param catalogId
     * @param usedSumPerMonth
     * @param memberPrice
     * @param regularPrice
     * @param venderName
     * @param toolName
     * @param futureName
     */
    public LicenseUsedBean(int licenseUseInfoId, int ipAddressId, int catalogId, Integer usedSumPerMonth, BigDecimal memberPrice, 
            BigDecimal regularPrice, String venderName, String toolName, String futureName){
        super();
        this.licenseUseInfoId = licenseUseInfoId;
        this.ipAddressId = ipAddressId;
        this.catalogId = catalogId;
        this.usedSumPerMonth = usedSumPerMonth;
        this.memberPrice = memberPrice;
        this.regularPrice = regularPrice;
        this.venderName = venderName;
        this.toolName = toolName;
        this.futureName = futureName;
    }

    public LicenseUsedBean(){}

    /**
     * @param licenseUseInfoId
     */
    public int getLicenseUseInfoId() {
        return licenseUseInfoId;
    }

    /**
     * @param licenseUseInfoId
     *            the licenseUseInfoId to set
     */
    public void setLicenseUseInfoId(int licenseUseInfoId) {
        this.licenseUseInfoId = licenseUseInfoId;
    }

    /**
     * @param ipAddressId
     */
    public int getIpAddressId() {
        return ipAddressId;
    }

    /**
     * @param ipAddressId
     *            the ipAddressId to set
     */
    public void setIpAddressId(int ipAddressId) {
        this.ipAddressId = ipAddressId;
    }

    /**
     * @param catalogId
     */
    public int getCatalogId() {
        return catalogId;
    }

    /**
     * @param catalogId
     *            the catalogId to set
     */
    public void setCatalogId(int catalogId) {
        this.catalogId = catalogId;
    }



    /**
     * @param usedSumPerMonth
     */
    public Integer getUsedSumPerMonth() {
        return usedSumPerMonth;
    }

    /**
     * @param usedSumPerMonth
     *            the usedSumPerMonth to set
     */
    public void setUsedSumPerMonth(Integer usedSumPerMonth) {
        this.usedSumPerMonth = usedSumPerMonth;
    }

    /**
     * @param memberPrice
     */
    public BigDecimal getMemberPrice() {
        return memberPrice;
    }

    /**
     * @param memberPrice
     *            the memberPrice to set
     */
    public void setMemberPrice(BigDecimal memberPrice) {
        this.memberPrice = memberPrice;
    }

    /**
     * @param regularPrice
     */
    public BigDecimal getRegularPrice() {
        return regularPrice;
    }

    /**
     * @param regularPrice
     *            the regularPrice to set
     */
    public void setRegularPrice(BigDecimal regularPrice) {
        this.regularPrice = regularPrice;
    }

    /**
     * @param venderName
     */
    public String getVenderName() {
        return venderName;
    }

    /**
     * @param venderName
     *            the venderName to set
     */
    public void setVenderName(String venderName) {
        this.venderName = venderName;
    }

    /**
     * @param toolName
     */
    public String getToolName() {
        return toolName;
    }

    /**
     * @param toolName
     *            the toolName to set
     */
    public void setToolName(String toolName) {
        this.toolName = toolName;
    }

    /**
     * @param futureName
     */
    public String getFutureName() {
        return futureName;
    }

    /**
     * @param futureName
     *            the futureName to set
     */
    public void setFutureName(String futureName) {
        this.futureName = futureName;
    }
}
