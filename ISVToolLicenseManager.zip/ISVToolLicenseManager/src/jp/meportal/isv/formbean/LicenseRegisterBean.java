package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.math.BigDecimal;

public class LicenseRegisterBean implements Serializable{
    private static final long serialVersionUID = 1L;
    
    private int projectId;
    private int catalogId;
    private int licenseRegisId;
    private Integer registerSumPerMonth;
    private BigDecimal memberPrice;
    private BigDecimal regularPrice;
    private String projectName;
    private String productNumber;
    private String loadOriginCode;
    public String venderName;
    public String toolName;
    public String futureName;
    
    
    /**
     * @param projectId
     * @param catalogId
     * @param registerSumPerMonth
     * @param memberPrice
     * @param regularPrice
     * @param projectName
     * @param venderName
     * @param toolName
     * @param futureName
     * @param productNumber
     */
    public LicenseRegisterBean(int projectId, int catalogId, int licenseRegisId, Integer registerSumPerMonth, BigDecimal memberPrice, BigDecimal regularPrice, String projectName,
            String loadOriginCode, String venderName, String toolName, String futureName, String productNumber){
        super();
        this.projectId = projectId;
        this.catalogId = catalogId;
        this.licenseRegisId = licenseRegisId;
        this.registerSumPerMonth = registerSumPerMonth;
        this.memberPrice = memberPrice;
        this.regularPrice = regularPrice;
        this.projectName = projectName;
        this.venderName = venderName;
        this.toolName = toolName;
        this.futureName = futureName;
        this.productNumber = productNumber;
        this.loadOriginCode = loadOriginCode;
    }
    
    public LicenseRegisterBean(){}

    /**
     * @param projectId
     */
    public int getProjectId() {
        return projectId;
    }
    
    /**
     * @param projectId
     *            the projectId to set
     */
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }
    
    /**
     * @param catalogId
     */
    public int getCatalogId() {
        return catalogId;
    }

    /**
     * @param catalogId
     *            the catalogId to set
     */
    public void setCatalogId(int catalogId) {
        this.catalogId = catalogId;
    }

    /**
     * @param licenseRegisId
     */
    public int getLicenseRegisId() {
        return licenseRegisId;
    }

    /**
     * @param licenseRegisId
     *            the licenseRegisId to set
     */
    public void setLicenseRegisId(int licenseRegisId) {
        this.licenseRegisId = licenseRegisId;
    }

    /**
     * @param registerSumPerMonth
     */
    public Integer getRegisterSumPerMonth() {
        return registerSumPerMonth;
    }

    /**
     * @param registerSumPerMonth
     *            the registerSumPerMonth to set
     */
    public void setRegisterSumPerMonth(Integer registerSumPerMonth) {
        this.registerSumPerMonth = registerSumPerMonth;
    }

    /**
     * @param memberPrice
     */
    public BigDecimal getMemberPrice() {
        return memberPrice;
    }

    /**
     * @param memberPrice
     *            the memberPrice to set
     */
    public void setMemberPrice(BigDecimal memberPrice) {
        this.memberPrice = memberPrice;
    }

    /**
     * @param regularPrice
     */
    public BigDecimal getRegularPrice() {
        return regularPrice;
    }

    /**
     * @param regularPrice
     *            the regularPrice to set
     */
    public void setRegularPrice(BigDecimal regularPrice) {
        this.regularPrice = regularPrice;
    }

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param venderName
     */
    public String getVenderName() {
        return venderName;
    }

    /**
     * @param venderName
     *            the venderName to set
     */
    public void setVenderName(String venderName) {
        this.venderName = venderName;
    }
    
    /**
     * @param loadOriginCode
     */
    public String getLoadOriginCode() {
        return loadOriginCode;
    }

    /**
     * @param loadOriginCode
     *            the loadOriginCode to set
     */
    public void setLoadOriginCode(String loadOriginCode) {
        this.loadOriginCode = loadOriginCode;
    }
    /**
     * @param toolName
     */
    public String getToolName() {
        return toolName;
    }

    /**
     * @param toolName
     *            the toolName to set
     */
    public void setToolName(String toolName) {
        this.toolName = toolName;
    }

    /**
     * @param futureName
     */
    public String getFutureName() {
        return futureName;
    }

    /**
     * @param futureName
     *            the futureName to set
     */
    public void setFutureName(String futureName) {
        this.futureName = futureName;
    }

    /**
     * @param productNumber
     */
    public String getProductNumber() {
        return productNumber;
    }

    /**
     * @param productNumber
     *            the productNumber to set
     */
    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }
}
