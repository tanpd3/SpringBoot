package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.util.List;

public class LicenseUsageForToolNameFormBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private String productNumber;
    private String projectName;
    private String toolName;
    private String vendorName;
    private List<LicenseUsageForFeatureFormBean> licenseUsageForFeatureList; 
    private List<LicenseUsageForProjectToolNameFormBean> licenseUsageForProjectToolNameList;
    private List<LicenseUsageDetailForDBFormBean> licenseUsageDetailForDBList;
    private int lengthFeatureAllList;
    private int runTimeForTool;
    private int runNumberForTool;
    private int lengthFeatureList;

    /**
     * Default constructor
     */
    public LicenseUsageForToolNameFormBean() {
        super();
    }

    /**
    * constructor for LicenseUsageForFeatureFormBean
    */
    public LicenseUsageForToolNameFormBean(String toolName,
            List<LicenseUsageForFeatureFormBean> licenseUsageForFeatureList, int runTimeForTool, int runNumberForTool,
            int lengthFeatureList) {
        super();
        this.toolName = toolName;
        this.licenseUsageForFeatureList = licenseUsageForFeatureList;
        this.runTimeForTool = runTimeForTool;
        this.runNumberForTool = runNumberForTool;
        this.lengthFeatureList = lengthFeatureList;
    }

    /**
    * constructor for LicenseUsageForFeatureFormBean
    */
    public LicenseUsageForToolNameFormBean(String vendorName, String toolName,
            List<LicenseUsageDetailForDBFormBean> licenseUsageDetailForDBList) {
        super();
        this.vendorName = vendorName;
        this.toolName = toolName;
        this.licenseUsageDetailForDBList = licenseUsageDetailForDBList;
    }

    /**
    * constructor for LicenseUsageForFeatureFormBean
    */
    public LicenseUsageForToolNameFormBean(String productNumber, String projectName, String vendorName, String toolName,
            List<LicenseUsageForFeatureFormBean> licenseUsageForFeatureList, int lengthFeatureList) {
        super();
        this.productNumber = productNumber;
        this.projectName = projectName;
        this.vendorName = vendorName;
        this.toolName = toolName;
        this.licenseUsageForFeatureList = licenseUsageForFeatureList;
        this.lengthFeatureList = lengthFeatureList;
    }

    /**
     * @param toolName
     */
    public String getToolName() {
        return toolName;
    }

    /**
     * @param toolName
     *            the toolName to set
     */
    public void setToolName(String toolName) {
        this.toolName = toolName;
    }

    /**
     * @param vendorName
     */
    public String getVendorName() {
        return vendorName;
    }

    /**
     * @param vendorName
     *            the vendorName to set
     */
    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    /**
     * @param licenseUsageForProjectToolNameList
     */
    public List<LicenseUsageForProjectToolNameFormBean> getLicenseUsageForProjectToolNameList() {
        return licenseUsageForProjectToolNameList;
    }

    /**
     * @param licenseUsageForProjectToolNameList
     *            the licenseUsageForProjectToolNameList to set
     */
    public void setLicenseUsageForProjectToolNameList(
            List<LicenseUsageForProjectToolNameFormBean> licenseUsageForProjectToolNameList) {
        this.licenseUsageForProjectToolNameList = licenseUsageForProjectToolNameList;
    }

    /**
     * @param lengthFeatureAllList
     */
    public int getLengthFeatureAllList() {
        return lengthFeatureAllList;
    }

    /**
     * @param lengthFeatureAllList
     *            the lengthFeatureAllList to set
     */
    public void setLengthFeatureAllList(int lengthFeatureAllList) {
        this.lengthFeatureAllList = lengthFeatureAllList;
    }

    /**
     * @param licenseUsageForFeatureList
     */
    public List<LicenseUsageForFeatureFormBean> getLicenseUsageForFeatureList() {
        return licenseUsageForFeatureList;
    }

    /**
     * @param licenseUsageForFeatureList
     *            the licenseUsageForFeatureList to set
     */
    public void setLicenseUsageForFeatureList(List<LicenseUsageForFeatureFormBean> licenseUsageForFeatureList) {
        this.licenseUsageForFeatureList = licenseUsageForFeatureList;
    }

    /**
     * @param runTimeForTool
     */
    public int getRunTimeForTool() {
        return runTimeForTool;
    }

    /**
     * @param runTimeForTool
     *            the runTimeForTool to set
     */
    public void setRunTimeForTool(int runTimeForTool) {
        this.runTimeForTool = runTimeForTool;
    }

    /**
     * @param runNumberForTool
     */
    public int getRunNumberForTool() {
        return runNumberForTool;
    }

    /**
     * @param runNumberForTool
     *            the runNumberForTool to set
     */
    public void setRunNumberForTool(int runNumberForTool) {
        this.runNumberForTool = runNumberForTool;
    }

    /**
     * @param lengthFeatureList
     */
    public int getLengthFeatureList() {
        return lengthFeatureList;
    }

    /**
     * @param lengthFeatureList
     *            the lengthFeatureList to set
     */
    public void setLengthFeatureList(int lengthFeatureList) {
        this.lengthFeatureList = lengthFeatureList;
    }

    /**
     * @param productNumber
     */
    public String getProductNumber() {
        return productNumber;
    }

    /**
     * @param productNumber
     *            the productNumber to set
     */
    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param licenseUsageDetailForDBList
     */
    public List<LicenseUsageDetailForDBFormBean> getLicenseUsageDetailForDBList() {
        return licenseUsageDetailForDBList;
    }

    /**
     * @param licenseUsageDetailForDBList
     *            the licenseUsageDetailForDBList to set
     */
    public void setLicenseUsageDetailForDBList(List<LicenseUsageDetailForDBFormBean> licenseUsageDetailForDBList) {
        this.licenseUsageDetailForDBList = licenseUsageDetailForDBList;
    }
}
