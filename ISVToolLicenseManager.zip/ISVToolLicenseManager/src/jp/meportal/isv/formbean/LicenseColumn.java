package jp.meportal.isv.formbean;

import java.io.Serializable;

public class LicenseColumn implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String catalogId;
    private String column_1;
    private String column_2;
    private String column_3;
    private String column_4;
    private String column_5;
    private String column_6;
    private String column_7;
    private String column_8;
    private String column_9;
    private String column_10;
    private String column_11;
    private String column_12;
    
    /**
     * @param column_1
     * @param column_2
     * @param column_3
     * @param column_4
     * @param column_5
     * @param column_6
     * @param column_7
     * @param column_8
     * @param column_9
     * @param column_10
     * @param column_11
     * @param column_12
     */
	public LicenseColumn(String catalogId, String column_1, String column_2,
			String column_3, String column_4, String column_5, String column_6,
			String column_7, String column_8, String column_9,
			String column_10, String column_11, String column_12) {
		super();
		this.catalogId = catalogId;
		this.column_1 = column_1;
		this.column_2 = column_2;
		this.column_3 = column_3;
		this.column_4 = column_4;
		this.column_5 = column_5;
		this.column_6 = column_6;
		this.column_7 = column_7;
		this.column_8 = column_8;
		this.column_9 = column_9;
		this.column_10 = column_10;
		this.column_11 = column_11;
		this.column_12 = column_12;
	}
	
    /**
     * @param catalogId
     */
	public String getCatalogId() {
		return catalogId;
	}
	
    /**
     * @param catalogId
     *            the catalogId to set
     */
	public void setCatalogId(String catalogId) {
		this.catalogId = catalogId;
	}
	
    /**
     * @param column_1
     */
	public String getColumn_1() {
		return column_1;
	}
	
    /**
     * @param column_1
     *            the column_1 to set
     */
	public void setColumn_1(String column_1) {
		this.column_1 = column_1;
	}
	
    /**
     * @param column_2
     */
	public String getColumn_2() {
		return column_2;
	}
	
    /**
     * @param column_2
     *            the column_2 to set
     */
	public void setColumn_2(String column_2) {
		this.column_2 = column_2;
	}
	
    /**
     * @param column_3
     */
	public String getColumn_3() {
		return column_3;
	}
	
    /**
     * @param column_3
     *            the column_3 to set
     */
	public void setColumn_3(String column_3) {
		this.column_3 = column_3;
	}
	
    /**
     * @param column_4
     */
	public String getColumn_4() {
		return column_4;
	}
	
    /**
     * @param column_4
     *            the column_4 to set
     */
	public void setColumn_4(String column_4) {
		this.column_4 = column_4;
	}
	
    /**
     * @param column_5
     */
	public String getColumn_5() {
		return column_5;
	}
	
    /**
     * @param column_5
     *            the column_5 to set
     */
	public void setColumn_5(String column_5) {
		this.column_5 = column_5;
	}
	
    /**
     * @param column_6
     */
	public String getColumn_6() {
		return column_6;
	}
	
    /**
     * @param column_6
     *            the column_6 to set
     */
	public void setColumn_6(String column_6) {
		this.column_6 = column_6;
	}
	
    /**
     * @param column_7
     */
	public String getColumn_7() {
		return column_7;
	}
	
    /**
     * @param column_7
     *            the column_7 to set
     */
	public void setColumn_7(String column_7) {
		this.column_7 = column_7;
	}
	
    /**
     * @param column_8
     */
	public String getColumn_8() {
		return column_8;
	}
	
    /**
     * @param column_8
     *            the column_8 to set
     */
	public void setColumn_8(String column_8) {
		this.column_8 = column_8;
	}
	
    /**
     * @param column_9
     */
	public String getColumn_9() {
		return column_9;
	}
	
    /**
     * @param column_9
     *            the column_9 to set
     */
	public void setColumn_9(String column_9) {
		this.column_9 = column_9;
	}
	
    /**
     * @param column_10
     */
	public String getColumn_10() {
		return column_10;
	}
	
    /**
     * @param column_10
     *            the column_10 to set
     */
	public void setColumn_10(String column_10) {
		this.column_10 = column_10;
	}
	
    /**
     * @param column_11
     */
	public String getColumn_11() {
		return column_11;
	}
	
    /**
     * @param column_11
     *            the column_11 to set
     */
	public void setColumn_11(String column_11) {
		this.column_11 = column_11;
	}
	
    /**
     * @param column_12
     */
	public String getColumn_12() {
		return column_12;
	}
	
    /**
     * @param column_12
     *            the column_12 to set
     */
	public void setColumn_12(String column_12) {
		this.column_12 = column_12;
	}
}
