package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.util.List;

public class LicenseUsageForProjectFormBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private String productNumber;
    private String projectName;
    private String loadOriginCode;
    private List<LicenseUsageForAccountFormBean> licenseAccFilterList;
    private List<LicenseUsageForVendorFormBean> licenseUsageForVendorList;
    private int runTimeForProject;
    private int runNumberForProject;
    private int lengthVendorFeatureList;

    /**
     * @param productNumber
     */
    public String getProductNumber() {
        return productNumber;
    }

    /**
     * @param productNumber
     *            the productNumber to set
     */
    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param loadOriginCode
     */
    public String getLoadOriginCode() {
        return loadOriginCode;
    }

    /**
     * @param loadOriginCode
     *            the loadOriginCode to set
     */
    public void setLoadOriginCode(String loadOriginCode) {
        this.loadOriginCode = loadOriginCode;
    }

    /**
     * @param licenseAccFilterList
     */
    public List<LicenseUsageForAccountFormBean> getLicenseAccFilterList() {
        return licenseAccFilterList;
    }

    /**
     * @param licenseAccFilterList
     *            the licenseAccFilterList to set
     */
    public void setLicenseAccFilterList(List<LicenseUsageForAccountFormBean> licenseAccFilterList) {
        this.licenseAccFilterList = licenseAccFilterList;
    }

    /**
     * @param runTimeForProject
     */
    public int getRunTimeForProject() {
        return runTimeForProject;
    }

    /**
     * @param runTimeForProject
     *            the runTimeForProject to set
     */
    public void setRunTimeForProject(int runTimeForProject) {
        this.runTimeForProject = runTimeForProject;
    }

    /**
     * @param runNumberForProject
     */
    public int getRunNumberForProject() {
        return runNumberForProject;
    }

    /**
     * @param runNumberForProject
     *            the runNumberForProject to set
     */
    public void setRunNumberForProject(int runNumberForProject) {
        this.runNumberForProject = runNumberForProject;
    }

    /**
     * @param lengthVendorFeatureList
     */
    public int getLengthVendorFeatureList() {
        return lengthVendorFeatureList;
    }

    /**
     * @param lengthVendorFeatureList
     *            the lengthVendorFeatureList to set
     */
    public void setLengthVendorFeatureList(int lengthVendorFeatureList) {
        this.lengthVendorFeatureList = lengthVendorFeatureList;
    }

    public List<LicenseUsageForVendorFormBean> getLicenseUsageForVendorList() {
        return licenseUsageForVendorList;
    }

    public void setLicenseUsageForVendorList(List<LicenseUsageForVendorFormBean> licenseUsageForVendorList) {
        this.licenseUsageForVendorList = licenseUsageForVendorList;
    }

}
