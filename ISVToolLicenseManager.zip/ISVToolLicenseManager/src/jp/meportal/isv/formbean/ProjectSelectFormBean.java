package jp.meportal.isv.formbean;

import java.io.Serializable;

public class ProjectSelectFormBean implements Serializable {

    private static final long serialVersionUID = -8767337896773261247L;

    private int seqNo;
    private String projectName;

    /**
     * @param seqNo
     */
    public int getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo
     *            the seqNo to set
     */
    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

}
