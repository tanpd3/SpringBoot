package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;

import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.util.DateUtils;

public class LicenseFormBean implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private int catalogId;
    private String vendorName;
    private String toolName;
    private String futureName;
    private BigDecimal memberPrice;
    private int keepNumber;
    private int year;
<<<<<<< .mine
    private int nextYear;
    private int month;
||||||| .r13147
=======
    private int nextYear;
    private int preYear;
    private int month;
    // start new data
>>>>>>> .r22123
    private Integer valueColumnLisence1;
    private Integer valueColumnLisence2;
    private Integer valueColumnLisence3;
    private Integer valueColumnLisence4;
    private Integer valueColumnLisence5;
    private Integer valueColumnLisence6;
    private Integer valueColumnLisence7;
    private Integer valueColumnLisence8;
    private Integer valueColumnLisence9;
    private Integer valueColumnLisence10;
    private Integer valueColumnLisence11;
    private Integer valueColumnLisence12;
    // end new data
    // start old data
    private Integer valueColumnLisence01;
    private Integer valueColumnLisence02;
    private Integer valueColumnLisence03;
    private Integer valueColumnLisence04;
    private Integer valueColumnLisence05;
    private Integer valueColumnLisence06;
    private Integer valueColumnLisence07;
    private Integer valueColumnLisence08;
    private Integer valueColumnLisence09;
    private Integer valueColumnLisence010;
    private Integer valueColumnLisence011;
    private Integer valueColumnLisence012;
    private String dateRegistation;
    private String dateUpdate;
    private int status;
    private int statusRegistation;
    // end old data
    
    private static NumberFormat formatter = NumberFormat.getInstance(Locale.JAPANESE);	// price format
    
    /**
     * @param catalogId
     * @param vendorName
     * @param toolName
     * @param memberPrice
     * @param keepNumber
     * @param year
     * @param nextYear
     * @param month
     * @param valueColumnLisence1
     * @param valueColumnLisence2
     * @param valueColumnLisence3
     * @param valueColumnLisence4
     * @param valueColumnLisence5
     * @param valueColumnLisence6
     * @param valueColumnLisence7
     * @param valueColumnLisence8
     * @param valueColumnLisence9
     * @param valueColumnLisence10
     * @param valueColumnLisence11
     * @param valueColumnLisence12
     * @param dateRegistation
     * @param dateUpdate
     * @param status
     * @param statusRegistation
     * @param valueColumnLisence01
     * @param valueColumnLisence02
     * @param valueColumnLisence03
     * @param valueColumnLisence04
     * @param valueColumnLisence05
     * @param valueColumnLisence06
     * @param valueColumnLisence07
     * @param valueColumnLisence08
     * @param valueColumnLisence09
     * @param valueColumnLisence010
     * @param valueColumnLisence011
     * @param valueColumnLisence012
     */
	public LicenseFormBean(int catalogId, String vendorName,
			String toolName, String futureName, BigDecimal memberPrice,
<<<<<<< .mine
			int keepNumber, int year, int nextYear, int month, Integer valueColumnLisence1,
||||||| .r13147
			int keepNumber, int year, Integer valueColumnLisence1,
=======
			int keepNumber, int year, int nextYear, int preYear, int month, Integer valueColumnLisence1,
>>>>>>> .r22123
			Integer valueColumnLisence2, Integer valueColumnLisence3,
			Integer valueColumnLisence4, Integer valueColumnLisence5,
			Integer valueColumnLisence6, Integer valueColumnLisence7,
			Integer valueColumnLisence8, Integer valueColumnLisence9,
			Integer valueColumnLisence10, Integer valueColumnLisence11,
			Integer valueColumnLisence12, String dateRegistation, String dateUpdate,
			int status, int statusRegistation, Integer valueColumnLisence01,
            Integer valueColumnLisence02, Integer valueColumnLisence03,
            Integer valueColumnLisence04, Integer valueColumnLisence05,
            Integer valueColumnLisence06, Integer valueColumnLisence07,
            Integer valueColumnLisence08, Integer valueColumnLisence09,
            Integer valueColumnLisence010, Integer valueColumnLisence011,
            Integer valueColumnLisence012) {
		super();
		this.catalogId = catalogId;
		this.vendorName = vendorName;
		this.toolName = toolName;
		this.futureName = futureName;
		this.memberPrice = memberPrice;
		this.keepNumber = keepNumber;
		this.year = year;
<<<<<<< .mine
		this.nextYear = nextYear;
		this.month = month;
||||||| .r13147
=======
		this.nextYear = nextYear;
		this.preYear = preYear;
		this.month = month;
>>>>>>> .r22123
		this.valueColumnLisence1 = valueColumnLisence1;
		this.valueColumnLisence2 = valueColumnLisence2;
		this.valueColumnLisence3 = valueColumnLisence3;
		this.valueColumnLisence4 = valueColumnLisence4;
		this.valueColumnLisence5 = valueColumnLisence5;
		this.valueColumnLisence6 = valueColumnLisence6;
		this.valueColumnLisence7 = valueColumnLisence7;
		this.valueColumnLisence8 = valueColumnLisence8;
		this.valueColumnLisence9 = valueColumnLisence9;
		this.valueColumnLisence10 = valueColumnLisence10;
		this.valueColumnLisence11 = valueColumnLisence11;
		this.valueColumnLisence12 = valueColumnLisence12;
		this.valueColumnLisence1 = valueColumnLisence01;
        this.valueColumnLisence2 = valueColumnLisence02;
        this.valueColumnLisence3 = valueColumnLisence03;
        this.valueColumnLisence4 = valueColumnLisence04;
        this.valueColumnLisence5 = valueColumnLisence05;
        this.valueColumnLisence6 = valueColumnLisence06;
        this.valueColumnLisence7 = valueColumnLisence07;
        this.valueColumnLisence8 = valueColumnLisence08;
        this.valueColumnLisence9 = valueColumnLisence09;
        this.valueColumnLisence10 = valueColumnLisence010;
        this.valueColumnLisence11 = valueColumnLisence011;
        this.valueColumnLisence12 = valueColumnLisence012;
		this.dateRegistation = dateRegistation;
		this.dateUpdate = dateUpdate;
		this.status = status;
		this.statusRegistation = statusRegistation;
	}
	
    /**
     * LicenseFormBean
     */
	public LicenseFormBean(){}
	
    /**
     * @param catalog
     */
	public LicenseFormBean(CatalogInfor catalog) {
		super();
		this.catalogId 		= catalog.getSeqNo();
		this.vendorName 	= catalog.getVendorName();
		this.toolName 		= catalog.getToolName();
		this.futureName		= catalog.getFutureName();
		this.memberPrice	= catalog.getMemberPrice();
		this.keepNumber		= catalog.getKeepNumber();
		this.year			= LocalDate.now().getYear();
		this.valueColumnLisence1 = 0;
		this.valueColumnLisence2 = 0;
		this.valueColumnLisence3 = 0;
		this.valueColumnLisence4 = 0;
		this.valueColumnLisence5 = 0;
		this.valueColumnLisence6 = 0;
		this.valueColumnLisence7 = 0;
		this.valueColumnLisence8 = 0;
		this.valueColumnLisence9 = 0;
		this.valueColumnLisence10 = 0;
		this.valueColumnLisence11 = 0;
		this.valueColumnLisence12 = 0;
		this.valueColumnLisence01 = 0;
        this.valueColumnLisence02 = 0;
        this.valueColumnLisence03 = 0;
        this.valueColumnLisence04 = 0;
        this.valueColumnLisence05 = 0;
        this.valueColumnLisence06 = 0;
        this.valueColumnLisence07 = 0;
        this.valueColumnLisence08 = 0;
        this.valueColumnLisence09 = 0;
        this.valueColumnLisence010 = 0;
        this.valueColumnLisence011 = 0;
        this.valueColumnLisence012 = 0;
		this.dateRegistation = StringUtils.EMPTY;
		this.dateUpdate = StringUtils.EMPTY;
		this.status = 0;
		this.statusRegistation = 2;
	}

    /**
     * @param catalogId
     */
    public int getCatalogId() {
        return catalogId;
    }

    /**
     * @param catalogId
     *            the catalogId to set
     */
    public void setCatalogId(int catalogId) {
        this.catalogId = catalogId;
    }

    /**
     * @param vendorName
     */
    public String getVendorName() {
        return vendorName;
    }

    /**
     * @param vendorName
     *            the vendorName to set
     */
    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    /**
     * @param toolName
     */
    public String getToolName() {
        return toolName;
    }

    /**
     * @param toolName
     *            the toolName to set
     */
    public void setToolName(String toolName) {
        this.toolName = toolName;
    }

    /**
     * @param futureName
     */
    public String getFutureName() {
        return futureName;
    }

    /**
     * @param futureName
     *            the futureName to set
     */
    public void setFutureName(String futureName) {
        this.futureName = futureName;
    }

    /**
     * @param memberPrice
     */
    public BigDecimal getMemberPrice() {
        return memberPrice;
    }
    
    /**
     * getMemberPriceString
     */
    public String getMemberPriceString() {
    	String memberPriceString = formatter.format(memberPrice.setScale(0,BigDecimal.ROUND_HALF_UP));
    	return memberPriceString;
    }
    
    /**
     * @param memberPrice
     *            the memberPrice to set
     */
    public void setMemberPrice(BigDecimal memberPrice) {
        this.memberPrice = memberPrice;
    }

    /**
     * @param keepNumber
     */
    public int getKeepNumber() {
        return keepNumber;
    }

    /**
     * @param keepNumber
     *            the keepNumber to set
     */
    public void setKeepNumber(int keepNumber) {
        this.keepNumber = keepNumber;
    }

    /**
     * @param year
     */
    public int getYear() {
        return year;
    }

    /**
     * @param year
     *            the year to set
     */
    public void setYear(int year) {
        this.year = year;
    }

    /**
     * @param preYear
     */
    public int getPreYear() {
        return preYear;
    }

    /**
     * @param preYear
     *            the preYear to set
     */
    public void setPreYear(int preYear) {
        this.preYear = preYear;
    }

    /**
     * @param valueColumnLisence1
     */
    public Integer getValueColumnLisence1() {
        return valueColumnLisence1;
    }

    /**
     * @param valueColumnLisence1
     *            the valueColumnLisence1 to set
     */
    public void setValueColumnLisence1(Integer valueColumnLisence1) {
        this.valueColumnLisence1 = valueColumnLisence1;
    }

    /**
     * @param valueColumnLisence2
     */
    public Integer getValueColumnLisence2() {
        return valueColumnLisence2;
    }

    /**
     * @param valueColumnLisence2
     *            the valueColumnLisence2 to set
     */
    public void setValueColumnLisence2(Integer valueColumnLisence2) {
        this.valueColumnLisence2 = valueColumnLisence2;
    }

    /**
     * @param valueColumnLisence3
     */
    public Integer getValueColumnLisence3() {
        return valueColumnLisence3;
    }

    /**
     * @param valueColumnLisence3
     *            the valueColumnLisence3 to set
     */
    public void setValueColumnLisence3(Integer valueColumnLisence3) {
        this.valueColumnLisence3 = valueColumnLisence3;
    }

    /**
     * @param valueColumnLisence4
     */
    public Integer getValueColumnLisence4() {
        return valueColumnLisence4;
    }

    /**
     * @param valueColumnLisence4
     *            the valueColumnLisence4 to set
     */
    public void setValueColumnLisence4(Integer valueColumnLisence4) {
        this.valueColumnLisence4 = valueColumnLisence4;
    }

    /**
     * @param valueColumnLisence5
     */
    public Integer getValueColumnLisence5() {
        return valueColumnLisence5;
    }

    /**
     * @param valueColumnLisence5
     *            the valueColumnLisence5 to set
     */
    public void setValueColumnLisence5(Integer valueColumnLisence5) {
        this.valueColumnLisence5 = valueColumnLisence5;
    }

    /**
     * @param valueColumnLisence6
     */
    public Integer getValueColumnLisence6() {
        return valueColumnLisence6;
    }

    /**
     * @param valueColumnLisence6
     *            the valueColumnLisence6 to set
     */
    public void setValueColumnLisence6(Integer valueColumnLisence6) {
        this.valueColumnLisence6 = valueColumnLisence6;
    }

    /**
     * @param valueColumnLisence7
     */
    public Integer getValueColumnLisence7() {
        return valueColumnLisence7;
    }

    /**
     * @param valueColumnLisence7
     *            the valueColumnLisence7 to set
     */
    public void setValueColumnLisence7(Integer valueColumnLisence7) {
        this.valueColumnLisence7 = valueColumnLisence7;
    }

    /**
     * @param valueColumnLisence8
     */
    public Integer getValueColumnLisence8() {
        return valueColumnLisence8;
    }

    /**
     * @param valueColumnLisence8
     *            the valueColumnLisence8 to set
     */
    public void setValueColumnLisence8(Integer valueColumnLisence8) {
        this.valueColumnLisence8 = valueColumnLisence8;
    }

    /**
     * @param valueColumnLisence9
     */
    public Integer getValueColumnLisence9() {
        return valueColumnLisence9;
    }

    /**
     * @param valueColumnLisence9
     *            the valueColumnLisence9 to set
     */
    public void setValueColumnLisence9(Integer valueColumnLisence9) {
        this.valueColumnLisence9 = valueColumnLisence9;
    }

    /**
     * @param valueColumnLisence10
     */
    public Integer getValueColumnLisence10() {
        return valueColumnLisence10;
    }

    /**
     * @param valueColumnLisence10
     *            the valueColumnLisence10 to set
     */
    public void setValueColumnLisence10(Integer valueColumnLisence10) {
        this.valueColumnLisence10 = valueColumnLisence10;
    }

    /**
     * @param valueColumnLisence11
     */
    public Integer getValueColumnLisence11() {
        return valueColumnLisence11;
    }

    /**
     * @param valueColumnLisence11
     *            the valueColumnLisence11 to set
     */
    public void setValueColumnLisence11(Integer valueColumnLisence11) {
        this.valueColumnLisence11 = valueColumnLisence11;
    }

    /**
     * @param valueColumnLisence12
     */
    public Integer getValueColumnLisence12() {
        return valueColumnLisence12;
    }

    /**
     * @param valueColumnLisence12
     *            the valueColumnLisence12 to set
     */
    public void setValueColumnLisence12(Integer valueColumnLisence12) {
        this.valueColumnLisence12 = valueColumnLisence12;
    }

    /**
     * @param dateRegistation
     */
    public String getDateRegistation() {
        return dateRegistation;
    }

    /**
     * @param getDateRegistationFormat
     */
    public String getDateRegistationFormat() {
        String dateFormat = StringUtils.EMPTY;
        if (!StringUtils.isEmpty(dateRegistation)) {
            dateFormat = DateUtils.getDateUpdate(dateRegistation);
        }
        return dateFormat;
    }
    
    /**
     * @param dateRegistation
     *            the dateRegistation to set
     */
    public void setDateRegistation(String dateRegistation) {
        this.dateRegistation = dateRegistation;
    }

    /**
     * @param dateUpdate
     */
    public String getDateUpdate() {
        return dateUpdate;
    }

    /**
     * @param getDateUpdateFormat
     */
    public String getDateUpdateFormat() {
        String dateFormat = StringUtils.EMPTY;
        if (!StringUtils.isEmpty(dateUpdate)) {
            dateFormat = DateUtils.getDateUpdate(dateUpdate);
        }
        return dateFormat;
    }
    
    /**
     * @param dateUpdate
     *            the dateUpdate to set
     */
    public void setDateUpdate(String dateUpdate) {
        this.dateUpdate = dateUpdate;
    }

    /**
     * @param status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @param statusRegistation
     */
    public int getStatusRegistation() {
        return statusRegistation;
    }

    /**
     * @param statusRegistation
     *            the statusRegistation to set
     */
    public void setStatusRegistation(int statusRegistation) {
        this.statusRegistation = statusRegistation;
    }
<<<<<<< .mine

    public int getNextYear() {
        return nextYear;
    }

    public void setNextYear(int nextYear) {
        this.nextYear = nextYear;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }
	
||||||| .r13147
	
=======

    /**
     * @param nextYear
     */
    public int getNextYear() {
        return nextYear;
    }

    /**
     * @param nextYear
     *            the nextYear to set
     */
    public void setNextYear(int nextYear) {
        this.nextYear = nextYear;
    }

    /**
     * @param month
     */
    public int getMonth() {
        return month;
    }

    /**
     * @param month
     *            the month to set
     */
    public void setMonth(int month) {
        this.month = month;
    }

    /**
     * @param valueColumnLisence01
     */
    public Integer getValueColumnLisence01() {
        return valueColumnLisence01;
    }

    /**
     * @param valueColumnLisence01
     *            the valueColumnLisence01 to set
     */
    public void setValueColumnLisence01(Integer valueColumnLisence01) {
        this.valueColumnLisence01 = valueColumnLisence01;
    }

    /**
     * @param valueColumnLisence02
     */
    public Integer getValueColumnLisence02() {
        return valueColumnLisence02;
    }

    /**
     * @param valueColumnLisence02
     *            the valueColumnLisence02 to set
     */
    public void setValueColumnLisence02(Integer valueColumnLisence02) {
        this.valueColumnLisence02 = valueColumnLisence02;
    }

    /**
     * @param valueColumnLisence03
     */
    public Integer getValueColumnLisence03() {
        return valueColumnLisence03;
    }

    /**
     * @param valueColumnLisence03
     *            the valueColumnLisence03 to set
     */
    public void setValueColumnLisence03(Integer valueColumnLisence03) {
        this.valueColumnLisence03 = valueColumnLisence03;
    }

    /**
     * @param valueColumnLisence04
     */
    public Integer getValueColumnLisence04() {
        return valueColumnLisence04;
    }

    /**
     * @param valueColumnLisence04
     *            the valueColumnLisence04 to set
     */
    public void setValueColumnLisence04(Integer valueColumnLisence04) {
        this.valueColumnLisence04 = valueColumnLisence04;
    }

    /**
     * @param valueColumnLisence05
     */
    public Integer getValueColumnLisence05() {
        return valueColumnLisence05;
    }

    /**
     * @param valueColumnLisence05
     *            the valueColumnLisence05 to set
     */
    public void setValueColumnLisence05(Integer valueColumnLisence05) {
        this.valueColumnLisence05 = valueColumnLisence05;
    }

    /**
     * @param valueColumnLisence06
     */
    public Integer getValueColumnLisence06() {
        return valueColumnLisence06;
    }

    /**
     * @param valueColumnLisence06
     *            the valueColumnLisence06 to set
     */
    public void setValueColumnLisence06(Integer valueColumnLisence06) {
        this.valueColumnLisence06 = valueColumnLisence06;
    }

    /**
     * @param valueColumnLisence07
     */
    public Integer getValueColumnLisence07() {
        return valueColumnLisence07;
    }

    /**
     * @param valueColumnLisence07
     *            the valueColumnLisence07 to set
     */
    public void setValueColumnLisence07(Integer valueColumnLisence07) {
        this.valueColumnLisence07 = valueColumnLisence07;
    }

    /**
     * @param valueColumnLisence08
     */
    public Integer getValueColumnLisence08() {
        return valueColumnLisence08;
    }

    /**
     * @param valueColumnLisence08
     *            the valueColumnLisence08 to set
     */
    public void setValueColumnLisence08(Integer valueColumnLisence08) {
        this.valueColumnLisence08 = valueColumnLisence08;
    }

    /**
     * @param valueColumnLisence09
     */
    public Integer getValueColumnLisence09() {
        return valueColumnLisence09;
    }

    /**
     * @param valueColumnLisence09
     *            the valueColumnLisence09 to set
     */
    public void setValueColumnLisence09(Integer valueColumnLisence09) {
        this.valueColumnLisence09 = valueColumnLisence09;
    }

    /**
     * @param valueColumnLisence010
     */
    public Integer getValueColumnLisence010() {
        return valueColumnLisence010;
    }

    /**
     * @param valueColumnLisence010
     *            the valueColumnLisence010 to set
     */
    public void setValueColumnLisence010(Integer valueColumnLisence010) {
        this.valueColumnLisence010 = valueColumnLisence010;
    }

    /**
     * @param valueColumnLisence011
     */
    public Integer getValueColumnLisence011() {
        return valueColumnLisence011;
    }

    /**
     * @param valueColumnLisence011
     *            the valueColumnLisence011 to set
     */
    public void setValueColumnLisence011(Integer valueColumnLisence011) {
        this.valueColumnLisence011 = valueColumnLisence011;
    }

    /**
     * @param valueColumnLisence012
     */
    public Integer getValueColumnLisence012() {
        return valueColumnLisence012;
    }

    /**
     * @param valueColumnLisence012
     *            the valueColumnLisence012 to set
     */
    public void setValueColumnLisence012(Integer valueColumnLisence012) {
        this.valueColumnLisence012 = valueColumnLisence012;
    }
>>>>>>> .r22123
}
