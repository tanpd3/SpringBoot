package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.util.List;

public class LicenseUsageForProjectToolNameFormBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private String projectName;
    private String productNumber;
    private List<LicenseUsageForFeatureFormBean> licenseUsageForFeatureList;
    private int lengthFeatureList;

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param productNumber
     */
    public String getProductNumber() {
        return productNumber;
    }

    /**
     * @param productNumber
     *            the productNumber to set
     */
    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    /**
     * @param licenseUsageForFeatureList
     */
    public List<LicenseUsageForFeatureFormBean> getLicenseUsageForFeatureList() {
        return licenseUsageForFeatureList;
    }

    /**
     * @param licenseUsageForFeatureList
     *            the licenseUsageForFeatureList to set
     */
    public void setLicenseUsageForFeatureList(List<LicenseUsageForFeatureFormBean> licenseUsageForFeatureList) {
        this.licenseUsageForFeatureList = licenseUsageForFeatureList;
    }

    /**
     * @param lengthFeatureList
     */
    public int getLengthFeatureList() {
        return lengthFeatureList;
    }

    /**
     * @param lengthFeatureList
     *            the lengthFeatureList to set
     */
    public void setLengthFeatureList(int lengthFeatureList) {
        this.lengthFeatureList = lengthFeatureList;
    }

}
