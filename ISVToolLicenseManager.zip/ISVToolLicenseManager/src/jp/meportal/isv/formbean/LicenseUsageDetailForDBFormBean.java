package jp.meportal.isv.formbean;

import java.io.Serializable;

public class LicenseUsageDetailForDBFormBean implements Serializable{
    private static final long serialVersionUID = 1L;

    private String account;
    private String vendorName;
    private String toolName;
    private String futureName;
    private String host;
    private int runTimeWithoutFew;
    private int runNumberWithoutFew;
    private int sameTimeUseNumber;
    private int isCharge;

    /**
     * @param account
     */
    public String getAccount() {
        return account;
    }

    /**
     * @param account
     *            the account to set
     */
    public void setAccount(String account) {
        this.account = account;
    }

    /**
     * @param vendorName
     */
    public String getVendorName() {
        return vendorName;
    }

    /**
     * @param vendorName
     *            the vendorName to set
     */
    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    /**
     * @param toolName
     */
    public String getToolName() {
        return toolName;
    }

    /**
     * @param toolName
     *            the toolName to set
     */
    public void setToolName(String toolName) {
        this.toolName = toolName;
    }

    /**
     * @param futureName
     */
    public String getFutureName() {
        return futureName;
    }

    /**
     * @param futureName
     *            the futureName to set
     */
    public void setFutureName(String futureName) {
        this.futureName = futureName;
    }

    /**
     * @param host
     */
    public String getHost() {
        return host;
    }

    /**
     * @param host
     *            the host to set
     */
    public void setHost(String host) {
        this.host = host;
    }

    /**
     * @param runTimeWithoutFew
     */
    public int getRunTimeWithoutFew() {
        return runTimeWithoutFew;
    }

    /**
     * @param runTimeWithoutFew
     *            the runTimeWithoutFew to set
     */
    public void setRunTimeWithoutFew(int runTimeWithoutFew) {
        this.runTimeWithoutFew = runTimeWithoutFew;
    }

    /**
     * @param runNumberWithoutFew
     */
    public int getRunNumberWithoutFew() {
        return runNumberWithoutFew;
    }

    /**
     * @param runNumberWithoutFew
     *            the runNumberWithoutFew to set
     */
    public void setRunNumberWithoutFew(int runNumberWithoutFew) {
        this.runNumberWithoutFew = runNumberWithoutFew;
    }

    /**
     * @param sameTimeUseNumber
     */
    public int getSameTimeUseNumber() {
        return sameTimeUseNumber;
    }

    /**
     * @param sameTimeUseNumber
     *            the sameTimeUseNumber to set
     */
    public void setSameTimeUseNumber(int sameTimeUseNumber) {
        this.sameTimeUseNumber = sameTimeUseNumber;
    }

    /**
     * @param isCharge
     */
    public int getIsCharge() {
        return isCharge;
    }

    /**
     * @param isCharge
     *            the isCharge to set
     */
    public void setIsCharge(int isCharge) {
        this.isCharge = isCharge;
    }
}
