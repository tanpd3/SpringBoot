package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.math.BigDecimal;

public class LicenseTotalTaxColumn implements Serializable{

    private static final long serialVersionUID = 1L;
    
    public int licenseUseInfoId;
    public int licenseRegisId;
    public int projectId;
    public int catalogId;
    public String projectName;
    public String productNumber;
    public String venderName;
    public String toolName;
    public String futureName;
    public String loadOriginCode;
    public Integer countBudgetPerMonth;
    public Integer countActualPerMonth;
    public Integer countSubTractBudgetActual;
    public BigDecimal moneyBudgetPerMonth;
    public BigDecimal moneyActualPerMonth;
    public BigDecimal moreBudgetPerMonth;
    public BigDecimal memberPrice;
    public BigDecimal regularPrice;
    public BigDecimal sumBudgetAndMoreBudget;
    
    /**
     * @param licenseUseInfoId
     * @param licenseRegisId
     * @param projectId
     * @param catalogId
     * @param projectName
     * @param venderName
     * @param toolName
     * @param futureName
     * @param loadOriginCode
     * @param countBudgetPerMonth
     * @param countActualPerMonth
     * @param countSubTractBudgetActual
     * @param moneyBudgetPerMonth
     * @param moneyActualPerMonth
     * @param memberPrice
     * @param regularPrice
     * @param moreBudgetPerMonth
     * @param productNumber
     * @param sumBudgetAndMoreBudget
     */
    public LicenseTotalTaxColumn(int licenseUseInfoId, int licenseRegisId, int projectId, int catalogId, String projectName, String venderName, String toolName, 
            String futureName, String loadOriginCode, Integer countBudgetPerMonth, Integer countActualPerMonth, Integer countSubTractBudgetActual, 
            BigDecimal moneyBudgetPerMonth, BigDecimal moneyActualPerMonth, BigDecimal memberPrice, BigDecimal regularPrice,
            BigDecimal moreBudgetPerMonth, String productNumber, BigDecimal sumBudgetAndMoreBudget) {
        this.licenseUseInfoId = licenseUseInfoId;
        this.licenseRegisId = licenseRegisId;
        this.projectId = projectId;
        this.catalogId = catalogId;
        this.projectName = projectName;
        this.venderName = venderName;
        this.toolName = toolName;
        this.futureName = futureName;
        this.loadOriginCode = loadOriginCode;
        this.countBudgetPerMonth = countBudgetPerMonth;
        this.countActualPerMonth = countActualPerMonth;
        this.countSubTractBudgetActual = countSubTractBudgetActual;
        this.moneyBudgetPerMonth = moneyBudgetPerMonth;
        this.moneyActualPerMonth = moneyActualPerMonth;
        this.memberPrice = memberPrice;
        this.regularPrice = regularPrice;
        this.moreBudgetPerMonth = moreBudgetPerMonth;
        this.productNumber = productNumber;
        this.sumBudgetAndMoreBudget = sumBudgetAndMoreBudget;
    }
    
    public LicenseTotalTaxColumn() {}

    /**
     * @param licenseUseInfoId
     */
    public int getLicenseUseInfoId() {
        return licenseUseInfoId;
    }

    /**
     * @param licenseUseInfoId
     *            the licenseUseInfoId to set
     */
    public void setLicenseUseInfoId(int licenseUseInfoId) {
        this.licenseUseInfoId = licenseUseInfoId;
    }
    
    /**
     * @param licenseRegisId
     */
    public int getLicenseRegisId() {
        return licenseRegisId;
    }

    /**
     * @param licenseRegisId
     *            the licenseRegisId to set
     */
    public void setLicenseRegisId(int licenseRegisId) {
        this.licenseRegisId = licenseRegisId;
    }
    /**
     * @param projectId
     */
    public int getProjectId() {
        return projectId;
    }

    /**
     * @param projectId
     *            the projectId to set
     */
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    /**
     * @param catalogId
     */
    public int getCatalogId() {
        return catalogId;
    }

    /**
     * @param catalogId
     *            the catalogId to set
     */
    public void setCatalogId(int catalogId) {
        this.catalogId = catalogId;
    }

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param venderName
     */
    public String getVenderName() {
        return venderName;
    }

    /**
     * @param venderName
     *            the venderName to set
     */
    public void setVenderName(String venderName) {
        this.venderName = venderName;
    }

    /**
     * @param toolName
     */
    public String getToolName() {
        return toolName;
    }

    /**
     * @param toolName
     *            the toolName to set
     */
    public void setToolName(String toolName) {
        this.toolName = toolName;
    }

    /**
     * @param futureName
     */
    public String getFutureName() {
        return futureName;
    }

    /**
     * @param futureName
     *            the futureName to set
     */
    public void setFutureName(String futureName) {
        this.futureName = futureName;
    }
    
    /**
     * @param loadOriginCode
     */
    public String getLoadOriginCode() {
        return loadOriginCode;
    }

    /**
     * @param loadOriginCode
     *            the loadOriginCode to set
     */
    public void setLoadOriginCode(String loadOriginCode) {
        this.loadOriginCode = loadOriginCode;
    }
    
    /**
     * @param countBudgetPerMonth
     */
    public Integer getCountBudgetPerMonth() {
        return countBudgetPerMonth;
    }

    /**
     * @param countBudgetPerMonth
     *            the countBudgetPerMonth to set
     */
    public void setCountBudgetPerMonth(Integer countBudgetPerMonth) {
        this.countBudgetPerMonth = countBudgetPerMonth;
    }

    /**
     * @param countActualPerMonth
     */
    public Integer getCountActualPerMonth() {
        return countActualPerMonth;
    }

    /**
     * @param countActualPerMonth
     *            the countActualPerMonth to set
     */
    public void setCountActualPerMonth(Integer countActualPerMonth) {
        this.countActualPerMonth = countActualPerMonth;
    }

    /**
     * @param countSubTractBudgetActual
     */
    public Integer getCountSubTractBudgetActual() {
        return countSubTractBudgetActual;
    }

    /**
     * @param countSubTractBudgetActual
     *            the countSubTractBudgetActual to set
     */
    public void setCountSubTractBudgetActual(Integer countSubTractBudgetActual) {
        this.countSubTractBudgetActual = countSubTractBudgetActual;
    }

    /**
     * @param moneyBudgetPerMonth
     */
    public BigDecimal getMoneyBudgetPerMonth() {
        return moneyBudgetPerMonth;
    }

    /**
     * @param moneyBudgetPerMonth
     *            the moneyBudgetPerMonth to set
     */
    public void setMoneyBudgetPerMonth(BigDecimal moneyBudgetPerMonth) {
        this.moneyBudgetPerMonth = moneyBudgetPerMonth;
    }

    /**
     * @param moneyActualPerMonth
     */
    public BigDecimal getMoneyActualPerMonth() {
        return moneyActualPerMonth;
    }

    /**
     * @param moneyActualPerMonth
     *            the moneyActualPerMonth to set
     */
    public void setMoneyActualPerMonth(BigDecimal moneyActualPerMonth) {
        this.moneyActualPerMonth = moneyActualPerMonth;
    }

    /**
     * @param memberPrice
     */
    public BigDecimal getMemberPrice() {
        return memberPrice;
    }

    /**
     * @param memberPrice
     *            the memberPrice to set
     */
    public void setMemberPrice(BigDecimal memberPrice) {
        this.memberPrice = memberPrice;
    }

    /**
     * @param regularPrice
     */
    public BigDecimal getRegularPrice() {
        return regularPrice;
    }

    /**
     * @param regularPrice
     *            the regularPrice to set
     */
    public void setRegularPrice(BigDecimal regularPrice) {
        this.regularPrice = regularPrice;
    }

    /**
     * @param moreBudgetPerMonth
     */
    public BigDecimal getMoreBudgetPerMonth() {
        return moreBudgetPerMonth;
    }

    /**
     * @param moreBudgetPerMonth
     *            the moreBudgetPerMonth to set
     */
    public void setMoreBudgetPerMonth(BigDecimal moreBudgetPerMonth) {
        this.moreBudgetPerMonth = moreBudgetPerMonth;
    }

    /**
     * @param productNumber
     */
    public String getProductNumber() {
        return productNumber;
    }

    /**
     * @param productNumber
     *            the productNumber to set
     */
    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    /**
     * @param sumBudgetAndMoreBudget
     */
    public BigDecimal getSumBudgetAndMoreBudget() {
        return sumBudgetAndMoreBudget;
    }

    /**
     * @param sumBudgetAndMoreBudget
     *            the sumBudgetAndMoreBudget to set
     */
    public void setSumBudgetAndMoreBudget(BigDecimal sumBudgetAndMoreBudget) {
        this.sumBudgetAndMoreBudget = sumBudgetAndMoreBudget;
    }
}
