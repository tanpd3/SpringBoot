package jp.meportal.isv.formbean;

import java.io.Serializable;

public class MemberByProjectIdFormBean implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String projectName;
    private String managerName;
    private String email;
    private String updateDate;
    private String checkBoxStatus;
    private String memberId;
    private String isManager;
    private String createDate;

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param managerName
     */
    public String getManagerName() {
        return managerName;
    }

    /**
     * @param managerName
     *            the managerName to set
     */
    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    /**
     * @param email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email
     *            the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @param updateDate
     */
    public String getUpdateDate() {
        return updateDate;
    }

    /**
     * @param updateDate
     *            the updateDate to set
     */
    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * @param checkBoxStatus
     */
    public String getCheckBoxStatus() {
        return checkBoxStatus;
    }

    /**
     * @param checkBoxStatus
     *            the checkBoxStatus to set
     */
    public void setCheckBoxStatus(String checkBoxStatus) {
        this.checkBoxStatus = checkBoxStatus;
    }

    /**
     * @param memberId
     */
    public String getMemberId() {
        return memberId;
    }

    /**
     * @param memberId
     *            the memberId to set
     */
    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    /**
     * @param isManager
     */
    public String getIsManager() {
        return isManager;
    }

    /**
     * @param isManager
     *            the isManager to set
     */
    public void setIsManager(String isManager) {
        this.isManager = isManager;
    }

    /**
     * @param createDate
     */
    public String getCreateDate() {
        return createDate;
    }

    /**
     * @param createDate
     *            the createDate to set
     */
    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    /**
     * @param MemberByProjectIdFormBean
     */
    public MemberByProjectIdFormBean() {
        super();
    }
}
