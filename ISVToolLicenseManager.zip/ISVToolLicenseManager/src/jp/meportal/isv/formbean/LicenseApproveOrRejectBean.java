package jp.meportal.isv.formbean;

import java.io.Serializable;

public class LicenseApproveOrRejectBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private int seqNo;
    private int status;
    private String projectName;
    private String comment;
    private String registeredUser;
    private String createDate;
    private String approver;
    private String approveDate;
    private String mailRegister;

    public LicenseApproveOrRejectBean() {}

    /**
     * @param seqNo
     * @param status
     * @param projectName
     * @param comment
     * @param registeredUser
     * @param createDate
     * @param approver
     * @param approveDate
     * @param mailRegister
     */
    public LicenseApproveOrRejectBean(int seqNo, int status, String projectName, String comment, String registeredUser,
            String createDate, String approver, String approveDate, String mailRegister) {
        this.status = status;
        this.projectName = projectName;
        this.comment = comment;
        this.registeredUser = registeredUser;
        this.createDate = createDate;
        this.approver = approver;
        this.approveDate = approveDate;
    }

    /**
     * @param seqNo
     */
    public int getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo
     *            the seqNo to set
     */
    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @param status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment
     *            the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @param registeredUser
     */
    public String getRegisteredUser() {
        return registeredUser;
    }

    /**
     * @param registeredUser
     *            the registeredUser to set
     */
    public void setRegisteredUser(String registeredUser) {
        this.registeredUser = registeredUser;
    }

    /**
     * @param createDate
     */
    public String getCreateDate() {
        return createDate;
    }

    /**
     * @param createDate
     *            the createDate to set
     */
    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    /**
     * @param approver
     */
    public String getApprover() {
        return approver;
    }

    /**
     * @param approver
     *            the approver to set
     */
    public void setApprover(String approver) {
        this.approver = approver;
    }

    /**
     * @param approveDate
     */
    public String getApproveDate() {
        return approveDate;
    }

    /**
     * @param approveDate
     *            the approveDate to set
     */
    public void setApproveDate(String approveDate) {
        this.approveDate = approveDate;
    }

    /**
     * @param mailRegister
     */
    public String getMailRegister() {
        return mailRegister;
    }

    /**
     * @param mailRegister
     *            the mailRegister to set
     */
    public void setMailRegister(String mailRegister) {
        this.mailRegister = mailRegister;
    }
}
