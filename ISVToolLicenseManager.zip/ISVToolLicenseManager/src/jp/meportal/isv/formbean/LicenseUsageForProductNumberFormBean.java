package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.util.List;

public class LicenseUsageForProductNumberFormBean implements Serializable{
    private static final long serialVersionUID = 1L;

    private String productNumber;
    private List<LicenseUsageForProjectFormBean> licenseUsageForProjectList;
    private int totalRunTime;
    private int totalRunNumber;
    private String strTotalRunTime;
    private int lengthProjectFeatureList;

    /**
     * @param productNumber
     */
    public String getProductNumber() {
        return productNumber;
    }

    /**
     * @param productNumber
     *            the productNumber to set
     */
    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    /**
     * @param licenseUsageForProjectList
     */
    public List<LicenseUsageForProjectFormBean> getLicenseUsageForProjectList() {
        return licenseUsageForProjectList;
    }

    /**
     * @param licenseUsageForProjectList
     *            the licenseUsageForProjectList to set
     */
    public void setLicenseUsageForProjectList(List<LicenseUsageForProjectFormBean> licenseUsageForProjectList) {
        this.licenseUsageForProjectList = licenseUsageForProjectList;
    }

    /**
     * @param totalRunTime
     */
    public int getTotalRunTime() {
        return totalRunTime;
    }

    /**
     * @param totalRunTime
     *            the totalRunTime to set
     */
    public void setTotalRunTime(int totalRunTime) {
        this.totalRunTime = totalRunTime;
    }

    /**
     * @param totalRunNumber
     */
    public int getTotalRunNumber() {
        return totalRunNumber;
    }

    /**
     * @param totalRunNumber
     *            the totalRunNumber to set
     */
    public void setTotalRunNumber(int totalRunNumber) {
        this.totalRunNumber = totalRunNumber;
    }

    /**
     * @param strTotalRunTime
     */
    public String getStrTotalRunTime() {
        return strTotalRunTime;
    }

    /**
     * @param strTotalRunTime
     *            the strTotalRunTime to set
     */
    public void setStrTotalRunTime(String strTotalRunTime) {
        this.strTotalRunTime = strTotalRunTime;
    }

    /**
     * @param lengthProjectFeatureList
     */
    public int getLengthProjectFeatureList() {
        return lengthProjectFeatureList;
    }

    /**
     * @param lengthProjectFeatureList
     *            the lengthProjectFeatureList to set
     */
    public void setLengthProjectFeatureList(int lengthProjectFeatureList) {
        this.lengthProjectFeatureList = lengthProjectFeatureList;
    }

}
