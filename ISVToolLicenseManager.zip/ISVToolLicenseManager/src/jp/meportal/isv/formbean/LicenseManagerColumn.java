package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.math.BigDecimal;

public class LicenseManagerColumn implements Serializable {
    
    private static final long serialVersionUID = 1L;

    public String projectName;
    public String venderName;
    public String toolName;
    public String futureName;
    public BigDecimal subTractBudgetActual;
    public BigDecimal budgetMonth1;
    public BigDecimal budgetMonth2;
    public BigDecimal budgetMonth3;
    public BigDecimal budgetMonth4;
    public BigDecimal budgetMonth5;
    public BigDecimal budgetMonth6;
    public BigDecimal budgetMonth7;
    public BigDecimal budgetMonth8;
    public BigDecimal budgetMonth9;
    public BigDecimal budgetMonth10;
    public BigDecimal budgetMonth11;
    public BigDecimal budgetMonth12;
    public BigDecimal budgetMonth1Div1000;
    public BigDecimal budgetMonth2Div1000;
    public BigDecimal budgetMonth3Div1000;
    public BigDecimal budgetMonth4Div1000;
    public BigDecimal budgetMonth5Div1000;
    public BigDecimal budgetMonth6Div1000;
    public BigDecimal budgetMonth7Div1000;
    public BigDecimal budgetMonth8Div1000;
    public BigDecimal budgetMonth9Div1000;
    public BigDecimal budgetMonth10Div1000;
    public BigDecimal budgetMonth11Div1000;
    public BigDecimal budgetMonth12Div1000;
    public BigDecimal budgetSumQ1;
    public BigDecimal budgetSumQ2;
    public BigDecimal budgetSumQ12;
    public BigDecimal budgetSumQ3;
    public BigDecimal budgetSumQ4;
    public BigDecimal budgetSumQ34;
    public BigDecimal budgetSumQ1Div1000;
    public BigDecimal budgetSumQ2Div1000;
    public BigDecimal budgetSumQ12Div1000;
    public BigDecimal budgetSumQ3Div1000;
    public BigDecimal budgetSumQ4Div1000;
    public BigDecimal budgetSumQ34Div1000;
    public BigDecimal budgetTotalInYear;
    public BigDecimal budgetTotalInYearDiv1000;
    public BigDecimal actualMonth1;
    public BigDecimal actualMonth2;
    public BigDecimal actualMonth3;
    public BigDecimal actualMonth4;
    public BigDecimal actualMonth5;
    public BigDecimal actualMonth6;
    public BigDecimal actualMonth7;
    public BigDecimal actualMonth8;
    public BigDecimal actualMonth9;
    public BigDecimal actualMonth10;
    public BigDecimal actualMonth11;
    public BigDecimal actualMonth12;
    public BigDecimal actualMonth1Div1000;
    public BigDecimal actualMonth2Div1000;
    public BigDecimal actualMonth3Div1000;
    public BigDecimal actualMonth4Div1000;
    public BigDecimal actualMonth5Div1000;
    public BigDecimal actualMonth6Div1000;
    public BigDecimal actualMonth7Div1000;
    public BigDecimal actualMonth8Div1000;
    public BigDecimal actualMonth9Div1000;
    public BigDecimal actualMonth10Div1000;
    public BigDecimal actualMonth11Div1000;
    public BigDecimal actualMonth12Div1000;
    public BigDecimal actualSumQ1;
    public BigDecimal actualSumQ2;
    public BigDecimal actualSumQ12;
    public BigDecimal actualSumQ3;
    public BigDecimal actualSumQ4;
    public BigDecimal actualSumQ34;
    public BigDecimal actualSumQ1Div1000;
    public BigDecimal actualSumQ2Div1000;
    public BigDecimal actualSumQ12Div1000;
    public BigDecimal actualSumQ3Div1000;
    public BigDecimal actualSumQ4Div1000;
    public BigDecimal actualSumQ34Div1000;
    public BigDecimal actualTotalInYear;
    public BigDecimal actualTotalInYearDiv1000;
    
    /**
     * @param projectName
     * @param budgetMonth1
     * @param budgetMonth2
     * @param budgetMonth3
     * @param budgetMonth4
     * @param budgetMonth5
     * @param budgetMonth6
     * @param budgetMonth7
     * @param budgetMonth8
     * @param budgetMonth9
     * @param budgetMonth10
     * @param budgetMonth11
     * @param budgetMonth12
     * @param budgetMonth1Div1000
     * @param budgetMonth2Div1000
     * @param budgetMonth3Div1000
     * @param budgetMonth4Div1000
     * @param budgetMonth5Div1000
     * @param budgetMonth6Div1000
     * @param budgetMonth7Div1000
     * @param budgetMonth8Div1000
     * @param budgetMonth9Div1000
     * @param budgetMonth10Div1000
     * @param budgetMonth11Div1000
     * @param budgetMonth12Div1000
     * @param budgetSumQ1
     * @param budgetSumQ2
     * @param budgetSumQ12
     * @param budgetSumQ3
     * @param budgetSumQ4
     * @param budgetSumQ34
     * @param budgetSumQ1Div1000
     * @param budgetSumQ2Div1000
     * @param budgetSumQ12Div1000
     * @param budgetSumQ3Div1000
     * @param budgetSumQ4Div1000
     * @param budgetSumQ34Div1000
     * @param budgetTotalInYear
     * @param budgetTotalInYearDiv1000
     * @param actualMonth1
     * @param actualMonth2
     * @param actualMonth3
     * @param actualMonth4
     * @param actualMonth5
     * @param actualMonth6
     * @param actualMonth7
     * @param actualMonth8
     * @param actualMonth9
     * @param actualMonth10
     * @param actualMonth11
     * @param actualMonth12
     * @param actualMonth1Div1000
     * @param actualMonth2Div1000
     * @param actualMonth3Div1000
     * @param actualMonth4Div1000
     * @param actualMonth5Div1000
     * @param actualMonth6Div1000
     * @param actualMonth7Div1000
     * @param actualMonth8Div1000
     * @param actualMonth9Div1000
     * @param actualMonth10Div1000
     * @param actualMonth11Div1000
     * @param actualMonth12Div1000
     * @param actualSumQ1
     * @param actualSumQ2
     * @param actualSumQ12
     * @param actualSumQ3
     * @param actualSumQ4
     * @param actualSumQ34
     * @param actualSumQ1Div1000
     * @param actualSumQ2Div1000
     * @param actualSumQ12Div1000
     * @param actualSumQ3Div1000
     * @param actualSumQ4Div1000
     * @param actualSumQ34Div1000
     * @param actualTotalInYear
     * @param actualTotalInYearDiv1000
     */
    public LicenseManagerColumn(String projectName, 
            BigDecimal budgetMonth1, BigDecimal budgetMonth2, BigDecimal budgetMonth3,
            BigDecimal budgetMonth4, BigDecimal budgetMonth5, BigDecimal budgetMonth6, BigDecimal budgetMonth7,
            BigDecimal budgetMonth8, BigDecimal budgetMonth9, BigDecimal budgetMonth10, BigDecimal budgetMonth11,
            BigDecimal budgetMonth12, 
            BigDecimal budgetMonth1Div1000, BigDecimal budgetMonth2Div1000, BigDecimal budgetMonth3Div1000,
            BigDecimal budgetMonth4Div1000, BigDecimal budgetMonth5Div1000, BigDecimal budgetMonth6Div1000, BigDecimal budgetMonth7Div1000,
            BigDecimal budgetMonth8Div1000, BigDecimal budgetMonth9Div1000, BigDecimal budgetMonth10Div1000, BigDecimal budgetMonth11Div1000,
            BigDecimal budgetMonth12Div1000, 
            BigDecimal budgetSumQ1, BigDecimal budgetSumQ2, BigDecimal budgetSumQ12,
            BigDecimal budgetSumQ3, BigDecimal budgetSumQ4, BigDecimal budgetSumQ34,
            BigDecimal budgetSumQ1Div1000, BigDecimal budgetSumQ2Div1000, BigDecimal budgetSumQ12Div1000,
            BigDecimal budgetSumQ3Div1000, BigDecimal budgetSumQ4Div1000, BigDecimal budgetSumQ34Div1000,
            BigDecimal budgetTotalInYear, BigDecimal budgetTotalInYearDiv1000,
            BigDecimal actualMonth1, BigDecimal actualMonth2, BigDecimal actualMonth3, BigDecimal actualMonth4,
            BigDecimal actualMonth5, BigDecimal actualMonth6, BigDecimal actualMonth7, BigDecimal actualMonth8,
            BigDecimal actualMonth9, BigDecimal actualMonth10, BigDecimal actualMonth11, BigDecimal actualMonth12,
            BigDecimal actualMonth1Div1000, BigDecimal actualMonth2Div1000, BigDecimal actualMonth3Div1000, BigDecimal actualMonth4Div1000,
            BigDecimal actualMonth5Div1000, BigDecimal actualMonth6Div1000, BigDecimal actualMonth7Div1000, BigDecimal actualMonth8Div1000,
            BigDecimal actualMonth9Div1000, BigDecimal actualMonth10Div1000, BigDecimal actualMonth11Div1000, BigDecimal actualMonth12Div1000,
            BigDecimal actualSumQ1, BigDecimal actualSumQ2, BigDecimal actualSumQ12, BigDecimal actualSumQ3,
            BigDecimal actualSumQ4, BigDecimal actualSumQ34,
            BigDecimal actualSumQ1Div1000, BigDecimal actualSumQ2Div1000, BigDecimal actualSumQ12Div1000, BigDecimal actualSumQ3Div1000,
            BigDecimal actualSumQ4Div1000, BigDecimal actualSumQ34Div1000,
            BigDecimal actualTotalInYear,  BigDecimal actualTotalInYearDiv1000) {
        super();
        this.projectName = projectName;
        this.budgetMonth1 = budgetMonth1;
        this.budgetMonth2 = budgetMonth2;
        this.budgetMonth3 = budgetMonth3;
        this.budgetMonth4 = budgetMonth4;
        this.budgetMonth5 = budgetMonth5;
        this.budgetMonth6 = budgetMonth6;
        this.budgetMonth7 = budgetMonth7;
        this.budgetMonth8 = budgetMonth8;
        this.budgetMonth9 = budgetMonth9;
        this.budgetMonth10 = budgetMonth10;
        this.budgetMonth11 = budgetMonth11;
        this.budgetMonth12 = budgetMonth12;
        this.budgetMonth1Div1000 = budgetMonth1Div1000;
        this.budgetMonth2Div1000 = budgetMonth2Div1000;
        this.budgetMonth3Div1000 = budgetMonth3Div1000;
        this.budgetMonth4Div1000 = budgetMonth4Div1000;
        this.budgetMonth5Div1000 = budgetMonth5Div1000;
        this.budgetMonth6Div1000 = budgetMonth6Div1000;
        this.budgetMonth7Div1000 = budgetMonth7Div1000;
        this.budgetMonth8Div1000 = budgetMonth8Div1000;
        this.budgetMonth9Div1000 = budgetMonth9Div1000;
        this.budgetMonth10Div1000 = budgetMonth10Div1000;
        this.budgetMonth11Div1000 = budgetMonth11Div1000;
        this.budgetMonth12Div1000 = budgetMonth12Div1000;
        this.budgetSumQ1 = budgetSumQ1;
        this.budgetSumQ2 = budgetSumQ2;
        this.budgetSumQ12 = budgetSumQ12;
        this.budgetSumQ3 = budgetSumQ3;
        this.budgetSumQ4 = budgetSumQ4;
        this.budgetSumQ34 = budgetSumQ34;
        this.budgetSumQ1 = budgetSumQ1Div1000;
        this.budgetSumQ2 = budgetSumQ2Div1000;
        this.budgetSumQ12 = budgetSumQ12Div1000;
        this.budgetSumQ3 = budgetSumQ3Div1000;
        this.budgetSumQ4 = budgetSumQ4Div1000;
        this.budgetSumQ34 = budgetSumQ34Div1000;
        this.budgetTotalInYear = budgetTotalInYear;
        this.budgetTotalInYearDiv1000 = budgetTotalInYearDiv1000;
        this.actualMonth1 = actualMonth1;
        this.actualMonth2 = actualMonth2;
        this.actualMonth3 = actualMonth3;
        this.actualMonth4 = actualMonth4;
        this.actualMonth5 = actualMonth5;
        this.actualMonth6 = actualMonth6;
        this.actualMonth7 = actualMonth7;
        this.actualMonth8 = actualMonth8;
        this.actualMonth9 = actualMonth9;
        this.actualMonth10 = actualMonth10;
        this.actualMonth11 = actualMonth11;
        this.actualMonth12 = actualMonth12;
        this.actualMonth1Div1000 = actualMonth1Div1000;
        this.actualMonth2Div1000 = actualMonth2Div1000;
        this.actualMonth3Div1000 = actualMonth3Div1000;
        this.actualMonth4Div1000 = actualMonth4Div1000;
        this.actualMonth5Div1000 = actualMonth5Div1000;
        this.actualMonth6Div1000 = actualMonth6Div1000;
        this.actualMonth7Div1000 = actualMonth7Div1000;
        this.actualMonth8Div1000 = actualMonth8Div1000;
        this.actualMonth9Div1000 = actualMonth9Div1000;
        this.actualMonth10Div1000 = actualMonth10Div1000;
        this.actualMonth11Div1000 = actualMonth11Div1000;
        this.actualMonth12Div1000 = actualMonth12Div1000;
        this.actualSumQ1 = actualSumQ1;
        this.actualSumQ2 = actualSumQ2;
        this.actualSumQ12 = actualSumQ12;
        this.actualSumQ3 = actualSumQ3;
        this.actualSumQ4 = actualSumQ4;
        this.actualSumQ34 = actualSumQ34;
        this.actualSumQ1 = actualSumQ1Div1000;
        this.actualSumQ2 = actualSumQ2Div1000;
        this.actualSumQ12 = actualSumQ12Div1000;
        this.actualSumQ3 = actualSumQ3Div1000;
        this.actualSumQ4 = actualSumQ4Div1000;
        this.actualSumQ34 = actualSumQ34Div1000;
        this.actualTotalInYear = actualTotalInYear;
        this.actualTotalInYearDiv1000 = actualTotalInYearDiv1000;
    }

    public LicenseManagerColumn(){}
    
    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param venderName
     */
    public String getVenderName() {
        return venderName;
    }

    /**
     * @param venderName
     *            the venderName to set
     */
    public void setVenderName(String venderName) {
        this.venderName = venderName;
    }

    /**
     * @param toolName
     */
    public String getToolName() {
        return toolName;
    }

    /**
     * @param toolName
     *            the toolName to set
     */
    public void setToolName(String toolName) {
        this.toolName = toolName;
    }

    /**
     * @param futureName
     */
    public String getFutureName() {
        return futureName;
    }

    /**
     * @param futureName
     *            the futureName to set
     */
    public void setFutureName(String futureName) {
        this.futureName = futureName;
    }

    /**
     * @param subTractBudgetActual
     */
    public BigDecimal getSubTractBudgetActual() {
        return subTractBudgetActual;
    }

    /**
     * @param subTractBudgetActual
     *            the subTractBudgetActual to set
     */
    public void setSubTractBudgetActual(BigDecimal subTractBudgetActual) {
        this.subTractBudgetActual = subTractBudgetActual;
    }

    /**
     * @param budgetMonth1
     */
    public BigDecimal getBudgetMonth1() {
        return budgetMonth1;
    }

    /**
     * @param budgetMonth1
     *            the budgetMonth1 to set
     */
    public void setBudgetMonth1(BigDecimal budgetMonth1) {
        this.budgetMonth1 = budgetMonth1;
    }

    /**
     * @param budgetMonth2
     */
    public BigDecimal getBudgetMonth2() {
        return budgetMonth2;
    }

    /**
     * @param budgetMonth2
     *            the budgetMonth2 to set
     */
    public void setBudgetMonth2(BigDecimal budgetMonth2) {
        this.budgetMonth2 = budgetMonth2;
    }

    /**
     * @param budgetMonth3
     */
    public BigDecimal getBudgetMonth3() {
        return budgetMonth3;
    }

    /**
     * @param budgetMonth3
     *            the budgetMonth3 to set
     */
    public void setBudgetMonth3(BigDecimal budgetMonth3) {
        this.budgetMonth3 = budgetMonth3;
    }

    /**
     * @param budgetMonth4
     */
    public BigDecimal getBudgetMonth4() {
        return budgetMonth4;
    }

    /**
     * @param budgetMonth4
     *            the budgetMonth4 to set
     */
    public void setBudgetMonth4(BigDecimal budgetMonth4) {
        this.budgetMonth4 = budgetMonth4;
    }

    /**
     * @param budgetMonth5
     */
    public BigDecimal getBudgetMonth5() {
        return budgetMonth5;
    }

    /**
     * @param budgetMonth5
     *            the budgetMonth5 to set
     */
    public void setBudgetMonth5(BigDecimal budgetMonth5) {
        this.budgetMonth5 = budgetMonth5;
    }

    /**
     * @param budgetMonth6
     */
    public BigDecimal getBudgetMonth6() {
        return budgetMonth6;
    }

    /**
     * @param budgetMonth6
     *            the budgetMonth6 to set
     */
    public void setBudgetMonth6(BigDecimal budgetMonth6) {
        this.budgetMonth6 = budgetMonth6;
    }

    /**
     * @param budgetMonth7
     */
    public BigDecimal getBudgetMonth7() {
        return budgetMonth7;
    }

    /**
     * @param budgetMonth7
     *            the budgetMonth7 to set
     */
    public void setBudgetMonth7(BigDecimal budgetMonth7) {
        this.budgetMonth7 = budgetMonth7;
    }

    /**
     * @param budgetMonth8
     */
    public BigDecimal getBudgetMonth8() {
        return budgetMonth8;
    }

    /**
     * @param budgetMonth8
     *            the budgetMonth8 to set
     */
    public void setBudgetMonth8(BigDecimal budgetMonth8) {
        this.budgetMonth8 = budgetMonth8;
    }

    /**
     * @param budgetMonth9
     */
    public BigDecimal getBudgetMonth9() {
        return budgetMonth9;
    }

    /**
     * @param budgetMonth9
     *            the budgetMonth9 to set
     */
    public void setBudgetMonth9(BigDecimal budgetMonth9) {
        this.budgetMonth9 = budgetMonth9;
    }

    /**
     * @param budgetMonth10
     */
    public BigDecimal getBudgetMonth10() {
        return budgetMonth10;
    }

    /**
     * @param budgetMonth10
     *            the budgetMonth10 to set
     */
    public void setBudgetMonth10(BigDecimal budgetMonth10) {
        this.budgetMonth10 = budgetMonth10;
    }

    /**
     * @param budgetMonth11
     */
    public BigDecimal getBudgetMonth11() {
        return budgetMonth11;
    }

    /**
     * @param budgetMonth11
     *            the budgetMonth11 to set
     */
    public void setBudgetMonth11(BigDecimal budgetMonth11) {
        this.budgetMonth11 = budgetMonth11;
    }

    /**
     * @param budgetMonth12
     */
    public BigDecimal getBudgetMonth12() {
        return budgetMonth12;
    }

    /**
     * @param budgetMonth12
     *            the budgetMonth12 to set
     */
    public void setBudgetMonth12(BigDecimal budgetMonth12) {
        this.budgetMonth12 = budgetMonth12;
    }

    /**
     * @param budgetSumQ1
     */
    public BigDecimal getBudgetSumQ1() {
        return budgetSumQ1;
    }

    /**
     * @param budgetSumQ1
     *            the budgetSumQ1 to set
     */
    public void setBudgetSumQ1(BigDecimal budgetSumQ1) {
        this.budgetSumQ1 = budgetSumQ1;
    }

    /**
     * @param budgetSumQ2
     */
    public BigDecimal getBudgetSumQ2() {
        return budgetSumQ2;
    }

    /**
     * @param budgetSumQ2
     *            the budgetSumQ2 to set
     */
    public void setBudgetSumQ2(BigDecimal budgetSumQ2) {
        this.budgetSumQ2 = budgetSumQ2;
    }

    /**
     * @param budgetSumQ12
     */
    public BigDecimal getBudgetSumQ12() {
        return budgetSumQ12;
    }

    /**
     * @param budgetSumQ12
     *            the budgetSumQ12 to set
     */
    public void setBudgetSumQ12(BigDecimal budgetSumQ12) {
        this.budgetSumQ12 = budgetSumQ12;
    }

    /**
     * @param budgetSumQ3
     */
    public BigDecimal getBudgetSumQ3() {
        return budgetSumQ3;
    }

    /**
     * @param budgetSumQ3
     *            the budgetSumQ3 to set
     */
    public void setBudgetSumQ3(BigDecimal budgetSumQ3) {
        this.budgetSumQ3 = budgetSumQ3;
    }

    /**
     * @param budgetSumQ4
     */
    public BigDecimal getBudgetSumQ4() {
        return budgetSumQ4;
    }

    /**
     * @param budgetSumQ4
     *            the budgetSumQ4 to set
     */
    public void setBudgetSumQ4(BigDecimal budgetSumQ4) {
        this.budgetSumQ4 = budgetSumQ4;
    }

    /**
     * @param budgetSumQ34
     */
    public BigDecimal getBudgetSumQ34() {
        return budgetSumQ34;
    }

    /**
     * @param budgetSumQ34
     *            the budgetSumQ34 to set
     */
    public void setBudgetSumQ34(BigDecimal budgetSumQ34) {
        this.budgetSumQ34 = budgetSumQ34;
    }

    /**
     * @param budgetTotalInYear
     */
    public BigDecimal getBudgetTotalInYear() {
        return budgetTotalInYear;
    }

    /**
     * @param budgetTotalInYear
     *            the budgetTotalInYear to set
     */
    public void setBudgetTotalInYear(BigDecimal budgetTotalInYear) {
        this.budgetTotalInYear = budgetTotalInYear;
    }

    /**
     * @param actualMonth1
     */
    public BigDecimal getActualMonth1() {
        return actualMonth1;
    }

    /**
     * @param actualMonth1
     *            the actualMonth1 to set
     */
    public void setActualMonth1(BigDecimal actualMonth1) {
        this.actualMonth1 = actualMonth1;
    }

    /**
     * @param actualMonth2
     */
    public BigDecimal getActualMonth2() {
        return actualMonth2;
    }

    /**
     * @param actualMonth2
     *            the actualMonth2 to set
     */
    public void setActualMonth2(BigDecimal actualMonth2) {
        this.actualMonth2 = actualMonth2;
    }

    /**
     * @param actualMonth3
     */
    public BigDecimal getActualMonth3() {
        return actualMonth3;
    }

    /**
     * @param actualMonth3
     *            the actualMonth3 to set
     */
    public void setActualMonth3(BigDecimal actualMonth3) {
        this.actualMonth3 = actualMonth3;
    }

    /**
     * @param actualMonth4
     */
    public BigDecimal getActualMonth4() {
        return actualMonth4;
    }

    /**
     * @param actualMonth4
     *            the actualMonth4 to set
     */
    public void setActualMonth4(BigDecimal actualMonth4) {
        this.actualMonth4 = actualMonth4;
    }

    /**
     * @param actualMonth5
     */
    public BigDecimal getActualMonth5() {
        return actualMonth5;
    }

    /**
     * @param actualMonth5
     *            the actualMonth5 to set
     */
    public void setActualMonth5(BigDecimal actualMonth5) {
        this.actualMonth5 = actualMonth5;
    }

    /**
     * @param actualMonth6
     */
    public BigDecimal getActualMonth6() {
        return actualMonth6;
    }

    /**
     * @param actualMonth6
     *            the actualMonth6 to set
     */
    public void setActualMonth6(BigDecimal actualMonth6) {
        this.actualMonth6 = actualMonth6;
    }

    /**
     * @param actualMonth7
     */
    public BigDecimal getActualMonth7() {
        return actualMonth7;
    }

    /**
     * @param actualMonth7
     *            the actualMonth7 to set
     */
    public void setActualMonth7(BigDecimal actualMonth7) {
        this.actualMonth7 = actualMonth7;
    }

    /**
     * @param actualMonth8
     */
    public BigDecimal getActualMonth8() {
        return actualMonth8;
    }

    /**
     * @param actualMonth8
     *            the actualMonth8 to set
     */
    public void setActualMonth8(BigDecimal actualMonth8) {
        this.actualMonth8 = actualMonth8;
    }

    /**
     * @param actualMonth9
     */
    public BigDecimal getActualMonth9() {
        return actualMonth9;
    }

    /**
     * @param actualMonth9
     *            the actualMonth9 to set
     */
    public void setActualMonth9(BigDecimal actualMonth9) {
        this.actualMonth9 = actualMonth9;
    }

    /**
     * @param actualMonth10
     */
    public BigDecimal getActualMonth10() {
        return actualMonth10;
    }

    /**
     * @param actualMonth10
     *            the actualMonth10 to set
     */
    public void setActualMonth10(BigDecimal actualMonth10) {
        this.actualMonth10 = actualMonth10;
    }

    /**
     * @param actualMonth11
     */
    public BigDecimal getActualMonth11() {
        return actualMonth11;
    }

    /**
     * @param actualMonth11
     *            the actualMonth11 to set
     */
    public void setActualMonth11(BigDecimal actualMonth11) {
        this.actualMonth11 = actualMonth11;
    }

    /**
     * @param actualMonth12
     */
    public BigDecimal getActualMonth12() {
        return actualMonth12;
    }

    /**
     * @param actualMonth12
     *            the actualMonth12 to set
     */
    public void setActualMonth12(BigDecimal actualMonth12) {
        this.actualMonth12 = actualMonth12;
    }

    /**
     * @param actualSumQ1
     */
    public BigDecimal getActualSumQ1() {
        return actualSumQ1;
    }

    /**
     * @param actualSumQ1
     *            the actualSumQ1 to set
     */
    public void setActualSumQ1(BigDecimal actualSumQ1) {
        this.actualSumQ1 = actualSumQ1;
    }

    /**
     * @param actualSumQ2
     */
    public BigDecimal getActualSumQ2() {
        return actualSumQ2;
    }

    /**
     * @param actualSumQ2
     *            the actualSumQ2 to set
     */
    public void setActualSumQ2(BigDecimal actualSumQ2) {
        this.actualSumQ2 = actualSumQ2;
    }

    /**
     * @param actualSumQ12
     */
    public BigDecimal getActualSumQ12() {
        return actualSumQ12;
    }

    /**
     * @param actualSumQ12
     *            the actualSumQ12 to set
     */
    public void setActualSumQ12(BigDecimal actualSumQ12) {
        this.actualSumQ12 = actualSumQ12;
    }

    /**
     * @param actualSumQ3
     */
    public BigDecimal getActualSumQ3() {
        return actualSumQ3;
    }

    /**
     * @param actualSumQ3
     *            the actualSumQ3 to set
     */
    public void setActualSumQ3(BigDecimal actualSumQ3) {
        this.actualSumQ3 = actualSumQ3;
    }

    /**
     * @param actualSumQ4
     */
    public BigDecimal getActualSumQ4() {
        return actualSumQ4;
    }

    /**
     * @param actualSumQ4
     *            the actualSumQ4 to set
     */
    public void setActualSumQ4(BigDecimal actualSumQ4) {
        this.actualSumQ4 = actualSumQ4;
    }

    /**
     * @param actualSumQ34
     */
    public BigDecimal getActualSumQ34() {
        return actualSumQ34;
    }

    /**
     * @param actualSumQ34
     *            the actualSumQ34 to set
     */
    public void setActualSumQ34(BigDecimal actualSumQ34) {
        this.actualSumQ34 = actualSumQ34;
    }

    /**
     * @param actualTotalInYear
     */
    public BigDecimal getActualTotalInYear() {
        return actualTotalInYear;
    }

    /**
     * @param actualTotalInYear
     *            the actualTotalInYear to set
     */
    public void setActualTotalInYear(BigDecimal actualTotalInYear) {
        this.actualTotalInYear = actualTotalInYear;
    }

    /**
     * @param budgetMonth1Div1000
     */
    public BigDecimal getBudgetMonth1Div1000() {
        return budgetMonth1Div1000;
    }

    /**
     * @param budgetMonth1Div1000
     *            the budgetMonth1Div1000 to set
     */
    public void setBudgetMonth1Div1000(BigDecimal budgetMonth1Div1000) {
        this.budgetMonth1Div1000 = budgetMonth1Div1000;
    }

    /**
     * @param budgetMonth2Div1000
     */
    public BigDecimal getBudgetMonth2Div1000() {
        return budgetMonth2Div1000;
    }

    /**
     * @param budgetMonth2Div1000
     *            the budgetMonth2Div1000 to set
     */
    public void setBudgetMonth2Div1000(BigDecimal budgetMonth2Div1000) {
        this.budgetMonth2Div1000 = budgetMonth2Div1000;
    }

    /**
     * @param budgetMonth3Div1000
     */
    public BigDecimal getBudgetMonth3Div1000() {
        return budgetMonth3Div1000;
    }

    /**
     * @param budgetMonth3Div1000
     *            the budgetMonth3Div1000 to set
     */
    public void setBudgetMonth3Div1000(BigDecimal budgetMonth3Div1000) {
        this.budgetMonth3Div1000 = budgetMonth3Div1000;
    }

    /**
     * @param budgetMonth4Div1000
     */
    public BigDecimal getBudgetMonth4Div1000() {
        return budgetMonth4Div1000;
    }

    /**
     * @param budgetMonth4Div1000
     *            the budgetMonth4Div1000 to set
     */
    public void setBudgetMonth4Div1000(BigDecimal budgetMonth4Div1000) {
        this.budgetMonth4Div1000 = budgetMonth4Div1000;
    }

    /**
     * @param budgetMonth5Div1000
     */
    public BigDecimal getBudgetMonth5Div1000() {
        return budgetMonth5Div1000;
    }

    /**
     * @param budgetMonth5Div1000
     *            the budgetMonth5Div1000 to set
     */
    public void setBudgetMonth5Div1000(BigDecimal budgetMonth5Div1000) {
        this.budgetMonth5Div1000 = budgetMonth5Div1000;
    }

    /**
     * @param budgetMonth6Div1000
     */
    public BigDecimal getBudgetMonth6Div1000() {
        return budgetMonth6Div1000;
    }

    /**
     * @param budgetMonth6Div1000
     *            the budgetMonth6Div1000 to set
     */
    public void setBudgetMonth6Div1000(BigDecimal budgetMonth6Div1000) {
        this.budgetMonth6Div1000 = budgetMonth6Div1000;
    }

    /**
     * @param budgetMonth7Div1000
     */
    public BigDecimal getBudgetMonth7Div1000() {
        return budgetMonth7Div1000;
    }

    /**
     * @param budgetMonth7Div1000
     *            the budgetMonth7Div1000 to set
     */
    public void setBudgetMonth7Div1000(BigDecimal budgetMonth7Div1000) {
        this.budgetMonth7Div1000 = budgetMonth7Div1000;
    }

    /**
     * @param budgetMonth8Div1000
     */
    public BigDecimal getBudgetMonth8Div1000() {
        return budgetMonth8Div1000;
    }

    /**
     * @param budgetMonth8Div1000
     *            the budgetMonth8Div1000 to set
     */
    public void setBudgetMonth8Div1000(BigDecimal budgetMonth8Div1000) {
        this.budgetMonth8Div1000 = budgetMonth8Div1000;
    }

    /**
     * @param budgetMonth9Div1000
     */
    public BigDecimal getBudgetMonth9Div1000() {
        return budgetMonth9Div1000;
    }

    /**
     * @param budgetMonth9Div1000
     *            the budgetMonth9Div1000 to set
     */
    public void setBudgetMonth9Div1000(BigDecimal budgetMonth9Div1000) {
        this.budgetMonth9Div1000 = budgetMonth9Div1000;
    }

    /**
     * @param budgetMonth10Div1000
     */
    public BigDecimal getBudgetMonth10Div1000() {
        return budgetMonth10Div1000;
    }

    /**
     * @param budgetMonth10Div1000
     *            the budgetMonth10Div1000 to set
     */
    public void setBudgetMonth10Div1000(BigDecimal budgetMonth10Div1000) {
        this.budgetMonth10Div1000 = budgetMonth10Div1000;
    }

    /**
     * @param budgetMonth11Div1000
     */
    public BigDecimal getBudgetMonth11Div1000() {
        return budgetMonth11Div1000;
    }

    /**
     * @param budgetMonth11Div1000
     *            the budgetMonth11Div1000 to set
     */
    public void setBudgetMonth11Div1000(BigDecimal budgetMonth11Div1000) {
        this.budgetMonth11Div1000 = budgetMonth11Div1000;
    }

    /**
     * @param budgetMonth12Div1000
     */
    public BigDecimal getBudgetMonth12Div1000() {
        return budgetMonth12Div1000;
    }

    /**
     * @param budgetMonth12Div1000
     *            the budgetMonth12Div1000 to set
     */
    public void setBudgetMonth12Div1000(BigDecimal budgetMonth12Div1000) {
        this.budgetMonth12Div1000 = budgetMonth12Div1000;
    }

    /**
     * @param actualMonth1Div1000
     */
    public BigDecimal getActualMonth1Div1000() {
        return actualMonth1Div1000;
    }

    /**
     * @param actualMonth1Div1000
     *            the actualMonth1Div1000 to set
     */
    public void setActualMonth1Div1000(BigDecimal actualMonth1Div1000) {
        this.actualMonth1Div1000 = actualMonth1Div1000;
    }

    /**
     * @param actualMonth2Div1000
     */
    public BigDecimal getActualMonth2Div1000() {
        return actualMonth2Div1000;
    }

    /**
     * @param actualMonth2Div1000
     *            the actualMonth2Div1000 to set
     */
    public void setActualMonth2Div1000(BigDecimal actualMonth2Div1000) {
        this.actualMonth2Div1000 = actualMonth2Div1000;
    }

    /**
     * @param actualMonth3Div1000
     */
    public BigDecimal getActualMonth3Div1000() {
        return actualMonth3Div1000;
    }

    /**
     * @param actualMonth3Div1000
     *            the actualMonth3Div1000 to set
     */
    public void setActualMonth3Div1000(BigDecimal actualMonth3Div1000) {
        this.actualMonth3Div1000 = actualMonth3Div1000;
    }

    /**
     * @param actualMonth4Div1000
     */
    public BigDecimal getActualMonth4Div1000() {
        return actualMonth4Div1000;
    }

    /**
     * @param actualMonth4Div1000
     *            the actualMonth4Div1000 to set
     */
    public void setActualMonth4Div1000(BigDecimal actualMonth4Div1000) {
        this.actualMonth4Div1000 = actualMonth4Div1000;
    }

    /**
     * @param actualMonth5Div1000
     */
    public BigDecimal getActualMonth5Div1000() {
        return actualMonth5Div1000;
    }

    /**
     * @param actualMonth5Div1000
     *            the actualMonth5Div1000 to set
     */
    public void setActualMonth5Div1000(BigDecimal actualMonth5Div1000) {
        this.actualMonth5Div1000 = actualMonth5Div1000;
    }

    /**
     * @param actualMonth6Div1000
     */
    public BigDecimal getActualMonth6Div1000() {
        return actualMonth6Div1000;
    }

    /**
     * @param actualMonth6Div1000
     *            the actualMonth6Div1000 to set
     */
    public void setActualMonth6Div1000(BigDecimal actualMonth6Div1000) {
        this.actualMonth6Div1000 = actualMonth6Div1000;
    }

    /**
     * @param actualMonth7Div1000
     */
    public BigDecimal getActualMonth7Div1000() {
        return actualMonth7Div1000;
    }

    /**
     * @param actualMonth7Div1000
     *            the actualMonth7Div1000 to set
     */
    public void setActualMonth7Div1000(BigDecimal actualMonth7Div1000) {
        this.actualMonth7Div1000 = actualMonth7Div1000;
    }

    /**
     * @param actualMonth8Div1000
     */
    public BigDecimal getActualMonth8Div1000() {
        return actualMonth8Div1000;
    }

    /**
     * @param actualMonth8Div1000
     *            the actualMonth8Div1000 to set
     */
    public void setActualMonth8Div1000(BigDecimal actualMonth8Div1000) {
        this.actualMonth8Div1000 = actualMonth8Div1000;
    }

    /**
     * @param actualMonth9Div1000
     */
    public BigDecimal getActualMonth9Div1000() {
        return actualMonth9Div1000;
    }

    /**
     * @param actualMonth9Div1000
     *            the actualMonth9Div1000 to set
     */
    public void setActualMonth9Div1000(BigDecimal actualMonth9Div1000) {
        this.actualMonth9Div1000 = actualMonth9Div1000;
    }

    /**
     * @param actualMonth10Div1000
     */
    public BigDecimal getActualMonth10Div1000() {
        return actualMonth10Div1000;
    }

    /**
     * @param actualMonth10Div1000
     *            the actualMonth10Div1000 to set
     */
    public void setActualMonth10Div1000(BigDecimal actualMonth10Div1000) {
        this.actualMonth10Div1000 = actualMonth10Div1000;
    }

    /**
     * @param actualMonth11Div1000
     */
    public BigDecimal getActualMonth11Div1000() {
        return actualMonth11Div1000;
    }

    /**
     * @param actualMonth11Div1000
     *            the actualMonth11Div1000 to set
     */
    public void setActualMonth11Div1000(BigDecimal actualMonth11Div1000) {
        this.actualMonth11Div1000 = actualMonth11Div1000;
    }

    /**
     * @param actualMonth12Div1000
     */
    public BigDecimal getActualMonth12Div1000() {
        return actualMonth12Div1000;
    }

    /**
     * @param actualMonth12Div1000
     *            the actualMonth12Div1000 to set
     */
    public void setActualMonth12Div1000(BigDecimal actualMonth12Div1000) {
        this.actualMonth12Div1000 = actualMonth12Div1000;
    }

    /**
     * @param budgetSumQ1Div1000
     */
    public BigDecimal getBudgetSumQ1Div1000() {
        return budgetSumQ1Div1000;
    }

    /**
     * @param budgetSumQ1Div1000
     *            the budgetSumQ1Div1000 to set
     */
    public void setBudgetSumQ1Div1000(BigDecimal budgetSumQ1Div1000) {
        this.budgetSumQ1Div1000 = budgetSumQ1Div1000;
    }

    /**
     * @param budgetSumQ2Div1000
     */
    public BigDecimal getBudgetSumQ2Div1000() {
        return budgetSumQ2Div1000;
    }

    /**
     * @param budgetSumQ2Div1000
     *            the budgetSumQ2Div1000 to set
     */
    public void setBudgetSumQ2Div1000(BigDecimal budgetSumQ2Div1000) {
        this.budgetSumQ2Div1000 = budgetSumQ2Div1000;
    }

    /**
     * @param budgetSumQ12Div1000
     */
    public BigDecimal getBudgetSumQ12Div1000() {
        return budgetSumQ12Div1000;
    }

    /**
     * @param budgetSumQ12Div1000
     *            the budgetSumQ12Div1000 to set
     */
    public void setBudgetSumQ12Div1000(BigDecimal budgetSumQ12Div1000) {
        this.budgetSumQ12Div1000 = budgetSumQ12Div1000;
    }

    /**
     * @param budgetSumQ3Div1000
     */
    public BigDecimal getBudgetSumQ3Div1000() {
        return budgetSumQ3Div1000;
    }

    /**
     * @param budgetSumQ3Div1000
     *            the budgetSumQ3Div1000 to set
     */
    public void setBudgetSumQ3Div1000(BigDecimal budgetSumQ3Div1000) {
        this.budgetSumQ3Div1000 = budgetSumQ3Div1000;
    }

    /**
     * @param budgetSumQ4Div1000
     */
    public BigDecimal getBudgetSumQ4Div1000() {
        return budgetSumQ4Div1000;
    }

    /**
     * @param budgetSumQ4Div1000
     *            the budgetSumQ4Div1000 to set
     */
    public void setBudgetSumQ4Div1000(BigDecimal budgetSumQ4Div1000) {
        this.budgetSumQ4Div1000 = budgetSumQ4Div1000;
    }

    /**
     * @param budgetSumQ34Div1000
     */
    public BigDecimal getBudgetSumQ34Div1000() {
        return budgetSumQ34Div1000;
    }

    /**
     * @param budgetSumQ34Div1000
     *            the budgetSumQ34Div1000 to set
     */
    public void setBudgetSumQ34Div1000(BigDecimal budgetSumQ34Div1000) {
        this.budgetSumQ34Div1000 = budgetSumQ34Div1000;
    }

    /**
     * @param budgetTotalInYearDiv1000
     */
    public BigDecimal getBudgetTotalInYearDiv1000() {
        return budgetTotalInYearDiv1000;
    }

    /**
     * @param budgetTotalInYearDiv1000
     *            the budgetTotalInYearDiv1000 to set
     */
    public void setBudgetTotalInYearDiv1000(BigDecimal budgetTotalInYearDiv1000) {
        this.budgetTotalInYearDiv1000 = budgetTotalInYearDiv1000;
    }

    /**
     * @param actualSumQ1Div1000
     */
    public BigDecimal getActualSumQ1Div1000() {
        return actualSumQ1Div1000;
    }

    /**
     * @param actualSumQ1Div1000
     *            the actualSumQ1Div1000 to set
     */
    public void setActualSumQ1Div1000(BigDecimal actualSumQ1Div1000) {
        this.actualSumQ1Div1000 = actualSumQ1Div1000;
    }

    /**
     * @param actualSumQ2Div1000
     */
    public BigDecimal getActualSumQ2Div1000() {
        return actualSumQ2Div1000;
    }

    /**
     * @param actualSumQ2Div1000
     *            the actualSumQ2Div1000 to set
     */
    public void setActualSumQ2Div1000(BigDecimal actualSumQ2Div1000) {
        this.actualSumQ2Div1000 = actualSumQ2Div1000;
    }

    /**
     * @param actualSumQ12Div1000
     */
    public BigDecimal getActualSumQ12Div1000() {
        return actualSumQ12Div1000;
    }

    /**
     * @param actualSumQ12Div1000
     *            the actualSumQ12Div1000 to set
     */
    public void setActualSumQ12Div1000(BigDecimal actualSumQ12Div1000) {
        this.actualSumQ12Div1000 = actualSumQ12Div1000;
    }

    /**
     * @param actualSumQ3Div1000
     */
    public BigDecimal getActualSumQ3Div1000() {
        return actualSumQ3Div1000;
    }

    /**
     * @param actualSumQ3Div1000
     *            the actualSumQ3Div1000 to set
     */
    public void setActualSumQ3Div1000(BigDecimal actualSumQ3Div1000) {
        this.actualSumQ3Div1000 = actualSumQ3Div1000;
    }

    /**
     * @param actualSumQ4Div1000
     */
    public BigDecimal getActualSumQ4Div1000() {
        return actualSumQ4Div1000;
    }

    /**
     * @param actualSumQ4Div1000
     *            the actualSumQ4Div1000 to set
     */
    public void setActualSumQ4Div1000(BigDecimal actualSumQ4Div1000) {
        this.actualSumQ4Div1000 = actualSumQ4Div1000;
    }

    /**
     * @param actualSumQ34Div1000
     */
    public BigDecimal getActualSumQ34Div1000() {
        return actualSumQ34Div1000;
    }

    /**
     * @param actualSumQ34Div1000
     *            the actualSumQ34Div1000 to set
     */
    public void setActualSumQ34Div1000(BigDecimal actualSumQ34Div1000) {
        this.actualSumQ34Div1000 = actualSumQ34Div1000;
    }

    /**
     * @param actualTotalInYearDiv1000
     */
    public BigDecimal getActualTotalInYearDiv1000() {
        return actualTotalInYearDiv1000;
    }

    /**
     * @param actualTotalInYearDiv1000
     *            the actualTotalInYearDiv1000 to set
     */
    public void setActualTotalInYearDiv1000(BigDecimal actualTotalInYearDiv1000) {
        this.actualTotalInYearDiv1000 = actualTotalInYearDiv1000;
    }
}
