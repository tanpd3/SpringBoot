package jp.meportal.isv.formbean;

import java.io.Serializable;

public class LicenseUsageForHostFormBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private String host;
    private int runTimeWithoutFew;
    private int runNumberWithoutFew;
    private String strIsCharge;
    private String strRuntime;

    /**
     * Default constructor
     */
    public LicenseUsageForHostFormBean() {
        super();
    }

    /**
     * constructor for LicenseUsageForHostFormBean on filter account
     */
    public LicenseUsageForHostFormBean(String host, int runTimeWithoutFew, int runNumberWithoutFew, String strIsCharge,
            String strRuntime) {
        super();
        this.host = host;
        this.runTimeWithoutFew = runTimeWithoutFew;
        this.runNumberWithoutFew = runNumberWithoutFew;
        this.strIsCharge = strIsCharge;
        this.strRuntime = strRuntime;
    }

    /**
     * @param host
     */
    public String getHost() {
        return host;
    }

    /**
     * @param host
     *            the host to set
     */
    public void setHost(String host) {
        this.host = host;
    }

    /**
     * @param runTimeWithoutFew
     */
    public int getRunTimeWithoutFew() {
        return runTimeWithoutFew;
    }

    /**
     * @param runTimeWithoutFew
     *            the runTimeWithoutFew to set
     */
    public void setRunTimeWithoutFew(int runTimeWithoutFew) {
        this.runTimeWithoutFew = runTimeWithoutFew;
    }

    /**
     * @param runNumberWithoutFew
     */
    public int getRunNumberWithoutFew() {
        return runNumberWithoutFew;
    }

    /**
     * @param runNumberWithoutFew
     *            the runNumberWithoutFew to set
     */
    public void setRunNumberWithoutFew(int runNumberWithoutFew) {
        this.runNumberWithoutFew = runNumberWithoutFew;
    }

    /**
     * @param strIsCharge
     */
    public String getStrIsCharge() {
        return strIsCharge;
    }

    /**
     * @param strIsCharge
     *            the strIsCharge to set
     */
    public void setStrIsCharge(String strIsCharge) {
        this.strIsCharge = strIsCharge;
    }

    /**
     * @param strRuntime
     */
    public String getStrRuntime() {
        return strRuntime;
    }

    /**
     * @param strRuntime
     *            the strRuntime to set
     */
    public void setStrRuntime(String strRuntime) {
        this.strRuntime = strRuntime;
    }

}
