package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.util.List;

public class ExecuteTimeAndCountFormBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private String grandTotalRunTime;
    private Integer grandTotalRunNumber;
    private List<LicenseUsageForProductNumberFormBean> licenseUsageForProductNumberList;

    /**
     * @param licenseUsageForProductNumberList
     */
    public List<LicenseUsageForProductNumberFormBean> getLicenseUsageForProductNumberList() {
        return licenseUsageForProductNumberList;
    }

    /**
     * @param licenseUsageForProductNumberList
     *            the licenseUsageForProductNumberList to set
     */
    public void setLicenseUsageForProductNumberList(
            List<LicenseUsageForProductNumberFormBean> licenseUsageForProductNumberList) {
        this.licenseUsageForProductNumberList = licenseUsageForProductNumberList;
    }

    /**
     * @param grandTotalRunTime
     */
    public String getGrandTotalRunTime() {
        return grandTotalRunTime;
    }

    /**
     * @param grandTotalRunTime
     *            the grandTotalRunTime to set
     */
    public void setGrandTotalRunTime(String grandTotalRunTime) {
        this.grandTotalRunTime = grandTotalRunTime;
    }

    /**
     * @param grandTotalRunNumber
     */
    public Integer getGrandTotalRunNumber() {
        return grandTotalRunNumber;
    }

    /**
     * @param grandTotalRunNumber
     *            the grandTotalRunNumber to set
     */
    public void setGrandTotalRunNumber(Integer grandTotalRunNumber) {
        this.grandTotalRunNumber = grandTotalRunNumber;
    }

}
