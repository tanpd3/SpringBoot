package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.util.List;

public class LicenseUsageForAccountFormBean implements Serializable{
    private static final long serialVersionUID = 1L;

    private String account;
    private List<LicenseUsageForHostFormBean> licenseUsageForHostList;
    private int runTimeForAcc;
    private int runNumberForAcc;
    private int lengthHostList;

    /**
     * Default constructor
     */
    public LicenseUsageForAccountFormBean() {
        super();
    }

    /**
    * constructor for LicenseUsageForAccountFormBean
    */
    public LicenseUsageForAccountFormBean(String account, List<LicenseUsageForHostFormBean> licenseUsageForHostList,
            int runTimeForAcc, int runNumberForAcc, int lengthHostList) {
        super();
        this.account = account;
        this.licenseUsageForHostList = licenseUsageForHostList;
        this.runTimeForAcc = runTimeForAcc;
        this.runNumberForAcc = runNumberForAcc;
        this.lengthHostList = lengthHostList;
    }

    /**
     * @param account
     */
    public String getAccount() {
        return account;
    }

    /**
     * @param account
     *            the account to set
     */
    public void setAccount(String account) {
        this.account = account;
    }

    /**
     * @param runTimeForAcc
     */
    public int getRunTimeForAcc() {
        return runTimeForAcc;
    }

    /**
     * @param runTimeForAcc
     *            the runTimeForAcc to set
     */
    public void setRunTimeForAcc(int runTimeForAcc) {
        this.runTimeForAcc = runTimeForAcc;
    }

    /**
     * @param runNumberForAcc
     */
    public int getRunNumberForAcc() {
        return runNumberForAcc;
    }

    /**
     * @param runNumberForAcc
     *            the runNumberForAcc to set
     */
    public void setRunNumberForAcc(int runNumberForAcc) {
        this.runNumberForAcc = runNumberForAcc;
    }

    /**
     * @param licenseUsageForHostList
     */
    public List<LicenseUsageForHostFormBean> getLicenseUsageForHostList() {
        return licenseUsageForHostList;
    }

    /**
     * @param licenseUsageForHostList
     *            the licenseUsageForHostList to set
     */
    public void setLicenseUsageForHostList(List<LicenseUsageForHostFormBean> licenseUsageForHostList) {
        this.licenseUsageForHostList = licenseUsageForHostList;
    }

    /**
     * @param lengthHostList
     */
    public int getLengthHostList() {
        return lengthHostList;
    }

    /**
     * @param lengthHostList
     *            the lengthHostList to set
     */
    public void setLengthHostList(int lengthHostList) {
        this.lengthHostList = lengthHostList;
    }
}
