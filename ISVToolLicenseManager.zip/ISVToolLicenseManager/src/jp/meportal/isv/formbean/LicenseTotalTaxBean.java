package jp.meportal.isv.formbean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class LicenseTotalTaxBean implements Serializable{
    private static final long serialVersionUID = 1L;
    
    private int projectId;
    private String projectName;
    private String productNumber;
    private String loadOriginCode;
    private List<LicenseTotalTaxColumn> taxList;
    private int lengthLicenseCatalog;
    private int catalogId;
    private BigDecimal sumTaxMoneyPro;
    
    /**
     * @param projectName
     * @param productNumber
     * @param loadOriginCode
     * @param taxList
     * @param lengthLicenseCatalog
     * @param catalogId
     */
    public LicenseTotalTaxBean(int projectId, String projectName, String productNumber, String loadOriginCode,
            List<LicenseTotalTaxColumn> taxList, int lengthLicenseCatalog, int catalogId, BigDecimal sumTaxMoneyPro){
        this.projectId = projectId;
        this.projectName = projectName;
        this.productNumber = productNumber;
        this.loadOriginCode = loadOriginCode;
        this.taxList = taxList;
        this.lengthLicenseCatalog = lengthLicenseCatalog;
        this.catalogId = catalogId;
        this.sumTaxMoneyPro = sumTaxMoneyPro;
    }
    
    public LicenseTotalTaxBean(){}

    /**
     * @param projectId
     */
    public int getProjectId() {
        return projectId;
    }

    /**
     * @param projectId
     *            the projectId to set
     */
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param productNumber
     */
    public String getProductNumber() {
        return productNumber;
    }

    /**
     * @param productNumber
     *            the productNumber to set
     */
    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }
    /**
     * @param loadOriginCode
     */
    public String getLoadOriginCode() {
        return loadOriginCode;
    }

    /**
     * @param loadOriginCode
     *            the loadOriginCode to set
     */
    public void setLoadOriginCode(String loadOriginCode) {
        this.loadOriginCode = loadOriginCode;
    }
    /**
     * @param taxList
     */
    public List<LicenseTotalTaxColumn> getTaxList() {
        return taxList;
    }

    /**
     * @param taxList
     *            the taxList to set
     */
    public void setTaxList(List<LicenseTotalTaxColumn> taxList) {
        this.taxList = taxList;
    }

    /**
     * @param lengthLicenseCatalog
     */
    public int getLengthLicenseCatalog() {
        return lengthLicenseCatalog;
    }

    /**
     * @param lengthLicenseCatalog
     *            the lengthLicenseCatalog to set
     */
    public void setLengthLicenseCatalog(int lengthLicenseCatalog) {
        this.lengthLicenseCatalog = lengthLicenseCatalog;
    }

    /**
     * @param catalogId
     */
    public int getCatalogId() {
        return catalogId;
    }

    /**
     * @param catalogId
     *            the catalogId to set
     */
    public void setCatalogId(int catalogId) {
        this.catalogId = catalogId;
    }

    /**
     * @param sumTaxMoneyPro
     */
    public BigDecimal getSumTaxMoneyPro() {
        return sumTaxMoneyPro;
    }

    /**
     * @param sumTaxMoneyPro
     *            the sumTaxMoneyPro to set
     */
    public void setSumTaxMoneyPro(BigDecimal sumTaxMoneyPro) {
        this.sumTaxMoneyPro = sumTaxMoneyPro;
    }
}
