package jp.meportal.isv.model;

public class CommonJsonObject extends AbstractPortalCommonJsonObject {
    private static final long serialVersionUID = 1L;
}
