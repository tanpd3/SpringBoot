package jp.meportal.isv.model;

import java.io.Serializable;
import jp.meportal.isv.entity.UserInfo;

public class LoginSession implements Serializable {
    
    private static final long serialVersionUID = 1L;

    private String openAmTokenId = null;
    private UserInfo user = null;
    private String userType = null;

    /**
     * UserInfo
     * 
     * @return uid
     */
    public String getUserType() {
        return userType;
    }

    /**
     * Set user permision type
     * 
     * @author ManhLB
     * @param user
     **/
    private void setUserType(UserInfo user) {
        if (user.getUserGroupID() > 1) {
            this.userType = UserType.SUPPORTER.toString();
        } else {
            this.userType = UserType.USER.toString();
        }
    }

    /**
     * UserInfo
     * 
     * @return uid
     */
    public UserInfo getUser() {
        return user;
    }

    /**
     * uid
     * 
     * @param uid
     *            uid
     */
    public void setUser(UserInfo user) {
        setUserType(user);
        this.user = user;
    }

    /**
     * openAmCookieId
     * 
     * @return openAmCookieId
     */
    public String getOpenAmTokenId() {
        return openAmTokenId;
    }

    /**
     * openAmCookieId
     * 
     * @param openAmCookieId
     *            openAmCookieId
     */
    public void setOpenAmTokenId(String openAmTokenId) {
        this.openAmTokenId = openAmTokenId;
    }
}
