package jp.meportal.isv.model;

public enum UserType {
    SUPPORTER("supporter_success"), USER("user_success");
    private String label = null;

    UserType(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return this.label;
    }
}
