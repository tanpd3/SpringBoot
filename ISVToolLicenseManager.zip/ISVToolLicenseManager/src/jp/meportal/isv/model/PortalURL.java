package jp.meportal.isv.model;

import java.io.Serializable;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.util.PropertiesUtil;

public class PortalURL implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private static String protalURL = null; // Portal
    private static PropertiesConfiguration config = null;
    private static long lastmodified = 0;
    private static final Object lock = new Object();
    private static String subProtalURL = null; // SubPortal

    public PortalURL() throws ConfigurationException {
        loadConfig();
    }

    private static void loadConfig() throws ConfigurationException {
        PropertiesConfiguration loadconfig = new PropertiesConfiguration(Constants.PROPERETIES_SERVER);
        if (config == null || (loadconfig.getFile() != null && lastmodified < loadconfig.getFile().lastModified())) {
            synchronized (lock) {
                config = loadconfig;
                protalURL = config.getString("mePortal.server");
                if (null != loadconfig.getFile()) {
                    lastmodified = loadconfig.getFile().lastModified();
                }
                subProtalURL = PropertiesUtil.getEnvConfig().getString("sub.mePortal");
            }
        }
    }

    public String getOpenAMCookieName() {
        return config.getString("openam.cookie.name");
    }

    public String getUserInfoURL() {
        return (protalURL + config.getString("mePortal.getUserInfo"));
    }

    public String getTokenValidPortalURL() {
        return (protalURL + config.getString("mePortal.isTokenValid"));
    }

    public String checkIsFileExists() {
        return (protalURL + config.getString("mePortal.IsFilePathExists"));
    }

    public String getSubCompanyInfo() {
        return (subProtalURL + config.getString("mePortal.CompanyInfo"));
    }

    public String getCompanyInfo() {
        return (protalURL + config.getString("mePortal.CompanyInfo"));
    }

    public String getMembersList() {
        return (protalURL + config.getString("mePortal.MemberList"));
    }

    public String getMembersListById() {
        return (protalURL + config.getString("mePortal.MemberListById"));
    }
}
