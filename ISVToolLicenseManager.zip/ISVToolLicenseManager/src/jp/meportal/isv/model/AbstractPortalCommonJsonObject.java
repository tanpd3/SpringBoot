package jp.meportal.isv.model;

import java.io.Serializable;

public abstract class AbstractPortalCommonJsonObject implements Serializable {
    private static final long serialVersionUID = 1L;

    private String result = null;
    private String errMessage = null;
    private String data = null;
    private int errCode = 0;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getErrMessage() {
        return errMessage;
    }

    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Boolean getBooleanResult() {
        if (this.result == null) {
            return Boolean.FALSE;
        }
        return Boolean.valueOf(this.result);
    }

    public int getErrCode() {
        return errCode;
    }

    public void setErrCode(int errCode) {
        this.errCode = errCode;
    }
}
