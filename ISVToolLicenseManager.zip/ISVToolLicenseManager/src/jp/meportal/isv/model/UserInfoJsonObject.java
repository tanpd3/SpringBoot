package jp.meportal.isv.model;

import java.io.Serializable;

public class UserInfoJsonObject extends AbstractPortalCommonJsonObject {
    private static final long serialVersionUID = 1L;

    private UserInfoData dataObject = null;

    public UserInfoData getDataObject() {
        return dataObject;
    }

    public void setDataObject(UserInfoData data) {
        this.dataObject = data;
    }

    public static class UserInfoData implements Serializable {
        private static final long serialVersionUID = 1L;

        private String userName = null; 
        private String userBelongCompanyName = null;
        private String userBelongCompanyCd = null; 
        private String userBelongDepartmentName = null; 
        private String userBelongDepartmentCd = null;
        private String emailAddress = null; 
        private String innerTelNumber = null; 
        private String outerTelNumber = null;
        private String uid = null; // UID
        private int userGroupID = 0;
        private String openAmTokenId = null;

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getUserBelongCompanyName() {
            return userBelongCompanyName;
        }

        public void setUserBelongCompanyName(String userBelongCompanyName) {
            this.userBelongCompanyName = userBelongCompanyName;
        }

        public String getUserBelongCompanyCd() {
            return userBelongCompanyCd;
        }

        public void setUserBelongCompanyCd(String userBelongCompanyCd) {
            this.userBelongCompanyCd = userBelongCompanyCd;
        }

        public String getUserBelongDepartmentName() {
            return userBelongDepartmentName;
        }

        public void setUserBelongDepartmentName(String userBelongDepartmentName) {
            this.userBelongDepartmentName = userBelongDepartmentName;
        }

        public String getUserBelongDepartmentCd() {
            return userBelongDepartmentCd;
        }

        public void setUserBelongDepartmentCd(String userBelongDepartmentCd) {
            this.userBelongDepartmentCd = userBelongDepartmentCd;
        }

        public String getEmailAddress() {
            return emailAddress;
        }

        public void setEmailAddress(String emailAddress) {
            this.emailAddress = emailAddress;
        }

        public String getInnerTelNumber() {
            return innerTelNumber;
        }

        public void setInnerTelNumber(String innerTelNumber) {
            this.innerTelNumber = innerTelNumber;
        }

        public String getOuterTelNumber() {
            return outerTelNumber;
        }

        public void setOuterTelNumber(String outerTelNumber) {
            this.outerTelNumber = outerTelNumber;
        }

        public String getUid() {
            return uid;
        }

        public void setUid(String uid) {
            this.uid = uid;
        }

        public String getOpenAmTokenId() {
            return openAmTokenId;
        }

        public void setOpenAmTokenId(String openAmTokenId) {
            this.openAmTokenId = openAmTokenId;
        }

		public int getUserGroupID() {
			return userGroupID;
		}

		public void setUserGroupID(int userGroupID) {
			this.userGroupID = userGroupID;
		}
    }
}
