package jp.meportal.isv.model;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;
import jp.meportal.isv.util.PropertiesUtil;

public class EmailInfo {
    
    protected Logger logger = Logger.getLogger(this.getClass());
    
    private String smtp = null;
    private String port = null;
    private String account = null;
    private String password = null;
    private String top = null;

    public EmailInfo() {
        PropertiesConfiguration emailPro = null;
        try {
            emailPro = PropertiesUtil.getEmailSettingConfig();
        } catch (ConfigurationException e) {
            logger.error(e.getMessage(), e);
        }
        if (emailPro != null) {
            this.smtp = emailPro.getString("mail.SMTP");
            this.port = emailPro.getString("mail.Port");
            this.account = emailPro.getString("mail.Account");
            this.password = emailPro.getString("mail.Password");
            this.top = emailPro.getString("mail.TOP");
        }
    }

    public String getSmtp() {
        return smtp;
    }

    public void setSmtp(String smtp) {
        this.smtp = smtp;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTop() {
        return top;
    }

    public void setTop(String top) {
        this.top = top;
    }
}
