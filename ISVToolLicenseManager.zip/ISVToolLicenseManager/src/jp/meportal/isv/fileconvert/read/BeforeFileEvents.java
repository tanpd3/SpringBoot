package jp.meportal.isv.fileconvert.read;

//import org.apache.log4j.Logger;

/**
 * Events line of before file
 * 変換前ファイルのEvents行の情報を保持するクラス
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
public class BeforeFileEvents {
//    /**
//     * Logger
//     */
//    private static final Logger logger = Logger.getLogger(BeforeFileEvents.class);

    /**
     * Tool name
     * ツール名
     */
    private String toolName;

    /**
     * Tool version
     * ツールバージョン
     */
    private String toolVersion;

    /**
     * Get tool name
     * ツール名取得
     * @return ツール名
     */
    public String getToolName() {
        return toolName;
    }

    /**
     * Set tool name
     * ツール名設定
     * @param toolName ツール名
     */
    public void setToolName(String toolName) {
        this.toolName = toolName;
    }

    /**
     * Get tool version
     * ツールバージョン取得
     * @return ツールバージョン
     */
    public String getToolVersion() {
        return toolVersion;
    }

    /**
     * Set tool version
     * ツールバージョン設定
     * @param toolVersion ツールバージョン
     */
    public void setToolVersion(String toolVersion) {
        this.toolVersion = toolVersion;
    }

    /**
     * Constructor
     */
    private BeforeFileEvents() {
        this.initialize();
    }

    /**
     * Initialize
     * 初期化処理
     */
    private void initialize() {
        toolName = "";
        toolVersion = "";
    }

    /**
     * Create instance from before file
     * 変換前ファイルのEvents行の読み込み
     * @param lineEvents 変換前ファイルのEvents行の内容
     * @return BeforeFileEventsクラスのインスタンス(失敗時はnull)
     */
    public static BeforeFileEvents read(String lineEvents) {
        final String SPACE_SEQ = "[\\s]+";  // 複数スペースのときに空文字の配列要素ができないようにする
        final String COLON = ":";

        final int ITEM_INDEX_TOOL = 2;
        final int ITEM_LENGTH = 3;

        // スペース区切り
        String[] items = lineEvents.split(SPACE_SEQ);
        if (items.length < ITEM_LENGTH) {
            return null;
        }

        // コロン区切りl
        String[] tools = items[ITEM_INDEX_TOOL].split(COLON);
        if (tools.length < 2) {
            return null;
        }
        String toolName = tools[0];
        String toolVersion = tools[1];

        BeforeFileEvents instance = new BeforeFileEvents();
        instance.setToolName(toolName);
        instance.setToolVersion(toolVersion);

        return instance;
    }

    /**
     * Dump for debug
     * デバッグ用のダンプ出力
     * @return ダンプ文字列
     */
    public String dumpForDebug() {
        StringBuilder sb = new StringBuilder();
        sb.append("[Events] toolName=")
          .append(this.getToolName())
          .append(", toolVersion=")
          .append(this.getToolVersion());

        return sb.toString();
    }
}
