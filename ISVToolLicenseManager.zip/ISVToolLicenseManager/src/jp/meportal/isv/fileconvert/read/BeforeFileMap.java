package jp.meportal.isv.fileconvert.read;

import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.ArrayList;

/**
 * LinkedHashMap of before file
 * 変換前ファイルのデータをLinkedHashMapに入れたもの
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
public class BeforeFileMap extends LinkedHashMap<BeforeFileEvents, ArrayList<BeforeFileUsed>> {
    /**
     * Constructor
     */
    public BeforeFileMap() {
        super();
    }

    /**
     * Divide by day
     * 月をまたぐときに日ごとに分割する処理
     * ※2017/06/30 10:00 ～ 2017/07/01 10:00のログを以下の二つに分割
     *   ・2017/06/30 10:00 ～ 2017/07/01  0:00
     *   ・2017/07/01  0:00 ～ 2017/07/01 10:00
     */
    public void divideByDay() {
        ArrayList<BeforeFileUsed> addList = new ArrayList<BeforeFileUsed>();

        for (ArrayList<BeforeFileUsed> usedList : this.values()) {
            addList.clear();

            for (BeforeFileUsed used : usedList) {
                BeforeFileUsed wkUsed = used;
                Date startTime = used.getStartTime();
                Date endTime = used.getEndTimeBefore1Second();  // 1秒前を取得
                Calendar startCalendar = Calendar.getInstance();
                Calendar endCalendar = Calendar.getInstance();
                Calendar divideCalendar = Calendar.getInstance();

                endCalendar.setTime(endTime);
                int endYear = endCalendar.get(Calendar.YEAR);
                int endMonth = endCalendar.get(Calendar.MONTH);

                while (true) {
                    startCalendar.setTime(startTime);
                    int startYear = startCalendar.get(Calendar.YEAR);
                    int startMonth = startCalendar.get(Calendar.MONTH);

                    // 年月が等しいなら分割不要
                    if (startYear == endYear &&
                        startMonth == endMonth) {
                        break;
                    }

                    BeforeFileUsed cloneUsed = wkUsed.clone();
                    // 分割点：翌月の1日 0:00:00
                    divideCalendar.setTime(startTime);
                    divideCalendar.add(Calendar.MONTH, 1);          // 翌月
                    divideCalendar.set(Calendar.DAY_OF_MONTH, 1);   // 1日
                    divideCalendar.set(Calendar.HOUR_OF_DAY, 0);    // 0時
                    divideCalendar.set(Calendar.MINUTE, 0);         // 0分
                    divideCalendar.set(Calendar.SECOND, 0);         // 0秒
                    Date divideTime = divideCalendar.getTime();

                    // 元データ：終了時刻を変更
                    wkUsed.setEndTime(divideTime);
                    this.resetDuration(wkUsed);

                    // クローン：開始時刻を変更
                    cloneUsed.setStartTime(divideTime);
                    this.resetDuration(cloneUsed);
                    addList.add(cloneUsed);

                    // クローンに対してさらに分割
                    wkUsed = cloneUsed;
                    startTime = divideTime;
                }
            }

            usedList.addAll(addList);
        }
    }

    /**
     * Reset duration
     * 開始/終了時間から期間を再設定する
     * @param beforeFileUsed    変換前ファイルのUsed行のデータ
     */
    private void resetDuration(BeforeFileUsed beforeFileUsed) {
        Date startTime = beforeFileUsed.getStartTime();
        Date endTime = beforeFileUsed.getEndTime();
        long duration = (endTime.getTime() - startTime.getTime()) / 1000;
        beforeFileUsed.setDuration((int)duration);
    }
}
