package jp.meportal.isv.fileconvert.read;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import com.jcraft.jsch.Session;

import jp.meportal.isv.util.ExecuteCommand;

/**
 * Reader of before file
 * 変換前ファイルの読み込み用クラス
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
public class BeforeFileReader {
    /**
     * Logger
     */
    private static final Logger logger = Logger.getLogger(BeforeFileReader.class);

    /**
     * Before file map
     */
    private BeforeFileMap beforeFileMap;

    /**
     * Get before file map
     * @return before file map
     */
    public BeforeFileMap getBeforeFileMap() {
        return beforeFileMap;
    }

    /**
     * Constructor
     */
    public BeforeFileReader() {
        beforeFileMap = null;
    }

    /**
     * Read before file
     * 変換前ファイルの読み込み
     * @param session           Session
     * @param beforeFilePath    変換前ファイルのパス
     * @return  true: 正常終了 / false: 異常終了
     */
    public boolean read(Session session, String beforeFilePath)
    {
        List<String> lines = this.readFile(session, beforeFilePath);
        if (lines == null) {
            logger.error("Failed to read file: " + beforeFilePath);
            return false;
        }

        beforeFileMap = new BeforeFileMap();

        ArrayList<BeforeFileUsed> useds = null;
        for (String line : lines) {
            if (line.startsWith("Events")) {
                // Events行の読み込み
                BeforeFileEvents events = BeforeFileEvents.read(line);
                if (events == null) {
                    logger.error("Failed to read line: " + line);
                    logger.error("Failed to read file: " + beforeFilePath);
                    return false;
                }

                // Data作成
                useds = new ArrayList<BeforeFileUsed>();
                beforeFileMap.put(events, useds);
            }
            else if (line.startsWith("Used")) {
                // Used行の読み込み
                BeforeFileUsed used = BeforeFileUsed.read(line);
                if (used == null) {
                    logger.error("Failed to read line: " + line);
                    logger.error("Failed to read file: " + beforeFilePath);
                    return false;
                }

                if (useds != null) {
                    useds.add(used);
                }
            }
        }

        return true;
    }

    /**
     * Read file
     * ファイル読み込み処理
     * @param session   Session
     * @param filePath  ファイルパス
     * @return  ファイルの内容(一行ごと)
     */
    private List<String> readFile(Session session, String filePath) {
        String command = "cat " + filePath;

        // コマンド実行
        ExecuteCommand executeCommand = new ExecuteCommand();
        List<String> contents = executeCommand.executeCommand(session, command);
        if (executeCommand.exitStatus != 0) {
            return null;
        }

        return contents;
    }

}
