package jp.meportal.isv.fileconvert.read;

import org.apache.log4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import jp.meportal.isv.constant.Constants;

 /**
 * Used line of before file
 * 変換前ファイルのUsed行の情報を保持するクラス
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
public class BeforeFileUsed implements Cloneable {
    /**
     * Logger
     */
    private static final Logger logger = Logger.getLogger(BeforeFileUsed.class);

    /**
     * User
     */
    private String user;

    /**
     * Host
     */
    private String host;

    /**
     * IP Address
     */
    private String ipAddress;

    /**
     * #(Sharp)
     */
    private String sharp;

    /**
     * Start Time
     */
    private Date startTime;

    /**
     * End Time
     */
    private Date endTime;

    /**
     * Duration[秒]
     */
    private int duration;

    /**
     * AppVer
     */
    private String appVer;

    /**
     * Display
     */
    private String display;

    /**
     * Project
     */
    private String project;

    /**
     * Vendor
     */
    private String vendor;

    /**
     * Get User
     * @return User
     */
    public String getUser() {
        return user;
    }

    /**
     * Set User
     * @param user User
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * Get Host
     * @return Host
     */
    public String getHost() {
        return host;
    }

    /**
     * Set Host
     * @param host Host
     */
    public void setHost(String host) {
        this.host = host;
    }

    /**
     * Get IP Address
     * @return IP Address
     */
    public String getIpAddress() {
        return ipAddress;
    }

    /**
     * Set IP Address
     * @param ipaddress IP Address
     */
    public void setIPAddress(String ipaddress) {
        this.ipAddress = ipaddress;
    }

    /**
     * Get Sharp
     * @return Sharp
     */
    public String getSharp() {
        return sharp;
    }

    /**
     * Set Sharp
     * @param sharp Sharp
     */
    public void setSharp(String sharp) {
        this.sharp = sharp;
    }

    /**
     * Get Start Time
     * @return Start Time
     */
    public Date getStartTime() {
        return startTime;
    }

    /**
     * Set Start Time
     * @param startTime Start Time
     */
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    /**
     * Get End Time
     * @return End Time
     */
    public Date getEndTime() {
        return endTime;
    }

    /**
     * Set End Time
     * @param endTime End Time
     */
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    /**
     * Get Duration[秒]
     * @return Duration[秒]
     */
    public int getDuration() {
        return duration;
    }

    /**
     * Set Duration[秒]
     * @param duration Duration[秒]
     */
    public void setDuration(int duration) {
        this.duration = duration;
    }

    /**
     * Get AppVer
     * @return AppVer
     */
    public String getAppVer() {
        return appVer;
    }

    /**
     * Set AppVer
     * @param appVer AppVer
     */
    public void setAppVer(String appVer) {
        this.appVer = appVer;
    }

    /**
     * Get Display
     * @return Display
     */
    public String getDisplay() {
        return display;
    }

    /**
     * Set Display
     * @param display Display
     */
    public void setDisplay(String display) {
        this.display = display;
    }

    /**
     * Get Project
     * @return Project
     */
    public String getProject() {
        return project;
    }

    /**
     * Set Project
     * @param project Project
     */
    public void setProject(String project) {
        this.project = project;
    }

    /**
     * Get Vendor
     * @return Vendor
     */
    public String getVendor() {
        return vendor;
    }

    /**
     * Set Vendor
     * @param vendor Vendor
     */
    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    /**
     * Constructor
     */
    private BeforeFileUsed() {
        this.initialize();
    }

    /**
     * Initialize
     * 初期化処理
     */
    private void initialize() {
        user = "";
        host = "";
        ipAddress = "";
        sharp = "";
        startTime = null;
        endTime = null;
        duration = 0;
        appVer = "";
        display = "";
        project = "";
        vendor = "";
    }

    /**
     * Create instance from before file
     * 変換前ファイルのUsed行の読み込み
     * @param lineUsed 変換前ファイルのUsed行の内容
     * @return BeforeFileUsedクラスのインスタンス(失敗時はnull)
     */
    public static BeforeFileUsed read(String lineUsed) {
//        return BeforeFileUsed.readBySplitSpace(lineUsed);
        return BeforeFileUsed.readBySearchComma(lineUsed);
    }

//    /**
//     * Read by splitting space
//     * スペース区切りで読み込む処理
//     * @param lineUsed
//     * @param lineUsed 変換前ファイルのUsed行の内容
//     * @return BeforeFileUsedクラスのインスタンス(失敗時はnull)
//     */
//    private static BeforeFileUsed readBySplitSpace(String lineUsed) {
//        final String SPACE_SEQ = "[\\s]+";  // 複数スペースのときに空文字の配列要素ができないようにする
//        final String COLON = ":";
//        final String COMMA = Constants.COMMA;
//
//        final int ITEM_INDEX_USER = 1;
//        final int ITEM_INDEX_HOST = 2;
//        final int ITEM_INDEX_IPADDRESS = 3;
//        final int ITEM_INDEX_SHARP = 4;
//        final int ITEM_INDEX_TIME_MONTH = 5;
//        final int ITEM_INDEX_TIME_DAY = 6;
//        final int ITEM_INDEX_TIME_YEAR = 7;
//        final int ITEM_INDEX_TIME_HHMMSS = 8;
//        final int ITEM_INDEX_DURATION_DAY = 9;
//        final int ITEM_INDEX_DURATION_HHMMSS = 10;
//        final int ITEM_INDEX_APPVER = 11;
//        final int ITEM_INDEX_DISPLAY = 12;
//        final int ITEM_INDEX_PROJECT = 13;
//        final int ITEM_INDEX_VENDOR = 14;
//        final int ITEM_LENGTH = 15;
//
//        // スペース区切り
//        String[] items = lineUsed.split(SPACE_SEQ);
//        if (items.length < ITEM_LENGTH) {
//            return null;
//        }
//
//        String user = items[ITEM_INDEX_USER];
//        String host = items[ITEM_INDEX_HOST];
//        String ipaddress = items[ITEM_INDEX_IPADDRESS];
//        String sharp = items[ITEM_INDEX_SHARP];
//
//        // Time
//        String timeMonth = items[ITEM_INDEX_TIME_MONTH];
//        String timeDay = items[ITEM_INDEX_TIME_DAY];
//        // "31," → "31" ※"7 31, 2017"のように日付に","がついている
//        if (timeDay.endsWith(COMMA)) {
//            timeDay = timeDay.substring(0, timeDay.length() - 1);
//        }
//        String timeYear = items[ITEM_INDEX_TIME_YEAR];
//        String[] timeHHMMSS = items[ITEM_INDEX_TIME_HHMMSS].split(COLON);
//        if (timeHHMMSS.length < 3) {
//            return null;
//        }
//        String timeHour = timeHHMMSS[0];
//        String timeMinute = timeHHMMSS[1];
//        String timeSecond = timeHHMMSS[2];
//
//        // Duration
//        String durationDay = items[ITEM_INDEX_DURATION_DAY];
//        // "00d" → "00"
//        if (durationDay.endsWith("d")) {
//            durationDay = durationDay.substring(0, durationDay.length() - 1);
//        }
//        String[] durationHHMMSS = items[ITEM_INDEX_DURATION_HHMMSS].split(COLON);
//        if (durationHHMMSS.length < 3) {
//            return null;
//        }
//        String durationHour = durationHHMMSS[0];
//        String durationMinute = durationHHMMSS[1];
//        String durationSecond = durationHHMMSS[2];
//
//        String appver = items[ITEM_INDEX_APPVER];
//        String display = items[ITEM_INDEX_DISPLAY];
//        String project = items[ITEM_INDEX_PROJECT];
//        String vendor = items[ITEM_INDEX_VENDOR];
//
//
//        BeforeFileUsed instance = new BeforeFileUsed();
//        if (!instance.setTimeDuration(timeYear,
//                                     timeMonth,
//                                     timeDay,
//                                     timeHour,
//                                     timeMinute,
//                                     timeSecond,
//                                     durationDay,
//                                     durationHour,
//                                     durationMinute,
//                                     durationSecond))
//        {
//            return null;
//        }
//        instance.setUser(user);
//        instance.setHost(host);
//        instance.setIPAddress(ipaddress);
//        instance.setSharp(sharp);
//        instance.setAppVer(appver);
//        instance.setDisplay(display);
//        instance.setProject(project);
//        instance.setVendor(vendor);
//
//        return instance;
//    }

    /**
     * Read by searching comma
     * カンマを検索し、そこを起点にして読み込む処理
     * ※User名にスペースが含まれるケースがあり、readBySplitSpace()で読み込めないので作成
     *   日付："6 31, 2017"のカンマを起点にさかのぼっていく方法での読み込み処理
     * @param lineUsed 変換前ファイルのUsed行の内容
     * @return BeforeFileUsedクラスのインスタンス(失敗時はnull)
     */
    private static BeforeFileUsed readBySearchComma(String lineUsed) {
        final String SPACE_SEQ = "[\\s]+";  // 複数スペースのときに空文字の配列要素ができないようにする
        final String COLON = ":";
        final String COMMA = Constants.COMMA;

        // カンマの前後で分ける
        int commaIndex = lineUsed.indexOf(COMMA);
        if (commaIndex < 0) {
            return null;
        }
        String beforeComma = lineUsed.substring(0, commaIndex);
        String afterComma = lineUsed.substring(commaIndex + 1);
        // スペースで区切る
        String[] itemsBeforeComma = beforeComma.split(SPACE_SEQ);
        String[] itemsAfterComma = afterComma.split(SPACE_SEQ);

        // カンマの前は後ろから順に設定
        int beforeCommaLength = itemsBeforeComma.length;
        final int ITEM_INDEX_BEFORE_COMMA_TIME_DAY = beforeCommaLength - 1;
        final int ITEM_INDEX_BEFORE_COMMA_TIME_MONTH = beforeCommaLength - 2;
        final int ITEM_INDEX_BEFORE_COMMA_SHARP = beforeCommaLength - 3;
        final int ITEM_INDEX_BEFORE_COMMA_IPADDRESS = beforeCommaLength - 4;
        final int ITEM_INDEX_BEFORE_COMMA_HOST = beforeCommaLength - 5;
        // Userが複数に分割される
        final int ITEM_INDEX_BEFORE_COMMA_USER_END = beforeCommaLength - 6;
        final int ITEM_INDEX_BEFORE_COMMA_USER_START = 1;
        if (ITEM_INDEX_BEFORE_COMMA_USER_END < ITEM_INDEX_BEFORE_COMMA_USER_START) {
            return null;
        }

        final int ITEM_INDEX_AFTER_COMMA_TIME_YEAR = 1;
        final int ITEM_INDEX_AFTER_COMMA_TIME_HHMMSS = 2;
        final int ITEM_INDEX_AFTER_COMMA_DURATION_DAY = 3;
        final int ITEM_INDEX_AFTER_COMMA_DURATION_HHMMSS = 4;
        final int ITEM_INDEX_AFTER_COMMA_APPVER = 5;
        final int ITEM_INDEX_AFTER_COMMA_DISPLAY = 6;
        final int ITEM_INDEX_AFTER_COMMA_PROJECT = 7;
        final int ITEM_INDEX_AFTER_COMMA_VENDOR = 8;
        final int ITEM_LENGTH_AFTER_COMMA = 9;
        if (itemsAfterComma.length < ITEM_LENGTH_AFTER_COMMA) {
            return null;
        }

        // Userを足していく
        String user = itemsBeforeComma[ITEM_INDEX_BEFORE_COMMA_USER_START];
        for (int i = ITEM_INDEX_BEFORE_COMMA_USER_START + 1; i <= ITEM_INDEX_BEFORE_COMMA_USER_END; i++) {
            user += " " + itemsBeforeComma[i];
        }

        String host = itemsBeforeComma[ITEM_INDEX_BEFORE_COMMA_HOST];
        String ipaddress = itemsBeforeComma[ITEM_INDEX_BEFORE_COMMA_IPADDRESS];
        String sharp = itemsBeforeComma[ITEM_INDEX_BEFORE_COMMA_SHARP];

        // Time
        String timeMonth = itemsBeforeComma[ITEM_INDEX_BEFORE_COMMA_TIME_MONTH];
        String timeDay = itemsBeforeComma[ITEM_INDEX_BEFORE_COMMA_TIME_DAY];
        // 年以降はカンマの後ろ側
        String timeYear = itemsAfterComma[ITEM_INDEX_AFTER_COMMA_TIME_YEAR];
        String[] timeHHMMSS = itemsAfterComma[ITEM_INDEX_AFTER_COMMA_TIME_HHMMSS].split(COLON);
        if (timeHHMMSS.length < 3) {
            return null;
        }
        String timeHour = timeHHMMSS[0];
        String timeMinute = timeHHMMSS[1];
        String timeSecond = timeHHMMSS[2];

        // Duration
        String durationDay = itemsAfterComma[ITEM_INDEX_AFTER_COMMA_DURATION_DAY];
        // "00d" → "00"
        if (durationDay.endsWith("d")) {
            durationDay = durationDay.substring(0, durationDay.length() - 1);
        }
        String[] durationHHMMSS = itemsAfterComma[ITEM_INDEX_AFTER_COMMA_DURATION_HHMMSS].split(COLON);
        if (durationHHMMSS.length < 3) {
            return null;
        }
        String durationHour = durationHHMMSS[0];
        String durationMinute = durationHHMMSS[1];
        String durationSecond = durationHHMMSS[2];

        String appver = itemsAfterComma[ITEM_INDEX_AFTER_COMMA_APPVER];
        String display = itemsAfterComma[ITEM_INDEX_AFTER_COMMA_DISPLAY];
        String project = itemsAfterComma[ITEM_INDEX_AFTER_COMMA_PROJECT];
        String vendor = itemsAfterComma[ITEM_INDEX_AFTER_COMMA_VENDOR];


        BeforeFileUsed instance = new BeforeFileUsed();
        if (!instance.setTimeDuration(timeYear,
                                     timeMonth,
                                     timeDay,
                                     timeHour,
                                     timeMinute,
                                     timeSecond,
                                     durationDay,
                                     durationHour,
                                     durationMinute,
                                     durationSecond))
        {
            return null;
        }
        instance.setUser(user);
        instance.setHost(host);
        instance.setIPAddress(ipaddress);
        instance.setSharp(sharp);
        instance.setAppVer(appver);
        instance.setDisplay(display);
        instance.setProject(project);
        instance.setVendor(vendor);

        return instance;
    }

    /**
     * Set start time, end time and duration
     * 開始時間、終了時間、期間の設定処理
     * @param startTimeYearStr      開始時間：年
     * @param startTimeMonthStr     開始時間：月
     * @param startTimeDayStr       開始時間：日
     * @param startTimeHourStr      開始時間：時
     * @param startTimeMinuteStr    開始時間：分
     * @param startTimeSecondStr    開始時間：秒
     * @param durationDayStr        期間：日
     * @param durationHourStr       期間：時
     * @param durationMinuteStr     期間：分
     * @param durationSecondStr     期間：秒
     * @return  true: 正常終了 / false: 異常終了
     */
    private boolean setTimeDuration(
                String startTimeYearStr,
                String startTimeMonthStr,
                String startTimeDayStr,
                String startTimeHourStr,
                String startTimeMinuteStr,
                String startTimeSecondStr,
                String durationDayStr,
                String durationHourStr,
                String durationMinuteStr,
                String durationSecondStr)
    {
        // int型に変換
        int startTimeYearInt = 0;
        int startTimeMonthInt = 0;
        int startTimeDayInt = 0;
        int startTimeHourInt = 0;
        int startTimeMinuteInt = 0;
        int startTimeSecondInt = 0;
        int durationDayInt = 0;
        int durationHourInt = 0;
        int durationMinuteInt = 0;
        int durationSecondInt = 0;
        try {
            startTimeYearInt = Integer.parseInt(startTimeYearStr);
            startTimeMonthInt = Integer.parseInt(startTimeMonthStr);
            startTimeDayInt = Integer.parseInt(startTimeDayStr);
            startTimeHourInt = Integer.parseInt(startTimeHourStr);
            startTimeMinuteInt = Integer.parseInt(startTimeMinuteStr);
            startTimeSecondInt = Integer.parseInt(startTimeSecondStr);

            durationDayInt = Integer.parseInt(durationDayStr);
            durationHourInt = Integer.parseInt(durationHourStr);
            durationMinuteInt = Integer.parseInt(durationMinuteStr);
            durationSecondInt = Integer.parseInt(durationSecondStr);
        } catch (NumberFormatException ex) {
            logger.error(ex.toString());
            return false;
        }

        // 開始時間を設定
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(startTimeYearInt,
                     startTimeMonthInt - 1,    // Calendarクラスでは月は0～11
                     startTimeDayInt,
                     startTimeHourInt,
                     startTimeMinuteInt,
                     startTimeSecondInt);
        this.setStartTime(calendar.getTime());

        // 終了時間を求める(durationを加算)
        calendar.add(Calendar.DAY_OF_MONTH, durationDayInt);
        calendar.add(Calendar.HOUR_OF_DAY, durationHourInt);
        calendar.add(Calendar.MINUTE, durationMinuteInt);
        calendar.add(Calendar.SECOND, durationSecondInt);
        // 終了時間を設定
        this.setEndTime(calendar.getTime());

        // 期間を設定
        duration = durationSecondInt;
        duration += durationMinuteInt * 60;
        duration += durationHourInt * 60 * 60;
        duration += durationDayInt * 24 * 60 * 60;

        return true;
    }

    /**
     * If End Time is 0:00, get End Time before 1 second
     * End Timeが0:00ちょうどの場合、End Timeの一秒前を取得
     * ※7/1 0:00に終わったログは6/30の分と扱うため
     * @return End Time or End Timeの一秒前
     */
    public Date getEndTimeBefore1Second() {
        Date endTime = this.getEndTime();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(endTime);

        // 0時ちょうどでなければそのまま返す
        // ※6/30 23:00～7/1 0:00のログは6月分としてカウントするため
        if (calendar.get(Calendar.HOUR_OF_DAY) != 0 ||
            calendar.get(Calendar.MINUTE) != 0 ||
            calendar.get(Calendar.SECOND) != 0)
        {
            return endTime;
        }

        // 開始＝終了ならそのまま返す
        // ※7/1 0:00～7/1 0:00のログは7月分としてカウントするため
        if (endTime.equals(this.getStartTime())) {
            return endTime;
        }

        calendar.add(Calendar.SECOND, -1);
        endTime = calendar.getTime();
        return endTime;
    }

    /**
     * clone
     * @return  clone
     */
    @Override
    public BeforeFileUsed clone() {
        BeforeFileUsed clone = null;

        try {
            clone = (BeforeFileUsed)super.clone();
        }catch (CloneNotSupportedException e){
            // 処理なし
        }

        return clone;
    }

    /**
     * Dump for debug
     * デバッグ用のダンプ出力
     * @return ダンプ文字列
     */
    public String dumpForDebug() {
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat f = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        sb.append("[Used]\nuser=")
          .append(this.getUser())
          .append("\nhost=")
          .append(this.getHost())
          .append("\nipaddress=")
          .append(this.getIpAddress())
          .append("\n#=")
          .append(this.getSharp())
          .append("\nStartTime=")
          .append(f.format(this.getStartTime()))
          .append("\nEndTime=")
          .append(f.format(this.getEndTime()))
          .append("\nDuration=")
          .append(this.getDuration())
          .append("\nAppVer=")
          .append(this.getAppVer())
          .append("\nDisplay=")
          .append(this.getDisplay())
          .append("\nProject=")
          .append(this.getProject())
          .append("\nVendor=")
          .append(this.getVendor());

        return sb.toString();
    }
}
