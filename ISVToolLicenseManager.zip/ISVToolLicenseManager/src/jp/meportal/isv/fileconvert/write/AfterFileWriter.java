package jp.meportal.isv.fileconvert.write;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import com.jcraft.jsch.Session;

import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.fileconvert.read.BeforeFileEvents;
import jp.meportal.isv.fileconvert.read.BeforeFileMap;
import jp.meportal.isv.fileconvert.read.BeforeFileUsed;
import jp.meportal.isv.util.DateUtils;
import jp.meportal.isv.util.ExecuteCommand;

/**
 * Writer of after file
 * 変換後ファイルの書き込み用クラス
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
public class AfterFileWriter {
    /**
     * Logger
     */
    private static final Logger logger = Logger.getLogger(AfterFileWriter.class);

    /**
     * Write after file
     * 変換後ファイルの書き込み
     * @param session           Session
     * @param afterFilePath     変換後ファイルのパス($yearなどは未置換)
     * @param beforeFileMap     変換前ファイルのデータ
     * @param catalogInfor      CatalogInfor
     * @return  true: 正常終了 / false: 異常あり
     */
    public boolean write(Session session,
                         String afterFilePath,
                         BeforeFileMap beforeFileMap,
                         CatalogInfor catalogInfor)
    {
        boolean successAll = true;

        // 月をまたぐログを分割
        beforeFileMap.divideByDay();

        HashMap<String, BeforeFileMap> map = this.divideByYearMonth(beforeFileMap);

        for (Entry<String, BeforeFileMap> entry : map.entrySet()) {
            String yyyyMM = entry.getKey();
            BeforeFileMap bMap = entry.getValue();

            // 出力ファイルのパス
            String filePath = this.createAfterFilePath(afterFilePath, yyyyMM);

            // 出力ファイルの親ディレクトリ
            String dirPath = this.getParentDirectoryPath(filePath);

            // 親ディレクトリを作っておく(失敗したら例外処理)
            if (!this.makeDirectory(session, dirPath)) {
                logger.error("Failed to create directory: " + dirPath);
                successAll = false;
                continue;
            }

            // 出力ファイルが既にあったらバックアップを取っておく
            String backupFilePath = null;
            if (this.isExistsFile(session, filePath)) {
                backupFilePath = this.getBackupFilePath(filePath);
                // コピー(失敗時は例外処理)
                if (!this.copyFile(session, filePath, backupFilePath)) {
                    logger.error("Failed to copy file: " + filePath + " -> " + backupFilePath);
                    successAll = false;
                    continue;
                }
            }

            // 出力
            if (!this.writeCore(session, filePath, bMap, catalogInfor)) {
                // バックアップしておいたファイルに戻す
                if (backupFilePath != null) {
                    this.deleteFile(session, filePath); // 変な状態のファイルを消す
                    this.moveFile(session, backupFilePath, filePath);   // バックアップしておいたファイルに戻す
                }

                successAll = false;
                continue;
            }

            // バックアップしたファイルを削除
            if (backupFilePath != null) {
                this.deleteFile(session, backupFilePath);
            }
        }

        return successAll;
    }

    /**
     * Write after file (core)
     * 変換後ファイルの書き込み(コア処理)
     * @param session           Session
     * @param afterFilePath     変換後ファイルのパス($yearなどは置換済み)
     * @param beforeFileMap     変換前ファイルのデータ(同じ年月のみ)
     * @param catalogInfor      CatalogInfor
     * @return  true: 正常終了 / false: 異常終了
     */
    private boolean writeCore(Session session,
                              String afterFilePath,
                              BeforeFileMap beforeFileMap,
                              CatalogInfor catalogInfor)
    {
        int seqNo = 1;

        for (Entry<BeforeFileEvents, ArrayList<BeforeFileUsed>> entry : beforeFileMap.entrySet()) {
            BeforeFileEvents events = entry.getKey();
            ArrayList<BeforeFileUsed> useds = entry.getValue();

            for (BeforeFileUsed used : useds) {
                // 最初の一回目は空ファイルで上書き
                if (seqNo == 1) {
                    if (!this.createNullFile(session, afterFilePath)) {
                        logger.error("Failed to write file: " + afterFilePath);
                        return false;
                    }
                }

                // 変換後ファイルの一行を作成
                String line = this.createAfterFileLine(events, used, catalogInfor, seqNo);

                if (!this.appendFile(session, afterFilePath, line)) {
                    logger.error("Failed to write file: " + afterFilePath);
                    return false;
                }

                seqNo++;
            }
        }

        return true;
    }

    /**
     * Divide before file data by year and month
     * 変換前ファイルのデータを年月ごとに分ける
     * @param beforeFileMap     変換前ファイルのデータ
     * @return  年月ごとに分けたもの。キーはyyyyMM("201707"など)
     */
    private LinkedHashMap<String, BeforeFileMap> divideByYearMonth(BeforeFileMap beforeFileMap) {
        LinkedHashMap<String, BeforeFileMap> map = new LinkedHashMap<String, BeforeFileMap>();

        for (Entry<BeforeFileEvents, ArrayList<BeforeFileUsed>> entry : beforeFileMap.entrySet()) {
            BeforeFileEvents events = entry.getKey();
            for (BeforeFileUsed used : entry.getValue()) {
                // 終了日で振り分ける
                String key = this.getKeyForDivideByYearMonth(used);

                BeforeFileMap bMap = map.get(key);
                if (bMap == null) {
                    bMap = new BeforeFileMap();
                    map.put(key, bMap);
                }

                ArrayList<BeforeFileUsed> bUseds = bMap.get(events);
                if (bUseds == null) {
                    bUseds = new ArrayList<BeforeFileUsed>();
                    bMap.put(events, bUseds);
                }

                bUseds.add(used);
            }
        }

        return map;
    }

    /**
     * Get key for divideByYearMonth()
     * divideByYearMonth()のキー文字列を取得(年月ごとに分けるためのキー)
     * @param beforeFileUsed    変換前ファイルのUsed行のデータ
     * @return  キー文字列。(構成要素：年月)
     */
    private String getKeyForDivideByYearMonth(BeforeFileUsed beforeFileUsed) {
        SimpleDateFormat f = new SimpleDateFormat("yyyyMM");

        Date date = beforeFileUsed.getEndTimeBefore1Second();
        String key = f.format(date);
        return key;
    }

    /**
     * Create a line of after file
     * 変換後ファイルの一行の文字列を作成
     * @param events            変換前ファイルのEvents行データ
     * @param used              変換前ファイルのUsed行データ
     * @param catalogInfor      CatalogInfor
     * @param sequentialNumber  連番
     * @return  変換後ファイルの一行の文字列
     */
    private String createAfterFileLine(BeforeFileEvents events,
                                       BeforeFileUsed used,
                                       CatalogInfor catalogInfor,
                                       int sequentialNumber)
    {
        final String SEPARATOR = ";";
        final String UNKN = "UNKN";

        SimpleDateFormat f = new SimpleDateFormat("yyyy.MM.dd(HHmmss)");

        StringBuilder sb = new StringBuilder();

        String startTime = f.format(used.getStartTime());
        sb.append(startTime);
        sb.append(SEPARATOR);

        String endTime = f.format(used.getEndTime());
        sb.append(endTime);
        sb.append(SEPARATOR);

        String duration = DateUtils.convertSecondsToString(used.getDuration());
        sb.append(duration);
        sb.append(SEPARATOR);

        sb.append(catalogInfor.getFutureName());
        sb.append(SEPARATOR);

        sb.append(events.getToolName());
        sb.append(SEPARATOR);

        String toolVersion = used.getAppVer();
        // "UNKN"だったらEvents側から取得
        if (toolVersion.equals(UNKN)) {
            toolVersion = events.getToolVersion();
        }
        sb.append(toolVersion);
        sb.append(SEPARATOR);

        sb.append(used.getHost());
        sb.append(SEPARATOR);

        sb.append(used.getUser());
        sb.append(SEPARATOR);

        sb.append(Integer.toString(sequentialNumber));
        sb.append(SEPARATOR);

        sb.append(used.getIpAddress());
        sb.append(SEPARATOR);

        String sharp = used.getSharp();
        // "1"なら""にする
        if (sharp.equals("1")) {
            sharp = "";
        }
        sb.append(sharp);
        sb.append(SEPARATOR);

        // 末尾の文字列
        String endStr = this.createAfterFileEndString(used, catalogInfor);
        sb.append(endStr);

        return sb.toString();
    }

    /**
     * Create end string of after file
     * 変換後ファイルの末尾の文字列を作成
     * @param used          変換前ファイルのUsed行
     * @param catalogInfor  CatalogInfor
     * @return  変換後ファイルの末尾の文字列
     */
    private String createAfterFileEndString(BeforeFileUsed used, CatalogInfor catalogInfor) {
        final String VENDR = "vEndR=";
        final String TERML = "tErmL=";
        final String USRDT = "uSrdT=";
        final String SEPARATOR = ",";

        StringBuffer sb = new StringBuffer();

        sb.append(VENDR);
        sb.append(catalogInfor.getVendorName());
        sb.append(SEPARATOR);

        sb.append(TERML);
        sb.append(used.getDisplay());
        sb.append(SEPARATOR);

        sb.append(USRDT);
        sb.append(used.getVendor());

        return sb.toString();
    }

    /**
     * Create after file path
     * 変換後ファイルのパスを作成
     * @param afterFilePath     変換後ファイルのパス($yearなどは未置換)
     * @param yyyyMM            年月 ex.) "2017.08"
     * @return  変換後ファイルのパス($yearなどを置換済み)
     */
    private String createAfterFilePath(String afterFilePath, String yyyyMM) {
        final String REPLACE_YEAR = "\\$year";
        final String REPLACE_MONTH = "\\$month";

        String yyyy = yyyyMM.substring(0, 4);
        String mm = yyyyMM.substring(4);

        String replaced = afterFilePath.replaceAll(REPLACE_YEAR, yyyy);
        replaced = replaced.replaceAll(REPLACE_MONTH, mm);

        return replaced;
    }

    /**
     * Get parent directory path
     * 親ディレクトリのパスを取得
     * @param path  パス
     * @return  親ディレクトリのパス
     */
    private String getParentDirectoryPath(String path) {
        final String SLASH = Constants.SlASH_CHARACTERS;

        int lastIndex = path.lastIndexOf(SLASH);
        if (lastIndex < 0) {
            return Constants.DOT;   // 相対パス扱い→カレントを返す
        }

        String parentPath = path.substring(0, lastIndex);
        return parentPath;
    }

    /**
     * Get file path for backup
     * バックアップ用のファイルパスを取得
     * ※元のファイルパスに"_yyyyMMddHHmmss" (現在時刻)をつける
     * ※拡張子は無視 "aaa.txt" → "aaa.txt_yyyyMMddHHmmss"
     * @param path  ファイルパス
     * @return  バックアップ用のファイルパス
     */
    private String getBackupFilePath(String path) {
        final String DATE_FORMAT = "yyyyMMddHHmmss";

        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT);
        String date = format.format(new Date());

        return path + "_" + date;
    }

    /**
     * Check file exists
     * ファイル存在チェック
     * @param session   Session
     * @param filePath  ファイルパス
     * @return  true: 存在する / false: 存在しない
     */
    private boolean isExistsFile(Session session, String filePath) {
        String command = "[ -f " + filePath + " ] && " + Constants.COMMAND_ECHO_YES_NO;

        // コマンド実行
        ExecuteCommand executeCommand = new ExecuteCommand();
        List<String> result = executeCommand.executeCommand(session, command);
        if (result != null && result.size() > 0) {
            if (Constants.FILE_EXISTS.equals(result.get(0))) {
                return true;
            }
        }

        return false;
    }

    /**
     * Make directory
     * ディレクトリ作成
     * @param session   Session
     * @param dirPath   ディレクトリパス
     * @return  true: 成功 / false: 失敗
     */
    private boolean makeDirectory(Session session, String dirPath) {
        String command = Constants.COMMAND_MKDIR_IF_EXISTS + dirPath;

        // コマンド実行
        ExecuteCommand executeCommand = new ExecuteCommand();
        executeCommand.executeCommand(session, command);
        if (executeCommand.exitStatus != 0) {
            return false;
        }

        return true;
    }

    /**
     * Move file
     * ファイルの移動
     * @param session   Session
     * @param srcPath   移動元のファイルパス
     * @param dstPath   移動先のファイルパス
     * @return  true: 成功 / false: 失敗
     */
    private boolean moveFile(Session session, String srcPath, String dstPath) {
        String command = Constants.COMMAND_MV + srcPath + " " + dstPath;

        // コマンド実行
        ExecuteCommand executeCommand = new ExecuteCommand();
        executeCommand.executeCommand(session, command);
        if (executeCommand.exitStatus != 0) {
            return false;
        }

        return true;
    }

    /**
     * Copy file
     * ファイルのコピー
     * @param session   Session
     * @param srcPath   コピー元のファイルパス
     * @param dstPath   コピー先のファイルパス
     * @return  true: 成功 / false: 失敗
     */
    private boolean copyFile(Session session, String srcPath, String dstPath) {
        String command = Constants.COMMAND_CP + srcPath + " " + dstPath;

        // コマンド実行
        ExecuteCommand executeCommand = new ExecuteCommand();
        executeCommand.executeCommand(session, command);
        if (executeCommand.exitStatus != 0) {
            return false;
        }

        return true;
    }

    /**
     * Delete file
     * ファイル削除
     * @param session   Session
     * @param filePath  ファイルパス
     * @return  true: 成功 / false: 失敗
     */
    private boolean deleteFile(Session session, String filePath) {
        String command = Constants.COMMAND_RM + filePath;

        // コマンド実行
        ExecuteCommand executeCommand = new ExecuteCommand();
        executeCommand.executeCommand(session, command);
        if (executeCommand.exitStatus != 0) {
            return false;
        }

        return true;
    }

    /**
     * Create null file
     * 空ファイルの作成
     * @param session   Session
     * @param filePath  ファイルパス
     * @return  true: 成功 / false: 失敗
     */
    private boolean createNullFile(Session session, String filePath) {
        String command = "echo -n > " + filePath;

        // コマンド実行
        ExecuteCommand executeCommand = new ExecuteCommand();
        executeCommand.executeCommand(session, command);
        if (executeCommand.exitStatus != 0) {
            return false;
        }
        return true;
    }

    /**
     * Append to file
     * ファイルに追記
     * @param session   Session
     * @param filePath  ファイルパス
     * @param contents  追記する内容
     * @return  true: 正常終了 / false: 異常終了
     */
    private boolean appendFile(Session session, String filePath, String contents) {
        String command = "echo " + "'" + contents + "'" + " >> " + filePath;

        // コマンド実行
        ExecuteCommand executeCommand = new ExecuteCommand();
        executeCommand.executeCommand(session, command);
        if (executeCommand.exitStatus != 0) {
            return false;
        }
        return true;
    }
}
