package jp.meportal.isv.fileconvert.listener;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import jp.meportal.isv.action.FileConvertAction;

import org.apache.log4j.Logger;

/**
 * Class Name: FileConvertListener<br>
 * Created date: 2017/11/08<br>
 * 
 * @author FPT
 */
@WebListener
public class FileConvertListener implements ServletContextListener {

	private  ScheduledExecutorService executor;
	protected Logger logger = Logger.getLogger(this.getClass());
	
	/**
     * contextDestroyed
     * 
     * @author FPT
     * @date: 2017/11/08
     */
	@Override
    public void contextDestroyed(ServletContextEvent event) {
		executor.shutdown();
    }
	
	/**
     * contextInitialized
     * 
     * @author FPT
     * @date: 2017/11/08
     */
    @Override
    public void contextInitialized(ServletContextEvent event) {
    	executor = Executors.newScheduledThreadPool(1);
        executor.scheduleWithFixedDelay(new FileConvertAction(), 0, 1, TimeUnit.HOURS);
    }
}