﻿package jp.meportal.isv.fileconvert.db;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.HashMap;

import org.apache.log4j.Logger;

import jp.meportal.isv.business.FileConvertBusiness;
import jp.meportal.isv.business.impl.FileConvertBusinessImpl;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.LicenseUseInfor;
import jp.meportal.isv.entity.IpAddressInfo;
import jp.meportal.isv.fileconvert.read.BeforeFileMap;
import jp.meportal.isv.fileconvert.read.BeforeFileUsed;

/**
 * Updater of DB(license_use_info)
 * DB更新クラス(ライセンス利用状況の詳細ページの表示に使うlicense_use_infoテーブルを更新)
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
public class DBUpdater {
//    /**
//     * Logger
//     */
    private static final Logger logger = Logger.getLogger(DBUpdater.class);

    /**
     * FileConvertBusiness
     */
    private FileConvertBusiness fileConvertBusiness;

    /**
     * IpAddressInfo cache
     */
    private HashMap<String, IpAddressInfo> ipAddressInfoCache;

    /**
     * LicenseInfo cache
     */
    private HashMap<String, LicenseInfo> licenseInfoCache;

    /**
     * Constuctor
     */
    public DBUpdater() {
        fileConvertBusiness = new FileConvertBusinessImpl();
        ipAddressInfoCache = new HashMap<String, IpAddressInfo>();
        licenseInfoCache = new HashMap<String, LicenseInfo>();
    }

    /**
     * Update DB
     * DB更新
     * @param beforeFileMap     変換前ファイルのデータ(ISVツール利用ログ)
     * @param catalogInfor      CatalogInfor
     * @return  true: 正常終了 / false: 異常あり
     */
    public boolean update(BeforeFileMap beforeFileMap, CatalogInfor catalogInfor) {
        boolean successAll = true;

        // 月をまたぐログを分割
        beforeFileMap.divideByDay();

        // プロジェクトごとに分ける
        LinkedHashMap<String, ArrayList<BeforeFileUsed>> map = this.divideByProjectAndYearMonth(beforeFileMap);

        // プロジェクトごとに処理
        for (ArrayList<BeforeFileUsed> list : map.values()) {
            if (!this.updateByProject(list, catalogInfor)) {
                successAll = false;
            }
        }

        return successAll;
    }

    /**
     * Update DB(by project)
     * DB更新(プロジェクトごと)
     * @param usedListByProject     変換前ファイルのUsed行データ(同一プロジェクトのみ)
     * @param catalogInfor          CatalogInfor
     * @return  true: 正常終了 / false: 異常あり
     */
    public boolean updateByProject(ArrayList<BeforeFileUsed> usedListByProject, CatalogInfor catalogInfor) {
        boolean successAll = true;

        // 同時利用本数の算出
        SameTimeUseCalculator c = new SameTimeUseCalculator();
        HashMap<String, Integer> sameTimeUseMap = c.calculate(usedListByProject);

        // 実行単位ごと(license_use_infoの1行分ごと)に分ける
        LinkedHashMap<String, ArrayList<BeforeFileUsed>> map = this.divideByExecution(usedListByProject);

        // 実行単位ごとに処理
        for (ArrayList<BeforeFileUsed> list : map.values()) {
            if (!this.updateByExecution(list, sameTimeUseMap, catalogInfor)) {
                successAll = false;
            }
        }

        return successAll;
    }

    /**
     * Update DB(by execution)
     * DB更新(実行単位ごと)
     * @param usedListByExecution   変換前ファイルのUsed行データ(同一の実行単位のみ)
     * @param catalogInfor          CatalogInfor
     * @return  true: 正常終了 / false: 異常あり
     */
    public boolean updateByExecution(
            ArrayList<BeforeFileUsed> usedListByExecution,
            HashMap<String, Integer> sameTimeUseMap,
            CatalogInfor catalogInfor)
    {
        BeforeFileUsed usedAny = null;  // どれか適当な1つ(同一の実行単位しかないのでどれでも良い)
        int timeAll = 0;
        int timeWithoutFew = 0;
        int countAll = 0;
        int countWithoutFew = 0;
        for (BeforeFileUsed used : usedListByExecution) {
            usedAny = used;
            int duration = used.getDuration();

            // 時間/回数をカウント
            timeAll += duration;
            countAll++;

            // わずかな期間は飛ばす
            if (!ChargeCondition.isLicenseUse(duration)) {
                continue;
            }

            // わずかな期間を除いた時間/回数をカウント
            timeWithoutFew += duration;
            countWithoutFew++;
        }

        String ipAddress = usedAny.getIpAddress();

        // IpAddressInfoの取得
        IpAddressInfo ipAddressInfo = this.getIpAddressInfo(ipAddress);
        if (ipAddressInfo == null) {
				logger.info("updateByExecution : ipaddress is  null. (ip="+
						ipAddress+" prj="+ usedAny.getProject()+" vendor=)"+usedAny.getVendor()+
						" usr="+usedAny.getUser()+")  "+
						catalogInfor.getVendorName()+" "+catalogInfor.getToolName()+" "+catalogInfor.getToolName());
        //    return false;
        }
		else {

        // LicenseUseInforの取得
        LicenseUseInfor licenseUseInfo = this.getLicenseUseInfor(usedAny, catalogInfor, ipAddressInfo);
        licenseUseInfo.setRunTimeAll(timeAll);
        // licenseUseInfo.setRunTimeWithoutFew(timeWithoutFew);
        licenseUseInfo.setRunTimewithoutFew(timeWithoutFew);
        licenseUseInfo.setRunNumberAll(countAll);
        licenseUseInfo.setRunNumberWithoutFew(countWithoutFew);

        // 同時利用本数を設定
        int sameTimeUse = 1;
        if (sameTimeUseMap.containsKey(ipAddress)) {
            sameTimeUse = sameTimeUseMap.get(ipAddress);
        }
        licenseUseInfo.setSameTimeUseNumber(sameTimeUse);

        // 課金対象かどうかを設定
        int isCharge = this.judgeIsCharge(catalogInfor, ipAddressInfo, licenseUseInfo) ? 1 : 0;
        licenseUseInfo.setIsCharge(isCharge);

//        logger.info("-- obara LicenseUseInfo: seq_no: " + Integer.toString(licenseUseInfo.getSeqNo()) +
//                    ", ipaddress_id: " + Integer.toString(licenseUseInfo.getIPAddressId()) +
//                    ", catalog_id: " + Integer.toString(licenseUseInfo.getCatalogId()) +
//                    ", year: " + Integer.toString(licenseUseInfo.getYear()) +
//                    ", month: " + Integer.toString(licenseUseInfo.getMonth()) +
//                    ", account: " + licenseUseInfo.getAccount() +
//                    ", host: " + licenseUseInfo.getHost() +
//                    ", run_time_all: " + Integer.toString(licenseUseInfo.getRunTimeAll()) +
//                    ", run_time_without_few: " + Integer.toString(licenseUseInfo.getRunTimeWithoutFew()) +
//                    ", run_number_all: " + Integer.toString(licenseUseInfo.getRunNumberAll()) +
//                    ", run_number_without_few:" + Integer.toString(licenseUseInfo.getRunNumberWithoutFew()) +
//                    ", same_time_use_number: " + Integer.toString(licenseUseInfo.getSameTimeUseNumber()) +
//                    ", is_charge: " + Integer.toString(licenseUseInfo.getIsCharge()));

        // DBに登録
        if (!fileConvertBusiness.insertOrUpdateLicenseUseInfor(licenseUseInfo)) {
            return false;
        }
		}

        return true;
    }

    /**
     * Divide before file data by project and year/month
     * 変換前ファイルのデータをプロジェクトと年月ごとに分ける
     * @param beforeFileMap     変換前ファイルのデータ
     * @return  プロジェクトと年月ごとに分けたもの。
     *          キーはgetKeyForDivideByProjectAndYearMonth()参照。
     */
    private LinkedHashMap<String, ArrayList<BeforeFileUsed>> divideByProjectAndYearMonth(
            BeforeFileMap beforeFileMap)
    {
        LinkedHashMap<String, ArrayList<BeforeFileUsed>> map =
                new LinkedHashMap<String, ArrayList<BeforeFileUsed>>();

        for (ArrayList<BeforeFileUsed> usedList : beforeFileMap.values()) {
            for (BeforeFileUsed used : usedList) {
                // キー取得
                String key = this.getKeyForDivideByProjectAndYearMonth(used);

                // リスト取得
                ArrayList<BeforeFileUsed> value;
                if (map.containsKey(key)) {
                    value = map.get(key);
                // リストがなければ作成
                } else {
                    value = new ArrayList<BeforeFileUsed>();
                    map.put(key, value);
                }

                // リストに追加
                value.add(used);
            }
        }

        return map;
    }

    /**
     * Get key for divideByProjectAndYearMonth()
     * divideByProjectAndYearMonth()のキー文字列を取得
     * @param beforeFileUsed    変換前ファイルのUsed行のデータ
     * @return  キー文字列。(構成要素：project_info:seqno, 年, 月)
     */
    private String getKeyForDivideByProjectAndYearMonth(BeforeFileUsed beforeFileUsed) {
        final String SEPARATOR = ":";

        SimpleDateFormat f = new SimpleDateFormat("yyyy:MM");

        StringBuilder sb = new StringBuilder();

        // IpAddressInfoを取得
        String ipAddress = beforeFileUsed.getIpAddress();
        IpAddressInfo ipAddressInfo = this.getIpAddressInfo(ipAddress);

		if( ipAddressInfo != null ) {

        // ProjectId
        int projectId = ipAddressInfo.getProjectId().getSeqNo();
        sb.append(Integer.toString(projectId));
        sb.append(SEPARATOR);

        // 年月
        // ※7/1 0:00ちょうどに終わったものは、6月分としてカウントする
        sb.append(f.format(beforeFileUsed.getEndTimeBefore1Second()));
		}
		else {
			//logger.info("getKeyForDivideByProjectAndYearMonth : ipAddressInfo is null, "+ipAddress);
		}

        return sb.toString();
    }

    /**
     * Divide before file used list by execution
     * 変換前ファイルのUsed行のリストを実行単位ごと(license_use_infoの一行分ごと)に分ける
     * @param beforeFileUsedList    変換前ファイルのUsed行のリスト
     * @return  実行単位ごとに分けたもの。キーはgetKeyForDivideByExecution()参照。
     */
    private LinkedHashMap<String, ArrayList<BeforeFileUsed>> divideByExecution(
            ArrayList<BeforeFileUsed> beforeFileUsedList)
    {
        LinkedHashMap<String, ArrayList<BeforeFileUsed>> map
        = new LinkedHashMap<String, ArrayList<BeforeFileUsed>>();
        for (BeforeFileUsed used : beforeFileUsedList) {

            String key = this.getKeyForDivideByExecution(used);
            ArrayList<BeforeFileUsed> value;
            if (map.containsKey(key)) {
                value = map.get(key);
            } else {
                value = new ArrayList<BeforeFileUsed>();
                map.put(key, value);
            }
            value.add(used);
        }

        return map;
    }

    /**
     * Get key for divideByExecution()
     * divideByExecution()のキー文字列を取得
     * @param beforeFileUsed    変換前ファイルのUsed行のデータ
     * @return  キー文字列。(構成要素：IPアドレス, アカウント, ホスト)
     */
    private String getKeyForDivideByExecution(BeforeFileUsed beforeFileUsed) {
        final String SEPARATOR = ":";

        StringBuilder sb = new StringBuilder();

        // IPアドレス
        sb.append(beforeFileUsed.getIpAddress());
        sb.append(SEPARATOR);

        // Account
        sb.append(beforeFileUsed.getUser());
        sb.append(SEPARATOR);

        // Host
        sb.append(beforeFileUsed.getHost());

        return sb.toString();
    }

    /**
     * Get IpAddressInfo
     * IpAddressInfoの取得
     * @param ipAddress     IPアドレス
     * @return  IpAddressInfo
     */
    private IpAddressInfo getIpAddressInfo(String ipAddress) {
        IpAddressInfo ipAddressInfo = null;

        // キャッシュにあればキャッシュから取得
        if (ipAddressInfoCache.containsKey(ipAddress)) {
            ipAddressInfo = ipAddressInfoCache.get(ipAddress);
        // キャッシュになければDBから取得
        } else {
            ipAddressInfo = fileConvertBusiness.findIpAddressInfoByIpAddress(ipAddress);
            ipAddressInfoCache.put(ipAddress, ipAddressInfo);
        }

        return ipAddressInfo;
    }

    /**
     * Get LicenseUseInfor
     * LicenseUseInforの取得
     * @param beforeFileUsed    変換前ファイルのUsed行データ
     * @param catalogInfor      CatalogInfor
     * @param ipAddressInfo     IpAddressInfo
     * @return  LicenseUseInfor
     */
    private LicenseUseInfor getLicenseUseInfor(
            BeforeFileUsed beforeFileUsed,
            CatalogInfor catalogInfor,
            IpAddressInfo ipAddressInfo)
    {
        int ipAddressId = ipAddressInfo.getSeqNo();
        int catalogId = catalogInfor.getSeqNo();

        // 年月を取得
        // ※7/1 0:00ちょうどに終わったものは、6月分としてカウントする
        Date date = beforeFileUsed.getEndTimeBefore1Second();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;   // Calendarクラスでは月は0～11
        // 年度にする(1～3月は前年にする)
        switch (month) {
        case 1:
        case 2:
        case 3:
            year--;
            break;
        default:
            break;
        }

        String account = beforeFileUsed.getUser();
        String host = beforeFileUsed.getHost();

        // 既存のテーブルを取得
        LicenseUseInfor licenseUseInfo = fileConvertBusiness.findLicenseUseInfor(
                ipAddressId, catalogId, year, month, account, host);

        // 無ければ作成
        if (licenseUseInfo == null) {
            licenseUseInfo = new LicenseUseInfor();
            licenseUseInfo.setIpaddressId(ipAddressInfo);
            licenseUseInfo.setCatalogId(catalogInfor);
            this.setYearMonth(licenseUseInfo, beforeFileUsed);
            licenseUseInfo.setAccount(beforeFileUsed.getUser());
            licenseUseInfo.setHost(beforeFileUsed.getHost());
        }

        return licenseUseInfo;
    }

    /**
     * Set year/month to LicenseUseInfor
     * LicenseUseInforに年月を設定
     * @param licenseUseInfo    LicenseUseInfor
     * @param beforeFileUsed    変換前ファイルのUsed行データ
     */
    private void setYearMonth(LicenseUseInfor licenseUseInfo, BeforeFileUsed beforeFileUsed) {
        // 終了日を取得
        // ※7/1 0:00ちょうどに終わったものは、6月分としてカウントする
        Date date = beforeFileUsed.getEndTimeBefore1Second();

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;   // Calendarクラスでは月は0～11

        // 年度にする(1～3月は前年にする)
        switch (month) {
        case 1:
        case 2:
        case 3:
            year--;
            break;
        default:
            break;
        }

        licenseUseInfo.setYear(year);
        licenseUseInfo.setMonth(month);
    }

    /**
     * Judge is charge
     * 課金対象かどうかの判定
     * @param catalogInfor      CatalogInfor
     * @param ipaddressInfo     IpAddressInfo
     * @param licenseUseInfo    LicenseUseInfor(年月と同時利用本数が設定されていること)
     * @return  true: 課金対象 / false: 課金対象ではない
     */
    private boolean judgeIsCharge(CatalogInfor catalogInfor, IpAddressInfo ipaddressInfo, LicenseUseInfor licenseUseInfo) {
        // 30秒以上の実行がない場合はライセンスを使用したとみなさない
        if (licenseUseInfo.getRunNumberWithoutFew() < 1) {
            return false;
        }

        // ライセンス情報取得
        LicenseInfo licenseInfo = this.getLicenseInfo(catalogInfor, ipaddressInfo, licenseUseInfo);

        // ライセンス申請数
        // ※ライセンス情報を取得できなかったときはライセンス申請数0で計算
        int licenseNumber = 0;
        if (licenseInfo != null) {
            licenseNumber = this.getLicenseNumber(licenseInfo, licenseUseInfo.getMonth());
        }

        // 同時利用本数
        int sameTimeUseNumber = licenseUseInfo.getSameTimeUseNumber();

        BigDecimal price = catalogInfor.getMemberPrice();   // 会員価格
        // 同時利用本数がライセンス申請数を超えている場合は通常価格を見る
        if (sameTimeUseNumber > licenseNumber) {
            price = catalogInfor.getRegularPrice();
        }

//        // 会員価格でのライセンス数
//        int memberNumber = licenseNumber;
//
//        // 通常価格でのライセンス数
//        int regularNumber = sameTimeUseNumber - licenseNumber;
//        // 同時利用本数がライセンス申請数未満のとき
//        if (sameTimeUseNumber < licenseNumber) {
//            regularNumber = 0;
//        }
//
//        // 価格を算出
//        BigDecimal memberPrice = catalogInfor.getMemberPrice();
//        memberPrice.multiply(new BigDecimal(memberNumber));
//        BigDecimal regularPrice = catalogInfor.getRegularPrice();
//        regularPrice.multiply(new BigDecimal(regularNumber));
//        BigDecimal price = memberPrice;
//        price.add(regularPrice);
        return price.compareTo(BigDecimal.ZERO) > 0;
    }

    /**
     * Get LicenseInfo
     * LicenseInfoの取得
     * @param catalogInfor      CatalogInfor
     * @param ipaddressInfo     IpAddressInfo
     * @param licenseUseInfor    LicenseUseInfo
     * @return  LicenseInfo
     */
    private LicenseInfo getLicenseInfo(
            CatalogInfor catalogInfor,
            IpAddressInfo ipaddressInfo,
            LicenseUseInfor licenseUseInfo)
    {
        LicenseInfo licenseInfo = null;

        int projectId = ipaddressInfo.getProjectId().getSeqNo();
        int catalogId = catalogInfor.getSeqNo();
        int year = licenseUseInfo.getYear();

        String key = this.getLicenseInfoCacheKey(projectId, catalogId, year);
        // キャッシュにあればキャッシュから取得
        if (licenseInfoCache.containsKey(key)) {
            licenseInfo = licenseInfoCache.get(key);
        // キャッシュになければDBから取得
        } else {
            licenseInfo = fileConvertBusiness
                            .findLicenseInfoByProjectIdAndCatalogIdAndYear(projectId, catalogId, year);
            licenseInfoCache.put(key, licenseInfo);
        }

        return licenseInfo;
    }

    /**
     * Get key of LicenseInfoCache
     * LicenseInfoのキャッシュのキーを取得
     * @param projectId     project_info:seq_no
     * @param catalogId     catalog_info:seq_no
     * @param year          年度
     * @return              キー
     */
    private String getLicenseInfoCacheKey(int projectId, int catalogId, int year) {
        final String SEPARATOR = ":";

        StringBuilder sb = new StringBuilder();

        sb.append(Integer.toString(projectId));
        sb.append(SEPARATOR);

        sb.append(Integer.toString(catalogId));
        sb.append(SEPARATOR);

        sb.append(Integer.toString(year));

        return sb.toString();
    }

    /**
     * Get license number
     * ライセンス申請数の取得
     * @param licenseInfo   LicenseInfo
     * @param month         月度
     * @return              ライセンス申請数
     */
    private int getLicenseNumber(LicenseInfo licenseInfo, int month) {
        switch (month) {
        case 4:
            return licenseInfo.getApr();
        case 5:
            return licenseInfo.getMay();
        case 6:
            return licenseInfo.getJun();
        case 7:
            return licenseInfo.getJul();
        case 8:
            return licenseInfo.getAug();
        case 9:
            return licenseInfo.getSep();
        case 10:
            return licenseInfo.getOct();
        case 11:
            return licenseInfo.getNov();
        case 12:
            return licenseInfo.getDec();
        case 1:
            return licenseInfo.getJan();
        case 2:
            return licenseInfo.getFeb();
        case 3:
            return licenseInfo.getMar();
        default:
            break;
        }

        return 0;
    }

}
