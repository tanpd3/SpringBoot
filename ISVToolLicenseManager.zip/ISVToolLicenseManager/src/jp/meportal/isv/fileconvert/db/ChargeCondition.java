package jp.meportal.isv.fileconvert.db;

// 【課金ルール】
// 一回の実行時間が30秒未満の場合、ライセンスを使用したとはみなしません。
// またライセンス使用の重なり時間が600秒(10分)未満の場合、同時使用とはみなしません。
// つまり、30秒未満の実行はライセンス料０円。同時に30秒以上複数本実行しても、
// 重なり時間が600秒未満ならばライセンス一回分
// (通常一本、但し一回に複数本ライセンスを要求するツールはその要求本数)の課金になります。

/**
 * 課金対象の条件を判断するためのクラス
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
public class ChargeCondition {
    /**
     * 一回の実行時間が30秒未満の場合、ライセンスを使用したとはみなしません。
     */
    public static final int USE_LICENSE_SECONDS = 30;

    /**
     * ライセンス使用の重なり時間が600秒(10分)未満の場合、同時使用とはみなしません。
     */
    public static final int SAME_TIME_USE_SECONDS = 600;

    /**
     * Judgment of using license
     * ライセンスを使用したとみなすかどうかの判定
     * @param duration  一回の実行時間[s]
     * @return  true: ライセンスを使用したとみなす / false: ライセンスを使用したとみなさない
     */
    public static boolean isLicenseUse(int duration) {
        return duration >= USE_LICENSE_SECONDS;
    }

    /**
     * Judgment of same time using
     * 同時使用とみなすかどうかの判定
     * @param overlappedDuration    重なり時間[s]
     * @return  true: 同時使用とみなす / false: 同時使用とみなさない
     */
    public static boolean isSameTimeUse(int overlappedDuration) {
        return overlappedDuration >= SAME_TIME_USE_SECONDS;
    }
}
