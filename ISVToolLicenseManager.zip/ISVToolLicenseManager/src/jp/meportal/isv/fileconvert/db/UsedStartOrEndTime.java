package jp.meportal.isv.fileconvert.db;

import java.util.Date;

import jp.meportal.isv.fileconvert.read.BeforeFileUsed;

/**
 * To get start/end time of BeoreFileUsed
 * 変換前ファイルのUsed行データの開始/終了時間を取得するクラス
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
class UsedStartOrEndTime implements Comparable<UsedStartOrEndTime> {
    /**
     * BeforeFileUsed
     */
    private BeforeFileUsed beforeFileUsed;

    /**
     * Is Start
     */
    private boolean isStart;

    /**
     * 時間(開始時間または終了時間)
     */
    private Date time;

    /**
     * Get BeforeFileUsed
     * @return  BeforeFileUsed
     */
    BeforeFileUsed getBeforeFileUsed() {
        return beforeFileUsed;
    }

    /**
     * Set BeforeFileUsed
     * @param beforeFileUsed    BeforeFileUsed
     */
    void setBeforeFileUsed(BeforeFileUsed beforeFileUsed) {
        this.beforeFileUsed = beforeFileUsed;
    }

    /**
     * Get is start
     * @return  true: start / false: end
     */
    boolean isStart() {
        return isStart;
    }

    /**
     * Set is start
     * @param isStart   true: start / false: end
     */
    void setIsStart(boolean isStart) {
        this.isStart = isStart;
    }

    /**
     * Get time
     * @return  time
     */
    Date getTime() {
        return time;
    }

    /**
     * Set time
     * @param time
     */
    void setTime(Date time) {
        this.time = time;
    }

    /**
     * Constructor
     */
    UsedStartOrEndTime() {
    }

    /**
     * Get IP address
     * IPアドレスの取得
     * @return  IPアドレス
     */
    String getIpAddress() {
        return beforeFileUsed.getIpAddress();
    }

    /**
     * CompareTo (Comparable I/F)
     */
    @Override
    public int compareTo(UsedStartOrEndTime o) {
        // まず時間で判断
        int compareTime = this.getTime().compareTo(o.getTime());
        if (compareTime != 0) {
            return compareTime;
        }

        // 時間が同じなら終了が先
        if (this.isStart() == o.isStart()) {
            return 0;
        }
        if (!this.isStart()) {
            return -1;
        }
        return 1;
    }
}
