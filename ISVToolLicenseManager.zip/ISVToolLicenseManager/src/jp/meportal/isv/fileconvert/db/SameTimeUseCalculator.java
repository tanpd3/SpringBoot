package jp.meportal.isv.fileconvert.db;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.HashMap;

//import org.apache.log4j.Logger;

import jp.meportal.isv.fileconvert.read.BeforeFileUsed;

/**
 * 同時利用本数の算出用クラス
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
public class SameTimeUseCalculator {
//    /**
//     * Logger
//     */
//    private static final Logger logger = Logger.getLogger(SameTimeUseCalculator.class);

    /**
     * Calculate same time use
     * 同時利用本数の算出
     * @param beforeFileUsedList  変換前ファイルのUsed行データ群
     * @return  同時利用本数テーブル(キー：IPアドレス、値：IPアドレスごとの同時利用本数)
     */
    public HashMap<String, Integer> calculate(ArrayList<BeforeFileUsed> beforeFileUsedList) {
        // 同時利用本数の初期化
        HashMap<String, Integer> sameTimeUseMap =
                this.initializeSameTimeUseMapByIpAddress(beforeFileUsedList);

        // 開始/終了時刻テーブル
        ArrayList<UsedStartOrEndTime> usedList =
                this.createUsedStartOrEndTimeList(beforeFileUsedList);
//        logger.info("-- obara SameTimeUseEx2Calculator.calculate() usedList:");
//        this.dumpForDebugUsedStartOrEndTimeList(usedList);

        // 同時利用本数テーブル
        ArrayList<SameTimeUse> sameTimeUseList = this.createSameTimeUseList(usedList);
//        logger.info("-- obara SameTimeUseEx2Calculator.calculate() sameTimeUseList:");
//        this.dumpForDebugSameTimeUseList(sameTimeUseList);

        // IPアドレスごとの同時利用本数
        this.setSameTimeUseMapByIpAddress(sameTimeUseMap, sameTimeUseList);
//        logger.info("-- obara SameTimeUseEx2Calculator.calculate() sameTimeUseMap:");
//        this.dumpForDebugSameTimeUseMap(sameTimeUseMap);

        return sameTimeUseMap;
    }

    /**
     * Initialize same time use map
     * 同時利用本数テーブルの初期化
     * @param beforeFileUsedList
     * @return  初期化した同時利用本数テーブル
     */
    private HashMap<String, Integer> initializeSameTimeUseMapByIpAddress(ArrayList<BeforeFileUsed> beforeFileUsedList) {
        HashMap<String, Integer> map = new HashMap<String, Integer>();

        for (BeforeFileUsed used : beforeFileUsedList) {
            String ipAddress = used.getIpAddress();
            int duration = used.getDuration();

            // 同時利用本数の初期値
            int use = 0;
            if (ChargeCondition.isLicenseUse(duration)) {
                use = 1;
            }

            // 登録済みなら大きいほうを登録
            if (map.containsKey(ipAddress)) {
                if (map.get(ipAddress) < use) {
                    map.put(ipAddress, use);
                }
            // 未登録なら同時利用本数の初期値を登録
            } else {
                map.put(ipAddress, use);
            }
        }

        return map;
    }

    /**
     * Create the list of UsedStartOrEndTime
     * UsedStartOrEndTime(Used行データの開始/終了時間)のリスト作成
     * @param beforeFileUsedList  変換前ファイルのUsed行のデータ群
     * @return  UsedStartOrEndTimeのリスト
     */
    private ArrayList<UsedStartOrEndTime> createUsedStartOrEndTimeList(
            ArrayList<BeforeFileUsed> beforeFileUsedList)
    {
        ArrayList<UsedStartOrEndTime> list = new ArrayList<UsedStartOrEndTime>();

        for (BeforeFileUsed used : beforeFileUsedList) {
            // 期間が同時利用本数とみなす秒数未満なら作成しない
            int duration = used.getDuration();
            if (!ChargeCondition.isSameTimeUse(duration)) {
                continue;
            }

            // 開始側を追加
            UsedStartOrEndTime usedStart = new UsedStartOrEndTime();
            usedStart.setBeforeFileUsed(used);
            usedStart.setIsStart(true);
            // 開始時間は同時利用本数とみなす秒数分遅らせる
            // (600秒未満のときは599秒遅らせる)
            Date startTime = used.getStartTime();
            int delay = ChargeCondition.SAME_TIME_USE_SECONDS - 1;
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(startTime);
            calendar.add(Calendar.SECOND, delay);
            usedStart.setTime(calendar.getTime());
            list.add(usedStart);

            // 終了側を追加
            UsedStartOrEndTime usedEnd = new UsedStartOrEndTime();
            usedEnd.setBeforeFileUsed(used);
            usedEnd.setIsStart(false);
            Date endTime = used.getEndTime();
            usedEnd.setTime(endTime);
            list.add(usedEnd);
        }

        // 時間でソート
        list.sort(null);

        return list;
    }

    /**
     * Create the list of SameTimeUse
     * SameTimeUse(同時利用本数)のリスト作成
     * @param usedList  UsedStartOrEndTime(Used行データの開始/終了時間)のリスト
     * @return  SameTimeUseのリスト
     */
    private ArrayList<SameTimeUse> createSameTimeUseList(ArrayList<UsedStartOrEndTime> usedList) {
        ArrayList<SameTimeUse> list = new ArrayList<SameTimeUse>();

        Date time = null;
        HashSet<BeforeFileUsed> usedSet = new HashSet<BeforeFileUsed>();

        for (UsedStartOrEndTime used : usedList) {
            // 一つ前の情報を保持
            Date prevTime = time;
            HashSet<BeforeFileUsed> prevUsedSet = new HashSet<BeforeFileUsed>(usedSet);

            time = used.getTime();

            // 開始なら追加
            BeforeFileUsed beforeFileUsed = used.getBeforeFileUsed();
            if (used.isStart()) {
                usedSet.add(beforeFileUsed);
            // 終了なら削除
            } else {
                usedSet.remove(beforeFileUsed);
            }

            // 最初の一つ目は飛ばす
            if (prevTime == null) {
                continue;
            }

            // 同じ日時なら飛ばす
            if (prevTime.equals(time)) {
                continue;
            }

            // 利用本数0のデータは作らない
            if (prevUsedSet.size() < 1) {
                continue;
            }

            // 同時利用本数を生成
            SameTimeUse sameTimeUse = new SameTimeUse();
            sameTimeUse.setStartTime(prevTime);
            sameTimeUse.setEndTime(time);
            sameTimeUse.setBeforeFileUsedSet(prevUsedSet);
            list.add(sameTimeUse);
        }

        return list;
    }

    /**
     * Create same time use map by IPAddress
     * IPアドレスごとの同時利用本数を設定します。
     * @param sameTimeUseMap    同時利用本数のリスト
     * @param sameTimeUseList   SameTimeUse(同時利用本数)のリスト
     * @return  IPアドレスごとの同時利用本数
     */
    private void setSameTimeUseMapByIpAddress(
            HashMap<String, Integer> sameTimeUseMap,
            ArrayList<SameTimeUse> sameTimeUseList)
    {
        for (SameTimeUse sameTimeUse : sameTimeUseList) {
            HashSet<BeforeFileUsed> set = sameTimeUse.getBeforeFileUsedSet();
            int use = set.size();
            for (BeforeFileUsed used : set) {
                String ipAddress = used.getIpAddress();

                // マップになければ追加
                if (!sameTimeUseMap.containsKey(ipAddress)) {
                    sameTimeUseMap.put(ipAddress, use);
                }
                // マップにある同時利用本数と比較して大きければ更新
                else if (sameTimeUseMap.get(ipAddress) < use) {
                    sameTimeUseMap.put(ipAddress, use);
                }
            }
        }
    }

//    /**
//     * Dump UsedStartOrEndTime list for debug
//     * UsedStartOrEndTimeリストのダンプ(デバッグ用)
//     * @param usedList  UsedStartOrEndTime(Used行データの開始/終了時間)のリスト
//     */
//    private void dumpForDebugUsedStartOrEndTimeList(ArrayList<UsedStartOrEndTime> usedList) {
//        SimpleDateFormat f = new SimpleDateFormat("yyyyMMddHHmmss");
//
//        StringBuffer sb = new StringBuffer();
//
//        for (UsedStartOrEndTime i : usedList) {
//            sb.append("\nIP: ");
//            sb.append(i.getIpAddress());
//            sb.append(", Time: ");
//            sb.append(f.format(i.getTime()));
//            sb.append(", IsStart: ");
//            sb.append(Boolean.toString(i.isStart()));
//        }
//
//        logger.info(sb.toString());
//    }
//
//    /**
//     * Dump SameTimeUse list for debug
//     * SameTimeUseリストのダンプ(デバッグ用)
//     * @param sameTimeUseList  SameTimeUse(同時利用本数)のリスト
//     */
//    private void dumpForDebugSameTimeUseList(ArrayList<SameTimeUse> sameTimeUseList) {
//        SimpleDateFormat f = new SimpleDateFormat("yyyyMMddHHmmss");
//
//        StringBuffer sb = new StringBuffer();
//
//        for (SameTimeUse i : sameTimeUseList) {
//            sb.append("\nstart-end: ");
//            sb.append(f.format(i.getStartTime()));
//            sb.append("-");
//            sb.append(f.format(i.getEndTime()));
//
//            HashSet<BeforeFileUsed> set = i.getBeforeFileUsedSet();
//            sb.append(", UsedSet (");
//            sb.append(set.size());
//            sb.append("):");
//            for (BeforeFileUsed j : set) {
//                sb.append("\n\tIP: ");
//                sb.append(j.getIpAddress());
//                sb.append(", start-end: ");
//                sb.append(f.format(j.getStartTime()));
//                sb.append("-");
//                sb.append(f.format(j.getEndTime()));
//            }
//        }
//
//        logger.info(sb.toString());
//    }
//
//    /**
//     * Dump same time use by IP address
//     * @param sameTimeUseMap    same time use by IP address
//     */
//    private void dumpForDebugSameTimeUseMap(HashMap<String, Integer> sameTimeUseMap) {
//        StringBuffer sb = new StringBuffer();
//
//        for (Entry<String, Integer> entry : sameTimeUseMap.entrySet()) {
//            sb.append("\n");
//            sb.append(entry.getKey());
//            sb.append(" : ");
//            sb.append(entry.getValue().toString());
//        }
//
//        logger.info(sb.toString());
//    }
}
