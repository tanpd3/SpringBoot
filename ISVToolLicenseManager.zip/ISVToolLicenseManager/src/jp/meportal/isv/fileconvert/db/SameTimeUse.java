package jp.meportal.isv.fileconvert.db;

import java.util.Date;
import java.util.HashSet;

import jp.meportal.isv.fileconvert.read.BeforeFileUsed;

/**
 * SameTimeUse
 * 同時利用本数を表すクラス
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
class SameTimeUse {
    /**
     * 開始時間
     */
    private Date startTime;

    /**
     * 終了時間
     */
    private Date endTime;

    /**
     * この同時利用を構成するBeforeFileUsed群
     */
    private HashSet<BeforeFileUsed> beforeFileUsedSet;

    /**
     * Get start time
     * @return  Start time
     */
    Date getStartTime() {
        return startTime;
    }

    /**
     * Set StartTime
     * @param startTime Start time
     */
    void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    /**
     * Get end time
     * @return  End time
     */
    Date getEndTime() {
        return endTime;
    }

    /**
     * Set end time
     * @param endTime   End time
     */
    void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    /**
     * Get BeforeFileUsed set
     * @return  BeforeFileUsed set
     */
    HashSet<BeforeFileUsed> getBeforeFileUsedSet() {
        return beforeFileUsedSet;
    }

    /**
     * Set BeforeFileUsed set
     * @param beforeFileUsedSet BeforeFileUsed set
     */
    void setBeforeFileUsedSet(HashSet<BeforeFileUsed> beforeFileUsedSet) {
        this.beforeFileUsedSet = beforeFileUsedSet;
    }

    /**
     * Constructor
     */
    public SameTimeUse() {
    }

    /**
     * Get duration[秒]
     * 期間(秒)の取得
     * @return  duration[秒]
     */
    int getDuration() {
        long startMilliSec = this.getStartTime().getTime();
        long endMilliSec = this.getEndTime().getTime();

        long diff = (endMilliSec - startMilliSec) / 1000;
        return (int)diff;
    }
}
