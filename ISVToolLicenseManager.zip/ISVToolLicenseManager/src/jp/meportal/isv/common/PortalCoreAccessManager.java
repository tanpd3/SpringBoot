package jp.meportal.isv.common;

import java.io.IOException;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.me.JSONException;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import jp.meportal.isv.entity.DepartmentEntity;
import jp.meportal.isv.model.MemberJsonDto;
import jp.meportal.isv.model.CommonJsonObject;
import jp.meportal.isv.model.PortalURL;
import jp.meportal.isv.model.UserInfoJsonObject.UserInfoData;

public class PortalCoreAccessManager implements Serializable  {

    private static final long serialVersionUID = 1L;
    protected transient Logger logger = Logger.getLogger(this.getClass());

    private PortalURL pInfo = null;
    private transient HttpClient client = null;

    /**
     * PortalCoreAccessManager
     * @throws Exception
     **/
    public PortalCoreAccessManager() throws ConfigurationException {
        pInfo = new PortalURL();
        client = getCommonClient();
    }

    /**
     * getRequestToTokenId
     * @param request
     * @return String
     */
    public String getRequestToTokenId(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        return getTokenIdByCookies(cookies);
    }

    /**
     * getCommonClient
     * @return HttpClient
     */
    private HttpClient getCommonClient() {
        HttpClient client = new DefaultHttpClient();
        HttpParams params = client.getParams();

        HttpConnectionParams.setConnectionTimeout(params, 10 * 1000);

        HttpConnectionParams.setSoTimeout(params, 10 * 1000);

        return client;
    }

    /**
     * setCommonHeader
     * @param method
     * @param params
     */
    private void setCommonHeader(HttpEntityEnclosingRequestBase method, ArrayList<NameValuePair> params)
            throws UnsupportedEncodingException {
        method.setHeader("Accept-Charset", "utf-8");
        method.setHeader("Accept-Language", "ja");
        if (params != null) {
            method.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
        }
    }

    /**
     * isTokenValid
     * @param tokenId
     * @return boolean
     */
    public boolean isTokenValid(String tokenId)
            throws ConfigurationException, JSONException, ParseException, IOException {
        HttpPost post = new HttpPost(pInfo.getTokenValidPortalURL());// url
        ArrayList<NameValuePair> params = new ArrayList<NameValuePair>();// parameter
        params.add(new BasicNameValuePair("tokenid", tokenId));
        this.setCommonHeader(post, params);
        HttpResponse response = client.execute(post);
        int sc = response.getStatusLine().getStatusCode();
        if (HttpServletResponse.SC_OK != sc) {
            return false;
        }
        Gson gson = new Gson();
        CommonJsonObject jo = gson.fromJson(EntityUtils.toString(response.getEntity()), CommonJsonObject.class);
        if (!Boolean.TRUE.equals(Boolean.valueOf(jo.getResult()))) {
            return false;
        }
        return true;
    }

    /**
     * getTokenIdByCookies
     * @param cookies
     * @return String
     */
    private String getTokenIdByCookies(Cookie[] cookies) {
        String tokenId = null;
        if (cookies == null) {
            return null;
        }
        String cookieName = pInfo.getOpenAMCookieName();
        for (Cookie cookie : cookies) {
            if (cookieName.equals(cookie.getName())) {
                tokenId = cookie.getValue();
            }
        }
        return tokenId;
    }

    /**
     * ���[�U���擾API���p���\�b�h.
     * @param tokenID getRequestToTokenId�Ŏ擾�����g�[�N��ID
     * @throws ConfigurationException
     * @throws ClientProtocolException
     * @throws IOException
     * @throws URISyntaxException
     */
    public UserInfoData getUserInfo(String tokenID)
            throws ConfigurationException, ClientProtocolException, IOException, URISyntaxException {
        // url
        HttpPost post = new HttpPost(pInfo.getUserInfoURL());

        // parameter
        ArrayList<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("tokenid", tokenID));

        this.setCommonHeader(post, params);

        HttpResponse response = client.execute(post);
        int sc = response.getStatusLine().getStatusCode();

        if (HttpServletResponse.SC_OK != sc) {
            return null;
        }

        Gson gson = new Gson();

        String jsonStr = EntityUtils.toString(response.getEntity());
        logger.debug(jsonStr);

        UserInfoData jo = gson.fromJson(jsonStr, UserInfoData.class);

        return jo;
    }

    /**
     * getListCompany
     * @param companyCode
     * @param subMeportal
     * @return companyList
     * @throws Exception
     */
    public List<DepartmentEntity> getListComPany(String companyCode, boolean subMeportal) throws Exception {
        String url = null;
        if (subMeportal) {
            url = pInfo.getSubCompanyInfo();
        } else {
            url = pInfo.getCompanyInfo();
        }

        List<DepartmentEntity> dataObj = null;
        ArrayList<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("companyCode", companyCode));

        String paramString = URLEncodedUtils.format(params, "utf-8");

        if (!url.endsWith("?")) {
            url += "?";
        }
        // add paramString to url
        url += paramString;

        HttpGet get = new HttpGet(url);

        HttpResponse response = getCommonClient().execute(get);
        int sc = response.getStatusLine().getStatusCode();

        if (HttpServletResponse.SC_OK != sc) {
            return null;
        }
        Gson gson = new Gson();

        String jsonStr = EntityUtils.toString(response.getEntity());

        CommonJsonObject jo = gson.fromJson(jsonStr, CommonJsonObject.class);

        if (jo.getData() != null) {
            Type listtype = new TypeToken<List<DepartmentEntity>>() {
            }.getType();

            dataObj = gson.fromJson(jo.getData(), listtype);

        }
        return dataObj;
    }

    /**
     * getMembersList
     * @param emailUserLogin
     * @param addEmail
     * @param companyCode
     * @param departmentCode
     * @return path
     * @throws Exception 
     */
    public List<MemberJsonDto> getMembersList(String emailUserLogin, String addEmail, String companyCode, String departmentCode) throws Exception {
        HttpPost post = new HttpPost(pInfo.getMembersList());//url
        List<MemberJsonDto> dataObj = null;
        ArrayList<NameValuePair> params = new ArrayList<NameValuePair>();//parameter
        params.add(new BasicNameValuePair("emailUserLogin", emailUserLogin));
        params.add(new BasicNameValuePair("addEmail", addEmail));
        params.add(new BasicNameValuePair("companyCode", companyCode));
        params.add(new BasicNameValuePair("departmentCode", departmentCode));
        this.setCommonHeader(post, params);
        HttpResponse response = getCommonClient().execute(post);
        int sc = response.getStatusLine().getStatusCode();
        if (HttpServletResponse.SC_OK != sc) {
            return null;
        }
        /*JSONで解析*/
        Gson gson = new Gson();
        
        String jsonStr = EntityUtils.toString(response.getEntity());

        CommonJsonObject jo = gson.fromJson(jsonStr, CommonJsonObject.class);
        if (jo.getData() != null) {
            Type typeList = new TypeToken<List<MemberJsonDto>>(){}.getType();
            dataObj = gson.fromJson(jo.getData(), typeList);
        }
        return dataObj;
    }

    /**
     * getMembersListById
     * @param emailList
     * @return List<MemberJsonDto>
     * @throws Exception
     */
    public List<MemberJsonDto> getMembersListById(List<String> emailList) throws Exception {
        HttpPost post = new HttpPost(pInfo.getMembersListById());//url
        List<MemberJsonDto> dataObj = null;
        ArrayList<NameValuePair> params = new ArrayList<NameValuePair>();//parameter
        for(String email: emailList){
            params.add(new BasicNameValuePair("emailList", email));
        }
        this.setCommonHeader(post, params);
        HttpResponse response = getCommonClient().execute(post);
        int sc = response.getStatusLine().getStatusCode();
        
        if (HttpServletResponse.SC_OK != sc) {
            return null;
        }
        /*JSONで解析*/
        Gson gson = new Gson();
        
        String jsonStr = EntityUtils.toString(response.getEntity());

        CommonJsonObject jo = gson.fromJson(jsonStr, CommonJsonObject.class);
        if (jo.getData() != null) {
            Type typeList = new TypeToken<List<MemberJsonDto>>(){}.getType();
            dataObj = gson.fromJson(jo.getData(), typeList);
        }
        return dataObj;
    }
}