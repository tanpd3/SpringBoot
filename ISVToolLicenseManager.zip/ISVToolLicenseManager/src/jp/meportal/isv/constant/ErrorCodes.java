﻿package jp.meportal.isv.constant;

public interface ErrorCodes {

    public static final String ERRORS_CODE_IN_VALID_USER = "ログインユーザが無効です。";
    public static final String ERRORS_CODE_INVALID_PROJECT_NAME = "プロジェクト名が無効です。";
    public static final String ERRORS_CODE_PROJECT_NOT_EXIST = "プロジェクトは存在しません。";
    public static final String ERRORS_CODE_LICENSE_CAN_NOT_RIGISTER = "現在ライセンス申請中の為、申請できません。";
    public static final String ERRORS_CODE_LICENSE_CAN_NOT_RIGISTER_NOT_DATA_CHANGE = "カタログにデータがありません。";
    public static final String ERRORS_CODE_IN_VALID_SUPPORT_DB = "ログインユーザがDBのsupportに登録できません。";
    public static final String ERRORS_CODE_REG_PRO_FORM_IS_NULL = "プロジェクト登録フォームは、nullまたは空であってはいけません。";
    public static final String ERRORS_CODE_CAN_NOT_APPROVE = "プロジェクトが承認できません。";
    public static final String ERRORS_CODE_CAN_NOT_REJECT = "プロジェクトが却下できません。";
    public static final String ERRORS_CODE_CAN_NOT_PERMISSION_REJECT_LICENSE = "ライセンス却下の権限がありません。";
    public static final String ERRORS_CODE_EMAIL_INVALID = "メールが無効です。";
    public static final String ERRORS_CODE_HAVE_NOT_PERMISSION_UPDATE = "You have not permission to update for this member: ";
    public static final String ERRORS_CODE_HAVE_NOT_PERMISSION_DELETE = "You have not permission to delete for this member: ";
    public static final String ERRORS_CODE_CATALOG_NOT_EXIST = "カタログ情報が存在しません ";
    public static final String ERRORS_CODE_EMAIL_NOT_FOUND = "ユーザーが見つかりません。. 指定メールアドレスが誤っているか、アカウントが無いようです。";
}
