package jp.meportal.isv.constant;

public interface Constants {

    public static final String SESSION_LOGIN_USER = "SESSION_LOGIN_USER";
    public static final String PROPERETIES_MESSAGE_PATH = "message.properties";
    public static final String PROPERETIES_CSV_PATH = "csvExport.properties";
    public static final String PROPERETIES_FILE_CONFIG = "filePath.properties";
    public static final String PROPERETIES_DIRSERVICEKEY = "directorySerPath";
    public static final String PROPERETIES_ENVKEY = "envPath";
    public static final String PROPERETIES_CONFIG_TIME_PATH = "configTime.properties";
    
    public static final String START_HOURS_CONFIG = "startHours";
    public static final String START_MINUTES_CONFIG = "startMinutes";
    public static final String START_SECONDS_CONFIG = "startSeconds";
    public static final String END_HOURS_CONFIG = "endHours";
    public static final String END_MINUTES_CONFIG = "endMinutes";
    public static final String END_SECONDS_CONFIG = "endSeconds";
    
    public static final String START_HOURS_CONFIG_EXPORT_CSV = "startHoursExportCSV";
    public static final String END_HOURS_CONFIG_EXPORT_CSV = "endHoursExportCSV";
    public static final String DAY_CONFIG_EXPORT_CSV = "dayExportCSV";
    
    public static final String PROPERETIES_SERVER = "/home/tomcat/portal/ISVToolLicenseManager/serversetting.properties";
    public static final String PROPERETIES_HIBERNATE_PATH = "/home/tomcat/portal/ISVToolLicenseManager/hibernate.properties";
    public static final String PROPERETIES_EMAIL_PATH = "/home/tomcat/portal/ISVToolLicenseManager/mailSetting.properties";
    
    public static final String ZERO = "0";
    public static final String DASH_CHARACTERS = "-";
    public static final String DASH_UNDER = "_";
    public static final String SlASH_CHARACTERS = "/";
    public static final String NONE = "";

    public static final int UN_APPROVED_STATUS = 0;
    public static final int APPROVED_STATUS = 1;
    public static final int REJECTED_STATUS = 2;
    public static final int DELETED_STATUS = 3;

    public static final String REQUEST_APPROVE = "承認をお願いします。";
    public static final String APPROVED = "承認しました。";
    public static final String UPDATED = "変更しました。";
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String DATE_FORMAT_UPDATE = "yyyy/MM/dd";
    public static final String DATE_TIME_FORMAT = "yyyy/MM/dd HH:mm:ss";
    public static final String YEAR_FORMAT = "%Year%";
    public static final String DATE_AFTER_7 = "%Date%";
    public static final String DATE_AFTER_8 = "%Date+1%";
    public static final String DATE_AFTER_7_CHAR = " (木)";
    public static final String DATE_AFTER_8_CHAR = " (金)";

    // define user role
    public static final int MANAGER_FALSE = 0;
    public static final int MANAGER_TRUE = 2;

    public static final int ISV_MEMBER = 0;// member
    public static final int ISV_OTHER_MANAGER = 1;// other manager
    public static final int ISV_MANAGER = 2;// manager
    public static final int ISV_SUPPORTER = 3;// supporter

    // permissonRole user login
    public static final int REGISTER_FAIL = 0;// member not permisson change project
    public static final int REGISTER_WARNING = 1;// manager can change project
    public static final int REGISTER_SUCCESS = 2;// member register success
    
    public static int MAIL_FLAG_TRUE = 1;
    // Flag load Ip address
    public static int IP_FLAG_FIRST = 0;
    public static int IP_FLAG_SECOND = 1;
    
    public static final String REGISTER_PROJECT_SUBJECT = "【ISVツール管理システム】プロジェクト申請";
    public static final String UPDATE_PROJECT_SUBJECT = "プロジェクト承認依頼";
    public static final String APPROVE_PROJECT_SUBJECT = "プロジェクト承認完了";
<<<<<<< .mine
    
    // mail License
    public static final String REGISTER_LICENSE_SUBJECT = "ライセンス申請";
    
||||||| .r13147

=======
    public static final String REJECT_PROJECT_SUBJECT = "プロジェクト申請却下";
    public static final String REGISTER_LICENSE_SUBJECT = "ライセンス申請・更新承認依頼";
    public static final String APPROVE_LICENSE_SUBJECT = "ライセンス申請承認完了通知";
    public static final String REJECT_LICENSE_SUBJECT = "ライセンス申請却下通知";

>>>>>>> .r22123
    public static final String STATUS_PROJECT_ON = "1";
    public static final String STATUS_PROJECT_OFF = "0";

    public static final String MANAGER_ACTION_INSERT_MEMBER = "insert";
    public static final String MANAGER_ACTION_UPDATE_MEMBER = "update";
    public static final String MANAGER_ACTION_DELETE_MEMBER = "delete";

    public static final String HEADER_TEMPLATE = "\n＊＊＊＊本メールはISVツール管理システムからの自動配信メールです＊＊＊＊\n\n" ;
    public static final String HEADER_TEMPLATE_APPROVE_PROJECT = "[DEPARTMENTNAME] [MANAGER_NAME]様\n";
    public static final String FOOTER_TEMPLATE_APPROVE_PROJECT = "URL: [TOP]";
    public static final String CONTENT_TEMPLATE_APPROVE_PROJECT = "[MANAGER_NAME]様からのプロジェクト申請・更新依頼が承認されました。\n"
            + "\nプロジェクト名：[PROJECT_NAME]\n" + "管理者名：[MANAGER_NAME]\n" + "負担コード：[LOAD_ORIGIN_CODE]\n"
            + "コストコード : [COST_CODE]\n" + "コメント: [COMMENT] \n";

    // Template Reject Project
    public static final String HEADER_TEMPLATE_REJECT_PROJECT = "[DEPARTMENTNAME] [MANAGER_NAME]様\n";
    public static final String FOOTER_TEMPLATE_REJECT_PROJECT = "URL: [TOP]";
    public static final String CONTENT_TEMPLATE_REJECT_PROJECT = "[MANAGER_NAME]様からのプロジェクト申請・更新依頼が却下されました。\n"
            + "\nプロジェクト名：[PROJECT_NAME]\n" + "管理者名：[MANAGER_NAME]\n" + "負担コード：[LOAD_ORIGIN_CODE]\n"
            + "コストコード : [COST_CODE]\n" + "コメント: [COMMENT] \n";
    
    public static final String HEADER_TEMPLATE_REGISTER_PROJECT = "ISVツール管理者様\n";
    public static final String FOOTER_TEMPLATE_REGISTER_PROJECT = "URL: [TOP]";
    public static final String CONTENT_TEMPLATE_REGISTER_PROJECT = "[DEPARTMENTNAME] [USER_NAME]様からプロジェクトの申請・更新依頼がありました。\n"
            + "プロジェクトの承認処理をお願いします。\n" + "\nプロジェクト名： [PROJECT_NAME]\n" + "管理者名： [MANAGER_NAME]\n" + "所属：FATEC 開発プラ\n"
            + "所属コード: [USER_BELONG_DEPARTMENT_CD]\n" + "負担コード： [LOAD_ORIGIN_CODE]\n" + "コストコード : [COST_CODE]\n"
            + "製番: [PRODUCT_NUMBER]\n" + "コメント: [COMMENT]\n"
            + "\n承認をお願いします\n";
    //Template register or update License
    public static final String HEADER_TEMPLATE_REGISTER_LICENSE = "ISVツール管理者様\n";
    public static final String FOOTER_TEMPLATE_REGISTER_LICENSE = "URL: [TOP]";
    public static final String CONTENT_TEMPLATE_REGISTER_LICENSE = "[DEPARTMENTNAME] [USER_NAME]様からライセンスの申請・更新の承認依頼がありました。\n"
            + "承認をお願いします。\n";
    
  //Template Approved or reject License
    public static final String HEADER_TEMPLATE_APPROVED_REJECT_LICENSE = "[DEPARTMENTNAME] [USER_NAME]様\n";
    public static final String FOOTER_TEMPLATE_APPROVED_REJECT_LICENSE = "URL: [TOP]";
    public static final String CONTENT_TEMPLATE_REJECT_LICENSE = "[DEPARTMENTNAME] [USER_NAME]様からライセンスの申請・更新依頼が却下されました。\n"
            + "却下理由： [COMMENT]\n";
    public static final String CONTENT_TEMPLATE_APPROVED_LICENSE = "[DEPARTMENTNAME] [USER_NAME]様からライセンスの申請・更新依頼が承認されました。\n";

    
    // header Lincense
    public static final String HEADER_TEMPLATE_REGISTER_LICENSE = "ISVツール管理者様\n";
    public static final String FOOTER_TEMPLATE_REGISTER_LICENSE = "URL: [TOP]";
    public static final String CONTENT_TEMPLATE_REGISTER_LICENSE = "[USER_NAME] [DEPARTMENTNAME] ライセンス申請者 様からライセンスの申請依頼がありました。\n"
                                                                    + "承認をお願いします。\n";
    
    // show pop up flag
    public static final int SHOW = 1;
    public static final int HIDDEN = 0;

    public static final String EMAIL_F5 = "F5";
    public static final String EMAIL_INVALID = "指定メールアドレスが誤っているか、アカウントが無いようです。<br>";
    public static final String CHECK_EMAIL_EXIST_ERROR = "メールは既にこのプロジェクトのために登録済です。";
    public static final String EMAIL_INSERT_ERROR = "このプロジェクトにメンバーを追加できませんでした。";
    public static final String EMAIL_UPDATE_ERROR = "メンバーの更新に失敗しました。";
    public static final String UPDATE_MEMBER_ERROR = "更新するメンバーを選択してください。 <br/>";
    public static final String DELETE_MEMBER_ERROR = "削除するメンバーを選択してください。 <br/>";
    public static final String USER_NOT_FOUND = "ユーザーが見つかりません。. 指定メールアドレスが誤っているか、アカウントが無いようです。<br/>";
    public static final String COMPANY_NOT_FOUND = "company code, none of the above department code DB, being designated";
    public static final String LICENSE_USE_INFOR_NOT_DATA = "データが存在しません。";
    
    public static final String STATUS_BUTTON_TRUE = "true";
    public static final String STATUS_BUTTON_FALSE = "false";

    public static final boolean LOAD_FIRST_FLAG = true;

    // #22604 T.Obara@tsr 2017.09.13 add start --
    public static final String UTF_8 = "UTF8";
    // #22604 T.Obara@tsr 2017.09.13 add end --

    public static final String DASH = "-";

    public static final String DASH_BRACKET = "[-]";
    
    public static final String DOT_SPLIT = "[.]";

    public static final String DOT = ".";

    public static final String COMMA = ",";
    
    public static final String DOT_COMMA = ";";
    
    public static final String COLON_STAR = "*";

    // #22604 T.Obara@tsr 2017.09.13 add start --
    //define exists file
    public static final String FILE_EXISTS = "YES";
    public static final String FILE_NOT_EXISTS = "NO";
    //end define exists file
    //define command
    public static final String COMMAND_ECHO_YES_NO = "echo 'YES' || echo 'NO'";//message yes or no
    public static final String COMMAND_MKDIR_IF_EXISTS = "mkdir -p ";//make directory if directory exits
    public static final String COMMAND_RM = "rm -frd ";//delete file
    public static final String COMMAND_MV = "mv -f ";//move file
    public static final String COMMAND_CP = "cp -p ";//copy file
    // #22604 T.Obara@tsr 2017.09.13 add end --

    // Linux/FlexLM config
    public static final String VAR_PROJECT_NAME = "%project_name%";
    public static final String VAR_SEQ_NO = "%seq_no%";
    public static final String VAR_IP_ADDRESS = "%ip_address%";
    public static final String CONFIG_HEADER = "# Group:<%project_name%> ID:<%seq_no%>";
    public static final String CONFIG_IP = "INCLUDEALL INTERNET %ip_address%";
    public static final String REGEX_LINUX_PATH = "^(\\/[\\w^ ]+)+\\/?([\\w.])+[^.]$";
    
    // No have license unapproved or approved
    public static final int NO_LICENSE = 0;

    // Message License Usage Status
    public static final String ALL_PROJECT = "全て";
    public static final String IS_CHANGE_TRUE = "(*2)";
    public static final String MONTH_NEXT_YEAR = "1,2,3";
    public static final String YEAR_NAME = "年度";
    public static final String MONTH_NAME = "月度";

    public static final String NAME_CATALOG_EMPTY = "---";
    public static final int NO_VALUE = 0;
    
    //Phase 5 Start
    public static final String CSV_EXPORT_NAME_SUPPORTER = "ISVToolLicenseManager_accounting_";
    public static final String CSV_EXPORT_NAME_DETAIL = "isvtool_detail_";
    public static final String CSV_EXPORT_NAME_SUMARY = "svtool_summary_";
    
    public static final String DATE_TIME_CSV_FORMAT_SUPORTER = "yyyyMMddHHmmss";
    public static final String DATE_FORMAT_CSV = "yyyyMMdd";
    public static final String DATE_TIME_FORMAT_CSV ="yyyyMMdd_HHmmss";
    public static final String TIME_FORMAT_CSV = "HHmmss";
    public static final Character COMMA_CHAR = ',';
    public static final String LINE_SEPARATOR = "\n";
    //Phase 5 End
}