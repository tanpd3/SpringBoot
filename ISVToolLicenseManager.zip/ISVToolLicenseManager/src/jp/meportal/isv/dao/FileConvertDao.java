package jp.meportal.isv.dao;

import jp.meportal.isv.entity.IpAddressInfo;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.LicenseUseInfor;
import jp.meportal.isv.entity.ServerInfo;

/**
 * FileConvertDao(Interface)
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
public interface FileConvertDao {

    /**
     * Find ServerInfo by sequential number
     * @param seqNo Sequential number
     * @return  ServerInfo(or null)
     */
    public ServerInfo findServerInfoBySeqNo(int seqNo);

    /**
     * Find IpAddressInfo by IPAddress
     * @param ipaddress IPAddress
     * @return  IpAddressInfo(or null)
     */
    public IpAddressInfo findIpAddressInfoByIpAddress(String ipaddress);

    /**
     * Find LicenseInfo by projectId, catalogId and year
     * @param projectId     projectId
     * @param catalogId     catalogId
     * @param year          year
     * @return  LicenseInfo(or null)
     */
    public LicenseInfo findLicenseInfoByProjectIdAndCatalogIdAndYear(int projectId, int catalogId, int year);

    /**
     * Find LicenseUseInfor
     * @param ipAddressId   IP address id
     * @param catalogId     Catalog id
     * @param year          Year
     * @param month         Month
     * @param account       Account
     * @param host          Host
     * @return  LicenseUseInfor(or null)
     */
    public LicenseUseInfor findLicenseUseInfor(
            int ipAddressId,
            int catalogId,
            int year,
            int month,
            String account,
            String host);

    /**
     * Insert or Update LicenseUseInfor
     * @param info  LicenseUseInfor
     * @return true: 正常終了 / false: 異常終了
     */
    public boolean insertOrUpdateLicenseUseInfor(LicenseUseInfor info);

}
