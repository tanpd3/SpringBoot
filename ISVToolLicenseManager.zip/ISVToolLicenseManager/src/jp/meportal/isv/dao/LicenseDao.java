package jp.meportal.isv.dao;

import java.util.List;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.IpAddressInfo;
import jp.meportal.isv.entity.LicenseInfo;

public interface LicenseDao {
<<<<<<< .mine
    public List<LicenseFormBean> listAllLicenseInfoByCatalogIdAndProjectID(int projectID);
    
||||||| .r13147
	
	public List<CatalogInfor> listAllCatalogInfo();
	
    public List<LicenseFormBean> listAllLicenseInfoByCatalogIdAndProjectID(int projectID);
    
=======

    /**
     * listAllCatalogInfo
     * 
     * @return List<CatalogInfor>
     **/
    public List<CatalogInfor> listAllCatalogInfo();

    /**
     * findLicensebyCatalogIdandProjectId
     * 
     * @return List<LicenseInfo>
     **/
>>>>>>> .r22123
    public List<LicenseInfo> findLicensebyCatalogIdandProjectId(int projectId, int catalogId, int year);
    
<<<<<<< .mine
    public List<CatalogInfor> listCatalogInforByProjectID(int projectID);
    
||||||| .r13147
=======
    /**
     * listLicenseInfo
     * 
     * @return List<LicenseInfo>
     **/
>>>>>>> .r22123
    public List<LicenseInfo> listLicenseInfo(int catalogId, int projectID, int monthNow, int yearNow);
    
    /**
     * insertOrUpdateLicense
     * 
     * @return LicenseInfo
     **/
    public LicenseInfo insertOrUpdateLicense(LicenseInfo licenseInfo, int projectId);
    
    /**
     * findCatalogInforBySeqNo
     * 
     * @return CatalogInfor
     **/
    public CatalogInfor findCatalogInforBySeqNo(int seqNo);

    /**
     * listAllIpBySeqNo
     * 
     * @return List<IpAddressInfo>
     **/
    public List<IpAddressInfo> listAllIpBySeqNo(int projectId);

    /**
     * deleteIPAddress
     * 
     * @return boolean
     **/
    public boolean deleteIPAddress(IpAddressInfo ipAddressDB);

    /**
     * insertAfterDeleteIpAdd
     * 
     * @return boolean
     **/
    public boolean insertAfterDeleteIpAdd(IpAddressInfo toDelete, List<IpAddressInfo> toInsertList);

    /**
     * insertIPAddress
     * 
     * @return boolean
     **/
    public boolean insertIPAddress(IpAddressInfo info);
<<<<<<< .mine
||||||| .r13147

	
=======

    /**
     * listIpAddressByStatus
     * 
     * @return List<IpAddressInfo>
     **/
    public List<IpAddressInfo> listIpAddressByStatus(int projectId, int status);

    /**
     * listAllLicenseInfoByProjectIdAndStatus
     * 
     * @return List<LicenseInfo>
     **/
    public List<LicenseInfo> listAllLicenseInfoByProjectIdAndStatus(int projectId, int status);
    
    /**
     * listAllLicenseInfoByProjectId
     * 
     * @return List<LicenseInfo>
     **/
    public List<LicenseInfo> listAllLicenseInfoByProjectId(int projectId);

    /**
     * listAllIpAddressByProjectId
     * 
     * @return List<IpAddressInfo>
     **/
    public List<IpAddressInfo> listAllIpAddressByProjectId(int projectId);

    /**
     * getLicenseInfoById
     * 
     * @return List<LicenseInfo>
     **/
    public List<LicenseInfo> getLicenseInfoById(int projectId, int catalogid);

    /**
     * getIpAddressUnApproved
     * 
     * @return List<IpAddressInfo>
     **/
    public List<IpAddressInfo> getIpAddressUnApproved(int projectId, int statusUnApp, int statusDel);

    /**
     * findIpAddressInfoByIP
     * 
     * @return IpAddressInfo
     **/
    public IpAddressInfo findIpAddressInfoByIP(int projectId, String ipInsert);
>>>>>>> .r22123
}
