package jp.meportal.isv.dao.impl;

import java.io.Serializable;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import jp.meportal.isv.dao.FileConvertDao;
import jp.meportal.isv.entity.IpAddressInfo;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.LicenseUseInfor;
import jp.meportal.isv.entity.ServerInfo;
import jp.meportal.isv.util.HibernateUtil;
import jp.meportal.isv.util.IpAddressUtils;

/**
 * FileConvertDao(Impl)
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
public class FileConvertDaoImpl extends HibernateUtil implements FileConvertDao, Serializable{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    /**
     * Logger
     */
    private static final Logger log = Logger.getLogger(FileConvertDaoImpl.class);

    /**
     * Constructor
     **/
    public FileConvertDaoImpl() {}

    /**
     * Find ServerInfo by sequential number
     * @param seqNo Sequential number
     * @return  ServerInfo(or null)
     */
    @Override
    public ServerInfo findServerInfoBySeqNo(int seqNo) {
        ServerInfo serverInfo = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from ServerInfo where seqNo=:seqNo");
            query.setParameter("seqNo", seqNo);
            query.setMaxResults(1);
            serverInfo = (ServerInfo)query.uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return serverInfo;
    }

    /**
     * Find IpAddressInfo by IPAddress
     * @param ipaddress IPAddress
     * @return  IpAddressInfo(or null)
     */
    @SuppressWarnings("unchecked")
    @Override
    public IpAddressInfo findIpAddressInfoByIpAddress(String ipaddress) {
        List<IpAddressInfo> listIpAddress = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("FROM IpAddressInfo ip WHERE ip.status = 1");
            listIpAddress = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }

        if (listIpAddress == null) {
            return null;
        }

        for (IpAddressInfo ip : listIpAddress) {
            if (IpAddressUtils.matchesIpAddress(ip.getIpaddress(), ipaddress)) {
                return ip;
            }
        }

        return null;
    }

    /**
     * Find LicenseInfo by projectId, catalogId and year
     * @param projectId     projectId
     * @param catalogId     catalogId
     * @param year          year
     * @return  LicenseInfo(or null)
     */
    @Override
    public LicenseInfo findLicenseInfoByProjectIdAndCatalogIdAndYear(int projectId, int catalogId, int year) {
        LicenseInfo licenseInfo = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from LicenseInfo as lic where lic.projectId.seqNo=:projectId AND lic.catalogId.seqNo=:catalogId AND lic.year=:year AND lic.status = 1");
            query.setParameter("projectId", projectId);
            query.setParameter("catalogId", catalogId);
            query.setParameter("year", year);
            query.setMaxResults(1);
            licenseInfo = (LicenseInfo)query.uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return licenseInfo;
    }

    /**
     * Find LicenseUseInfor
     * @param ipAddressId   IP address id
     * @param catalogId     Catalog id
     * @param year          Year
     * @param month         Month
     * @param account       Account
     * @param host          Host
     * @return  LicenseUseInfor(or null)
     */
    @Override
    public LicenseUseInfor findLicenseUseInfor(
            int ipAddressId,
            int catalogId,
            int year,
            int month,
            String account,
            String host)
    {
        LicenseUseInfor licenseUseInfo = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from LicenseUseInfor as lic where" +
                                              " lic.ipaddressId.seqNo=:ipAddressId AND" +
                                              " lic.catalogId.seqNo=:catalogId AND" +
                                              " lic.year=:year AND" +
                                              " lic.month=:month AND" +
                                              " lic.account=:account AND" +
                                              " lic.host=:host");
            query.setParameter("ipAddressId", ipAddressId);
            query.setParameter("catalogId", catalogId);
            query.setParameter("year", year);
            query.setParameter("month", month);
            query.setParameter("account", account);
            query.setParameter("host", host);
            query.setMaxResults(1);
            licenseUseInfo = (LicenseUseInfor)query.uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return licenseUseInfo;
    }

    /**
     * Insert or Update LicenseUseInfor
     * LicenseUseInfoのInsert or Update
     * @param info  LicenseUseInfo
     * @return true: 正常終了 / false: 異常終了
     */
    @Override
    public boolean insertOrUpdateLicenseUseInfor(LicenseUseInfor info) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        Boolean result = false;
        try {
            tx = session.beginTransaction();
            session.saveOrUpdate(info);
            tx.commit();
            result = true;
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            tx.rollback();
        }
        return result;
    }
}
