﻿package jp.meportal.isv.dao.impl;

import java.io.Serializable;
import java.util.List;

import jp.meportal.isv.dao.ManagerLicenseDao;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.LicenseUseInfor;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ServerInfo;
import jp.meportal.isv.formbean.LicenseRegisterBean;
import jp.meportal.isv.formbean.LicenseUsageDetailForDBFormBean;
import jp.meportal.isv.formbean.LicenseUsedBean;
import jp.meportal.isv.util.HibernateUtil;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.hibernate.transform.Transformers;

public class ManagerLicenseDaoImpl implements ManagerLicenseDao, Serializable {

    private static final long serialVersionUID = 1L;
    private static final Logger log = Logger.getLogger(ManagerLicenseDaoImpl.class);
    
    /**
     * getServerInforList
     * 
     * @return List<ServerInfo>
     **/
    @SuppressWarnings("unchecked")
    public List<ServerInfo> getServerInforList(){
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        List<ServerInfo> serverInforList = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("FROM ServerInfo ORDER BY seqNo ASC");
            serverInforList = query.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return serverInforList;
    }
    
    /**
     * getLicenseListByProject
     * 
     * @return List<LicenseInfo>
     **/
    @SuppressWarnings("unchecked")
    public List<LicenseInfo> getLicenseListByProject(Project project){
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        List<LicenseInfo> licenseInforList = null;
        int projectId = 0;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            projectId = project.getSeqNo();
            Query query = session.createQuery("FROM LicenseInfo as ls WHERE ls.projectId.seqNo=:projectId");
            query.setParameter("projectId", projectId);
            licenseInforList = query.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return licenseInforList;
    }
    
    /**
     * getIpAddressInfoList
     * 
     * @return List<IpAddressInfo>
     **/
    @SuppressWarnings("unchecked")
    public List<Integer> getIpAddressInfoListByProject(Project project){
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        List<Integer> addressInfosList = null;
        int projectId = 0;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            projectId = project.getSeqNo();
            Query query = session.createSQLQuery("SELECT ip.seq_no FROM ipaddress_info as ip "
                    + "WHERE ip.project_id=:projectId");
            query.setParameter("projectId", projectId);
            addressInfosList = query.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return addressInfosList;
    }
    
    /**
     * getListIpAddressByProjectId
     * 
     * @return List<IpAddressInfo>
     **/
    @SuppressWarnings("unchecked")
    public List<Integer> getListIpAddressByProjectId(int projectId, int year){
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        List<Integer> addressInfosList = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createSQLQuery("SELECT ip.seq_no FROM ipaddress_info as ip "
                    + "WHERE ip.project_id=:projectId AND ip.status=1 AND SUBSTRING(date_updated, 1, 4)=:year");
            query.setParameter("projectId", projectId);
            query.setParameter("year", year);
            addressInfosList = query.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return addressInfosList;
    }
    
    /**
     * getLicenseUsedInforApr
     * 
     * @return List<LicenseUsedBean>
     **/
    @SuppressWarnings("unchecked")
    public List<LicenseUsedBean> getLicenseUseInfor(int year, int month){
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        List<LicenseUsedBean> licenseUsedBeansList = null;
        try {
            Transaction tx = null;
            tx = session.beginTransaction();
            Query query = session.createSQLQuery("SELECT lsf.seq_no AS licenseUseInfoId, lsf.ipaddress_id AS ipAddressId,ca.seq_no As CatalogId, lsf.same_time_use_number AS usedSumPerMonth," 
                    + " ca.member_price AS memberPrice, ca.regular_price AS regularPrice, ca.vendor_name AS venderName,"
                    + " ca.tool_name AS toolName, ca.future_name AS futureName"
                    + " FROM license_use_info AS lsf, catalog_info As ca"
                    + " WHERE lsf.catalog_id = ca.seq_no"
                    + " AND lsf.year=:year And lsf.month=:month").setResultTransformer(Transformers.aliasToBean(LicenseUsedBean.class));
            query.setParameter("year", year);
            query.setParameter("month", month);
            licenseUsedBeansList = query.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return licenseUsedBeansList;
    }
    
    /**
     * getLicenseRegisterInforApr
     * 
     * @return List<LicenseRegisterBean>
     **/
    @SuppressWarnings("unchecked")
    public List<LicenseRegisterBean> getLicenseRegisInfor(List<Integer> listPro, int year, String month){
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        List<LicenseRegisterBean> licenseRegisterBeansList = null;
        try {
            Transaction tx = null;
            tx = session.beginTransaction();
            String values = StringUtils.join(listPro,",");
            Query query = session.createSQLQuery("SELECT ls.seq_no AS licenseRegisId, ls.project_id AS projectId, ca.seq_no AS CatalogId,"+month+" AS registerSumPerMonth,"
                    + " ca.member_price AS memberPrice, ca.regular_price AS regularPrice, ca.vendor_name AS venderName,"
                    + " ca.tool_name AS toolName, ca.future_name AS futureName, pi.project_name AS projectName, pi.product_number AS productNumber, pi.load_origin_code AS loadOriginCode"
                    + " FROM license_info AS ls, catalog_info As ca, project_info As pi"
                    + " WHERE ls.catalog_id = ca.seq_no AND ls.project_id IN("+values+") AND ls.project_id = pi.seq_no"
                    + " AND ls.year=:year").setResultTransformer(Transformers.aliasToBean(LicenseRegisterBean.class));
            query.setParameter("year", year);
            licenseRegisterBeansList = query.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return licenseRegisterBeansList;
    }
    
    /**
     * getListYears
     * 
     * @return List<Integer>
     **/
    @SuppressWarnings("unchecked")
    public List<Integer> getListYears() {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        List<Integer> listYears = null;
        try {
            Transaction tx = null;
            tx = session.beginTransaction();
            Query query = session.createQuery("SELECT DISTINCT year FROM LicenseUseInfor ORDER BY year DESC");
            listYears = query.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return listYears;
    }

    /**
     * getLicenUseInfor
     * 
     * @return List<LicenseUseInfor>
     **/
    @SuppressWarnings("unchecked")
    public List<LicenseUseInfor> getLicenUseInfor() {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        List<LicenseUseInfor> listlicenseUseInfor = null;
        try {
            Transaction tx = null;
            tx = session.beginTransaction();
            Query query = session.createQuery("FROM LicenseUseInfor ORDER BY year DESC");
            listlicenseUseInfor = query.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return listlicenseUseInfor;
    }

    /**
     * getLicenseUsageDetailForDBList
     * 
     * @return List<LicenseUsageDetailForDBFormBean>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<LicenseUsageDetailForDBFormBean> getLicenseUsageDetailForDBList(List<Integer> ipAddList, List<Integer> idCatalogList, int yearDB,
            String monthSelect) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<LicenseUsageDetailForDBFormBean> licenseUsageDetailList = null;
        try {
            tx = session.beginTransaction();
            // convert List to String
            String strIpAddList = StringUtils.join(ipAddList, ",");
            String strIdCatalogList = StringUtils.join(idCatalogList, ",");

            String sql = "SELECT lu.account, ct.vendor_name vendorName, ct.tool_name toolName, ct.future_name futureName,lu.host host, lu.run_time_without_few runTimeWithoutFew"
                    + ", lu.run_number_without_few runNumberWithoutFew, lu.same_time_use_number sameTimeUseNumber,lu.is_charge isCharge"
                    + " FROM license_use_info lu"
                    + " INNER JOIN catalog_info ct ON lu.catalog_id = ct.seq_no"
                    + " INNER JOIN ipaddress_info ip ON lu.ipaddress_id = ip.seq_no"
                    + " WHERE lu.catalog_id IN ("+strIdCatalogList+") AND lu.ipaddress_id IN ("+strIpAddList+")"
                    + " AND lu.year = "+yearDB+" AND lu.month = "+monthSelect+"";
            Query q = session.createSQLQuery(sql).setResultTransformer(Transformers.aliasToBean(LicenseUsageDetailForDBFormBean.class));

            licenseUsageDetailList = q.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return licenseUsageDetailList;
    }
}
