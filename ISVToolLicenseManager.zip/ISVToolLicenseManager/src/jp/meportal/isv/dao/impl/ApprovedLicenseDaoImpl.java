package jp.meportal.isv.dao.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jp.meportal.isv.action.BaseAction;
import jp.meportal.isv.dao.ApprovedLicenseDao;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.IpAddressInfo;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ServerInfo;
import jp.meportal.isv.formbean.ProjectLicenseFromBean;
import jp.meportal.isv.util.HibernateUtil;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.hibernate.transform.Transformers;

public class ApprovedLicenseDaoImpl implements ApprovedLicenseDao, Serializable {
    private static final long serialVersionUID = 1L;
    private static final Logger log = Logger.getLogger(BaseAction.class);
    
    /**
     * ApprovedLicenseDaoImpl
     * 
     **/
    public ApprovedLicenseDaoImpl () {}

    /**
     * rejectLicense
     * 
     * @return boolean
     **/
    public boolean rejectLicense(List<Integer> listProId, List<LicenseInfo> licenseInfosList) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        boolean flag = false;
        if (licenseInfosList != null) {
            try {
                tx = session.beginTransaction();
                for (LicenseInfo LicenseInfo : licenseInfosList) {
                    if (!StringUtils.isEmpty(LicenseInfo.getDateApproved())) {
                        try {
                            Query q = session.createSQLQuery("UPDATE license_info as li SET li.status= 1,"
                                            + " li.Apr_updated= IF(li.Apr_updated is not null,null,null),"
                                            + " li.May_updated= IF(li.May_updated is not null,null,null),"
                                            + " li.Jun_updated= IF(li.Jun_updated is not null,null,null),"
                                            + " li.Jul_updated= IF(li.Jul_updated is not null,null,null),"
                                            + " li.Aug_updated= IF(li.Aug_updated is not null,null,null),"
                                            + " li.Sep_updated= IF(li.Sep_updated is not null,null,null),"
                                            + " li.Oct_updated= IF(li.Oct_updated is not null,null,null),"
                                            + " li.Nov_updated= IF(li.Nov_updated is not null,null,null),"
                                            + " li.Dec_updated= IF(li.Dec_updated is not null,null,null),"
                                            + " li.Jan_updated= IF(li.Jan_updated is not null,null,null),"
                                            + " li.Feb_updated= IF(li.Feb_updated is not null,null,null),"
                                            + " li.Mar_updated= IF(li.Mar_updated is not null,null,null)"
                                            + " WHERE li.approval_dated is not null AND li.project_id IN(:listProId)").addEntity(LicenseInfo.class);
                            q.setParameterList("listProId", listProId);
                            q.executeUpdate();
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    } else {
                        try {
                            Query q = session.createSQLQuery("UPDATE license_info as li SET li.status= 2,"
                                    + " li.Apr_updated= IF(li.Apr_updated is null,null,null),"
                                    + " li.May_updated= IF(li.May_updated is null,null,null),"
                                    + " li.Jun_updated= IF(li.Jun_updated is null,null,null),"
                                    + " li.Jul_updated= IF(li.Jul_updated is null,null,null),"
                                    + " li.Aug_updated= IF(li.Aug_updated is null,null,null),"
                                    + " li.Sep_updated= IF(li.Sep_updated is null,null,null),"
                                    + " li.Oct_updated= IF(li.Oct_updated is null,null,null),"
                                    + " li.Nov_updated= IF(li.Nov_updated is null,null,null),"
                                    + " li.Dec_updated= IF(li.Dec_updated is null,null,null),"
                                    + " li.Jan_updated= IF(li.Jan_updated is null,null,null),"
                                    + " li.Feb_updated= IF(li.Feb_updated is null,null,null),"
                                    + " li.Mar_updated= IF(li.Mar_updated is null,null,null)"
                                    + " WHERE li.approval_dated is null AND li.project_id IN(:listProId)").addEntity(LicenseInfo.class);
                            q.setParameterList("listProId", listProId);
                            q.executeUpdate();
                        } catch (Exception e) {
                            log.error(e.getMessage(), e);
                        }
                    }
                }
                tx.commit();
                flag = true;
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }

        }
        return flag;
    }
    
    /**
     * rejectIpAddressLicense
     * 
     * @return boolean
     **/
    public boolean rejectIpAddressLicense(List<Integer> listProId) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        boolean flag = false;
        try {
            tx = session.beginTransaction();
            Query q = session
                    .createQuery("Update IpAddressInfo as ip SET ip.status=2 WHERE (ip.status = 0 OR ip.status = 3) AND ip.projectId.seqNo IN(:listProId)");
            q.setParameterList("listProId", listProId);
            q.executeUpdate();
            tx.commit();
            flag = true;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return flag;
    }

    /**
     * licenseByStatusList
     * 
     * @return List<ProjectLicenseFromBean>
     **/
    @SuppressWarnings("unchecked")
    public List<ProjectLicenseFromBean> licenseByStatusList(String statusList, int status, int statusDel) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<ProjectLicenseFromBean> projectLicenseList = new ArrayList<ProjectLicenseFromBean>();
        try {
            tx = session.beginTransaction();
            // get list license info have status in 0 or 1
            StringBuilder sqlBuilder = new StringBuilder();
            sqlBuilder.append("SELECT * FROM (SELECT pj.seq_no as seqNo, pj.project_name as projectName, pj.comment")
                      .append(", pm.email as mailRegister")
                      .append(", IF(li.update_dated is NULL, li.date_created, li.update_dated) as dateRegister");
            if (status == 1) {
                sqlBuilder.append(", pj.approval_dated, sp.name as nameApprover");
            }
            sqlBuilder.append(" FROM project_info pj, project_member_info pm, license_info li");
            if (status == 1) {
                sqlBuilder.append(", support sp");
            }
            sqlBuilder.append(" WHERE li.project_id = pj.seq_no AND pj.update = pm.seq_no AND li.status IN ("+statusList+")")
                      .append(" AND pj.status = 1");
            if (status == 0) {
                sqlBuilder.append(" AND pj.approval_dated is NULL AND pj.approver is NULL");
            }
            if (status == 1) {
                sqlBuilder.append(" AND pj.approval_dated is NOT NULL AND pj.approver is NOT NULL AND pj.approver = sp.seq_no");
            }
            sqlBuilder.append(" GROUP BY li.project_id HAVING min(li.status) = :status")
                      .append(" union")
                      // get list ipAddress info have status in 0 or 1
                      .append(" SELECT pj.seq_no as seqNo, pj.project_name as projectName, pj.comment")
                      .append(", pm.email as mailRegister, ip.date_updated as dateRegister");
            if (status == 1) {
                sqlBuilder.append(", pj.approval_dated, sp.name as nameApprover");
            }
            sqlBuilder.append(" FROM project_info pj, project_member_info pm, ipaddress_info ip, license_info li");
            if (status == 1) {
                sqlBuilder.append(", support sp");
            }
            sqlBuilder.append(" WHERE ip.project_id = pj.seq_no AND pj.update = pm.seq_no AND ip.status IN ("+statusList+")")
                      .append(" AND pj.status = 1");
            if (status == 0) {
                sqlBuilder.append(" AND pj.approval_dated is NULL AND pj.approver is NULL AND (ip.status =:status OR ip.status =:statusDel)")
                          .append(" GROUP BY ip.project_id");
            }
            if (status == 1) {
                sqlBuilder.append(" AND pj.approval_dated is NOT NULL AND pj.approver is NOT NULL")
                          .append(" AND pj.approver = sp.seq_no")
                          .append(" GROUP BY ip.project_id HAVING min(ip.status) =:status");
            }
            sqlBuilder.append(") as projectLicense GROUP BY projectName");

            Query q = session.createSQLQuery (sqlBuilder.toString())
                    .setResultTransformer(Transformers.aliasToBean(ProjectLicenseFromBean.class));
            q.setParameter("status", status);
            if (status == 0) {
                q.setParameter("statusDel", statusDel);
            }
            projectLicenseList = q.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return projectLicenseList;
    }
    
    /**
     * getServerInfoBySeqNo
     * 
     * @return ServerInfo
     **/
    public ServerInfo getServerInfoBySeqNo(int seqNo) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        ServerInfo result = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("FROM ServerInfo sr WHERE sr.seqNo =:seqNo");
            q.setParameter("seqNo", seqNo);
            result = (ServerInfo) q.uniqueResult();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }

    /**
     * approvedLicense
     * 
     * @return boolean
     **/
    @Override
    public boolean approvedLicense(String projectIdList, String dateApproved, int status) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        boolean flagUpdate = false;
        String sqlUpdateLicense = "UPDATE license_info as li"
                // set licenseUpdate to normal
                + " SET li.status=1, li.approval_dated =:dateApproved,"
                + " li.apr= IF(li.Apr_updated is null,0,li.Apr_updated),"
                + " li.may= IF(li.May_updated is null,0,li.May_updated),"
                + " li.jun= IF(li.Jun_updated is null,0,li.Jun_updated),"
                + " li.jul= IF(li.Jul_updated is null,0,li.Jul_updated),"
                + " li.aug= IF(li.Aug_updated is null,0,li.Aug_updated),"
                + " li.sep= IF(li.Sep_updated is null,0,li.Sep_updated),"
                + " li.oct= IF(li.Oct_updated is null,0,li.Oct_updated),"
                + " li.nov= IF(li.Nov_updated is null,0,li.Nov_updated),"
                + " li.dec= IF(li.Dec_updated is null,0,li.Dec_updated),"
                + " li.jan= IF(li.Jan_updated is null,0,li.Jan_updated),"
                + " li.feb= IF(li.Feb_updated is null,0,li.Feb_updated),"
                + " li.mar= IF(li.Mar_updated is null,0,li.Mar_updated),"
                // set LicenseUpdated to null
                + " li.Apr_updated= null, li.May_updated= null, li.Jun_updated= null, li.Jul_updated= null, "
                + " li.Aug_updated= null, li.Sep_updated= null, li.Oct_updated= null, li.Nov_updated= null, "
                + " li.Dec_updated= null, li.Jan_updated= null, li.Feb_updated= null, li.Mar_updated= null "
                + " WHERE li.project_Id IN(" + projectIdList + ") AND li.status=:status";
        try {
            tx = session.beginTransaction();
            SQLQuery qLicense = session.createSQLQuery(sqlUpdateLicense).addEntity(LicenseInfo.class);
            qLicense.setParameter("dateApproved", dateApproved);
            qLicense.setParameter("status", status);
            qLicense.executeUpdate();
            tx.commit();
            flagUpdate = true;
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            log.error(e.getMessage(), e);
        }
        return flagUpdate;
    }

    /**
     * approvedIpAddress
     * 
     * @return boolean
     **/
    @Override
    public boolean approvedIpAddress(String projectIdList, int status) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        boolean flagIpAdd = false;
        try {
            tx = session.beginTransaction();
            Query q = session.createSQLQuery("UPDATE ipaddress_info ip"
                    + " SET ip.status ="
                    + " CASE ip.status"
                    + " WHEN 0 THEN 1"
                    + " WHEN 1 THEN 1"
                    + " WHEN 2 THEN 2"
                    + " ELSE 4 END"
                    + " WHERE ip.project_id IN ("+ projectIdList +")")
                    .addEntity(IpAddressInfo.class);
            q.executeUpdate();
            tx.commit();
            flagIpAdd = true;
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            log.error(e.getMessage(), e);
        }
        return flagIpAdd;
    }

    /**
     * updateProjectLicense
     * 
     * @return boolean
     **/
    @Override
    public boolean updateProjectLicense(int approverId, String projectIdList, String dateApproved, String comment) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        boolean flag = false;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("UPDATE Project pj SET approver =:approverId, dateApproved =:dateApproved, comment =:comment"
                            + " WHERE pj.seqNo IN (" + projectIdList + ")");
            q.setParameter("approverId", approverId);
            q.setParameter("dateApproved", dateApproved);
            q.setParameter("comment", comment);
            q.executeUpdate();
            tx.commit();
            flag = true;
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            log.error(e.getMessage(), e);
        }
        return flag;
    }

    /**
     * getMailUpdaterById
     * 
     * @return mail Updater
     **/
    @Override
    public String getMailUpdaterById(int projectId) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        String mailUpdater = StringUtils.EMPTY;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("SELECT mb.email FROM Member mb, Project pj WHERE pj.seqNo =? AND mb.seqNo = pj.update");
            q.setParameter(0, projectId);
            mailUpdater = (String) q.uniqueResult();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return mailUpdater;
    }
    
    /**
     * findLicenseInforByListProId
     * 
     * @return List<LicenseInfo>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<LicenseInfo> findLicenseInforByListProId(List<Integer> listProId) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<LicenseInfo> licenseInfosList = null;
        try {
            tx = session.beginTransaction();
            Query query = session
                    .createQuery(" FROM LicenseInfo as ls WHERE ls.status=0 AND ls.projectId.seqNo IN(:listProId)");
            query.setParameterList("listProId", listProId);
            licenseInfosList = query.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return licenseInfosList;
    }

    /**
     * getAllIpAddressById
     * 
     * @return List<String>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<String> getAllIpAddressById(int projectId, int status) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<String> ipAddressList = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("SELECT ip.ipaddress FROM IpAddressInfo ip WHERE ip.projectId.seqNo =:projectId "
                    + "AND ip.status =:status");
            q.setParameter("projectId", projectId);
            q.setParameter("status", status);
            ipAddressList = q.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return ipAddressList;
    }

    /**
     * getCatalogApprovedList
     * 
     * @return List<CatalogInfor>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<CatalogInfor> getCatalogApprovedList(String projectIdList, String statusList) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<CatalogInfor> catalogList = null;
        try {
            tx = session.beginTransaction();
            StringBuilder sqlBuilder = new StringBuilder();
            sqlBuilder.append("SELECT * FROM catalog_info ca")
                    .append(" INNER JOIN license_info li ON ca.seq_no = li.catalog_id")
                    .append(" INNER JOIN project_info pj ON pj.seq_no = li.project_id")
                    .append(" WHERE li.status IN ("+statusList+")")
                    .append(" AND pj.seq_no IN (")
                    .append(" SELECT pj.seq_no FROM project_info pj, ipaddress_info ip")
                    .append(" WHERE pj.seq_no = ip.project_id")
                    .append(" AND pj.seq_no IN("+projectIdList+") AND (ip.status = 0 OR ip.status = 3)")
                    .append(" GROUP BY pj.seq_no) GROUP BY ca.vendor_name")
                    .append(" UNION")
                    .append(" SELECT * FROM catalog_info ca")
                    .append(" INNER JOIN license_info li ON ca.seq_no = li.catalog_id")
                    .append(" INNER JOIN project_info pj ON pj.seq_no = li.project_id")
                    .append(" WHERE li.status = 0")
                    .append(" AND pj.seq_no IN (")
                    .append(" SELECT pj.seq_no FROM project_info pj, ipaddress_info ip")
                    .append(" WHERE pj.seq_no = ip.project_id")
                    .append(" AND pj.seq_no IN("+projectIdList+")")
                    .append(" GROUP BY pj.seq_no HAVING min(ip.status) = 1) GROUP BY ca.vendor_name");

            Query q = session.createSQLQuery(sqlBuilder.toString()).addEntity(CatalogInfor.class);
            catalogList = q.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return catalogList;
    }

    /**
     * getProjectApprovedList
     * 
     * @return List<Project>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<Project> getProjectApprovedList(int catalogId, int status) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<Project> projectList = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("SELECT li.projectId FROM LicenseInfo li WHERE li.catalogId.seqNo =:catalogId"
                    + " AND li.status =:status");
            q.setParameter("catalogId", catalogId);
            q.setParameter("status", status);
            projectList = q.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return projectList;
    }

}
