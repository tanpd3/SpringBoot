package jp.meportal.isv.dao.impl;

import java.io.Serializable;
import java.util.List;
import jp.meportal.isv.action.BaseAction;
import jp.meportal.isv.dao.SupporterDao;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.Support;
import jp.meportal.isv.util.HibernateUtil;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

public class SupporterDaoImpl extends HibernateUtil implements SupporterDao, Serializable {

    private static final long serialVersionUID = 1L;
    private static final Logger log = Logger.getLogger(BaseAction.class);

    /**
     * approveProject
     * 
     * @return boolean
     **/
    @Override
    public boolean approveProject(Project project) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        boolean flagApproved = false;
        try {
            tx = session.beginTransaction();
            session.update(project);
            tx.commit();
            flagApproved = true;
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            if (tx != null)
                tx.rollback();
        }
        return flagApproved;
    }

    /**
     * rejectProject
     * 
     * @return boolean
     **/
    @Override
    public boolean rejectProject(Project project) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        boolean flagReject = false;
        try {
            tx = session.beginTransaction();
            session.update(project);
            tx.commit();
            flagReject = true;
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            if (tx != null)
                tx.rollback();
        }
        return flagReject;
    }

    /**
     * getSupportDbList
     * 
     * @return List<Support>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<Support> getSupportDbList(int mailFlag) {
        List<Support> listSupport = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from Support  where mailFlag=:mailFlag  ");
            query.setParameter("mailFlag", mailFlag);
            listSupport = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return listSupport;
    }
	
    /**
     * getListSupportByEmail
     * 
     * @return List<Support>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<Support> getListSupportByEmail(String email) {
        List<Support> listSupport = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from Support where email=:email");
            query.setParameter("email", email);
            listSupport = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return listSupport;
    }

    /**
     * getSupportDb
     * 
     * @return Support
     **/
    @Override
    public Support getSupportDb(String email) {
        Support dbSupport = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from Support where lower(email) LIKE lower(:email) ");
            query.setParameter("email", email);
            query.setMaxResults(1);
            dbSupport = (Support) query.uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return dbSupport;
    }

    /**
     * deleteProject
     * 
     * @return boolean
     **/
    @Override
    public boolean deleteProject(Project project) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        boolean flagDelete = false;
        try {
            tx = session.beginTransaction();
            session.update(project);
            tx.commit();
            flagDelete = true;
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            if (tx != null)
                tx.rollback();
        }
        return flagDelete;
    }
}
