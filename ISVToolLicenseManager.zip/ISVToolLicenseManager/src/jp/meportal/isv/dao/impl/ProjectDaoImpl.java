package jp.meportal.isv.dao.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.dao.MemberDao;
import jp.meportal.isv.dao.ProjectDao;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.Member;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ProjectBelongInfo;
import jp.meportal.isv.formbean.MemberByProjectIdFormBean;
import jp.meportal.isv.util.DateUtils;
import jp.meportal.isv.util.HibernateUtil;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

public class ProjectDaoImpl extends HibernateUtil implements ProjectDao,Serializable  {

    private static final long serialVersionUID = 1L;
    private static final Logger log = Logger.getLogger(ProjectDaoImpl.class);

    private MemberDao memberDao;
    /**
     * ProjectDaoImpl
     * 
     **/
    public ProjectDaoImpl() {}

    /**
     * findProjectByName
     * 
     * @return Project
     **/
    @Override
    public Project findProjectByName(String projectName) {
        Project dbProject = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from Project  where lower(projectName) LIKE lower(:projectName) ");
            query.setParameter("projectName", projectName);
            query.setMaxResults(1);
            dbProject = (Project) query.uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return dbProject;
    }

    /**
     * findProjectBySeqNo
     * 
     * @return Project
     **/
    @Override
    public Project findProjectBySeqNo(int seqNo) {
        Project dbProject = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from Project where seqNo=:seqNo ");
            query.setParameter("seqNo", seqNo);
            query.setMaxResults(1);
            dbProject = (Project) query.uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return dbProject;
    }

    /**
     * findProjectBelongInforBySeqNo
     * 
     * @return ProjectBelongInfo
     **/
    @Override
    public ProjectBelongInfo findProjectBelongInforBySeqNo(int seqNo) {
        ProjectBelongInfo projectBelongInfo = new ProjectBelongInfo();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from ProjectBelongInfo bl where bl.project_id.seqNo=:seqNo ");
            query.setParameter("seqNo", seqNo);
            query.setMaxResults(1);
            projectBelongInfo = (ProjectBelongInfo) query.uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return projectBelongInfo;
    }

    /**
     * insertProjectBelongInfo
     * 
     * @return ProjectBelongInfo
     **/
    @Override
    public ProjectBelongInfo insertProjectBelongInfo(ProjectBelongInfo projectBelongInfo) {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.save(projectBelongInfo);
            tx.commit();
        } catch (HibernateException e) {
            if (tx != null)
                log.error(e.getMessage(), e);
            tx.rollback();
        }
        return projectBelongInfo;
    }

    /**
     * listAllProject
     * 
     * @return List<Project>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<Project> listAllProject() {
        List<Project> listPro = new ArrayList<Project>();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from Project where status=1 ORDER BY projectName ASC");
            listPro = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return listPro;
    }

    /**
     * registerOrUpdateProject
     * 
     * @return Project
     **/
    @Override
    public Project registerOrUpdateProject(Project project, int isManager) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        memberDao = new MemberDaoImpl();
        try {
            tx = session.beginTransaction();
            session.saveOrUpdate(project);
            session.flush();
            if (project != null) {
                String link = StringUtils.EMPTY;
                String manager = StringUtils.EMPTY;
                Member member = memberDao.getMemberDb(project.getManagerEmail());
                if (member != null) {
                    String linkExisted = member.getLink();
                    if (StringUtils.isEmpty(linkExisted)) {// insert projectID to member.
                        link = String.valueOf(project.getSeqNo());
                    } else {
                        if (linkExisted.contains(String.valueOf(project.getSeqNo()))) {
                            link = linkExisted;
                        } else {
                            link = linkExisted.concat(",").concat(String.valueOf(project.getSeqNo()));
                        }
                    }
                    String managerExits = member.getIsManager();
                    if (StringUtils.isEmpty(managerExits)) {// set Manager to member.
                        manager = String.valueOf(Constants.ISV_MANAGER);
                    } else {
                        manager = managerExits.concat(",").concat(String.valueOf(Constants.ISV_MANAGER));
                    }

                } else {// insert member
                    member = new Member();
                    member.setEmail(project.getManagerEmail());
                    link = String.valueOf(project.getSeqNo());
                    manager = String.valueOf(Constants.ISV_MANAGER);
                }
                member.setLink(link);
                member.setIsManager(manager);
                session.saveOrUpdate(member);
                session.flush();
                if (member != null) {// insert projectBelongInfo
                    ProjectBelongInfo projectBelongInfo = new ProjectBelongInfo();
                    projectBelongInfo.setProject_id(project);
                    projectBelongInfo.setMember(member);
                    projectBelongInfo.setRegistrationDate(DateUtils.convertDateToString(new Date(),
                            Constants.DATE_FORMAT_UPDATE));
                    projectBelongInfo.setUpdateDate(DateUtils.convertDateToString(new Date(),
                            Constants.DATE_FORMAT_UPDATE));
                    projectBelongInfo.setStatus(Constants.APPROVED_STATUS);
                    projectBelongInfo.setIsManager(isManager);
                    session.saveOrUpdate(projectBelongInfo);
                    session.flush();
                }
                session.getTransaction().commit();
                if (!tx.wasCommitted())
                    tx.commit();
            }
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            if (tx != null) {
                tx.rollback();
            }
        } finally {
            session.close();
        }
        return project;
    }

    /**
     * updateProject
     * 
     * @return Project
     **/
    public Project updateProject(Project project, int isManager) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.saveOrUpdate(project);
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            if (tx != null) {
                tx.rollback();
            }
        }
        return project;
    }
    
    /**
     * listAllProjectByStatus
     * 
     * @return List<Project>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<Project> listAllProjectByStatus(int status) {
        List<Project> listProject = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from Project  where status=:status  ");
            query.setParameter("status", status);
            listProject = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return listProject;
    }

    /**
     * listAllProjectBelongInforByStatus
     * 
     * @return List<ProjectBelongInfo>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<ProjectBelongInfo> listAllProjectBelongInforByStatus(int status) {
        List<ProjectBelongInfo> listProject = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from ProjectBelongInfo  where status=:status  ");
            query.setParameter("status", status);
            listProject = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return listProject;
    }

    /**
     * listAllProjectByStatusAndEmail
     * 
     * @return List<ProjectBelongInfo>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<ProjectBelongInfo> listAllProjectByStatusAndEmail(String email, int status) {
        List<ProjectBelongInfo> listProject = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("select bl from ProjectBelongInfo bl  "
                    + " where bl.member.email = ? and bl.project_id.status = ? ");
            query.setParameter(0, email);
            query.setParameter(1, status);
            listProject = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return listProject;
    }
    
    /**
     * listAllProjectByEmailSupporter
     * 
     * @return List<Project>
     **/
    @SuppressWarnings("unchecked")
    public List<Project> listAllProjectByEmailSupporter() {
        List<Project> listProject = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from Project p where p.status = 1 ");
            listProject = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return listProject;
    }
    
    /**
     * listAllProjectByStatusAndEmailAndIsManager
     * 
     * @return List<Project>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<Project> listAllProjectByStatusAndEmailAndIsManager(int status, List<Integer> ListIsManager,
            int seqNoMember, String email) {
        List<Project> listProject = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session
                    .createQuery("from Project as p where p.status=?"
                            + " and (p.managerEmail=? or p.seqNo in (select distinct pbi.project_id "
                            + " from ProjectBelongInfo as pbi where pbi.member.seqNo =? and pbi.isManager in (:ListIsManager)))");
            query.setParameter(0, status);
            query.setParameter(1, email);
            query.setParameter(2, seqNoMember);
            query.setParameterList("ListIsManager", ListIsManager);
            listProject = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        } finally {
            session.close();
        }
        return listProject;
    }
    
    /**
     * listAllProjectByManager
     * 
     * @return List<Project>
     **/
    @SuppressWarnings("unchecked")
    public List<Project> listAllProjectByManager(int status, Member member, String email, boolean isSupportor) {
        List<Project> listProject = new ArrayList<Project>();
        List<Project> listProjectNoManager = new ArrayList<Project>();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
<<<<<<< .mine
        if (member.getLink() != null && member.getIsManager() != null) {
            String[] listLink = member.getLink().split(",");
            String[] listManager = member.getIsManager().split(",");
||||||| .r13147
        String memberLink = member.getLink();
        String memberIsManager = member.getIsManager();
        if (memberLink != null && memberIsManager != null) {
            String[] listLink = memberLink.split(",");
            String[] listManager = memberIsManager.split(",");
=======
        String memberLink = member.getLink();
        String memberIsManager = member.getIsManager();
        if (!StringUtils.isEmpty(memberLink) && !StringUtils.isEmpty(memberIsManager)) {
            String[] listLink = memberLink.split(",");
            String[] listManager = memberIsManager.split(",");
>>>>>>> .r22123
            StringBuilder strProjectId = new StringBuilder();
            for (int i = 0; i < listLink.length; i++) {
                int isManager = Integer.parseInt(listManager[i]);
                if (!(isManager == Constants.ISV_MEMBER)) {// member is Manager
                    if (!StringUtils.isEmpty(strProjectId.toString())) {
                        strProjectId.append(", " + listLink[i]);
                    }
                    else {
                        strProjectId.append(listLink[i]);
                    }
                }
            }
            try {
                String strQuery = StringUtils.EMPTY;
                String strQueryNoManager = StringUtils.EMPTY;
                tx = session.beginTransaction();
                strQuery = "from Project as p where p.status='" + status + "'"
                        + " and (p.managerEmail = '" + email + "' or p.seqNo in (" + strProjectId + "))";
                if (isSupportor) {
                    strQueryNoManager = " from Project as p where p.status='" + status + "'"
                        + " and (p.managerEmail != '" + email + "') and p.seqNo not in (" + strProjectId + ")";
                }
                Query query = session.createQuery(strQuery);
                listProject = query.list();
                
                if (isSupportor) {
                    Query queryNoManager = session.createQuery(strQueryNoManager);
                    listProjectNoManager = queryNoManager.list();
                    listProject.addAll(listProjectNoManager);
                }
                
                tx.commit();
            } catch (HibernateException e) {
                log.error(e.getMessage(), e);
            }
        }
        return listProject;
    }
    
    /**
     * listAllProjectByMember
     * 
     * @return List<Project>
     **/
    @SuppressWarnings("unchecked")
    public List<Project> listAllProjectByMember(int status, Member member, String email, boolean isSupportor) {
        List<Project> listProject = new ArrayList<Project>();
        List<Project> listProjectNoManager = new ArrayList<Project>();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        if (!StringUtils.isEmpty(member.getLink()) && !StringUtils.isEmpty(member.getIsManager())) {
            String[] listLink = member.getLink().split(",");
            StringBuilder strProjectId = new StringBuilder();
            for (int i = 0; i < listLink.length; i++) {// user login is member
                if (!StringUtils.isEmpty(strProjectId.toString())) {
                    strProjectId.append(", " + listLink[i]);
                }
                else {
                    strProjectId.append(listLink[i]);
                }
            }
            try {
                String strQuery = StringUtils.EMPTY;
                String strQueryNoManager = StringUtils.EMPTY;
                tx = session.beginTransaction();
                strQuery = "from Project as p where p.status='" + status + "'"
                        + " and (p.managerEmail = '" + email + "' or p.seqNo in (" + strProjectId + "))";
                if (isSupportor) {
                    strQueryNoManager = " from Project as p where p.status='" + status + "'"
                        + " and (p.managerEmail != '" + email + "') and p.seqNo not in (" + strProjectId + ")";
                }
                Query query = session.createQuery(strQuery);
                listProject = query.list();
                
                if (isSupportor) {
                    Query queryNoManager = session.createQuery(strQueryNoManager);
                    listProjectNoManager = queryNoManager.list();
                    listProject.addAll(listProjectNoManager);
                }
                
                tx.commit();
            } catch (HibernateException e) {
                log.error(e.getMessage(), e);
            }
        }
        return listProject;
    }
    
    /**
     * listMemberByProjectId
     * 
     * @return List<MemberByProjectIdFormBean>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<MemberByProjectIdFormBean> listMemberByProjectId(int seqNo) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        List<MemberByProjectIdFormBean> listMemberBySeqNo = new ArrayList<>();
        MemberByProjectIdFormBean memberBySeqNo = null;
        List<ProjectBelongInfo> listProjectBelong = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query q = session
                    .createQuery("select bl from ProjectBelongInfo bl where bl.project_id.seqNo = ? and bl.status=1");
            q.setParameter(0, seqNo);
            listProjectBelong = q.list();
            if (listProjectBelong != null) {
                for (ProjectBelongInfo belong : listProjectBelong) {
                    memberBySeqNo = new MemberByProjectIdFormBean();
                    memberBySeqNo.setProjectName(belong.getProject_id().getProjectName());
                    memberBySeqNo.setManagerName(belong.getProject_id().getManagerName());
                    memberBySeqNo.setEmail(belong.getMember().getEmail());
                    memberBySeqNo.setCreateDate(DateUtils.getDateUpdate(belong.getRegistrationDate()));
                    memberBySeqNo.setMemberId(String.valueOf(belong.getMember().getSeqNo()));
                    memberBySeqNo.setIsManager(String.valueOf(belong.getIsManager()));

                    if (memberBySeqNo.getIsManager().equals("2") || memberBySeqNo.getIsManager().equals("1")) {
                        memberBySeqNo.setCheckBoxStatus("true");
                    } else {
                        memberBySeqNo.setCheckBoxStatus("false");
                    }
                    listMemberBySeqNo.add(memberBySeqNo);
                }
            }
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return listMemberBySeqNo;
    }

    /**
     * countMember
     * 
     * @return Long
     **/
    @Override
    public Long countMember(int seqNo) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Long result = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("select count(*) from ProjectBelongInfo bl "
                    + "where bl.project_id.seqNo = ? and bl.status=1");
            q.setParameter(0, seqNo);
            result = (Long) q.uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }

    /**
     * listAllProjectByEmail
     * 
     * @return List<Project>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<Project> listAllProjectByEmail(String email, int status) {
        List<Project> listProject = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session
                    .createQuery("from Project where lower(managerEmail) LIKE lower(:email) and status=:status");
            query.setParameter("email", email);
            query.setParameter("status", status);
            listProject = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return listProject;
    }

    /**
     * getProjectBelongInfoList
     * 
     * @return List<ProjectBelongInfo>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<ProjectBelongInfo> getProjectBelongInfoList(int projectId, int status) {
        List<ProjectBelongInfo> listProjectBelongInfo = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session
                    .createQuery("from ProjectBelongInfo where  project_id.seqNo=:projectId and status=:status");
            query.setParameter("projectId", projectId);
            query.setParameter("status", status);
            listProjectBelongInfo = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return listProjectBelongInfo;
    }

    /**
     * countAllProjectByStatus
     * 
     * @return Long
     **/
    @Override
    public Long countAllProjectByStatus(int status) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Long result = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("select count(*) from Project bl where status = ?");
            q.setParameter(0, status);
            result = (Long) q.uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }

    /**
     * listAllProjectByListStatus
     * 
     * @return List<Project>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<Project> listAllProjectByListStatus(List<Integer> listStatus) {
        List<Project> listProject = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("FROM Project  WHERE status IN(:listStatus) ");
            query.setParameterList("listStatus", listStatus);
            listProject = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return listProject;
    }
}
