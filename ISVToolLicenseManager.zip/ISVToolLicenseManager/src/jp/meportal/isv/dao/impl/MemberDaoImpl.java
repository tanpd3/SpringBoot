﻿package jp.meportal.isv.dao.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.meportal.isv.action.BaseAction;
import jp.meportal.isv.business.ProjectBusiness;
import jp.meportal.isv.business.impl.ProjectBusinessImpl;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.dao.MemberDao;
import jp.meportal.isv.entity.Member;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ProjectBelongInfo;
import jp.meportal.isv.formbean.MemberByProjectIdFormBean;
import jp.meportal.isv.util.DateUtils;
import jp.meportal.isv.util.HibernateUtil;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

public class MemberDaoImpl extends HibernateUtil implements MemberDao, Serializable {

    private static final long serialVersionUID = 1L;
    private static final Logger log = Logger.getLogger(BaseAction.class);

    private ProjectBusiness projectBusiness;

    /**
     * MemberDaoImpl
     * 
     **/
    public MemberDaoImpl() {
        projectBusiness = new ProjectBusinessImpl();
    }

    /**
     * findMemberByMemberId
     * 
     * @return Member
     **/
    @Override
    public Member findMemberByMemberId(int memberId) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Member member = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("from Member as mem Where mem.seqNo =:memberId");
            q.setParameter("memberId", memberId);
            member = (Member)q.uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return member;
    }
    
    /**
     * getMembertList
     * 
     * @return List<Member>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<Member> getMembertList(Long seqNo) {

        List<Member> memberList = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from  Member where link=:seq_no ");
            query.setParameter("seq_no", seqNo);
            memberList = (List<Member>) query.list();
            tx.commit();

        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }

        return memberList;
    }

    /**
     * insertMember
     * 
     * @return Member
     **/
    @Override
    public Member insertMember(Member member) {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.save(member);
            session.flush();
            session.refresh(member);
            tx.commit();
        } catch (HibernateException e) {
            if (tx != null)
                tx.rollback();
            log.error(e.getMessage(), e);
        }
        return member;
    }

    /**
     * getMemberDb
     * 
     * @return Member
     **/
    @Override
    public Member getMemberDb(String email) {
        Member dbMember = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from Member where lower(email) LIKE lower(:email) ");
            query.setParameter("email", email);
            query.setMaxResults(1);
            dbMember = (Member) query.uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return dbMember;
    }

    /**
     * getIsManagerOfMember
     * 
     * @return int
     **/
    @Override
    public int getIsManagerOfMember(int seqNo, String email) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        int result = 0;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("select DISTINCT bl.isManager from ProjectBelongInfo bl "
                    + "where bl.project_id.seqNo = ? and bl.member.email= ? and bl.status=1");
            q.setParameter(0, seqNo);
            q.setParameter(1, email);
            if (q.uniqueResult() != null) {
                result = (int) q.uniqueResult();
            }
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }

    /**
     * insertMemberAndProjectBelongInfo
     * 
     * @return boolean
     **/
    @Override
    public boolean insertMemberAndProjectBelongInfo(Member member, ProjectBelongInfo bl) {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction trans = null;
        boolean result = false;
        try {
            trans = session.beginTransaction();
            session.save(member);
            session.save(bl);
            session.refresh(bl);
            trans.commit();
            result = true;
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            trans.rollback();
        }
        return result;
    }

    /**
     * insertMemberIntoProjectBelongInfo
     * 
     * @return boolean
     **/
    @Override
    public boolean insertMemberIntoProjectBelongInfo(ProjectBelongInfo bl) {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction trans = null;
        boolean result = false;
        try {
            trans = session.beginTransaction();
            session.save(bl);
            trans.commit();
            result = true;
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            trans.rollback();
        }
        return result;
    }

    /**
     * updateMemberIntoProjectBelongInfo
     * 
     * @return boolean
     **/
    @Override
    public boolean updateMemberIntoProjectBelongInfo(ProjectBelongInfo bl) {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction trans = null;
        boolean result = false;
        try {
            trans = session.beginTransaction();
            session.saveOrUpdate(String.valueOf(bl.getProject_id().getSeqNo()), bl);
            trans.commit();
            result = true;
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            trans.rollback();
        }
        return result;
    }

    /**
     * insertMemberIntoProjectInfor
     * 
     * @return boolean
     **/
    @Override
    public boolean insertMemberIntoProjectInfor(Project project) {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction trans = null;
        boolean result = false;
        try {
            trans = session.beginTransaction();
            session.update(project);
            session.flush();
            trans.commit();
            result = true;
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            trans.rollback();
        }
        return result;
    }

    /**
     * checkExistEmailMember
     * 
     * @return Member
     **/
    @Override
    public Member checkExistEmailMember(String email) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Member member = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("from Member where email=:email");
            q.setParameter("email", email);
            member = (Member) q.uniqueResult();
            if (q.uniqueResult() != null) {
                member = (Member) q.uniqueResult();
            }
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return member;
    }

    /**
     * checkExistMemberOfProject
     * 
     * @return ProjectBelongInfo
     **/
    @Override
    public ProjectBelongInfo checkExistMemberOfProject(int projectId, Member m) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        ProjectBelongInfo proBl = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("select bl from ProjectBelongInfo bl "
                    + "where bl.project_id.seqNo = ? and bl.member.email= ? and bl.status=1");
            q.setParameter(0, projectId);
            q.setParameter(1, m.getEmail());
            if (q.uniqueResult() != null) {
                proBl = (ProjectBelongInfo) q.uniqueResult();
            }
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return proBl;
    }

    /**
     * checkExistMemberOfProjectAndStatus
     * 
     * @return ProjectBelongInfo
     **/
    @Override
    public ProjectBelongInfo checkExistMemberOfProjectAndStatus(int projectId, Member m, int status) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        ProjectBelongInfo proBl = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("select bl from ProjectBelongInfo bl "
                    + "where bl.project_id.seqNo = ? and bl.member.email= ? and bl.status= ?");
            q.setParameter(0, projectId);
            q.setParameter(1, m.getEmail());
            q.setParameter(2, status);
            if (q.uniqueResult() != null) {
                proBl = (ProjectBelongInfo) q.uniqueResult();
            }
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return proBl;
    }

    /**
     * updateMemberAndProjectInfo
     * 
     * @return boolean
     **/
    @Override
    public boolean updateMemberAndProjectInfo(Member member, String oldLink, String newLink, ProjectBelongInfo bl,
            String oldManager, String newManager) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction trans = null;
        boolean result = false;
        try {
            trans = session.beginTransaction();
            String link = StringUtils.EMPTY;
            String isManager = StringUtils.EMPTY;
            if (oldLink.isEmpty()) {
                link = newLink;
            } else {
                link = oldLink + "," + newLink;
            }
            if (oldManager.isEmpty()) {
                isManager = newManager;
            } else {
                isManager = oldManager + "," + newManager;
            }
            member.setLink(link);
            member.setIsManager(isManager);
            session.update(member);
            trans.commit();
            result = true;
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            trans.rollback();
        }
        return result;
    }

    /**
     * getManagerEmailOfProject
     * 
     * @return MemberByProjectIdFormBean
     **/
    @SuppressWarnings("unchecked")
    @Override
    public MemberByProjectIdFormBean getManagerEmailOfProject(int seqNo) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();

        MemberByProjectIdFormBean memberBySeqNo = new MemberByProjectIdFormBean();
        List<ProjectBelongInfo> listBelong = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("select bl from ProjectBelongInfo bl "
                    + "where bl.project_id.seqNo = ? and bl.isManager=2 and bl.status=1");
            q.setParameter(0, seqNo);
            listBelong = q.list();
            if (listBelong != null) {
                for (ProjectBelongInfo belong : listBelong) {
                    memberBySeqNo = new MemberByProjectIdFormBean();
                    memberBySeqNo.setManagerName(belong.getProject_id().getManagerName());
                    memberBySeqNo.setEmail(belong.getMember().getEmail());
                }
            }
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return memberBySeqNo;
    }

    /**
     * deleteMember
     * 
     * @return boolean
     **/
    @SuppressWarnings( "unused")
    @Override
    public boolean deleteMember(String email, int seqNo, Member member) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction trans = null;
        boolean result = false;
        ProjectBelongInfo proBl = null;
        Project project = null;
        try {
            trans = session.beginTransaction();
            Query q = session.createQuery("select bl from ProjectBelongInfo bl "
                    + "where bl.project_id.seqNo=? and bl.member.email=? and status =1");
            q.setParameter(0, seqNo);
            q.setParameter(1, email);

            proBl = (ProjectBelongInfo) q.uniqueResult();

            if (proBl != null) {
                project = projectBusiness.findProjectBySeqNo(proBl.getProject_id().getSeqNo());
                String strListOther = StringUtils.EMPTY;
                String strReplace = StringUtils.EMPTY;
                String strListMember = StringUtils.EMPTY;
                String strReplaceMember = StringUtils.EMPTY;
                String strLink = StringUtils.EMPTY;
                String strLinkReplace = StringUtils.EMPTY;
                String strIsManager = StringUtils.EMPTY;
                String strIsManagerReplace = StringUtils.EMPTY;

                String memberIsManager = member.getIsManager();
                String memberLink = member.getLink();
                if (StringUtils.isEmpty(memberIsManager) || StringUtils.isEmpty(memberLink)) {
                    return false;
                }
                String[] memberIsManagerArray = null;
                String[] memberLinkArray = null;
                if (memberIsManager != null && memberIsManager.length() > 1) {
                    memberIsManagerArray = memberIsManager.split(",");
                } else if (memberIsManager != null && memberIsManager.length() == 1) {
                    memberIsManagerArray = new String[1];
                    memberIsManagerArray[0] = memberIsManager;
                }
                if (memberLink.length() > 1) {
                    memberLinkArray = memberLink.split(",");
                } else if (memberLink.length() == 1) {
                    memberLinkArray = new String[1];
                    memberLinkArray[0] = memberLink;
                }
                
                if (memberLinkArray != null && memberLinkArray.length > 0) {// update member.IsManager after deleted member in project.
                    if (memberIsManagerArray != null && memberIsManagerArray.length > 0) {
                        for (int i = 0; i < memberLinkArray.length; i++) {
                            if (memberLinkArray[i] != null) {
                                if (memberLinkArray[i].equals(String.valueOf(seqNo))) {
                                    if (memberIsManager != null && memberIsManagerArray[i] != null) {
                                        if (memberIsManager.contains(memberIsManagerArray[i] + ",")) {
                                            strIsManagerReplace = memberIsManager.replace(memberIsManagerArray[i] + ",", "");
                                        } else {
                                            strIsManagerReplace = memberIsManager.replace(memberIsManagerArray[i], "");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (strIsManagerReplace.endsWith(",")) {
                    strIsManagerReplace = strIsManagerReplace.substring(0, strIsManagerReplace.length() - 1);
                }
                member.setIsManager(strIsManagerReplace);

                if (project.getOtherManager() != null) {
                    strListOther = project.getOtherManager();
                }
                if (project.getMember() != null) {
                    strListMember = project.getMember();
                }
                if (member.getLink() != null) {
                    strLink = member.getLink();
                }

                if (member.getLink() != null) {
                    if (member.getLink().contains(String.valueOf(project.getSeqNo()))) {
                        if (strLink.contains(String.valueOf(project.getSeqNo()) + ",")) {
                            strLinkReplace = strLink.replace(String.valueOf(project.getSeqNo()) + ",", "");
                        } else {
                            strLinkReplace = strLink.replace(String.valueOf(project.getSeqNo()), "");
                        }
                        if (strLinkReplace.endsWith(",")) {
                            strLinkReplace = strLinkReplace.substring(0, strLinkReplace.length() - 1);
                        }
                        member.setLink(strLinkReplace);
                    }
                }

                if (project.getOtherManager() != null) {
                    if (project.getOtherManager().contains(String.valueOf(member.getSeqNo()))) {
                        if (strListOther.contains(String.valueOf(member.getSeqNo()) + ",")) {
                            strReplace = strListOther.replace(String.valueOf(member.getSeqNo()) + ",", "");
                        } else {
                            strReplace = strListOther.replace(String.valueOf(member.getSeqNo()), "");
                        }
                        if (strReplace.endsWith(",")) {
                            strReplace = strReplace.substring(0, strReplace.length() - 1);
                        }
                        project.setOtherManager(strReplace);
                    }
                }

                if (project.getMember() != null) {
                    if (project.getMember().contains(String.valueOf(member.getSeqNo()))) {
                        if (strListMember.contains(String.valueOf(member.getSeqNo()) + ",")) {
                            strReplaceMember = strListMember.replace(String.valueOf(member.getSeqNo()) + ",", "");
                        } else {
                            strReplaceMember = strListMember.replace(String.valueOf(member.getSeqNo()), "");
                        }
                        if (strReplaceMember.endsWith(",")) {
                            strReplaceMember = strReplaceMember.substring(0, strReplaceMember.length() - 1);
                        }
                        project.setMember(strReplaceMember);
                    }
                }

                proBl.setStatus(3);
                proBl.setIsManager(0);
                Member mm = (Member) session.merge(member);
                Object pp = session.merge(project);
                session.saveOrUpdate(String.valueOf(proBl.getSeqNo()), proBl);
                session.saveOrUpdate(String.valueOf(proBl.getSeqNo()), mm);
                session.save(pp);
                trans.commit();
                result = true;
            } else {
                trans.rollback();
            }

        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            trans.rollback();
        }
        return result;
    }

    /**
     * updatePermissionMember
     * 
     * @return boolean
     **/
    @Override
    public boolean updatePermissionMember(String email, int seqNo, int permission, Member member) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction trans = null;
        boolean result = false;
        ProjectBelongInfo proBl = null;
        Project project = null;
        String memberIsManager = member.getIsManager();
        String memberLink = member.getLink();
        String[] memberIsManagerArray = null;
        String[] memberLinkArray = null;
        if (memberIsManager != null && memberIsManager.length() > 1) {
            memberIsManagerArray = memberIsManager.split(",");
        } else if (memberIsManager != null && memberIsManager.length() == 1) {
            memberIsManagerArray = new String[1];
            memberIsManagerArray[0] = memberIsManager;
        }
        if (memberLink != null && memberLink.length() > 1) {
            memberLinkArray = memberLink.split(",");
        } else if (memberLink != null && memberLink.length() == 1) {
            memberLinkArray = new String[1];
            memberLinkArray[0] = memberLink;
        }

        project = projectBusiness.findProjectBySeqNo(seqNo);
        String strListOther = StringUtils.EMPTY;
        if (project.getOtherManager() != null) {
            strListOther = project.getOtherManager();
        }

        try {
            trans = session.beginTransaction();
            Query q = session.createQuery("select bl from ProjectBelongInfo bl "
                    + "where bl.project_id.seqNo=? and bl.member.email=? and status=1");
            q.setParameter(0, seqNo);
            q.setParameter(1, email);
            proBl = (ProjectBelongInfo) q.uniqueResult();
            project = projectBusiness.findProjectBySeqNo(seqNo);
            if (proBl != null) {
                if (permission == 0) {
                    proBl.setIsManager(1);
                    proBl.setUpdateDate(DateUtils.convertDateToString(new Date(), Constants.DATE_FORMAT_UPDATE));
                    if (strListOther != null && !strListOther.isEmpty()) {
                        if (!project.getOtherManager().contains(String.valueOf(member.getSeqNo()))) {
                            project.setOtherManager(project.getOtherManager().concat(",")
                                    .concat(String.valueOf(member.getSeqNo())));
                        }
                    } else {
                        project.setOtherManager(String.valueOf(member.getSeqNo()));
                    }
                    if (memberLinkArray != null && memberLinkArray.length > 0) {
                        if (memberIsManagerArray != null && memberIsManagerArray.length > 0) {
                            for (int i = 0; i < memberLinkArray.length; i++) {// update IsManagerMember
                                if (memberLinkArray[i] != null && memberIsManagerArray[i] != null) {
                                    if (memberLinkArray[i].equals(String.valueOf(seqNo))) {
                                        memberIsManagerArray[i] = String.valueOf(1);
                                    }
                                }
                            }
                        }
                    }
                    String memberStr = StringUtils.EMPTY;
                    if (memberIsManagerArray != null) {
                       memberStr = String.join(",", memberIsManagerArray);
                    }
                    member.setIsManager(memberStr);
                    Project pp = (Project) session.merge(project);
                    Member mm = (Member) session.merge(member);
                    session.saveOrUpdate(String.valueOf(proBl.getSeqNo()), proBl);
                    session.saveOrUpdate(String.valueOf(seqNo), mm);
                    session.saveOrUpdate(String.valueOf(seqNo), pp);
                    trans.commit();
                    result = true;

                } else if (permission == 1) {
                    proBl.setIsManager(0);
                    if (project.getOtherManager().contains(String.valueOf(member.getSeqNo()))) {
                        String strReplace = StringUtils.EMPTY;
                        if (strListOther.contains(String.valueOf(member.getSeqNo()) + ",")) {
                            strReplace = strListOther.replace(String.valueOf(member.getSeqNo()) + ",", "");
                        } else {
                            strReplace = strListOther.replace(String.valueOf(member.getSeqNo()), "");
                        }
                        if (strReplace.endsWith(",")) {
                            strReplace = strReplace.substring(0, strReplace.length() - 1);
                        }
                        project.setOtherManager(strReplace);
                    }
                    if (memberLinkArray != null && memberLinkArray.length > 0) {
                        if (memberIsManagerArray != null && memberIsManagerArray.length > 0) {
                            for (int i = 0; i < memberLinkArray.length; i++) {// update IsManagerMember
                                if (memberLinkArray[i] != null && memberIsManagerArray[i] != null) {
                                    if (memberLinkArray[i].equals(String.valueOf(seqNo))) {
                                        memberIsManagerArray[i] = String.valueOf(0);
                                    }
                                }
                            }
                        }
                    }
                    String memberStr = StringUtils.EMPTY;
                    if (memberIsManagerArray != null) {
                        memberStr = String.join(",", memberIsManagerArray);
                    }
                    member.setIsManager(memberStr);
                    Project pp = (Project) session.merge(project);
                    Member mm = (Member) session.merge(member);
                    session.saveOrUpdate(String.valueOf(proBl.getSeqNo()), proBl);
                    session.saveOrUpdate(String.valueOf(seqNo), mm);
                    session.saveOrUpdate(String.valueOf(seqNo), pp);
                    trans.commit();
                    result = true;
                } else {
                    trans.rollback();
                }
            }
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            trans.rollback();
        } finally {
            session.close();
        }
        return result;
    }

    /**
     * getOtherManagerList
     * 
     * @return List<Member>
     **/
    @SuppressWarnings("unchecked")
    public List<Member> getOtherManagerList(int projectId, String otherManagerId) {
        List<Member> otherManagerList = new ArrayList<Member>();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            SQLQuery q = session
                    .createSQLQuery("SELECT * FROM project_member_info mb WHERE (SELECT FIND_IN_SET(?, mb.Link ) > 0) AND mb.seq_no IN ("
                            + otherManagerId + ")");
            q.addEntity(Member.class);
            q.setParameter(0, projectId);
            otherManagerList = q.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return otherManagerList;
    }

    /**
     * getOtherManagerById
     * 
     * @return String
     **/
    public String getOtherManagerById(int projectId) {
        String otherManagerById = StringUtils.EMPTY;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("SELECT pj.otherManager FROM Project pj WHERE pj.seqNo = ?");
            q.setParameter(0, projectId);
            otherManagerById = (String) q.uniqueResult();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return otherManagerById;
    }

}
