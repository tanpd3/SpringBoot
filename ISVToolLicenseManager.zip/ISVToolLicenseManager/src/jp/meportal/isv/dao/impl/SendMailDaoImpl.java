package jp.meportal.isv.dao.impl;

import java.io.Serializable;
import java.util.List;
import jp.meportal.isv.dao.SendMailDao;
import jp.meportal.isv.entity.MailTemplate;
import jp.meportal.isv.util.HibernateUtil;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

public class SendMailDaoImpl implements SendMailDao, Serializable {

    private static final long serialVersionUID = 1L;
    private static final Logger log = Logger.getLogger(SendMailDaoImpl.class);
    /**
     * getMailTemplateList
     * 
     * @return List<MailTemplate>
     **/
    @SuppressWarnings("unchecked")
    public List<MailTemplate> getMailTemplateList() {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        List<MailTemplate> mailTemplateList = null;
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("FROM MailTemplate AS mt ORDER BY mt.seqNo ASC");
            mailTemplateList = query.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return mailTemplateList;
    }
}
