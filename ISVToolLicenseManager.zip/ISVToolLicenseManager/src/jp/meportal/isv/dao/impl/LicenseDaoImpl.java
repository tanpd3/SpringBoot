package jp.meportal.isv.dao.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jp.meportal.isv.action.BaseAction;
import jp.meportal.isv.dao.LicenseDao;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.IpAddressInfo;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.util.HibernateUtil;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

public class LicenseDaoImpl extends HibernateUtil implements LicenseDao, Serializable{

    private static final long serialVersionUID = 1L;
    private static final Logger log = Logger.getLogger(BaseAction.class);

    /**
     * LicenseDaoImpl
     * 
     **/
    public LicenseDaoImpl() {}

    /**
     * listAllLicenseInfoByProjectId
     * 
     * @return List<LicenseInfo>
     **/
    @SuppressWarnings("unchecked")
    public List<LicenseInfo> listAllLicenseInfoByProjectId(int projectId) {
        List<LicenseInfo> licenseInfo = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from LicenseInfo as licen where licen.projectId.seqNo=:projectId");
            query.setParameter("projectId", projectId);
            licenseInfo = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return licenseInfo;
    }
    
<<<<<<< .mine
||||||| .r13147
    
	@SuppressWarnings("unchecked")
	@Override
	public List<CatalogInfor> listAllCatalogInfo() {
		List<CatalogInfor> catalogInfor = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from CatalogInfor as cata ORDER BY cata.vendorName ASC");
            catalogInfor = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        
		return catalogInfor;
	}
	
=======
    /**
     * listAllLicenseInfoByProjectIdAndStatus
     * 
     * @return List<LicenseInfo>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<LicenseInfo> listAllLicenseInfoByProjectIdAndStatus(int projectId, int status) {
        List<LicenseInfo> licenseInfo = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session
                    .createQuery("from LicenseInfo as licen where licen.projectId.seqNo=:projectId AND licen.status=:status");
            query.setParameter("projectId", projectId);
            query.setParameter("status", status);
            licenseInfo = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return licenseInfo;
    }

    /**
     * listAllCatalogInfo
     * 
     * @return List<CatalogInfor>
     **/
	@SuppressWarnings("unchecked")
	@Override
    public List<CatalogInfor> listAllCatalogInfo() {
        List<CatalogInfor> catalogInfor = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from CatalogInfor as cata ORDER BY cata.vendorName ASC");
            catalogInfor = query.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return catalogInfor;
    }

    /**
     * findCatalogInforBySeqNo
     * 
     * @return CatalogInfor
     **/
>>>>>>> .r22123
    @Override
    public CatalogInfor findCatalogInforBySeqNo(int seqNo) {
        CatalogInfor catalogInfor = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from CatalogInfor where seqNo=:seqNo ");
            query.setParameter("seqNo", seqNo);
            query.setMaxResults(1);
            catalogInfor = (CatalogInfor) query.uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return catalogInfor;
    }

    /**
     * insertOrUpdateLicense
     * 
     * @return LicenseInfo
     **/
    @Override
    public LicenseInfo insertOrUpdateLicense(LicenseInfo licenseInfo, int projectId) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.saveOrUpdate(licenseInfo);
            tx.commit();
        } catch (HibernateException e) {
            if (tx != null)
                tx.rollback();
            log.error(e.getMessage(), e);
        }
        return licenseInfo;
    }
<<<<<<< .mine
    
    @SuppressWarnings({ "unchecked"})
    @Override
    public List<CatalogInfor> listCatalogInforByProjectID(int ProjectID){
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<CatalogInfor> listAllCatalogInfors = new ArrayList<CatalogInfor>();
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("from CatalogInfor as cata ORDER BY cata.vendorName ASC");
            listAllCatalogInfors = q.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return listAllCatalogInfors;
    }
    
//    @SuppressWarnings({ "unchecked"})
//    @Override
//    public List<LicenseInfo> listLicenseInfo(int projectId, int monthNow, int yearNow){
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        Transaction tx = null;
//        List<LicenseInfo> listLicenseInfo = new ArrayList<LicenseInfo>();
//        StringBuilder hql = new StringBuilder();
//        int yearAdd = 0;
//        if (monthNow == 3) {
//            yearAdd = yearNow + 1;
//            hql.append("from LicenseInfo as lic where lic.catalogId.seqNo in (select catalog.seqNo from CatalogInfor as catalog)"
//                 + " and lic.projectId.seqNo=:projectId and (lic.year=:year or lic.year=:yearAdd)");
//        } else {
//            hql.append("from LicenseInfo as lic where lic.catalogId.seqNo "
//                    + " in (select catalog.seqNo from CatalogInfor as catalog)"
//                    + " and lic.projectId.seqNo=:projectId and lic.year=:year");
//                }
//        try {
//            tx = session.beginTransaction();
//            Query q = session.createQuery(hql.toString());
//            if (monthNow == 3) {
//                q.setParameter("projectId", projectId);
//                q.setParameter("year", yearNow);
//                q.setParameter("yearAdd", yearAdd);
//            }
//            else {
//                q.setParameter("projectId", projectId);
//                q.setParameter("year", yearNow);
//            }
//            listLicenseInfo = q.list();
//            tx.commit();
//        } catch (HibernateException e) {
//            log.error(e.getMessage(), e);
//        }
//        return listLicenseInfo;
//    }
    
||||||| .r13147
    
//    @SuppressWarnings({ "unchecked"})
//    @Override
//    public List<LicenseInfo> listLicenseInfo(int projectId, int monthNow, int yearNow){
//        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//        Transaction tx = null;
//        List<LicenseInfo> listLicenseInfo = new ArrayList<LicenseInfo>();
//        StringBuilder hql = new StringBuilder();
//        int yearAdd = 0;
//        if (monthNow == 3) {
//            yearAdd = yearNow + 1;
//            hql.append("from LicenseInfo as lic where lic.catalogId.seqNo in (select catalog.seqNo from CatalogInfor as catalog)"
//                 + " and lic.projectId.seqNo=:projectId and (lic.year=:year or lic.year=:yearAdd)");
//        } else {
//            hql.append("from LicenseInfo as lic where lic.catalogId.seqNo "
//                    + " in (select catalog.seqNo from CatalogInfor as catalog)"
//                    + " and lic.projectId.seqNo=:projectId and lic.year=:year");
//                }
//        try {
//            tx = session.beginTransaction();
//            Query q = session.createQuery(hql.toString());
//            if (monthNow == 3) {
//                q.setParameter("projectId", projectId);
//                q.setParameter("year", yearNow);
//                q.setParameter("yearAdd", yearAdd);
//            }
//            else {
//                q.setParameter("projectId", projectId);
//                q.setParameter("year", yearNow);
//            }
//            listLicenseInfo = q.list();
//            tx.commit();
//        } catch (HibernateException e) {
//            log.error(e.getMessage(), e);
//        }
//        return listLicenseInfo;
//    }
    
=======

    /**
     * listLicenseInfo
     * 
     * @return List<LicenseInfo>
     **/
>>>>>>> .r22123
    @SuppressWarnings({ "unchecked"})
    @Override
    public List<LicenseInfo> listLicenseInfo(int catalogId, int projectId, int monthNow, int yearNow) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<LicenseInfo> listLicenseInfo = new ArrayList<LicenseInfo>();
        StringBuilder hql = new StringBuilder();
        int yearAdd = 0;
        List<Integer> listMonth = new ArrayList<Integer>();
        listMonth.add(1);
        listMonth.add(2);
        listMonth.add(3);
        if (!listMonth.contains(monthNow)) {
            yearAdd = yearNow + 1;
            hql.append("from LicenseInfo as lic where lic.catalogId.seqNo=:catalogId"
                    + " and lic.projectId.seqNo=:projectId and (lic.year=:year or lic.year=:yearAdd)");
        } else {
            yearAdd = yearNow - 1;
            hql.append("from LicenseInfo as lic where lic.catalogId.seqNo=:catalogId"
                    + " and lic.projectId.seqNo=:projectId and (lic.year=:year or lic.year=:yearAdd)");
        }
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery(hql.toString());
            q.setParameter("catalogId", catalogId);
            q.setParameter("projectId", projectId);
            q.setParameter("year", yearNow);
            q.setParameter("yearAdd", yearAdd);
            listLicenseInfo = q.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return listLicenseInfo;
    }

    /**
     * findLicensebyCatalogIdandProjectId
     * 
     * @return List<LicenseInfo>
     **/
    @SuppressWarnings("unchecked")
    public List<LicenseInfo> findLicensebyCatalogIdandProjectId(int projectId, int catalogId, int year) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<LicenseInfo> licenseInfosList = new ArrayList<LicenseInfo>();
        try {
            tx = session.beginTransaction();
            Query qc = session.createQuery("from LicenseInfo lif where lif.projectId.seqNo = ? "
                    + "and lif.catalogId.seqNo = ? and lif.year = ? ");
            qc.setParameter(0, projectId);
            qc.setParameter(1, catalogId);
            qc.setParameter(2, year);
            licenseInfosList = qc.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return licenseInfosList;
    }

    /**
     * listAllIpBySeqNo
     * 
     * @return List<IpAddressInfo>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<IpAddressInfo> listAllIpBySeqNo(int projectId) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<IpAddressInfo> IpAddList = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("FROM IpAddressInfo ip WHERE ip.projectId.seqNo = ?");
            q.setParameter(0, projectId);
            IpAddList = q.list();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return IpAddList;
    }

    /**
     * insertIPAddress
     * 
     * @return boolean
     **/
    @Override
    public boolean insertIPAddress(IpAddressInfo info) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        Boolean result = false;
        try {
            tx = session.beginTransaction();
            session.saveOrUpdate(info);
            tx.commit();
            result = true;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            tx.rollback();
        }
        return result;
    }

    /**
     * deleteIPAddress
     * 
     * @return boolean
     **/
    @Override
    public boolean deleteIPAddress(IpAddressInfo IpAddressDB) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        Boolean result = false;
        try {
            tx = session.beginTransaction();
            session.saveOrUpdate(IpAddressDB);
            tx.commit();
            result = true;
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
            tx.rollback();
        }
        return result;
    }

    /**
     * insertAfterDeleteIpAdd
     * 
     * @return boolean
     **/
    @Override
    public boolean insertAfterDeleteIpAdd(IpAddressInfo toDelete, List<IpAddressInfo> toInsertList) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        Boolean result = false;
        try {
            tx = session.beginTransaction();
            session.delete(toDelete);
            session.flush();
            for (IpAddressInfo info : toInsertList) {
                session.save(info);
                session.flush();
            }
            tx.commit();
            result = true;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            tx.rollback();
        } finally {
            session.close();
        }
        return result;
    }

    /**
     * listIpAddressByStatus
     * 
     * @return List<IpAddressInfo>
     **/
    @SuppressWarnings("unchecked")
    public List<IpAddressInfo> listIpAddressByStatus(int projectId, int status) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<IpAddressInfo> ipAddressDBList = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createQuery("FROM IpAddressInfo ip WHERE ip.projectId.seqNo = ? AND ip.status = ?");
            q.setParameter(0, projectId);
            q.setParameter(1, status);
            ipAddressDBList = q.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return ipAddressDBList;
    }

    /**
     * listAllIpAddressByProjectId
     * 
     * @return List<IpAddressInfo>
     **/
    @SuppressWarnings("unchecked")
    public List<IpAddressInfo> listAllIpAddressByProjectId(int projectId) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<IpAddressInfo> ipAddressInfosList = null;
        try {
            tx = session.beginTransaction();
            Query query = session
                    .createQuery("FROM IpAddressInfo ip WHERE ip.projectId.seqNo =:projectId AND ip.status IN(0,1) ORDER BY ip.status ASC");
            query.setParameter("projectId", projectId);
            ipAddressInfosList = query.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return ipAddressInfosList;
    }

    /**
     * getLicenseInfoById
     * 
     * @return LicenseInfo
     **/
    @Override
    public List<LicenseInfo> getLicenseInfoById(int projectId, int catalogid) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<LicenseInfo> liInfoList = null;
        try {
            tx = session.beginTransaction();
            Query q = session
                    .createQuery("FROM LicenseInfo li WHERE li.projectId.seqNo =:projectId AND li.status = 1 AND li.catalogId.seqNo =:catalogid");
            q.setParameter("projectId", projectId);
            q.setParameter("catalogid", catalogid);
            liInfoList = q.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return liInfoList;
    }

    /**
     * getIpAddressUnApproved
     * 
     * @return List<IpAddressInfo>
     **/
    @SuppressWarnings("unchecked")
    @Override
    public List<IpAddressInfo> getIpAddressUnApproved(int projectId, int statusUnApp, int statusDel) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        List<IpAddressInfo> ipAddressUnAppDBList = null;
        try {
            tx = session.beginTransaction();
            Query q = session.createSQLQuery("SELECT * FROM ipaddress_info ip"
                    + " INNER JOIN project_info pj ON ip.project_id =pj.seq_no AND ip.project_id =:projectId"
                    + " WHERE pj.approval_dated is NULL AND pj.approver is NULL AND (ip.status =:statusUnApp OR ip.status =:statusDel)"
                    + " GROUP BY ip.status")
//                    + "HAVING (min(ip.status) =:statusUnApp OR ip.status=:statusDel)")
                    .addEntity(IpAddressInfo.class);
            q.setParameter("projectId", projectId);
            q.setParameter("statusUnApp", statusUnApp);
            q.setParameter("statusDel", statusDel);
            ipAddressUnAppDBList = q.list();
            tx.commit();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return ipAddressUnAppDBList;
    }

    /**
     * findIpAddressInfoByIP
     * 
     * @return IpAddressInfo
     **/
    @Override
    public IpAddressInfo findIpAddressInfoByIP(int projectId, String ipInsert) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        Transaction tx = null;
        IpAddressInfo ipAddDB = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from IpAddressInfo ip where ip.ipaddress=:ipInsert AND ip.projectId.seqNo=:projectId");
            query.setParameter("ipInsert", ipInsert);
            query.setParameter("projectId", projectId);
            ipAddDB = (IpAddressInfo) query.uniqueResult();
            tx.commit();
        } catch (HibernateException e) {
            log.error(e.getMessage(), e);
        }
        return ipAddDB;
    }

}
