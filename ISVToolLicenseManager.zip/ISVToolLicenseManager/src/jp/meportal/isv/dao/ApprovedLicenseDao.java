package jp.meportal.isv.dao;

import java.util.List;

import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ServerInfo;
import jp.meportal.isv.formbean.ProjectLicenseFromBean;

public interface ApprovedLicenseDao {

    /**
     * licenseByStatusList
     * 
     * @return List<ProjectLicenseFromBean>
     **/
    public List<ProjectLicenseFromBean> licenseByStatusList(String statusList, int status, int statusDel);

    /**
     * rejectLicense
     * 
     * @return boolean
     **/
    public boolean rejectLicense(List<Integer> listProId, List<LicenseInfo> licenseInfosList);

    /**
     * rejectIpAddressLicense
     * 
     * @return boolean
     **/
    public boolean rejectIpAddressLicense(List<Integer> listProId);

    /**
     * getServerInfoBySeqNo
     * 
     * @return ServerInfo
     **/
	public ServerInfo getServerInfoBySeqNo(int seqNo);
	
    /**
     * approvedLicense
     * 
     * @return boolean
     **/
	public boolean approvedLicense(String projectIdList, String dateApproved, int status);

    /**
     * approvedIpAddress
     * 
     * @return boolean
     **/
	public boolean approvedIpAddress(String projectIdList, int status);

    /**
     * updateProjectLicense
     * 
     * @return boolean
     **/
    public boolean updateProjectLicense(int approverId, String projectIdList, String dateApproved, String comment);

    /**
     * getMailUpdaterById
     * 
     * @return Mail Updater
     **/
    public String getMailUpdaterById(int projectId);

    /**
     * getAllIpAddressById
     * 
     * @return List<String>
     **/
    public List<String> getAllIpAddressById(int projectId, int status);

    /**
     * getCatalogApprovedList
     * 
     * @return List<CatalogInfor>
     **/
    public List<CatalogInfor> getCatalogApprovedList(String projectIdList, String statusList);

    /**
     * getProjectApprovedList
     * 
     * @return List<Project>
     **/
    public List<Project> getProjectApprovedList(int catalogId, int status);

    /**
     * findLicenseInforByListProId
     * 
     * @return List<LicenseInfo>
     **/
    public List<LicenseInfo> findLicenseInforByListProId(List<Integer> listProId);

}
