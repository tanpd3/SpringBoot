package jp.meportal.isv.dao;

import java.util.List;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.Support;

public interface SupporterDao {

    /**
     * approveProject
     * 
     * @return boolean
     **/
    public boolean approveProject(Project project);

    /**
     * rejectProject
     * 
     * @return boolean
     **/
    public boolean rejectProject(Project project);

    /**
     * getSupportDbList
     * 
     * @return List<Support>
     **/
    public List<Support> getSupportDbList(int mailFlag);

    /**
     * getListSupportByEmail
     * 
     * @return List<Support>
     **/
    public List<Support> getListSupportByEmail(String email);

    /**
     * getSupportDb
     * 
     * @return Support
     **/
    public Support getSupportDb(String email);

    /**
     * deleteProject
     * 
     * @return boolean
     **/
    public boolean deleteProject(Project project);
}
