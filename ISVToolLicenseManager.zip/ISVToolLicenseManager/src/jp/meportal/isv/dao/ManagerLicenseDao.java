package jp.meportal.isv.dao;

import java.util.List;

import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.LicenseUseInfor;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ServerInfo;
import jp.meportal.isv.formbean.LicenseRegisterBean;
import jp.meportal.isv.formbean.LicenseUsageDetailForDBFormBean;
import jp.meportal.isv.formbean.LicenseUsedBean;

public interface ManagerLicenseDao {

    /**
     * getServerInforList
     * 
     * @return List<ServerInfo>
     **/
    public List<ServerInfo> getServerInforList();
    
    /**
     * getLicenseListByProject
     * 
     * @return List<LicenseInfo>
     **/
    public List<LicenseInfo> getLicenseListByProject(Project project);
    
    /**
     * getIpAddressInfoListByProject
     * 
     * @return List<Integer>
     **/
    public List<Integer> getIpAddressInfoListByProject(Project project);
    
    /**
     * getListIpAddressByProjectId
     * 
     * @return List<Integer>
     **/
    public List<Integer> getListIpAddressByProjectId(int projectId, int year);

    /**
     * getLicenseUseInfor
     * 
     * @return List<LicenseUsedBean>
     **/
    public List<LicenseUsedBean> getLicenseUseInfor(int year, int month);

    /**
     * getLicenseRegisInfor
     * 
     * @return List<LicenseRegisterBean>
     **/
    public List<LicenseRegisterBean> getLicenseRegisInfor(List<Integer> listPro, int year, String month);

    /**
     * getListYears
     * 
     * @return List<Integer>
     **/
    public List<Integer> getListYears();

    /**
     * getLicenUseInfor
     * 
     * @return List<LicenseUseInfor>
     **/
    public List<LicenseUseInfor> getLicenUseInfor();

    /**
     * getLicenseUsageDetailForDBList
     * 
     * @return List<LicenseUsageDetailForDBFormBean>
     **/
    public List<LicenseUsageDetailForDBFormBean> getLicenseUsageDetailForDBList(List<Integer> ipAddList, List<Integer> idCatalogList, int yearDB,
            String monthSelect);
}
