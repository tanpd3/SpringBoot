package jp.meportal.isv.dao;

import java.util.List;
import jp.meportal.isv.entity.Member;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ProjectBelongInfo;
import jp.meportal.isv.formbean.MemberByProjectIdFormBean;

public interface MemberDao {

    /**
     * getMembertList
     * 
     * @return List<Member>
     **/
    public List<Member> getMembertList(Long seqNo);

    /**
     * insertMember
     * 
     * @return Member
     **/
    public Member insertMember(Member member);

    /**
     * getMemberDb
     * 
     * @return Member
     **/
    public Member getMemberDb(String email);

    /**
     * getIsManagerOfMember
     * 
     * @return int
     **/
    public int getIsManagerOfMember(int seqNo, String email);

    /**
     * insertMemberAndProjectBelongInfo
     * 
     * @return boolean
     **/
    public boolean insertMemberAndProjectBelongInfo(Member member, ProjectBelongInfo bl);
    
    /**
     * insertMemberIntoProjectBelongInfo
     * 
     * @return boolean
     **/
    public boolean insertMemberIntoProjectBelongInfo(ProjectBelongInfo bl);
    
    /**
     * updateMemberIntoProjectBelongInfo
     * 
     * @return boolean
     **/
    public boolean updateMemberIntoProjectBelongInfo(ProjectBelongInfo bl);
    
    /**
     * insertMemberIntoProjectInfor
     * 
     * @return boolean
     **/
    public boolean insertMemberIntoProjectInfor(Project project);

    /**
     * checkExistEmailMember
     * 
     * @return Member
     **/
    public Member checkExistEmailMember(String email);

    /**
     * checkExistMemberOfProject
     * 
     * @return ProjectBelongInfo
     **/
    public ProjectBelongInfo checkExistMemberOfProject(int projectId, Member m);
    
    /**
     * checkExistMemberOfProjectAndStatus
     * 
     * @return ProjectBelongInfo
     **/
    public ProjectBelongInfo checkExistMemberOfProjectAndStatus(int projectId, Member m, int status);

    /**
     * updateMemberAndProjectInfo
     * 
     * @return boolean
     **/
    public boolean updateMemberAndProjectInfo(Member member, String oldLink, String newLink, ProjectBelongInfo bl, String oldManager, String newManager);

    /**
     * getManagerEmailOfProject
     * 
     * @return MemberByProjectIdFormBean
     **/
    public MemberByProjectIdFormBean getManagerEmailOfProject(int seqNo);

    /**
     * deleteMember
     * 
     * @return boolean
     **/
    public boolean deleteMember(String email, int seqNo, Member member);

    /**
     * updatePermissionMember
     * 
     * @return boolean
     **/
    public boolean updatePermissionMember(String email, int seqNo, int permission, Member member);

    /**
     * getOtherManagerList
     * 
     * @return List<Member>
     **/
	public List<Member> getOtherManagerList(int projectId, String otherManagerId);

    /**
     * getOtherManagerById
     * 
     * @return String
     **/
    public String getOtherManagerById(int projectId);
    
    /**
     * findMemberByMemberId
     * 
     * @return Member
     **/
    public Member findMemberByMemberId(int memberId);
}
