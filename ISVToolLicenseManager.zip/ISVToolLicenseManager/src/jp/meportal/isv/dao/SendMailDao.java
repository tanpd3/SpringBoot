package jp.meportal.isv.dao;

import java.util.List;

import jp.meportal.isv.entity.MailTemplate;

public interface SendMailDao {
    
    /**
     * getMailTemplateList
     * 
     * @return List<MailTemplate>
     **/
    public List<MailTemplate> getMailTemplateList();

}
