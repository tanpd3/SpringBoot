package jp.meportal.isv.dao;

import java.util.List;
import jp.meportal.isv.entity.Member;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ProjectBelongInfo;
import jp.meportal.isv.formbean.MemberByProjectIdFormBean;

public interface ProjectDao {

    /**
     * findProjectByName
     * 
     * @return Project
     **/
    public Project findProjectByName(String projectName);

    /**
     * findProjectBySeqNo
     * 
     * @return Project
     **/
    public Project findProjectBySeqNo(int seqNo);

    /**
     * listAllProject
     * 
     * @return List<Project>
     **/
    public List<Project> listAllProject();

    /**
     * insertProjectBelongInfo
     * 
     * @return ProjectBelongInfo
     **/
    public ProjectBelongInfo insertProjectBelongInfo(ProjectBelongInfo projectBelongInfo);

    /**
     * registerOrUpdateProject
     * 
     * @return Project
     **/
    public Project registerOrUpdateProject(Project project, int isManager);
    
    /**
     * updateProject
     * 
     * @return Project
     **/
    public Project updateProject(Project project, int isManager);

    /**
     * listAllProjectByStatus
     * 
     * @return List<Project>
     **/
    public List<Project> listAllProjectByStatus(int status);

    /**
     * listAllProjectBelongInforByStatus
     * 
     * @return List<ProjectBelongInfo>
     **/
    public List<ProjectBelongInfo> listAllProjectBelongInforByStatus(int status);

    /**
     * listMemberByProjectId
     * 
     * @return List<MemberByProjectIdFormBean>
     **/
    public List<MemberByProjectIdFormBean> listMemberByProjectId(int status);

    /**
     * countMember
     * 
     * @return Long
     **/
    public Long countMember(int seqNo);

    /**
     * listAllProjectByEmail
     * 
     * @return List<Project>
     **/
    public List<Project> listAllProjectByEmail(String email, int status);

    /**
     * getProjectBelongInfoList
     * 
     * @return List<ProjectBelongInfo>
     **/
    public List<ProjectBelongInfo> getProjectBelongInfoList(int projectId, int status);

    /**
     * findProjectBelongInforBySeqNo
     * 
     * @return ProjectBelongInfo
     **/
    public ProjectBelongInfo findProjectBelongInforBySeqNo(int seqNo);

    /**
     * countAllProjectByStatus
     * 
     * @return Long
     **/
    public Long countAllProjectByStatus(int status);

    /**
     * listAllProjectByListStatus
     * 
     * @return List<Project>
     **/
    public List<Project> listAllProjectByListStatus(List<Integer> listStatus);

    /**
     * listAllProjectByStatusAndEmail
     * 
     * @return List<ProjectBelongInfo>
     **/
    public List<ProjectBelongInfo> listAllProjectByStatusAndEmail(String email, int status);
    
    /**
     * listAllProjectByStatusAndEmailAndIsManager
     * 
     * @return List<Project>
     **/
    public List<Project> listAllProjectByStatusAndEmailAndIsManager(int status, List<Integer> ListIsManager, int seqNoMember, String email);
    
    /**
     * listAllProjectByManager
     * 
     * @return List<Project>
     **/
    public List<Project> listAllProjectByManager(int status, Member member, String email, boolean isSupportor);
    
    /**
     * listAllProjectByMember
     * 
     * @return List<Project>
     **/
    public List<Project> listAllProjectByMember(int status, Member member, String email, boolean isSupportor);
    
    /**
     * listAllProjectByEmailSupporter
     * 
     * @return List<Project>
     **/
    public List<Project> listAllProjectByEmailSupporter();
}
