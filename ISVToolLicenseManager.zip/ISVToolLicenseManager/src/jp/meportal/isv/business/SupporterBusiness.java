package jp.meportal.isv.business;

import java.util.List;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.Support;

public interface SupporterBusiness {

    /**
     * approveProject
     * 
     * @return boolean
     **/
    public boolean approveProject(Project project);

    /**
     * getSupportDbList
     * 
     * @return List<Support>
     **/
    public List<Support> getSupportDbList(int mailFlag);

    /**
     * getSupportDb
     * 
     * @return Support
     **/
    public Support getSupportDb(String email);

    /**
     * rejectProject
     * 
     * @return boolean
     **/
    public boolean rejectProject(Project project);

    /**
     * deleteProject
     * 
     * @return boolean
     **/
    public boolean deleteProject(Project project);

    /**
     * getMailList
     * 
     * @return String
     **/
    public String getMailList();
}
