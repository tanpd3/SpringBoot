package jp.meportal.isv.business;

import java.util.List;

import jp.meportal.isv.entity.MailTemplate;

public interface SendMailBussiness {

    /**
     * getMailTemplateList
     * 
     * @return List<MailTemplate>
     **/
    public List<MailTemplate> getMailTemplateList();
    
}
