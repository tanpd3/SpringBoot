package jp.meportal.isv.business;

import java.util.List;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ServerInfo;
import jp.meportal.isv.formbean.ProjectLicenseFromBean;

public interface ApprovedLicenseBussiness {

    /**
     * licenseByStatusList
     * 
     * @return List<ProjectLicenseFromBean>
     **/
    public List<ProjectLicenseFromBean> licenseByStatusList (String statusList, int status, int statusDel);
    
    /**
     * rejectLicense
     * 
     * @return boolean
     **/
    public boolean rejectLicense(List<Integer> listProId, List<LicenseInfo> licenseInfosList);
    
    /**
     * rejectIpAddressLicense
     * 
     * @return boolean
     **/
    public boolean rejectIpAddressLicense(List<Integer> listProId);
    
    /**
     * approvedProjectLicense
     * 
     * @return boolean
     **/
    public boolean approvedProjectLicense (String projectIdList, String dateApproved, int status);

    /**
     * updateProjectLicense
     * 
     * @return boolean
     **/
    public boolean updateProjectLicense(int approverId, String projectIdList, String dateApproved, String comment);

    /**
     * getMailUpdaterById
     * 
     * @return mail Updater
     */
    public String getMailUpdaterById(int projectId);

    /**
     * updateProjectLicense
     * 
     * @return boolean
     **/
    public List<String> getAllIpAddressById(int projectId, int status);

    /**
     * getCatalogApprovedList
     * 
     * @return List<CatalogInfor>
     **/
    public List<CatalogInfor> getCatalogApprovedList(String projectIdList, String statusList);

    /**
     * getProjectApprovedList
     * 
     * @return List<Project>
     **/
    public List<Project> getProjectApprovedList(int seqNo, int status);

    /**
     * getServerInfoBySeqNo
     * 
     * @return ServerInfo
     **/
    public ServerInfo getServerInfoBySeqNo(int ipAddressServerId);

    /**
     * findLicenseInforByListProId
     * 
     * @return List<LicenseInfo>
     **/
    public List<LicenseInfo> findLicenseInforByListProId(List<Integer> listProId);
}
