package jp.meportal.isv.business;

import java.util.List;

import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.IpAddressInfo;
import jp.meportal.isv.entity.LicenseInfo;

public interface LicenseBusiness {

    /**
     * findLicensebyCatalogIdandProjectId
     * 
     * @return List<LicenseInfo>
     **/
    public List<LicenseInfo> findLicensebyCatalogIdandProjectId(int projectId, int catalogId, int year);
    
    /**
     * listAllIpBySeqNo
     * 
     * @return List<IpAddressInfo>
     **/
    public List<IpAddressInfo> listAllIpBySeqNo (int projectId);

    /**
     * deleteIPAddress
     * 
     * @return boolean
     **/
    public boolean deleteIPAddress(IpAddressInfo IpAddressDB);

    /**
     * insertAfterDeleteIpAdd
     * 
     * @return boolean
     **/
    public boolean insertAfterDeleteIpAdd(IpAddressInfo toDelete, List<IpAddressInfo> toInsertList);

    /**
     * insertIPAddress
     * 
     * @return boolean
     **/
    public boolean insertIPAddress(IpAddressInfo info);

<<<<<<< .mine
    public List<CatalogInfor> listCatalogInforByProjectID(int ProjectID);
    
||||||| .r13147
=======
    /**
     * listLicenseInfo
     * 
     * @return List<LicenseInfo>
     **/
>>>>>>> .r22123
    public List<LicenseInfo> listLicenseInfo(int catalogId, int ProjectID, int monthNow, int yearNow);
    
    /**
     * insertOrUpdateLicense
     * 
     * @return LicenseInfo
     **/
    public LicenseInfo insertOrUpdateLicense(LicenseInfo licenseInfo, int projectId);
    
    /**
     * findCatalogInforBySeqNo
     * 
     * @return CatalogInfor
     **/
    public CatalogInfor findCatalogInforBySeqNo(int seqNo);
<<<<<<< .mine
||||||| .r13147

	public List<CatalogInfor> listAllCatalogInfo();
=======

    /**
     * listAllCatalogInfo
     * 
     * @return List<CatalogInfor>
     **/
	public List<CatalogInfor> listAllCatalogInfo();
>>>>>>> .r22123

    /**
     * listIpAddressByStatus
     * 
     * @return List<IpAddressInfo>
     **/
    public List<IpAddressInfo> listIpAddressByStatus(int projectId, int status);

    /**
     * listAllLicenseInfoByProjectIdAndStatus
     * 
     * @return List<LicenseInfo>
     **/
    public List<LicenseInfo> listAllLicenseInfoByProjectIdAndStatus(int projectId, int status);
    
    /**
     * listAllLicenseInfoByProjectId
     * 
     * @return List<LicenseInfo>
     **/
    public List<LicenseInfo> listAllLicenseInfoByProjectId(int projectId);
    
    /**
     * listAllIpAddressByProjectId
     * 
     * @return List<IpAddressInfo>
     **/
    public List<IpAddressInfo> listAllIpAddressByProjectId(int projectId);

    /**
     * getLicenseInfoById
     * 
     * @return List<LicenseInfo>
     **/
    public List<LicenseInfo> getLicenseInfoById(int projectId, int catalogid);

    /**
     * listIpAddressUnApproved
     * 
     * @return List<IpAddressInfo>
     **/
    public List<IpAddressInfo> getIpAddressUnApproved(int projectId, int unApprovedStatus, int deletedStatus);

    /**
     * findIpAddressInfoByIP
     * 
     * @return IpAddressInfo
     **/
    public IpAddressInfo findIpAddressInfoByIP(int projectId, String ipInsert);
}
