package jp.meportal.isv.business;

 /**
 * Interface Name: BaseBusiness<br>
 * Created date: 2017/04/10<br>
 * @author FPT
 *
 */
public interface BaseBusiness {

}
