package jp.meportal.isv.business;

import java.util.List;
import jp.meportal.isv.entity.Member;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ProjectBelongInfo;
import jp.meportal.isv.formbean.MemberByProjectIdFormBean;

public interface MemberBusiness {
    
    /**
     * findMemberByMemberId
     * 
     * @return Member
     **/
    public Member findMemberByMemberId(int memberId);

    /**
     * getMembertList
     * 
     * @return List<Member>
     **/
    public List<Member> getMembertList(Long seqNo);

    /**
     * insertMember
     * 
     * @return Member
     **/
    public Member insertMember(Member member);

    /**
     * getIsManagerOfMember
     * 
     * @return int
     **/
    public int getIsManagerOfMember(int seqNo, String email);

    /**
     * getMemberInfoList
     * 
     * @return List<Member>
     **/
    public List<Member> getMemberInfoList(int projectId);

    /**
     * insertMemberIntoProjectBelongInfo
     * 
     * @return boolean
     **/
    public boolean insertMemberIntoProjectBelongInfo(ProjectBelongInfo bl);
    
    /**
     * updateMemberIntoProjectBelongInfo
     * 
     * @return boolean
     **/
    public boolean updateMemberIntoProjectBelongInfo(ProjectBelongInfo bl);

    /**
     * insertMemberAndProjectBelongInfo
     * 
     * @return boolean
     **/
    public boolean insertMemberAndProjectBelongInfo(Member member,
            ProjectBelongInfo bl);
    
    /**
     * insertMemberIntoProjectInfor
     * 
     * @return boolean
     **/
    public boolean insertMemberIntoProjectInfor(Project project);
    
    /**
     * checkExistEmailMember
     * 
     * @return Member
     **/
    public Member checkExistEmailMember(String email);

    /**
     * checkExistMemberOfProject
     * 
     * @return ProjectBelongInfo
     **/
    public ProjectBelongInfo checkExistMemberOfProject(int projectId, Member m);
    
    /**
     * checkExistMemberOfProjectAndStatus
     * 
     * @return ProjectBelongInfo
     **/
    public ProjectBelongInfo checkExistMemberOfProjectAndStatus(int projectId, Member m, int status);

    /**
     * updateMemberAndProjectInfo
     * 
     * @return boolean
     **/
    public boolean updateMemberAndProjectInfo(Member member, String oldLink,
            String newLink, ProjectBelongInfo bl, String oldManager, String newManager);

    /**
     * getManagerEmailOfProject
     * 
     * @return MemberByProjectIdFormBean
     **/
    public MemberByProjectIdFormBean getManagerEmailOfProject(int seqNo);

    /**
     * deleteMember
     * 
     * @return boolean
     **/
    public boolean deleteMember(String email, int seqNo, Member member);
    
    /**
     * updatePermissionMember
     * 
     * @return boolean
     **/
    public boolean updatePermissionMember(String email, int seqNo, int permission, Member member);

    /**
     * getAllMailManager
     * 
     * @return String
     **/
	public String getAllMailManager(int projectId, String mailUserLogin, String mailManager);
}
