package jp.meportal.isv.business.impl;

import java.io.Serializable;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import jp.meportal.isv.business.SupporterBusiness;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.dao.SupporterDao;
import jp.meportal.isv.dao.impl.SupporterDaoImpl;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.Support;

public class SupporterBusinessImpl implements SupporterBusiness, Serializable {
    private static final long serialVersionUID = 1L;
    private SupporterDao supporterDao;

    /**
     * SupporterBusinessImpl
     * 
     **/
    public SupporterBusinessImpl() {
        supporterDao = new SupporterDaoImpl();
    }

    /**
     * approveProject
     * 
     * @return boolean
     **/
    @Override
    public boolean approveProject(Project project) {
        return supporterDao.approveProject(project);
    }

    /**
     * getSupportDbList
     * 
     * @return List<Support>
     **/
    @Override
    public List<Support> getSupportDbList(int mailFlag) {
        return supporterDao.getSupportDbList(mailFlag);
    }

    /**
     * getSupportDb
     * 
     * @return Support
     **/
    @Override
    public Support getSupportDb(String email) {
        return supporterDao.getSupportDb(email);
    }

    /**
     * rejectProject
     * 
     * @return boolean
     **/
    @Override
    public boolean rejectProject(Project project) {
        return supporterDao.rejectProject(project);
    }

    /**
     * deleteProject
     * 
     * @return boolean
     **/
    @Override
    public boolean deleteProject(Project project) {
        return supporterDao.deleteProject(project);
    }

    /**
     * getMailList
     * 
     * @return String
     **/
    @Override
    public String getMailList() {
        String mailList = StringUtils.EMPTY;
        List<Support> supportList = getSupportDbList(Constants.MAIL_FLAG_TRUE);
        if (supportList != null && supportList.size() > 0) {
            for (Support element : supportList) {
                mailList = mailList.concat(element.getEmail()).concat(",");
            }
        }
        return mailList;
    }
}
