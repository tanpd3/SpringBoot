package jp.meportal.isv.business.impl;

import java.io.Serializable;
import java.util.List;
import jp.meportal.isv.business.LicenseBusiness;
import jp.meportal.isv.dao.LicenseDao;
import jp.meportal.isv.dao.impl.LicenseDaoImpl;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.IpAddressInfo;
import jp.meportal.isv.entity.LicenseInfo;

public class LicenseBusinessImpl implements LicenseBusiness,Serializable {
    
    private static final long serialVersionUID = 1L;
    private LicenseDao licenseDao;

    /**
     * LicenseBusinessImpl
     * 
     **/
    public LicenseBusinessImpl() {
        licenseDao = new LicenseDaoImpl();
    }
    

    /**
     * findLicensebyCatalogIdandProjectId
     * 
     * @return List<LicenseInfo>
     **/
    @Override
    public List<LicenseInfo> findLicensebyCatalogIdandProjectId(int projectId, int catalogId, int year){
        return licenseDao.findLicensebyCatalogIdandProjectId(projectId, catalogId, year);
    }

    /**
     * listAllIpBySeqNo
     * 
     * @return List<IpAddressInfo>
     **/
    @Override
    public List<IpAddressInfo> listAllIpBySeqNo(int projectId) {
        return licenseDao.listAllIpBySeqNo(projectId);
    }

    /**
     * deleteIPAddress
     * 
     * @return boolean
     **/
    @Override
    public boolean deleteIPAddress(IpAddressInfo IpAddressDB) {
        return licenseDao.deleteIPAddress(IpAddressDB);
    }

    /**
     * insertAfterDeleteIpAdd
     * 
     * @return boolean
     **/
    @Override
    public boolean insertAfterDeleteIpAdd(IpAddressInfo toDelete, List<IpAddressInfo> toInsertList) {
        return licenseDao.insertAfterDeleteIpAdd(toDelete, toInsertList);
    }

    /**
     * insertIPAddress
     * 
     * @return boolean
     **/
    @Override
    public boolean insertIPAddress(IpAddressInfo info) {
        return licenseDao.insertIPAddress(info);
    }

    
    /**
     * listLicenseInfo
     * 
     * @return List<LicenseInfo>
     **/
    @Override
    public List<CatalogInfor> listCatalogInforByProjectID(int projectID) {
        return licenseDao.listCatalogInforByProjectID(projectID);
    }
    
    @Override
    public List<LicenseInfo> listLicenseInfo(int catalogId, int projectID, int monthNow, int yearNow) {
        return licenseDao.listLicenseInfo(catalogId, projectID, monthNow, yearNow);
    }
    
    /**
     * insertOrUpdateLicense
     * 
     * @return LicenseInfo
     **/
    @Override
    public LicenseInfo insertOrUpdateLicense(LicenseInfo licenseInfo, int projectId){
        return licenseDao.insertOrUpdateLicense(licenseInfo, projectId);
    }
    
    /**
     * findCatalogInforBySeqNo
     * 
     * @return CatalogInfor
     **/
    @Override
    public CatalogInfor findCatalogInforBySeqNo(int seqNo){
        return licenseDao.findCatalogInforBySeqNo(seqNo);
    }

<<<<<<< .mine
||||||| .r13147
	@Override
	public List<CatalogInfor> listAllCatalogInfo() {
		return licenseDao.listAllCatalogInfo();
	}
    
    

=======
    /**
     * listAllCatalogInfo
     * 
     * @return List<CatalogInfor>
     **/
	@Override
	public List<CatalogInfor> listAllCatalogInfo() {
		return licenseDao.listAllCatalogInfo();
	}

>>>>>>> .r22123
    /**
     * listIpAddressByStatus
     * 
     * @return List<IpAddressInfo>
     **/
    @Override
	public List<IpAddressInfo> listIpAddressByStatus(int projectId, int status) {
	    return licenseDao.listIpAddressByStatus(projectId, status);
	}

    /**
     * listAllLicenseInfoByProjectIdAndStatus
     * 
     * @return List<LicenseInfo>
     **/
	@Override
	public List<LicenseInfo> listAllLicenseInfoByProjectIdAndStatus(int projectId, int status){
	    return licenseDao.listAllLicenseInfoByProjectIdAndStatus(projectId, status);
	}
	
    /**
     * listAllLicenseInfoByProjectId
     * 
     * @return List<LicenseInfo>
     **/
    @Override
	public List<LicenseInfo> listAllLicenseInfoByProjectId(int projectId){
	    return licenseDao.listAllLicenseInfoByProjectId(projectId);
	}
	
    /**
     * listAllIpAddressByProjectId
     * 
     * @return List<IpAddressInfo>
     **/
    @Override
	public List<IpAddressInfo> listAllIpAddressByProjectId(int projectId){
	    return licenseDao.listAllIpAddressByProjectId(projectId);
	}

    /**
     * getLicenseInfoById
     * 
     * @return List<LicenseInfo>
     **/
    @Override
    public List<LicenseInfo> getLicenseInfoById(int projectId, int catalogid) {
        return licenseDao.getLicenseInfoById(projectId, catalogid);
    }

    /**
     * getIpAddressUnApproved
     * 
     * @return List<IpAddressInfo>
     **/
    @Override
    public List<IpAddressInfo> getIpAddressUnApproved(int projectId, int statusUnApp, int statusDel) {
        return licenseDao.getIpAddressUnApproved(projectId, statusUnApp, statusDel);
    }

    /**
     * findIpAddressInfoByIP
     * 
     * @return IpAddressInfo
     **/
    @Override
    public IpAddressInfo findIpAddressInfoByIP(int projectId, String ipInsert) {
        return licenseDao.findIpAddressInfoByIP(projectId, ipInsert);
    }

}
