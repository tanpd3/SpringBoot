package jp.meportal.isv.business.impl;

import java.io.Serializable;
import java.util.List;

import jp.meportal.isv.business.SendMailBussiness;
import jp.meportal.isv.dao.SendMailDao;
import jp.meportal.isv.dao.impl.SendMailDaoImpl;
import jp.meportal.isv.entity.MailTemplate;

public class SendMailBussinessImpl implements SendMailBussiness, Serializable {

    private static final long serialVersionUID = 1L;

    private SendMailDao sendMailDao;

    /**
     * SendMailBussinessImpl
     * 
     **/
    public SendMailBussinessImpl() {
        sendMailDao = new SendMailDaoImpl();
    }

    /**
     * getMailTemplateList
     * 
     * @return List<MailTemplate>
     **/
    @Override
    public List<MailTemplate> getMailTemplateList() {
        return sendMailDao.getMailTemplateList();
    }
}
