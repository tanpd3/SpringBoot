package jp.meportal.isv.business.impl;

import java.io.Serializable;

import jp.meportal.isv.business.FileConvertBusiness;
import jp.meportal.isv.dao.FileConvertDao;
import jp.meportal.isv.dao.impl.FileConvertDaoImpl;
import jp.meportal.isv.entity.IpAddressInfo;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.LicenseUseInfor;
import jp.meportal.isv.entity.ServerInfo;

/**
 * File Convert Business(Implement)
 * @author  T.Obara@@tsr
 * @since   2017.09.13
 */
public class FileConvertBusinessImpl implements FileConvertBusiness, Serializable {
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    /**
     * FileConvert DAO
     */
    private FileConvertDao fileConvertDao;

    /**
     * Constructor
     */
    public FileConvertBusinessImpl() {
        fileConvertDao = new FileConvertDaoImpl();
    }

    /**
     * Find ServerInfo by sequential number
     * @param seqNo Sequential number
     * @return  ServerInfo(or null)
     */
    @Override
    public ServerInfo findServerInfoBySeqNo(int seqNo) {
        return fileConvertDao.findServerInfoBySeqNo(seqNo);
    }

    /**
     * Find IpAddressInfo by IPAddress
     * @param ipaddress IPAddress
     * @return  IpAddressInfo(or null)
     */
    @Override
    public IpAddressInfo findIpAddressInfoByIpAddress(String ipaddress) {
        return fileConvertDao.findIpAddressInfoByIpAddress(ipaddress);
    }

    /**
     * Find LicenseInfo by projectId, catalogId and year
     * @param projectId     projectId
     * @param catalogId     catalogId
     * @param year          year
     * @return  LicenseInfo(or null)
     */
    @Override
    public LicenseInfo findLicenseInfoByProjectIdAndCatalogIdAndYear(int projectId, int catalogId, int year) {
        return fileConvertDao.findLicenseInfoByProjectIdAndCatalogIdAndYear(projectId, catalogId, year);
    }

    /**
     * Find LicenseUseInfor
     * @param ipAddressId   IP address id
     * @param catalogId     Catalog id
     * @param year          Year
     * @param month         Month
     * @param account       Account
     * @param host          Host
     * @return  LicenseUseInfor(or null)
     */
    @Override
    public LicenseUseInfor findLicenseUseInfor(
            int ipAddressId,
            int catalogId,
            int year,
            int month,
            String account,
            String host)
    {
        return fileConvertDao.findLicenseUseInfor(ipAddressId, catalogId, year, month, account, host);
    }

    /**
     * Insert or Update LicenseUseInfor
     * LicenseUseInforのInsert or Update
     * @param info  LicenseUseInfor
     * @return true: 正常終了 / false: 異常終了
     */
    @Override
    public boolean insertOrUpdateLicenseUseInfor(LicenseUseInfor info) {
        return fileConvertDao.insertOrUpdateLicenseUseInfor(info);
    }
}
