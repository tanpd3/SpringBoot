package jp.meportal.isv.business.impl;

import java.io.Serializable;
import java.util.List;
import jp.meportal.isv.business.ProjectBusiness;
import jp.meportal.isv.dao.ProjectDao;
import jp.meportal.isv.dao.impl.ProjectDaoImpl;
import jp.meportal.isv.entity.Member;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ProjectBelongInfo;
import jp.meportal.isv.formbean.MemberByProjectIdFormBean;

public class ProjectBusinessImpl implements ProjectBusiness,Serializable {
    private static final long serialVersionUID = 1L;
    private ProjectDao projectDao;

    /**
     * ProjectBusinessImpl
     * 
     **/
    public ProjectBusinessImpl() {
        projectDao = new ProjectDaoImpl();
    }

    /**
     * findProjectByName
     * 
     * @return Project
     **/
    @Override
    public Project findProjectByName(String projectName) {
        return projectDao.findProjectByName(projectName);
    }

    /**
     * insertProjectBelongInfo
     * 
     * @return ProjectBelongInfo
     **/
    @Override
    public ProjectBelongInfo insertProjectBelongInfo(ProjectBelongInfo projectBelongInfo) {
        return projectDao.insertProjectBelongInfo(projectBelongInfo);
    }

    /**
     * listAllProject
     * 
     * @return List<Project>
     **/
    @Override
    public List<Project> listAllProject() {
        return projectDao.listAllProject();
    }

    /**
     * findProjectBySeqNo
     * 
     * @return Project
     **/
    @Override
    public Project findProjectBySeqNo(int seqNo) {
        return projectDao.findProjectBySeqNo(seqNo);
    }

    /**
     * registerOrUpdateProject
     * 
     * @return Project
     **/
    @Override
    public Project registerOrUpdateProject(Project project, int isManager) {
        return projectDao.registerOrUpdateProject(project, isManager);
    }

    /**
     * updateProject
     * 
     * @return Project
     **/
    @Override
    public Project updateProject(Project project, int isManager) {
        return projectDao.updateProject(project, isManager);
    }

    /**
     * listAllProjectByStatus
     * 
     * @return List<Project>
     **/
    @Override
    public List<Project> listAllProjectByStatus(int status) {
        return projectDao.listAllProjectByStatus(status);
    }

    /**
     * listMemberByProjectId
     * 
     * @return List<MemberByProjectIdFormBean>
     **/
    @Override
    public List<MemberByProjectIdFormBean> listMemberByProjectId(int status) {
        return projectDao.listMemberByProjectId(status);
    }

    /**
     * countMember
     * 
     * @return Long
     **/
    @Override
    public Long countMember(int seqNo) {
        return projectDao.countMember(seqNo);
    }

    /**
     * listAllProjectByEmail
     * 
     * @return List<Project>
     **/
    @Override
    public List<Project> listAllProjectByEmail(String email, int status) {
        return projectDao.listAllProjectByEmail(email, status);
    }

    /**
     * countAllProjectByStatus
     * 
     * @return Long
     **/
    @Override
    public Long countAllProjectByStatus(int status) {
        return projectDao.countAllProjectByStatus(status);
    }

    /**
     * listAllProjectByListStatus
     * 
     * @return List<Project>
     **/
    @Override
    public List<Project> listAllProjectByListStatus(List<Integer> listStatus) {
        return projectDao.listAllProjectByListStatus(listStatus);
    }

    /**
     * listAllProjectByStatusAndEmail
     * 
     * @return List<ProjectBelongInfo>
     **/
    @Override
    public List<ProjectBelongInfo> listAllProjectByStatusAndEmail(String email, int status) {
        return projectDao.listAllProjectByStatusAndEmail(email, status);
    }

    /**
     * findProjectBelongInforBySeqNo
     * 
     * @return ProjectBelongInfo
     **/
    @Override
    public ProjectBelongInfo findProjectBelongInforBySeqNo(int seqNo) {
        return projectDao.findProjectBelongInforBySeqNo(seqNo);
    }
    
    /**
     * listAllProjectByStatusAndEmailAndIsManager
     * 
     * @return List<Project>
     **/
    @Override
    public List<Project> listAllProjectByStatusAndEmailAndIsManager(int status, List<Integer> ListIsManager, int seqNoMember, String email){
        return projectDao.listAllProjectByStatusAndEmailAndIsManager(status, ListIsManager, seqNoMember, email);
    }
    
    /**
     * listAllProjectByManager
     * 
     * @return List<Project>
     **/
    @Override
    public List<Project> listAllProjectByManager(int status, Member member, String email, boolean isSupportor){
        return projectDao.listAllProjectByManager(status, member, email, isSupportor);
    }
    
    /**
     * listAllProjectByMember
     * 
     * @return List<Project>
     **/
    @Override
    public List<Project> listAllProjectByMember(int status, Member member, String email, boolean isSupportor){
        return projectDao.listAllProjectByMember(status, member, email, isSupportor);
    }
    
    /**
     * listAllProjectByEmailSupporter
     * 
     * @return List<Project>
     **/
    @Override
    public List<Project> listAllProjectByEmailSupporter(){
        return projectDao.listAllProjectByEmailSupporter();
    }
}
