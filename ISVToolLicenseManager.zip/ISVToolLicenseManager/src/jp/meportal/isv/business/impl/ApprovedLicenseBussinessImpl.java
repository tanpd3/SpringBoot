package jp.meportal.isv.business.impl;

import java.io.Serializable;
import java.util.List;

import jp.meportal.isv.business.ApprovedLicenseBussiness;
import jp.meportal.isv.dao.ApprovedLicenseDao;
import jp.meportal.isv.dao.impl.ApprovedLicenseDaoImpl;
import jp.meportal.isv.entity.CatalogInfor;
import jp.meportal.isv.entity.LicenseInfo;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ServerInfo;
import jp.meportal.isv.formbean.ProjectLicenseFromBean;

public class ApprovedLicenseBussinessImpl implements ApprovedLicenseBussiness, Serializable {
    
    private static final long serialVersionUID = 1L;
    public ApprovedLicenseDao approvedLicenseDao;
    
    /**
     * ApprovedLicenseBussinessImpl
     * 
     **/
    public ApprovedLicenseBussinessImpl() {
        approvedLicenseDao = new ApprovedLicenseDaoImpl();
    }
    
    /**
     * licenseByStatusList
     * 
     * @return List<ProjectLicenseFromBean>
     **/
    @Override
    public List<ProjectLicenseFromBean> licenseByStatusList (String statusList, int status, int statusDel) {
        return approvedLicenseDao.licenseByStatusList(statusList, status, statusDel);
    }
    
    /**
     * rejectLicense
     * 
     * @return boolean
     **/
    @Override
    public boolean rejectLicense(List<Integer> listProId, List<LicenseInfo> licenseInfosList){
       return approvedLicenseDao.rejectLicense(listProId, licenseInfosList);
    }
    
    /**
     * rejectIpAddressLicense
     * 
     * @return boolean
     **/
    @Override
    public boolean rejectIpAddressLicense(List<Integer> listProId){
        return approvedLicenseDao.rejectIpAddressLicense(listProId);
    }

    /**
     * approvedLicense
     * 
     * @return boolean
     **/
    public boolean approvedLicense(String projectIdList, String dateApproved, int status) {
        return approvedLicenseDao.approvedLicense(projectIdList, dateApproved, status);
    }

    /**
     * approvedIpAddress
     * 
     * @return boolean
     **/
    public boolean approvedIpAddress(String projectIdList, int status) {
        return approvedLicenseDao.approvedIpAddress(projectIdList, status);
    }

    /**
     * updateProjectLicense
     * 
     * @return boolean
     **/
    @Override
    public boolean updateProjectLicense(int approverId, String projectIdList, String dateApproved, String comment) {
        return approvedLicenseDao.updateProjectLicense(approverId, projectIdList, dateApproved, comment);
    }
	
    /**
     * approvedProjectLicense
     * 
     * @return boolean
     **/
    @Override
    public boolean approvedProjectLicense(String projectIdList, String dateApproved, int status) {
        boolean flagLicense = approvedLicense (projectIdList, dateApproved, status);
        boolean flagIpAdd = approvedIpAddress (projectIdList, status);
        boolean flag = false;
        if (flagLicense && flagIpAdd) {
           flag = true;
        }
        return flag;
    }

    /**
     * getMailUpdaterById
     * 
     * @return Mail updater
     **/
    @Override
    public String getMailUpdaterById(int projectId) {
        return approvedLicenseDao.getMailUpdaterById(projectId);
    }

    /**
     * getMailUpdaterById
     * 
     * @return Mail updater
     **/
    @Override
    public List<String> getAllIpAddressById(int projectId, int status) {
        return approvedLicenseDao.getAllIpAddressById (projectId, status);
    }

    /**
     * getCatalogApprovedList
     * 
     * @return List<CatalogInfor>
     **/
    @Override
    public List<CatalogInfor> getCatalogApprovedList(String projectIdList, String statusList) {
        return approvedLicenseDao.getCatalogApprovedList (projectIdList, statusList);
    }

    /**
     * getProjectApprovedList
     * 
     * @return List<Project>
     **/
    @Override
    public List<Project> getProjectApprovedList(int catalogId, int status) {
        return approvedLicenseDao.getProjectApprovedList (catalogId, status);
    }

    /**
     * getServerInfoBySeqNo
     * 
     * @return ServerInfo
     **/
    @Override
    public ServerInfo getServerInfoBySeqNo(int seqNo) {
        return approvedLicenseDao.getServerInfoBySeqNo (seqNo);
    }

    /**
     * findLicenseInforByListProId
     * 
     * @return List<LicenseInfo>
     **/
    @Override
    public List<LicenseInfo> findLicenseInforByListProId(List<Integer> listProId) {
        return approvedLicenseDao.findLicenseInforByListProId (listProId);
    }
}
