package jp.meportal.isv.business.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import jp.meportal.isv.business.MemberBusiness;
import jp.meportal.isv.constant.Constants;
import jp.meportal.isv.dao.MemberDao;
import jp.meportal.isv.dao.ProjectDao;
import jp.meportal.isv.dao.impl.MemberDaoImpl;
import jp.meportal.isv.dao.impl.ProjectDaoImpl;
import jp.meportal.isv.entity.Member;
import jp.meportal.isv.entity.Project;
import jp.meportal.isv.entity.ProjectBelongInfo;
import jp.meportal.isv.formbean.MemberByProjectIdFormBean;

public class MemberBusinessImpl implements MemberBusiness, Serializable {

    private static final long serialVersionUID = 1L;

    private MemberDao memberDao;

    private ProjectDao projectDao;

    /**
     * MemberBusinessImpl
     * 
     **/
    public MemberBusinessImpl() {
        memberDao = new MemberDaoImpl();
        projectDao = new ProjectDaoImpl();
    }

    /**
     * findMemberByMemberId
     * 
     * @return Member
     **/
    @Override
    public Member findMemberByMemberId(int memberId){
        return memberDao.findMemberByMemberId(memberId);
    }

    /**
     * getMembertList
     * 
     * @return List<Member>
     **/
    @Override
    public List<Member> getMembertList(Long seqNo) {
        return memberDao.getMembertList(seqNo);
    }

    /**
     * insertMember
     * 
     * @return Member
     **/
    @Override
    public Member insertMember(Member member) {
        return memberDao.insertMember(member);
    }

    /**
     * getIsManagerOfMember
     * 
     * @return int
     **/
    @Override
    public int getIsManagerOfMember(int seqNo, String email) {
        return memberDao.getIsManagerOfMember(seqNo, email);
    }

    @Override
    public List<Member> getMemberInfoList(int projectId) {

        List<Member> listMember = new ArrayList<Member>();
        List<ProjectBelongInfo> projectBelongInfoList = projectDao.getProjectBelongInfoList(projectId,
                Constants.APPROVED_STATUS);

        if (projectBelongInfoList != null && projectBelongInfoList.size() > 0) {

            for (ProjectBelongInfo element : projectBelongInfoList) {

                Member member = element.getMember();
                member.setProjectName(element.getProject_id().getProjectName());
                member.setManagerName(element.getProject_id().getManagerName());
                member.setIsManager(String.valueOf(element.getIsManager()));
                member.setRegistrationDate(element.getRegistrationDate());
                listMember.add(member);

            }

        }
        return listMember;
    }
    
    /**
     * insertMemberAndProjectBelongInfo
     * 
     * @return boolean
     **/
    @Override
    public boolean insertMemberAndProjectBelongInfo(Member member, ProjectBelongInfo bl) {
        return memberDao.insertMemberAndProjectBelongInfo(member, bl);
    }
    
    /**
     * insertMemberIntoProjectBelongInfo
     * 
     * @return boolean
     **/
    @Override
    public boolean insertMemberIntoProjectBelongInfo(ProjectBelongInfo bl) {
        return memberDao.insertMemberIntoProjectBelongInfo(bl);
    }
    
    /**
     * updateMemberIntoProjectBelongInfo
     * 
     * @return boolean
     **/
    @Override
    public boolean updateMemberIntoProjectBelongInfo(ProjectBelongInfo bl){
        return memberDao.updateMemberIntoProjectBelongInfo(bl);
    }
    
    /**
     * insertMemberIntoProjectInfor
     * 
     * @return boolean
     **/
    @Override
    public boolean insertMemberIntoProjectInfor(Project project) {
        return memberDao.insertMemberIntoProjectInfor(project);
    }

    /**
     * checkExistEmailMember
     * 
     * @return Member
     **/
    @Override
    public Member checkExistEmailMember(String email) {
        return memberDao.checkExistEmailMember(email);
    }

    /**
     * checkExistMemberOfProject
     * 
     * @return ProjectBelongInfo
     **/
    @Override
    public ProjectBelongInfo checkExistMemberOfProject(int projectId, Member m) {
        return memberDao.checkExistMemberOfProject(projectId, m);
    }

    /**
     * checkExistMemberOfProjectAndStatus
     * 
     * @return ProjectBelongInfo
     **/
    @Override
    public ProjectBelongInfo checkExistMemberOfProjectAndStatus(int projectId, Member m, int status) {
        return memberDao.checkExistMemberOfProjectAndStatus(projectId, m, status);
    }
    
    /**
     * updateMemberAndProjectInfo
     * 
     * @return boolean
     **/
    @Override
    public boolean updateMemberAndProjectInfo(Member member, String oldLink, String newLink, ProjectBelongInfo bl, String oldManager, String newManager) {
        return memberDao.updateMemberAndProjectInfo(member, oldLink, newLink, bl, oldManager, newManager);
    }

    /**
     * getManagerEmailOfProject
     * 
     * @return MemberByProjectIdFormBean
     **/
    @Override
    public MemberByProjectIdFormBean getManagerEmailOfProject(int seqNo) {
        return memberDao.getManagerEmailOfProject(seqNo);
    }

    /**
     * deleteMember
     * 
     * @return boolean
     **/
    @Override
    public boolean deleteMember(String email, int seqNo, Member member) {
        return memberDao.deleteMember(email, seqNo, member);
    }

    /**
     * updatePermissionMember
     * 
     * @return boolean
     **/
    @Override
    public boolean updatePermissionMember(String email, int seqNo, int permission, Member member) {
        return memberDao.updatePermissionMember(email, seqNo, permission, member);
    }

    @Override
    public String getAllMailManager(int projectId, String mailUserLogin, String mailManager) {
    	String allMailManagerList = mailManager;
    	String otherManagerId = getOtherManagerById(projectId);
    	List<Member> otherManagerList = getOtherManagerList(projectId, otherManagerId);
    	if (otherManagerList != null && otherManagerList.size() > 0) {
            for (Member om : otherManagerList) {
                allMailManagerList = allMailManagerList.concat(",").concat(om.getEmail());

            }   
        }
    	if (!StringUtils.isEmpty(mailUserLogin)) {
    	    allMailManagerList = allMailManagerList.concat(",").concat(mailUserLogin);
        }

    	return allMailManagerList;
    }

    /**
     * getOtherManagerById
     * 
     * @return String
     **/
	private String getOtherManagerById(int projectId) {
	    return memberDao.getOtherManagerById(projectId);
    }

    /**
     * getOtherManagerList
     * 
     * @return List<Member>
     **/
    private List<Member> getOtherManagerList(int projectId, String otherManagerId) {
        return memberDao.getOtherManagerList(projectId, otherManagerId);
	}
}
