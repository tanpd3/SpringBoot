package jp.meportal.isv.entity;

import java.io.Serializable;
import org.apache.commons.lang.StringUtils;

public class UserInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String uid = StringUtils.EMPTY;
    private String userName = StringUtils.EMPTY;
    private String firstName = StringUtils.EMPTY;
    private String lastName = StringUtils.EMPTY;
    private String emailAddress = StringUtils.EMPTY;
    private String userBelongCompanyCd = StringUtils.EMPTY;
    private String userBelongCompanyName = StringUtils.EMPTY;
    private String userBelongDepartmentCd = StringUtils.EMPTY;
    private String userBelongDepartmentName = StringUtils.EMPTY;
    private String innerTelNumber = StringUtils.EMPTY;
    private String outerTelNumber = StringUtils.EMPTY;
    private int userGroupID = 0;
    private String apiKey = StringUtils.EMPTY;

    /**
     * Default constructor
     */
    public UserInfo() {
        super();
    }

    /**
     * Constructor
     * 
     * @param uid
     * @param userName
     * @param firstName
     * @param lastName
     * @param emailAddress
     * @param userBelongCompanyCd
     * @param userBelongCompanyName
     * @param userBelongDepartmentCd
     * @param userBelongDepartmentName
     * @param innerTelNumber
     * @param outerTelNumber
     * @param userGroupID
     * @param apiKey
     */
    public UserInfo(String uid, String userName, String firstName, String lastName, String emailAddress,
            String userBelongCompanyCd, String userBelongCompanyName, String userBelongDepartmentCd,
            String userBelongDepartmentName, String innerTelNumber, String outerTelNumber, int userGroupID,
            String apiKey) {
        super();
        this.uid = uid;
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailAddress = emailAddress;
        this.userBelongCompanyCd = userBelongCompanyCd;
        this.userBelongCompanyName = userBelongCompanyName;
        this.userBelongDepartmentCd = userBelongDepartmentCd;
        this.userBelongDepartmentName = userBelongDepartmentName;
        this.innerTelNumber = innerTelNumber;
        this.outerTelNumber = outerTelNumber;
        this.userGroupID = userGroupID;
        this.apiKey = apiKey;
    }

    /**
     * Constructor
     * 
     * @param uid
     * @param userName
     * @param firstName
     * @param lastName
     * @param emailAddress
     * @param userBelongCompanyCd
     * @param userBelongCompanyName
     * @param userBelongDepartmentCd
     * @param userBelongDepartmentName
     * @param innerTelNumber
     * @param outerTelNumber
     * @param apiKey
     */
    public UserInfo(String uid, String userName, String firstName, String lastName, String emailAddress,
            String userBelongCompanyCd, String userBelongCompanyName, String userBelongDepartmentCd,
            String userBelongDepartmentName, String innerTelNumber, String outerTelNumber, String apiKey) {
        super();
        this.uid = uid;
        this.userName = userName;
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailAddress = emailAddress;
        this.userBelongCompanyCd = userBelongCompanyCd;
        this.userBelongCompanyName = userBelongCompanyName;
        this.userBelongDepartmentCd = userBelongDepartmentCd;
        this.userBelongDepartmentName = userBelongDepartmentName;
        this.innerTelNumber = innerTelNumber;
        this.outerTelNumber = outerTelNumber;
        this.apiKey = apiKey;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the group of user
     */
    public int getUserGroupID() {
        return userGroupID;
    }

    public void setUserGroupID(int userGroupID) {
        this.userGroupID = userGroupID;
    }

    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return the company name of user
     */
    public String getUserBelongCompanyName() {
        return userBelongCompanyName;
    }

    /**
     * @param userBelongCompanyName
     */
    public void setUserBelongCompanyName(String userBelongCompanyName) {
        this.userBelongCompanyName = userBelongCompanyName;
    }

    /**
     * @return the company code of user
     */
    public String getUserBelongCompanyCd() {
        return userBelongCompanyCd;
    }

    /**
     * @param userBelongCompanyCd
     */
    public void setUserBelongCompanyCd(String userBelongCompanyCd) {
        this.userBelongCompanyCd = userBelongCompanyCd;
    }

    /**
     * @return the department name of user
     */
    public String getUserBelongDepartmentName() {
        return userBelongDepartmentName;
    }

    /**
     * @param userBelongDepartmentName
     */
    public void setUserBelongDepartmentName(String userBelongDepartmentName) {
        this.userBelongDepartmentName = userBelongDepartmentName;
    }

    /**
     * @return the department code of user
     */
    public String getUserBelongDepartmentCd() {
        return userBelongDepartmentCd;
    }

    /**
     * @param userBelongDepartmentCd
     */
    public void setUserBelongDepartmentCd(String userBelongDepartmentCd) {
        this.userBelongDepartmentCd = userBelongDepartmentCd;
    }

    /**
     * @return the emailAddress
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * @param emailAddress
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * @return the inner telephone number
     */
    public String getInnerTelNumber() {
        return innerTelNumber;
    }

    /**
     * @param innerTelNumber
     */
    public void setInnerTelNumber(String innerTelNumber) {
        this.innerTelNumber = innerTelNumber;
    }

    /**
     * @return the outer telephone number
     */
    public String getOuterTelNumber() {
        return outerTelNumber;
    }

    /**
     * @param outerTelNumber
     */
    public void setOuterTelNumber(String outerTelNumber) {
        this.outerTelNumber = outerTelNumber;
    }

    /**
     * @return the uid
     */
    public String getUid() {
        return uid;
    }

    /**
     * @param uid
     */
    public void setUid(String uid) {
        this.uid = uid;
    }

    /**
     * @return the user's Redmine API key
     */
    public String getApiKey() {
        return apiKey;
    }

    /**
     * @param apiKey
     */
    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }
}
