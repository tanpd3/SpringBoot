package jp.meportal.isv.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "catalog_info")
public class CatalogInfor implements Serializable {

    private static final long serialVersionUID = -8767337896773261247L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "seq_no")
    private int seqNo;

    @Column(name = "vendor_name")
    private String vendorName;
    
    @Column(name = "tool_name")
    private String toolName;
    
    @Column(name = "future_name")
    private String futureName;
    
    @Column(name = "member_price")
    private BigDecimal memberPrice;
    
    @Column(name = "regular_price")
    private BigDecimal regularPrice;
    
    @Column(name = "keep_number")
    private int keepNumber;
    
    @Column(name = "overview")
    private String overView;
    
    @Column(name = "note")
    private String note;
    
    @Column(name = "ipaddress_server_id")
    private Integer ipAddressServerId;

    @Column(name = "ipaddress_file_path")
    private String ipAddressFilePath;

    @Column(name = "result_server_id")
    private Integer resultServerId; 

    @Column(name = "result_file_before_path")
    private String resultFileBeforePath;

    @Column(name = "result_file_after_path")
    private String resultFileAfterPath;

    /**
     * @param seqNo
     */
    public int getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo
     *            the seqNo to set
     */
    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @param vendorName
     */
    public String getVendorName() {
        return vendorName;
    }

    /**
     * @param vendorName
     *            the vendorName to set
     */
    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    /**
     * @param toolName
     */
    public String getToolName() {
        return toolName;
    }

    /**
     * @param toolName
     *            the toolName to set
     */
    public void setToolName(String toolName) {
        this.toolName = toolName;
    }

    /**
     * @param futureName
     */
    public String getFutureName() {
        return futureName;
    }

    /**
     * @param futureName
     *            the futureName to set
     */
    public void setFutureName(String futureName) {
        this.futureName = futureName;
    }

    /**
     * @param memberPrice
     */
    public BigDecimal getMemberPrice() {
        return memberPrice;
    }

    /**
     * @param memberPrice
     *            the memberPrice to set
     */
    public void setMemberPrice(BigDecimal memberPrice) {
        this.memberPrice = memberPrice.setScale(0, RoundingMode.DOWN);
    }

    /**
     * @param regularPrice
     */
    public BigDecimal getRegularPrice() {
        return regularPrice;
    }

    /**
     * @param regularPrice
     *            the regularPrice to set
     */
    public void setRegularPrice(BigDecimal regularPrice) {
        this.regularPrice = regularPrice.setScale(0, RoundingMode.DOWN);
    }

    /**
     * @param keepNumber
     */
    public int getKeepNumber() {
        return keepNumber;
    }

    /**
     * @param keepNumber
     *            the keepNumber to set
     */
    public void setKeepNumber(int keepNumber) {
        this.keepNumber = keepNumber;
    }

    /**
     * @param overView
     */
    public String getOverView() {
        return overView;
    }

    /**
     * @param overView
     *            the overView to set
     */
    public void setOverView(String overView) {
        this.overView = overView;
    }

    /**
     * @param note
     */
    public String getNote() {
        return note;
    }

    /**
     * @param note
     *            the note to set
     */
    public void setNote(String note) {
        this.note = note;
    }

    /**
     * @param ipAddressServerId
     */
    public Integer getIpAddressServerId() {
        return ipAddressServerId;
    }

    /**
     * @param ipAddressServerId
     *            the ipAddressServerId to set
     */
    public void setIpAddressServerId(Integer ipAddressServerId) {
        this.ipAddressServerId = ipAddressServerId;
    }

    /**
     * @param ipAddressFilePath
     */
    public String getIpAddressFilePath() {
        return ipAddressFilePath;
    }

    /**
     * @param ipAddressFilePath
     *            the ipAddressFilePath to set
     */
    public void setIpAddressFilePath(String ipAddressFilePath) {
        this.ipAddressFilePath = ipAddressFilePath;
    }

    /**
     * @param resultServerId
     */
    public Integer getResultServerId() {
        return resultServerId;
    }

    /**
     * @param resultServerId
     *            the resultServerId to set
     */
    public void setResultServerId(Integer resultServerId) {
        this.resultServerId = resultServerId;
    }

    /**
     * @param resultFileBeforePath
     */
    public String getResultFileBeforePath() {
        return resultFileBeforePath;
    }

    /**
     * @param resultFileBeforePath
     *            the resultFileBeforePath to set
     */
    public void setResultFileBeforePath(String resultFileBeforePath) {
        this.resultFileBeforePath = resultFileBeforePath;
    }

    /**
     * @param resultFileAfterPath
     */
    public String getResultFileAfterPath() {
        return resultFileAfterPath;
    }

    /**
     * @param resultFileAfterPath
     *            the resultFileAfterPath to set
     */
    public void setResultFileAfterPath(String resultFileAfterPath) {
        this.resultFileAfterPath = resultFileAfterPath;
    }
}
