package jp.meportal.isv.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import jp.meportal.isv.util.DateUtils;
import org.apache.commons.lang.StringUtils;

@Entity
@Table(name = "project_info")
public class Project implements Serializable {

    private static final long serialVersionUID = -8767337896773261247L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "seq_no")
    private int seqNo;

    @Column(name = "project_name")
    private String projectName;

    @Column(name = "manager_email")
    private String managerEmail;

    @Column(name = "load_origin_code")
    private String loadOriginCode;

    @Column(name = "cost_code")
    private String costCode;

    @Column(name = "other_manager")
    private String otherManager;

    @Column(name = "member")
    private String member;

    @Column(name = "status")
    private int status;

    @Column(name = "create_dated")
    private String createDated;

    @Column(name = "update_dated")
    private String updateDated;

    @Column(name = "comment")
    private String comment;

    @Column(name = "product_number")
    private String productNumber;

    @Column(name = "manager_name")
    private String managerName;

    @Column(name = "approval_dated")
    private String dateApproved;

    @Column(name = "`update`", nullable = true)
    private Integer update;

    @Column(name = "approver", nullable = true)
    private Integer approver;

    @Transient
    private Long numberMember;

    @Transient
    private String departmentCode;

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param managerEmail
     */
    public String getManagerEmail() {
        return managerEmail;
    }

    /**
     * @param managerEmail
     *            the managerEmail to set
     */
    public void setManagerEmail(String managerEmail) {
        this.managerEmail = managerEmail;
    }

    /**
     * @param loadOriginCode
     */
    public String getLoadOriginCode() {
        return loadOriginCode;
    }

    /**
     * @param loadOriginCode
     *            the loadOriginCode to set
     */
    public void setLoadOriginCode(String loadOriginCode) {
        this.loadOriginCode = loadOriginCode;
    }

    /**
     * @param costCode
     */
    public String getCostCode() {
        return costCode;
    }

    /**
     * @param costCode
     *            the costCode to set
     */
    public void setCostCode(String costCode) {
        this.costCode = costCode;
    }

    /**
     * @param otherManager
     */
    public String getOtherManager() {
        return otherManager;
    }

    /**
     * @param otherManager
     *            the otherManager to set
     */
    public void setOtherManager(String otherManager) {
        this.otherManager = otherManager;
    }

    /**
     * @param member
     */
    public String getMember() {
        return member;
    }

    /**
     * @param member
     *            the member to set
     */
    public void setMember(String member) {
        this.member = member;
    }

    /**
     * @param status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @param createDated
     */
    public String getCreateDated() {
        return createDated;
    }
    
    /**
     * @param getCreateDatedFormat
     */
    public String getCreateDatedFormat() {
        String dateFormat = StringUtils.EMPTY;
        if (!StringUtils.isEmpty(createDated)) {
            dateFormat = DateUtils.getDateUpdate(createDated);
        }
        return dateFormat;
    }
    
    /**
     * @param createDated
     *            the createDated to set
     */
    public void setCreateDated(String createDated) {
        this.createDated = createDated;
    }

    /**
     * @param updateDated
     */
    public String getUpdateDated() {
        return updateDated;
    }

    /**
     * @param getUpdateDatedFormat
     */
    public String getUpdateDatedFormat() {
        String dateFormat = StringUtils.EMPTY;
        if (!StringUtils.isEmpty(updateDated)) {
            dateFormat = DateUtils.getDateUpdate(updateDated);
        }
        return dateFormat;
    }
    
    /**
     * @param updateDated
     *            the updateDated to set
     */
    public void setUpdateDated(String updateDated) {
        this.updateDated = updateDated;
    }

    /**
     * @param comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment
     *            the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @param productNumber
     */
    public String getProductNumber() {
        return productNumber;
    }

    /**
     * @param productNumber
     *            the productNumber to set
     */
    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    /**
     * @param managerName
     */
    public String getManagerName() {
        return managerName;
    }

    /**
     * @param managerName
     *            the managerName to set
     */
    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    /**
     * @param seqNo
     */
    public int getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo
     *            the seqNo to set
     */
    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @param numberMember
     */
    public Long getNumberMember() {
        return numberMember;
    }

    /**
     * @param numberMember
     *            the numberMember to set
     */
    public void setNumberMember(Long numberMember) {
        this.numberMember = numberMember;
    }

    /**
     * getDepartmentCode
     */
    public String getDepartmentCode() {
        String loadOriginCode = getLoadOriginCode();
        String departmentCode = loadOriginCode.split("-")[0];
        return departmentCode;
    }

    /**
     * @param getDepartmentCode
     *            the getDepartmentCode to set
     */
    public void setDepartmentCode(String departmentCode) {
        this.departmentCode = departmentCode;
    }

    /**
     * @param dateApproved
     */
    public String getDateApproved() {
        return dateApproved;
    }

    /**
     * @param dateApproved
     *            the dateApproved to set
     */
    public void setDateApproved(String dateApproved) {
        this.dateApproved = dateApproved;
    }

    /**
     * @param update
     */
    public Integer getUpdate() {
        return update;
    }

    /**
     * @param update
     *            the update to set
     */
    public void setUpdate(Integer update) {
        this.update = update;
    }

    /**
     * @param approver
     */
    public Integer getApprover() {
        return approver;
    }

    /**
     * @param approver
     *            the approver to set
     */
    public void setApprover(Integer approver) {
        this.approver = approver;
    }
}
