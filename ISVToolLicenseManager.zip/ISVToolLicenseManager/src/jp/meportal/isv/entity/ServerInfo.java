package jp.meportal.isv.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "server_info")
public class ServerInfo implements Serializable {

    private static final long serialVersionUID = -8767337896773261247L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "seq_no")
    private int seqNo;

    @Column(name = "server_name")
    private String serverName;

    @Column(name = "port", nullable = true)
    private int port;

    @Column(name = "account")
    private String account;

    @Column(name = "password")
    private String password;
    
    @Column(name = "accounting_folder")
    private String accountingFolder;
    /**
     * @param seqNo
     */
    public int getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo
     *            the seqNo to set
     */
    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @param serverName
     */
    public String getServerName() {
        return serverName;
    }

    /**
     * @param serverName
     *            the serverName to set
     */
    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    /**
     * @param port
     */
    public int getPort() {
        return port;
    }

    /**
     * @param port
     *            the port to set
     */
    public void setPort(int port) {
        this.port = port;
    }

    /**
     * @param account
     */
    public String getAccount() {
        return account;
    }

    /**
     * @param account
     *            the account to set
     */
    public void setAccount(String account) {
        this.account = account;
    }

    /**
     * @param password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password
     *            the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @param accountingFolder
     */
    public String getAccountingFolder() {
        return accountingFolder;
    }

    /**
     * @param accountingFolder
     *            the accountingFolder to set
     */
    public void setAccountingFolder(String accountingFolder) {
        this.accountingFolder = accountingFolder;
    }
}
