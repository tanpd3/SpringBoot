package jp.meportal.isv.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "license_info")
public class LicenseInfo implements Serializable {
    private static final long serialVersionUID = -8767337896773261247L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`seq_no`")
    private int seqNo;

    @ManyToOne
    @JoinColumn(name = "`project_id`", nullable = false)
    private Project projectId;
    
    @ManyToOne
    @JoinColumn(name = "`catalog_id`", nullable = false)
    private CatalogInfor catalogId;
    
    @Column(name = "`year`")
    private int year;

    @Column(name = "`Apr`")
    private int apr;
   
    @Column(name = "`May`")
    private int may;
   
    @Column(name = "`Jun`")
    private int jun;
   
    @Column(name = "`Jul`")
    private int jul;
   
    @Column(name = "`Aug`")
    private int aug;
   
    @Column(name = "`Sep`")
    private int sep;
   
    @Column(name = "`Oct`")
    private int oct;
   
    @Column(name = "`Nov`")
    private int nov;
   
    @Column(name = "`Dec`")
    private int dec;
   
    @Column(name = "`Jan`")
    private int jan;
   
    @Column(name = "`Feb`")
    private int feb;
   
    @Column(name = "`Mar`")
    private int mar;

    @Column(nullable=true, name = "`Apr_updated`")
    private Integer aprUpdated;
   
    @Column(nullable=true, name = "`May_updated`")
    private Integer mayUpdated;
   
    @Column(nullable=true, name = "`Jun_updated`")
    private Integer junUpdated;
   
    @Column(nullable=true, name = "`Jul_updated`")
    private Integer julUpdated;
   
    @Column(nullable=true, name = "`Aug_updated`")
    private Integer augUpdated;
   
    @Column(nullable=true, name = "`Sep_updated`")
    private Integer sepUpdated;
   
    @Column(nullable=true, name = "`Oct_updated`")
    private Integer octUpdated;
   
    @Column(nullable=true, name = "`Nov_updated`")
    private Integer novUpdated;
   
    @Column(nullable=true, name = "`Dec_updated`")
    private Integer decUpdated;
   
    @Column(nullable=true, name = "`Jan_updated`")
    private Integer janUpdated;
   
    @Column(nullable=true, name = "`Feb_updated`")
    private Integer febUpdated;
   
    @Column(nullable=true, name = "`Mar_updated`")
    private Integer marUpdated;
   
    @Column(name = "update_dated")
    private String dateUpdated;
    
    @Column(name = "date_created")
    private String dateCreated;
    
    @Column(name = "status")
    private int status;
    
    @Column(name = "approval_dated")
    private String dateApproved;

    /**
     * @param seqNo
     */
    public int getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo
     *            the seqNo to set
     */
    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @param projectId
     */
    public Project getProjectId() {
        return projectId;
    }

    /**
     * @param projectId
     *            the projectId to set
     */
    public void setProjectId(Project projectId) {
        this.projectId = projectId;
    }

    /**
     * @param catalogId
     */
    public CatalogInfor getCatalogId() {
        return catalogId;
    }

    /**
     * @param catalogId
     *            the catalogId to set
     */
    public void setCatalogId(CatalogInfor catalogId) {
        this.catalogId = catalogId;
    }

    /**
     * @param year
     */
    public int getYear() {
        return year;
    }

    /**
     * @param year
     *            the year to set
     */
    public void setYear(int year) {
        this.year = year;
    }

    /**
     * @param apr
     */
    public int getApr() {
        return apr;
    }

    /**
     * @param apr
     *            the apr to set
     */
    public void setApr(int apr) {
        this.apr = apr;
    }

    /**
     * @param may
     */
    public int getMay() {
        return may;
    }

    /**
     * @param may
     *            the may to set
     */
    public void setMay(int may) {
        this.may = may;
    }

    /**
     * @param jun
     */
    public int getJun() {
        return jun;
    }

    /**
     * @param jun
     *            the jun to set
     */
    public void setJun(int jun) {
        this.jun = jun;
    }

    /**
     * @param jul
     */
    public int getJul() {
        return jul;
    }

    /**
     * @param jul
     *            the jul to set
     */
    public void setJul(int jul) {
        this.jul = jul;
    }

    /**
     * @param aug
     */
    public int getAug() {
        return aug;
    }

    /**
     * @param aug
     *            the aug to set
     */
    public void setAug(int aug) {
        this.aug = aug;
    }

    /**
     * @param sep
     */
    public int getSep() {
        return sep;
    }

    /**
     * @param sep
     *            the sep to set
     */
    public void setSep(int sep) {
        this.sep = sep;
    }

    /**
     * @param oct
     */
    public int getOct() {
        return oct;
    }

    /**
     * @param oct
     *            the oct to set
     */
    public void setOct(int oct) {
        this.oct = oct;
    }

    /**
     * @param nov
     */
    public int getNov() {
        return nov;
    }

    /**
     * @param nov
     *            the nov to set
     */
    public void setNov(int nov) {
        this.nov = nov;
    }

    /**
     * @param dec
     */
    public int getDec() {
        return dec;
    }

    /**
     * @param dec
     *            the dec to set
     */
    public void setDec(int dec) {
        this.dec = dec;
    }

    /**
     * @param jan
     */
    public int getJan() {
        return jan;
    }

    /**
     * @param jan
     *            the jan to set
     */
    public void setJan(int jan) {
        this.jan = jan;
    }

    /**
     * @param feb
     */
    public int getFeb() {
        return feb;
    }

    /**
     * @param feb
     *            the feb to set
     */
    public void setFeb(int feb) {
        this.feb = feb;
    }

    /**
     * @param mar
     */
    public int getMar() {
        return mar;
    }

    /**
     * @param mar
     *            the mar to set
     */
    public void setMar(int mar) {
        this.mar = mar;
    }

    /**
     * @param aprUpdated
     */
    public Integer getAprUpdated() {
        return aprUpdated;
    }

    /**
     * @param aprUpdated
     *            the aprUpdated to set
     */
    public void setAprUpdated(Integer aprUpdated) {
        this.aprUpdated = aprUpdated;
    }

    /**
     * @param mayUpdated
     */
    public Integer getMayUpdated() {
        return mayUpdated;
    }

    /**
     * @param mayUpdated
     *            the mayUpdated to set
     */
    public void setMayUpdated(Integer mayUpdated) {
        this.mayUpdated = mayUpdated;
    }

    /**
     * @param junUpdated
     */
    public Integer getJunUpdated() {
        return junUpdated;
    }

    /**
     * @param junUpdated
     *            the junUpdated to set
     */
    public void setJunUpdated(Integer junUpdated) {
        this.junUpdated = junUpdated;
    }

    /**
     * @param julUpdated
     */
    public Integer getJulUpdated() {
        return julUpdated;
    }

    /**
     * @param julUpdated
     *            the julUpdated to set
     */
    public void setJulUpdated(Integer julUpdated) {
        this.julUpdated = julUpdated;
    }

    /**
     * @param augUpdated
     */
    public Integer getAugUpdated() {
        return augUpdated;
    }

    /**
     * @param augUpdated
     *            the augUpdated to set
     */
    public void setAugUpdated(Integer augUpdated) {
        this.augUpdated = augUpdated;
    }

    /**
     * @param sepUpdated
     */
    public Integer getSepUpdated() {
        return sepUpdated;
    }

    /**
     * @param sepUpdated
     *            the sepUpdated to set
     */
    public void setSepUpdated(Integer sepUpdated) {
        this.sepUpdated = sepUpdated;
    }

    /**
     * @param octUpdated
     */
    public Integer getOctUpdated() {
        return octUpdated;
    }

    /**
     * @param octUpdated
     *            the octUpdated to set
     */
    public void setOctUpdated(Integer octUpdated) {
        this.octUpdated = octUpdated;
    }

    /**
     * @param novUpdated
     */
    public Integer getNovUpdated() {
        return novUpdated;
    }

    /**
     * @param novUpdated
     *            the novUpdated to set
     */
    public void setNovUpdated(Integer novUpdated) {
        this.novUpdated = novUpdated;
    }

    /**
     * @param decUpdated
     */
    public Integer getDecUpdated() {
        return decUpdated;
    }

    /**
     * @param decUpdated
     *            the decUpdated to set
     */
    public void setDecUpdated(Integer decUpdated) {
        this.decUpdated = decUpdated;
    }

    /**
     * @param janUpdated
     */
    public Integer getJanUpdated() {
        return janUpdated;
    }

    /**
     * @param janUpdated
     *            the janUpdated to set
     */
    public void setJanUpdated(Integer janUpdated) {
        this.janUpdated = janUpdated;
    }

    /**
     * @param febUpdated
     */
    public Integer getFebUpdated() {
        return febUpdated;
    }

    /**
     * @param febUpdated
     *            the febUpdated to set
     */
    public void setFebUpdated(Integer febUpdated) {
        this.febUpdated = febUpdated;
    }

    /**
     * @param marUpdated
     */
    public Integer getMarUpdated() {
        return marUpdated;
    }

    /**
     * @param marUpdated
     *            the marUpdated to set
     */
    public void setMarUpdated(Integer marUpdated) {
        this.marUpdated = marUpdated;
    }

    /**
     * @param dateUpdated
     */
    public String getDateUpdated() {
        return dateUpdated;
    }

    /**
     * @param dateUpdated
     *            the dateUpdated to set
     */
    public void setDateUpdated(String dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    /**
     * @param dateCreated
     */
    public String getDateCreated() {
        return dateCreated;
    }

    /**
     * @param dateCreated
     *            the dateCreated to set
     */
    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    /**
     * @param dateApproved
     */
    public String getDateApproved() {
        return dateApproved;
    }

    /**
     * @param dateApproved
     *            the dateApproved to set
     */
    public void setDateApproved(String dateApproved) {
        this.dateApproved = dateApproved;
    }

    /**
     * @param status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }
}
