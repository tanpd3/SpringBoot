package jp.meportal.isv.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "license_use_info")
public class LicenseUseInfor implements Serializable {
    private static final long serialVersionUID = -8767337896773261247L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "`seq_no`")
    private int seqNo;

    @ManyToOne
    @JoinColumn(name = "`ipaddress_id`", nullable = false)
    private IpAddressInfo ipaddressId;

    @ManyToOne
    @JoinColumn(name = "`catalog_id`", nullable = false)
    private CatalogInfor catalogId;

    @Column(name = "`year`")
    private int year;

    @Column(name = "`month`")
    private int month;

    @Column(name = "`account`")
    private String account;

    @Column(name = "`host`")
    private String host;

    @Column(name = "`run_time_all`")
    private int runTimeAll;

    @Column(name = "`run_time_without_few`")
    private int runTimeWithoutFew;

    @Column(name = "`run_number_all`")
    private int runNumberAll;

    @Column(name = "`run_number_without_few`")
    private int runNumberWithoutFew;

    @Column(name = "`same_time_use_number`")
    private int sameTimeUseNumber;

    @Column(name = "`is_charge`")
    private int isCharge;

    public int getSeqNo() {
        return seqNo;
    }

    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    public IpAddressInfo getIpaddressId() {
        return ipaddressId;
    }

    public void setIpaddressId(IpAddressInfo ipaddressId) {
        this.ipaddressId = ipaddressId;
    }

    public CatalogInfor getCatalogId() {
        return catalogId;
    }

    public void setCatalogId(CatalogInfor catalogId) {
        this.catalogId = catalogId;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getRunTimeAll() {
        return runTimeAll;
    }

    public void setRunTimeAll(int runTimeAll) {
        this.runTimeAll = runTimeAll;
    }
	
	// #22604 T.Obara@tsr 2017.09.13 メソッド名の大文字小文字変更(without→Without)
    public int getRunTimewithoutFew() {
        return runTimeWithoutFew;
    }
	
	// #22604 T.Obara@tsr 2017.09.13 メソッド名の大文字小文字変更(without→Without)
    public void setRunTimewithoutFew(int runTimeWithoutFew) {
        this.runTimeWithoutFew = runTimeWithoutFew;
    }

    public int getRunNumberAll() {
        return runNumberAll;
    }

    // #22604 T.Obara@tsr 2017.09.13 メソッド名変更(setRun_number_all→setRunNumberAll)
    public void setRunNumberAll(int runNumberAll) {
        this.runNumberAll = runNumberAll;
    }

    public int getRunNumberWithoutFew() {
        return runNumberWithoutFew;
    }

    public void setRunNumberWithoutFew(int runNumberWithoutFew) {
        this.runNumberWithoutFew = runNumberWithoutFew;
    }

    public int getSameTimeUseNumber() {
        return sameTimeUseNumber;
    }

    public void setSameTimeUseNumber(int sameTimeUseNumber) {
        this.sameTimeUseNumber = sameTimeUseNumber;
    }

    public int getIsCharge() {
        return isCharge;
    }

    public void setIsCharge(int isCharge) {
        this.isCharge = isCharge;
    }
}
