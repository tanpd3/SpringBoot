package jp.meportal.isv.entity;

import java.io.Serializable;
import java.util.List;

public class DepartmentEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String companyCode = null;
    private String companyName = null;
    private List<DepartmentMasterEntity> department = null;

    /**
     * @param companyCode
     */
    public String getCompanyCode() {
        return companyCode;
    }

    /**
     * @param companyCode
     *            the companyCode to set
     */
    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    /**
     * @param companyName
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * @param companyName
     *            the companyName to set
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    /**
     * @param department
     */
    public List<DepartmentMasterEntity> getDepartment() {
        return department;
    }

    /**
     * @param department
     *            the department to set
     */
    public void setDepartment(List<DepartmentMasterEntity> department) {
        this.department = department;
    }
}
