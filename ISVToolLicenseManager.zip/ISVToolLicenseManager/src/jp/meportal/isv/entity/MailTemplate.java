package jp.meportal.isv.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mail_template")
public class MailTemplate implements Serializable {
    private static final long serialVersionUID = -8767337896773261247L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "seq_no")
    private int seqNo;

    @Column(name = "label")
    private String label;
    
    @Column(name = "title")
    private String title;
    
    @Column(name = "contents")
    private String contents;
    
    @Column(name = "footer")
    private String footer;
    
    @Column(name = "to")
    private String to;

    /**
     * @param seqNo
     */
    public int getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo
     *            the seqNo to set
     */
    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @param label
     */
    public String getLabel() {
        return label;
    }

    /**
     * @param label
     *            the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * @param title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title
     *            the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @param contents
     */
    public String getContents() {
        return contents;
    }

    /**
     * @param contents
     *            the contents to set
     */
    public void setContents(String contents) {
        this.contents = contents;
    }

    /**
     * @param footer
     */
    public String getFooter() {
        return footer;
    }

    /**
     * @param footer
     *            the footer to set
     */
    public void setFooter(String footer) {
        this.footer = footer;
    }

    /**
     * @param to
     */
    public String getTo() {
        return to;
    }

    /**
     * @param to
     *            the to to set
     */
    public void setTo(String to) {
        this.to = to;
    }
}
