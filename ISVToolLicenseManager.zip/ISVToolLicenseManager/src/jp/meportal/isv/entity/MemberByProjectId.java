package jp.meportal.isv.entity;

public class MemberByProjectId {
    private String projectName;
    private String managerName;
    private String email;
    private String updateDate;

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param managerName
     */
    public String getManagerName() {
        return managerName;
    }

    /**
     * @param managerName
     *            the managerName to set
     */
    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    /**
     * @param email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email
     *            the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @param updateDate
     */
    public String getUpdateDate() {
        return updateDate;
    }

    /**
     * @param updateDate
     *            the updateDate to set
     */
    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * MemberByProjectId
     * @param projectName
     *            the projectName to set
     * @param managerName
     *            the managerName to set
     * @param email
     *            the email to set
     * @param updateDate
     *            the updateDate to set
     */
    public MemberByProjectId(String projectName, String managerName, String email, String updateDate) {
        super();
        this.projectName = projectName;
        this.managerName = managerName;
        this.email = email;
        this.updateDate = updateDate;
    }

    public MemberByProjectId() {
        super();
    }

    /**
     * MemberByProjectId
     * @param projectName
     *            the projectName to set
     * @param managerName
     *            the managerName to set
     * @param email
     *            the email to set
     * @param updateDate
     *            the updateDate to set
     */
    @Override
    public String toString() {
        return "MemberByProjectId [projectName=" + projectName + ", managerName=" + managerName + ", email=" + email
                + ", updateDate=" + updateDate + "]";
    }
}
