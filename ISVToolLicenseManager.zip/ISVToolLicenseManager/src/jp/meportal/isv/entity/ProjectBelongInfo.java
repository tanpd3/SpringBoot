package jp.meportal.isv.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "project_belong_info")
public class ProjectBelongInfo implements Serializable {
    private static final long serialVersionUID = 118849151170461073L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "seq_no")
    private int seqNo;

    @ManyToOne
    @JoinColumn(name = "project_id", nullable = false)
    private Project project_id;

    @ManyToOne
    @JoinColumn(name = "member", nullable = false)
    private Member member;

    @Column(name = "registration_date")
    private String registrationDate;

    @Column(name = "update_date")
    private String updateDate;

    @Column(name = "status")
    private int status;

    @Column(name = "isManager")
    private int isManager;

    @Transient
    private Long numberMember;

    /**
     * @param registrationDate
     */
    public String getRegistrationDate() {
        return registrationDate;
    }

    /**
     * @param registrationDate
     *            the registrationDate to set
     */
    public void setRegistrationDate(String registrationDate) {
        this.registrationDate = registrationDate;
    }

    /**
     * @param updateDate
     */
    public String getUpdateDate() {
        return updateDate;
    }

    /**
     * @param updateDate
     *            the updateDate to set
     */
    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * @param status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @param project_id
     */
    public Project getProject_id() {
        return project_id;
    }

    /**
     * @param project_id
     *            the project_id to set
     */
    public void setProject_id(Project project_id) {
        this.project_id = project_id;
    }

    /**
     * @param member
     */
    public Member getMember() {
        return member;
    }

    /**
     * @param member
     *            the member to set
     */
    public void setMember(Member member) {
        this.member = member;
    }

    /**
     * @param seqNo
     */
    public int getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo
     *            the seqNo to set
     */
    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @param isManager
     */
    public int getIsManager() {
        return isManager;
    }

    /**
     * @param isManager
     *            the isManager to set
     */
    public void setIsManager(int isManager) {
        this.isManager = isManager;
    }

    /**
     * @param numberMember
     */
    public Long getNumberMember() {
        return numberMember;
    }

    /**
     * @param numberMember
     *            the numberMember to set
     */
    public void setNumberMember(Long numberMember) {
        this.numberMember = numberMember;
    }
}
