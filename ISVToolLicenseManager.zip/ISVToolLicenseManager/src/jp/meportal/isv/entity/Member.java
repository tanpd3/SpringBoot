package jp.meportal.isv.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Proxy;

@Entity
@Table(name = "project_member_info")
@Proxy(lazy = false)
public class Member implements Serializable {
    private static final long serialVersionUID = -8767337896773261247L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "seq_no")
    private int seqNo;

    @Column(name = "email")
    private String email;

    @Column(name = "link")
    private String link;
    
    @Column(name = "isManager")
    private String isManager;

    @Transient
    private String memberName;
    @Transient
    private String departmentName;

    @Transient
    private String registrationDate;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "member")
    @Fetch(FetchMode.SELECT)
    private List<ProjectBelongInfo> projectBelongInfoList;

    @Transient
    private String projectName;

    @Transient
    private String managerName;

    /**
     * @param email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email
     *            the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @param projectBelongInfoList
     */
    public List<ProjectBelongInfo> getProjectBelongInfoList() {
        return projectBelongInfoList;
    }

    /**
     * @param projectBelongInfoList
     *            the projectBelongInfoList to set
     */
    public void setProjectBelongInfoList(List<ProjectBelongInfo> projectBelongInfoList) {
        this.projectBelongInfoList = projectBelongInfoList;
    }

    /**
     * @param seqNo
     */
    public int getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo
     *            the seqNo to set
     */
    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @param link
     */
    public String getLink() {
        return link;
    }

    /**
     * @param link
     *            the link to set
     */
    public void setLink(String link) {
        this.link = link;
    }

    /**
     * @param isManager
     */
    public String getIsManager() {
        return isManager;
    }

    /**
     * @param isManager
     *            the isManager to set
     */
    public void setIsManager(String isManager) {
        this.isManager = isManager;
    }

    /**
     * @param memberName
     */
    public String getMemberName() {
        return memberName;
    }

    /**
     * @param memberName
     *            the memberName to set
     */
    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    /**
     * @param departmentName
     */
    public String getDepartmentName() {
        return departmentName;
    }

    /**
     * @param departmentName
     *            the departmentName to set
     */
    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    /**
     * @param registrationDate
     */
    public String getRegistrationDate() {
        return registrationDate;
    }

    /**
     * @param registrationDate
     *            the registrationDate to set
     */
    public void setRegistrationDate(String registrationDate) {
        this.registrationDate = registrationDate;
    }

    /**
     * @param projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * @param managerName
     */
    public String getManagerName() {
        return managerName;
    }

    /**
     * @param managerName
     *            the managerName to set
     */
    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }
}
