package jp.meportal.isv.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.hibernate.annotations.Proxy;

@Entity
@Table(name = "ipaddress_info")
@Proxy(lazy = false)
public class IpAddressInfo implements Serializable {
    private static final long serialVersionUID = -8767337896773261247L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "seq_no")
    private int seqNo;

    @ManyToOne
    @JoinColumn(name = "project_id", nullable = false)
    private Project projectId;
    
    @Column(name = "ipaddress")
    private String ipaddress;
    
    @Column(name = "ipaddress_1")
    private String ipaddressOne;
    
    @Column(name = "ipaddress_2")
    private String ipaddressTwo;
    
    @Column(name = "status")
    private int status;
    
    @Column(name = "date_updated")
    private String dateUpdated;

    @Transient
    private int resultStart;

    @Transient
    private int resultEnd;
    
    @Transient
    private int countStt;

    /**
     * @param seqNo
     */
    public int getSeqNo() {
        return seqNo;
    }

    /**
     * @param seqNo
     *            the seqNo to set
     */
    public void setSeqNo(int seqNo) {
        this.seqNo = seqNo;
    }

    /**
     * @param projectId
     */
    public Project getProjectId() {
        return projectId;
    }

    /**
     * @param projectId
     *            the projectId to set
     */
    public void setProjectId(Project projectId) {
        this.projectId = projectId;
    }

    /**
     * @param ipaddress
     */
    public String getIpaddress() {
        return ipaddress;
    }

    /**
     * @param ipaddress
     *            the ipaddress to set
     */
    public void setIpaddress(String ipaddress) {
        this.ipaddress = ipaddress;
    }

    /**
     * @param ipaddressOne
     */
    public String getIpaddressOne() {
        return ipaddressOne;
    }

    /**
     * @param ipaddressOne
     *            the ipaddressOne to set
     */
    public void setIpaddressOne(String ipaddressOne) {
        this.ipaddressOne = ipaddressOne;
    }

    /**
     * @param ipaddressTwo
     */
    public String getIpaddressTwo() {
        return ipaddressTwo;
    }

    /**
     * @param ipaddressTwo
     *            the ipaddressTwo to set
     */
    public void setIpaddressTwo(String ipaddressTwo) {
        this.ipaddressTwo = ipaddressTwo;
    }

    /**
     * @param status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @param dateUpdated
     */
    public String getDateUpdated() {
        return dateUpdated;
    }

    /**
     * @param dateUpdated
     *            the dateUpdated to set
     */
    public void setDateUpdated(String dateUpdated) {
        this.dateUpdated = dateUpdated;
    }

    /**
     * @param resultStart
     */
    public int getResultStart() {
        return resultStart;
    }

    /**
     * @param resultStart
     *            the resultStart to set
     */
    public void setResultStart(int resultStart) {
        this.resultStart = resultStart;
    }

    /**
     * @param resultEnd
     */
    public int getResultEnd() {
        return resultEnd;
    }

    /**
     * @param resultEnd
     *            the resultEnd to set
     */
    public void setResultEnd(int resultEnd) {
        this.resultEnd = resultEnd;
    }

    /**
     * @param countStt
     */
    public int getCountStt() {
        return countStt;
    }

    /**
     * @param countStt
     *            the countStt to set
     */
    public void setCountStt(int countStt) {
        this.countStt = countStt;
    }
}
