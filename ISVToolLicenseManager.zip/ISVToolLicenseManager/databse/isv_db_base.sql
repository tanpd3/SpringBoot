--  Database: isv_db
-- ------------------------------------------------------
DROP DATABASE IF EXISTS isv_db;

--
-- Create Database isv_db
--

CREATE DATABASE isv_db;

USE isv_db;
--
-- Table structure for table `project_info`
--

DROP TABLE IF EXISTS `project_info`;

CREATE TABLE `project_info` (
  `seq_no` int(11) NOT NULL  AUTO_INCREMENT,
  `project_name` varchar(255) NOT NULL,
  `manager_name` varchar(100) NOT NULL,
  `manager_email` varchar(100) NOT NULL,
  `load_origin_code` varchar(255) NOT NULL,
  `cost_code` varchar(10) NOT NULL,
  `other_manager` TEXT DEFAULT NULL,
  `member` TEXT DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `create_dated` date DEFAULT NULL,
  `update_dated` date DEFAULT NULL,
  `product_number` varchar(50) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `approval_dated` date DEFAULT NULL,
  `update` int(11) DEFAULT NULL,
  `approver` int(11) DEFAULT NULL,
  PRIMARY KEY (`seq_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Table structure for table `project_member_info`
--

DROP TABLE IF EXISTS `project_member_info`;

CREATE TABLE `project_member_info` (
  `seq_no` int(11) NOT NULL  AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `link` varchar(255) NOT NULL,
  `isManager` TEXT DEFAULT NULL,
  `status` TEXT DEFAULT NULL,
  PRIMARY KEY (`seq_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `project_belong_info`
--

DROP TABLE IF EXISTS `project_belong_info`;

CREATE TABLE `project_belong_info` (
  `seq_no` int(11) NOT NULL  AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `member` int(11) NOT NULL,
  `registration_date` date NOT NULL,
  `update_date` date NOT NULL,
  `status` tinyint(4) NOT NULL,
  `isManager` tinyint(4) NOT NULL,
  PRIMARY KEY (`seq_no`,`project_id`,`member`),
  KEY `member_FK_idx` (`member`),
  KEY `pro_id_FK_idx` (`project_id`),
  CONSTRAINT `member_FK` FOREIGN KEY (`member`) REFERENCES `project_member_info` (`seq_no`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `pro_id_FK` FOREIGN KEY (`project_id`) REFERENCES `project_info` (`seq_no`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `support`
--

DROP TABLE IF EXISTS `support`;

CREATE TABLE `support` (
  `seq_no` int(11) NOT NULL  AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mailFlag` tinyint(4) NOT NULL,
  PRIMARY KEY (`seq_no`),
  KEY `email_idx` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `catalog_info`
--

DROP TABLE IF EXISTS `catalog_info`;

CREATE TABLE `catalog_info` (
  `seq_no` int(11) NOT NULL  AUTO_INCREMENT,
  `vendor_name` varchar(100) NOT NULL,
  `tool_name` varchar(255) NOT NULL,
  `future_name` varchar(255) NOT NULL,
  `member_price` decimal(12, 2) NOT NULL,
  `regular_price` decimal(12, 2) NOT NULL,
  `keep_number` int(11) NOT NULL,
  `overview` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`seq_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `license_info`
--

DROP TABLE IF EXISTS `license_info`;

CREATE TABLE `license_info` (
  `seq_no` int(11) NOT NULL  AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `catalog_id` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `Apr` tinyint(4) DEFAULT 0 NOT NULL,
  `May` tinyint(4) DEFAULT 0 NOT NULL,
  `Jun` tinyint(4) DEFAULT 0 NOT NULL,
  `Jul` tinyint(4) DEFAULT 0 NOT NULL,
  `Aug` tinyint(4) DEFAULT 0 NOT NULL,
  `Sep` tinyint(4) DEFAULT 0 NOT NULL,
  `Oct` tinyint(4) DEFAULT 0 NOT NULL,
  `Nov` tinyint(4) DEFAULT 0 NOT NULL,
  `Dec` tinyint(4) DEFAULT 0 NOT NULL,
  `Jan` tinyint(4) DEFAULT 0 NOT NULL,
  `Feb` tinyint(4) DEFAULT 0 NOT NULL,
  `Mar` tinyint(4) DEFAULT 0 NOT NULL,
  `Apr_updated` tinyint(4) NOT NULL,
  `May_updated` tinyint(4) NOT NULL,
  `Jun_updated` tinyint(4) NOT NULL,
  `Jul_updated` tinyint(4) NOT NULL,
  `Aug_updated` tinyint(4) NOT NULL,
  `Sep_updated` tinyint(4) NOT NULL,
  `Oct_updated` tinyint(4) NOT NULL,
  `Nov_updated` tinyint(4) NOT NULL,
  `Dec_updated` tinyint(4) NOT NULL,
  `Jan_updated` tinyint(4) NOT NULL,
  `Feb_updated` tinyint(4) NOT NULL,
  `Mar_updated` tinyint(4) NOT NULL,
  `date_request` date DEFAULT now() NOT NULL,
  `date_updated` date NOT NULL,
  `status` int(11) NOT NULL,
  
  PRIMARY KEY (`seq_no`,`project_id`,`catalog_id`),
  KEY `project_id_FK_idx` (`project_id`),
  KEY `catalog_id_FK_idx` (`catalog_id`),
  CONSTRAINT `project_id_FK` FOREIGN KEY (`project_id`) REFERENCES `project_info` (`seq_no`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `catalog_id_FK` FOREIGN KEY (`catalog_id`) REFERENCES `catalog_info` (`seq_no`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Table structure for table `ipaddress_info`
--

DROP TABLE IF EXISTS `ipaddress_info`;

CREATE TABLE `ipaddress_info` (
  `seq_no` int(11) NOT NULL  AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `ipaddress_1` varchar(255) NOT NULL,
  `ipaddress_2` TEXT NOT NULL,
  `status` int(11) NOT NULL,
  `date_updated` DATETIME NOT NULL,
  PRIMARY KEY (`seq_no`,`project_id`),
  KEY `proj_id_FK_idx` (`project_id`),
  CONSTRAINT `proj_id_FK` FOREIGN KEY (`project_id`) REFERENCES `project_info` (`seq_no`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


