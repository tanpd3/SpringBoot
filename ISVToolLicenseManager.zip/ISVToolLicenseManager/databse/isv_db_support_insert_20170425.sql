INSERT INTO `isv_db`.`support` (`name`, `email`, `mailFlag`) VALUES ('高木美紀', 'takagi.miki@jp.fujitsu.com', '1');
INSERT INTO `isv_db`.`support` (`name`, `email`, `mailFlag`) VALUES ('富士通太郎', 'fujitsu.tarou@jp.fujitsu.com', '0');
INSERT INTO `isv_db`.`support` (`name`, `email`, `mailFlag`) VALUES ('富士通花子', 'fujitsu.hanako@jp.fujitsu.com', '0');
INSERT INTO `isv_db`.`support` (`name`, `email`, `mailFlag`) VALUES ('takagi', 'takagi@jp.fujitsu.com', '1');
INSERT INTO `isv_db`.`support` (`name`, `email`, `mailFlag`) VALUES ('ThaiHX1', 'ThaiHX1@fsoft.com.vn', '1');

