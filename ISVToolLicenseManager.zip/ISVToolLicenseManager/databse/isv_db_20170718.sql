-- MySQL dump 10.13  Distrib 5.6.24, for Win32 (x86)
--
-- Host: 10.17.39.88    Database: isv_db
-- ------------------------------------------------------
-- Server version	5.5.42-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--  Database: isv_db
-- ------------------------------------------------------
DROP DATABASE IF EXISTS isv_db;

--
-- Create Database isv_db
--

CREATE DATABASE isv_db;

USE isv_db;
--
-- Table structure for table `catalog_info`
--

DROP TABLE IF EXISTS `catalog_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `catalog_info` (
  `seq_no` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(100) NOT NULL,
  `tool_name` varchar(100) NOT NULL,
  `future_name` varchar(100) DEFAULT NULL,
  `member_price` decimal(13,4) DEFAULT NULL,
  `regular_price` decimal(13,4) NOT NULL,
  `keep_number` int(11) NOT NULL,
  `overview` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `ipaddress_server_name` int(11) DEFAULT NULL,
  `ipaddress_file_path` text,
  `result_server_name` int(11) DEFAULT NULL,
  `result_file_path` text,
  PRIMARY KEY (`seq_no`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ipaddress_info`
--

DROP TABLE IF EXISTS `ipaddress_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipaddress_info` (
  `seq_no` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `ipaddress` varchar(50) NOT NULL,
  `ipaddress_1` varchar(12) NOT NULL,
  `ipaddress_2` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_updated` date NOT NULL,
  PRIMARY KEY (`seq_no`),
  KEY `FKD0664C0BAF57F13` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `license_info`
--

DROP TABLE IF EXISTS `license_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `license_info` (
  `seq_no` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `catalog_id` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `Apr` int(11) NOT NULL DEFAULT '0',
  `May` int(11) NOT NULL DEFAULT '0',
  `Jun` int(11) NOT NULL DEFAULT '0',
  `Jul` int(11) NOT NULL DEFAULT '0',
  `Aug` int(11) NOT NULL DEFAULT '0',
  `Sep` int(11) NOT NULL DEFAULT '0',
  `Oct` int(11) NOT NULL DEFAULT '0',
  `Nov` int(11) NOT NULL DEFAULT '0',
  `Dec` int(11) NOT NULL DEFAULT '0',
  `Jan` int(11) NOT NULL DEFAULT '0',
  `Feb` int(11) NOT NULL DEFAULT '0',
  `Mar` int(11) NOT NULL DEFAULT '0',
  `Apr_updated` int(11) DEFAULT NULL,
  `May_updated` int(11) DEFAULT NULL,
  `Jun_updated` int(11) DEFAULT NULL,
  `Jul_updated` int(11) DEFAULT NULL,
  `Aug_updated` int(11) DEFAULT NULL,
  `Sep_updated` int(11) DEFAULT NULL,
  `Oct_updated` int(11) DEFAULT NULL,
  `Nov_updated` int(11) DEFAULT NULL,
  `Dec_updated` int(11) DEFAULT NULL,
  `Jan_updated` int(11) DEFAULT NULL,
  `Feb_updated` int(11) DEFAULT NULL,
  `Mar_updated` int(11) DEFAULT NULL,
  `update_dated` date DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `approval_dated` date DEFAULT NULL,
  PRIMARY KEY (`seq_no`),
  KEY `FK601919ECE9A6FB93` (`catalog_id`),
  KEY `FK601919ECBAF57F13` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `project_belong_info`
--

DROP TABLE IF EXISTS `project_belong_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_belong_info` (
  `seq_no` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `member` int(11) NOT NULL,
  `registration_date` date DEFAULT NULL,
  `update_date` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `isManager` int(11) DEFAULT NULL,
  PRIMARY KEY (`seq_no`),
  KEY `FK653DF88BAF57F13` (`project_id`),
  KEY `FK653DF8826D6221B` (`member`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `project_info`
--

DROP TABLE IF EXISTS `project_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_info` (
  `seq_no` int(11) NOT NULL AUTO_INCREMENT,
  `project_name` varchar(255) DEFAULT NULL,
  `manager_email` varchar(100) DEFAULT NULL,
  `load_origin_code` varchar(100) DEFAULT NULL,
  `cost_code` varchar(50) DEFAULT NULL,
  `other_manager` text,
  `member` text,
  `status` tinyint(1) DEFAULT NULL,
  `Comment` varchar(255) DEFAULT NULL,
  `create_dated` date DEFAULT NULL,
  `update_dated` date DEFAULT NULL,
  `product_number` varchar(100) DEFAULT NULL,
  `approval_dated` date DEFAULT NULL,
  `update` int(11) DEFAULT NULL,
  `approver` int(11) DEFAULT NULL,
  `manager_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`seq_no`),
  KEY `fk_update_idx` (`update`),
  KEY `fk_approver_idx` (`approver`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `project_member_info`
--

DROP TABLE IF EXISTS `project_member_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_member_info` (
  `seq_no` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) DEFAULT NULL,
  `Link` text,
  `isManager` text,
  PRIMARY KEY (`seq_no`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `server_info`
--

DROP TABLE IF EXISTS `server_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_info` (
  `seq_no` int(11) NOT NULL AUTO_INCREMENT,
  `server_name` varchar(16) NOT NULL,
  `port` int(11) NOT NULL,
  `account` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`seq_no`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `support`
--

DROP TABLE IF EXISTS `support`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support` (
  `seq_no` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mailFlag` tinyint(4) NOT NULL,
  PRIMARY KEY (`seq_no`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-18  9:17:13
