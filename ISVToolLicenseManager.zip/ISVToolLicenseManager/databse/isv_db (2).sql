USE isv_db;
--
-- Table structure for table `mail_template`
--

DROP TABLE IF EXISTS `mail_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail_template` (
  `seq_no` int(11) NOT NULL AUTO_INCREMENT,
  `label` text NOT NULL,
  `title` text NOT NULL,
  `contents` text NOT NULL,
  `footer` text NOT NULL,
  `to` text NOT NULL,
  PRIMARY KEY (`seq_no`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;